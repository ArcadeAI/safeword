import { createHash, randomUUID } from 'node:crypto';
import { existsSync, mkdirSync, readFileSync, realpathSync, writeFileSync } from 'node:fs';
import nodePath from 'node:path';
import process from 'node:process';

import {
  afterAll,
  beforeAll,
  describe,
  expect as hookExpect,
  it,
  type TestContext,
  vi,
} from 'vitest';

import {
  createExecutionPlanDeliveryDefinition,
  normalizedExecutionPlanDigest,
  parseDeliveryPlanContract,
} from '../../src/execution-plan/delivery-checklist.js';
import type { ReviewAgent, ReviewerOutput, ReviewPacket } from '../../src/review/contract.js';
import {
  EXECUTION_PLAN_CONFORMANCE_CASES,
  type ExecutionPlanConformanceCase,
  executionPlanConformanceDigests,
  type ExecutionPlanConformanceResult,
} from '../../src/review/execution-plan-conformance.js';
import {
  reviewTimeoutMilliseconds,
  runHeadlessReviewerWithProvenance,
} from '../../src/review/runtime.js';
import {
  type ExecutionObservation,
  readExecutionCheckpoint,
  writeExecutionCheckpoint,
} from '../fixtures/execution-plan-live-checkpoint.js';
import {
  EXECUTION_PLAN_SLICING_CASES,
  type SlicingAcceptanceCase,
} from '../fixtures/execution-plan-slicing-cases.js';
import { liveReviewerEnvironment } from '../fixtures/live-reviewer-profile.js';
import {
  createTemporaryDirectory,
  removeTemporaryDirectory,
  runCliWithLiteralArguments,
} from '../helpers.js';

const ACCEPTANCE_CASES = process.env.SAFEWORD_EXECUTION_PLAN_ACCEPTANCE === '1';
const cases = ACCEPTANCE_CASES ? EXECUTION_PLAN_SLICING_CASES : EXECUTION_PLAN_CONFORMANCE_CASES;

const PUBLIC_CLI = process.env.SAFEWORD_EXECUTION_PLAN_LIVE_CLI === '1';
const CAN_RUN = process.env.SAFEWORD_RUN_EXECUTION_PLAN_LIVE === '1';
if (CAN_RUN && ACCEPTANCE_CASES && !PUBLIC_CLI) {
  throw new Error('Semantic acceptance requires SAFEWORD_EXECUTION_PLAN_LIVE_CLI=1');
}
const REVIEW_TIMEOUT_MS = reviewTimeoutMilliseconds({ SAFEWORD_REVIEW_WORKER: '1' });
const LIVE_TEST_TIMEOUT_MS = REVIEW_TIMEOUT_MS + 60_000;
const reviewer = process.env.SAFEWORD_EXECUTION_PLAN_LIVE_REVIEWER as ReviewAgent | undefined;
const model = process.env.SAFEWORD_EXECUTION_PLAN_LIVE_MODEL?.trim() || undefined;
const resultsPath = process.env.SAFEWORD_EXECUTION_PLAN_RESULTS_PATH;
const replayPath = process.env.SAFEWORD_EXECUTION_PLAN_REPLAY_PATH;
const retainedPath = process.env.SAFEWORD_EXECUTION_PLAN_RETAINED_RESULTS_PATH;
if (CAN_RUN && replayPath !== undefined && retainedPath !== undefined) {
  throw new Error('Saved observation reuse cannot combine replay and retained inputs');
}
if (CAN_RUN && resultsPath !== undefined && retainedPath !== undefined) {
  const canonical = (path: string) =>
    existsSync(path) ? realpathSync(path) : nodePath.resolve(path);
  const carriers = (path: string) =>
    [path, `${path}.outputs.json`, `${path}.metadata.json`].map(canonical);
  const source = new Set(carriers(retainedPath));
  if (carriers(resultsPath).some(path => source.has(path))) {
    throw new Error('Saved evidence source and destination must be distinct');
  }
}
if (
  CAN_RUN &&
  (replayPath !== undefined || retainedPath !== undefined) &&
  (ACCEPTANCE_CASES || PUBLIC_CLI || model === undefined)
) {
  throw new Error('Saved observation reuse supports exact headless conformance only');
}
const results: ExecutionPlanConformanceResult[] = [];
const outputs: ExecutionObservation[] = [];
type Assertions = TestContext['expect'];
const collectionIdentity = {
  schema_version: 1,
  ...executionPlanConformanceDigests(),
  reviewer,
  requested_model: model,
  corpus_kind: ACCEPTANCE_CASES ? 'acceptance' : 'conformance',
  dispatch_mode: PUBLIC_CLI ? 'cli' : 'headless',
  ...(ACCEPTANCE_CASES && {
    corpus_sha256: createHash('sha256').update(JSON.stringify(cases)).digest('hex'),
  }),
  oracle_sha256: createHash('sha256')
    .update(readFileSync(import.meta.filename))
    .digest('hex'),
};
const retained =
  CAN_RUN && retainedPath !== undefined
    ? readExecutionCheckpoint(
        retainedPath,
        collectionIdentity,
        cases.map(testCase => testCase.id),
      )
    : undefined;
const replay: ExecutionObservation[] =
  CAN_RUN && replayPath !== undefined ? JSON.parse(readFileSync(replayPath, 'utf8')) : [];
if (
  CAN_RUN &&
  replayPath !== undefined &&
  (!Array.isArray(replay) ||
    replay.length === 0 ||
    new Set(replay.map(item => item.case_id)).size !== replay.length ||
    replay.some(item => cases.every(testCase => testCase.id !== item.case_id)))
) {
  throw new Error('Replay requires unique known raw observations');
}
const selectedCases = cases.filter(testCase =>
  replayPath === undefined
    ? !retained?.results.some(result => result.case_id === testCase.id)
    : replay.some(item => item.case_id === testCase.id),
);
const metadata = {
  ...collectionIdentity,
  mode: replayPath === undefined ? 'live' : 'replay',
  current_attempt_timeout_ms: REVIEW_TIMEOUT_MS,
  retained_source: retained?.source,
};

function packetFor(testCase: ExecutionPlanConformanceCase, assigned: ReviewAgent): ReviewPacket {
  const identity =
    model === undefined ? `${assigned} runtime default` : `${assigned} model ${model}`;
  const parsed = parseDeliveryPlanContract(testCase.execution_plan);
  if (!parsed.ok) throw new Error(`Invalid conformance fixture: ${parsed.message}`);
  const definition = createExecutionPlanDeliveryDefinition(parsed, false);
  return {
    schema_version: 1,
    dispatch_id: randomUUID(),
    kind: 'plan-execution',
    logical_files: [{ path: 'execution-plan.md', content: testCase.execution_plan }],
    context_files: [
      { path: 'impl-plan.md', content: testCase.implementation_plan },
      { path: 'scenario.feature', content: testCase.scenario },
      {
        path: 'reviewer-identity.md',
        content: `Assigned reviewer: ${identity}.`,
      },
    ],
    execution_plan_delivery_definition: definition,
    execution_plan_normalized_digest: normalizedExecutionPlanDigest(testCase.execution_plan),
  };
}

async function reviewThroughCli(
  testCase: ExecutionPlanConformanceCase,
  root: string,
  assigned: ReviewAgent,
  expect: Assertions,
): Promise<ReviewerOutput> {
  const relative = '.project/tickets/CASE01-conformance';
  const ticket = nodePath.join(root, relative);
  mkdirSync(ticket, { recursive: true });
  mkdirSync(nodePath.join(root, '.safeword'), { recursive: true });
  const author = assigned === 'claude' ? 'codex' : 'claude';
  writeFileSync(
    nodePath.join(root, '.safeword/config.json'),
    JSON.stringify({
      crossAgentReviewRoutes: { [author]: [{ reviewer: assigned, ...(model && { model }) }] },
    }),
  );
  writeFileSync(nodePath.join(ticket, 'execution-plan.md'), testCase.execution_plan);
  writeFileSync(
    nodePath.join(ticket, 'impl-plan.md'),
    `**Status:** planned\n\n${testCase.implementation_plan}`,
  );
  writeFileSync(nodePath.join(ticket, 'scenario.feature'), testCase.scenario);
  writeFileSync(
    nodePath.join(ticket, 'ticket.md'),
    '---\nid: CASE01\nslug: conformance\ntype: feature\nphase: plan-execution\nscope:\n  - Deliver the accepted obligations in the Implementation Plan.\nout_of_scope:\n  - Change the accepted approach.\ndone_when:\n  - Every accepted obligation has startable reviewed work.\n---\n',
  );
  const options = {
    cwd: root,
    timeout: LIVE_TEST_TIMEOUT_MS,
    env: liveReviewerEnvironment(assigned, author),
  };
  let invoked = await runCliWithLiteralArguments(
    [
      'review',
      'run',
      'plan-execution',
      `${relative}/execution-plan.md`,
      '--context',
      `${relative}/impl-plan.md`,
      '--context',
      `${relative}/scenario.feature`,
      '--context',
      `${relative}/ticket.md`,
      '--cwd',
      root,
      '--json',
      '--no-input',
    ],
    options,
  );
  let envelope = JSON.parse(invoked.stdout);
  if (envelope.findings?.some((finding: { code: string }) => finding.code === 'REVIEW_PENDING')) {
    await vi.waitFor(
      async () => {
        invoked = await runCliWithLiteralArguments(
          ['review', 'status', envelope.data.review_id, '--cwd', root, '--json'],
          options,
        );
        envelope = JSON.parse(invoked.stdout);
        expect(
          Boolean(
            envelope.findings?.some(
              (finding: { code: string }) => finding.code === 'REVIEW_PENDING',
            ),
          ),
        ).toBe(false);
      },
      { timeout: REVIEW_TIMEOUT_MS, interval: 1000 },
    );
  }
  expect(envelope.data?.actual_reviewer, invoked.stdout).toBe(assigned);
  expect(envelope.data?.independence, invoked.stdout).toBe('cross-agent');
  const output = envelope.data?.reviewer_output as ReviewerOutput | undefined;
  if (!output) throw new Error(`Public CLI did not return a reviewer output: ${invoked.stdout}`);
  expect(invoked.exitCode, invoked.stdout).toBe(testCase.expectation.verdict === 'approve' ? 0 : 2);
  expect(readFileSync(nodePath.join(ticket, 'execution-plan.md'), 'utf8')).toBe(
    testCase.execution_plan,
  );
  await assertCliDiscovery(testCase, { root, ticket }, output, options, expect);
  return output;
}

async function assertCliDiscovery(
  testCase: ExecutionPlanConformanceCase,
  paths: { root: string; ticket: string },
  output: ReviewerOutput,
  options: Parameters<typeof runCliWithLiteralArguments>[1],
  expect: Assertions,
): Promise<void> {
  const { root, ticket } = paths;
  if (!testCase.id.includes('discovery')) return;
  if (output.verdict === 'request_changes') {
    const applied = await runCliWithLiteralArguments(
      ['ticket', 'approve-plan', 'CASE01', '--cwd', root, '--json', '--no-input'],
      options,
    );
    const disposition = JSON.parse(applied.stdout);
    expect(disposition.data?.planning_destination, applied.stdout).toBe(
      testCase.expectation.planning_destination,
    );
  }
  expect(readFileSync(nodePath.join(ticket, 'ticket.md'), 'utf8')).toContain(
    `phase: ${testCase.expectation.planning_destination}`,
  );
}

function recordOf(output: ReviewerOutput): NonNullable<ReviewerOutput['execution_plan_record']> {
  const record = output.execution_plan_record;
  if (record === undefined || record === null) throw new Error('Approval omitted its typed record');
  return record;
}

export function assertSlicingRationale(id: string, rationale: string, expect: Assertions): void {
  expect(rationale.trim()).not.toBe('');
  const patterns: Record<string, readonly RegExp[]> = {
    'one-coherent-change': [
      /coher|cohes|insepar|coupl|atomic|single boundary|same (?:boundary|contract|outcome)/iu,
      /review|judg|contract|command|result/iu,
      /split|separat|independen|insepar|indivis/iu,
    ],
    'several-ordered-changes': [
      /contract|schema/iu,
      /activat|rout/iu,
      /independent|separat|depend|order|before/iu,
    ],
  };
  const expectedPatterns = patterns[id] ?? [];
  for (const pattern of expectedPatterns) expect(rationale).toMatch(pattern);
  if (id === 'one-coherent-change') {
    const inseparability = [
      /\b(?:(?:cannot|can't|not|no)\s+(?:[\p{L}-]+\s+){0,4}(?:split|separat|independen)|inseparable|indivisible)/iu,
      /\b(?:splitting|separation)\s+is\s+(?:not possible|impossible)\b/iu,
      /\b(?:must|need to)\s+ship\s+together\b/iu,
    ];
    expect(
      inseparability.some(pattern => pattern.test(rationale)),
      'rationale must explain why separate changes cannot stand alone',
    ).toBe(true);
  }
}

function assertObligationOwners(
  testCase: ExecutionPlanConformanceCase,
  record: ReturnType<typeof recordOf>,
  expect: Assertions,
): void {
  const expectedObligations = testCase.expectation.obligations ?? [];
  for (const obligation of expectedObligations) {
    const prefix = `- ${obligation}: `;
    const ownerLine = testCase.execution_plan.split('\n').find(line => line.startsWith(prefix));
    if (ownerLine === undefined) throw new Error(`Missing expected owner: ${obligation}`);
    expect(record.obligation_owners).toContainEqual({
      obligation,
      slices: [ownerLine.slice(prefix.length)],
    });
  }
}

function assertAcceptanceRecord(
  testCase: ExecutionPlanConformanceCase,
  record: ReturnType<typeof recordOf>,
  expect: Assertions,
): void {
  assertSlicingRationale(testCase.id, record.rationale, expect);
  for (const slice of record.slices) {
    expect(slice.relies_on_unmerged_successor).toBe(false);
    const fields = [slice.purpose, slice.boundary, slice.proof, slice.completion_signal];
    for (const field of fields) expect(field.trim()).not.toBe('');
  }
  if (testCase.id === 'ordered-schema-before-reader') {
    expect(
      record.slices.map(slice => ({ name: slice.name, prerequisites: slice.prerequisites })),
    ).toEqual([
      { name: 'Schema', prerequisites: [] },
      { name: 'Reader', prerequisites: ['Schema'] },
    ]);
  }
  const proofOwners: Record<string, readonly [string, string][]> = {
    'many-mechanical-edits': [['Contract mirrors', 'data-compatibility']],
    'few-files-two-outcomes': [
      ['Inert schema', 'data-compatibility'],
      ['Public activation', 'behavior-boundary'],
    ],
  };
  const expectedProofOwners = proofOwners[testCase.id] ?? [];
  for (const [name, proof] of expectedProofOwners) {
    expect(record.slices.find(slice => slice.name === name)?.proof).toContain(proof);
  }
  assertObligationOwners(testCase, record, expect);
}

function assertApproval(
  testCase: ExecutionPlanConformanceCase,
  output: ReviewerOutput,
  expect: Assertions,
): void {
  expect(output.verdict).toBe('approve');
  const record = recordOf(output);
  expect(record.slicing_decision).toBe(testCase.expectation.slicing_decision);
  expect(record.accepted_scenarios_covered).toBe(true);
  expect(record.accepted_approach_preserved).toBe(true);
  expect(record.slices.map(slice => slice.name)).toEqual(testCase.expectation.slice_names);
  if (ACCEPTANCE_CASES) {
    assertAcceptanceRecord(testCase, record, expect);
  } else {
    // Keep production route qualification independent of the stricter acceptance oracle.
    const obligations = testCase.expectation.obligations ?? [];
    for (const obligation of obligations) {
      expect(record.obligation_owners.map(owner => owner.obligation)).toContain(obligation);
    }
  }
  const expectedDecisions = testCase.expectation.decisions ?? [];
  for (const decision of expectedDecisions) {
    expect(record.decision_statuses).toContainEqual({ decision, status: 'unchanged' });
  }
}

function assertDenial(
  testCase: SlicingAcceptanceCase,
  output: ReviewerOutput,
  expect: Assertions,
): void {
  expect(output.verdict).toBe('request_changes');
  expect(output.execution_plan_record).toBeNull();
  const explanation =
    `${output.summary}\n${output.findings.map(finding => finding.message).join('\n')}`.toLowerCase();
  const expectedTerms = testCase.expectation.finding_terms ?? [];
  for (const term of expectedTerms) {
    expect(explanation).toContain(term.toLowerCase());
  }
  if (testCase.expectation.finding_subject !== undefined) {
    const subject = testCase.expectation.finding_subject.toLowerCase();
    const purposePatterns =
      testCase.id === 'two-independent-purposes'
        ? [/contract|schema/iu, /activat|public.*(?:command|rout)/iu, /separat|split|independen/iu]
        : [];
    expect(
      output.findings.some(finding => {
        const message = finding.message.toLowerCase();
        return (
          message.includes(subject) &&
          expectedTerms.every(term => message.includes(term.toLowerCase())) &&
          purposePatterns.every(pattern => pattern.test(message))
        );
      }),
      `One finding must name the affected slice and its missing field: ${subject}`,
    ).toBe(true);
  }
}

function assertCase(
  testCase: ExecutionPlanConformanceCase,
  output: ReviewerOutput,
  assigned: ReviewAgent,
  dispatchId: string | undefined,
  expect: Assertions,
): void {
  expect(output.reviewer_agent).toBe(assigned);
  // The public CLI owns dispatch binding; direct runtime probes own their packet.
  if (dispatchId !== undefined) expect(output.dispatch_id).toBe(dispatchId);
  expect(output.planning_destination).toBe(testCase.expectation.planning_destination);
  if (testCase.expectation.verdict === 'approve') assertApproval(testCase, output, expect);
  else assertDenial(testCase, output, expect);
}

function useLiveReviewerProfile(assigned: ReviewAgent): void {
  if (PUBLIC_CLI) return;
  const author = assigned === 'claude' ? 'codex' : 'claude';
  const environment = Object.entries(liveReviewerEnvironment(assigned, author));
  for (const [key, value] of environment) vi.stubEnv(key, value);
}

/* eslint-disable unicorn/no-top-level-side-effects -- This live test module exports its oracle for deterministic regression tests. */
beforeAll(() => {
  if (!CAN_RUN || (reviewer !== 'claude' && reviewer !== 'codex')) return;
  if (retained !== undefined) {
    for (const observation of retained.outputs) {
      const testCase = cases.find(candidate => candidate.id === observation.case_id);
      if (testCase === undefined) throw new Error('Unknown retained case');
      assertCase(
        testCase,
        observation.output,
        reviewer,
        // The original dispatch packet is not retained; do not assert an ID against itself.
        undefined,
        hookExpect,
      );
    }
    results.push(...retained.results);
    outputs.push(...retained.outputs);
    checkpoint();
  }
  if (replayPath !== undefined) return;
  if (!PUBLIC_CLI) vi.stubEnv('SAFEWORD_REVIEW_WORKER', '1');
  useLiveReviewerProfile(reviewer);
});
afterAll(() => vi.unstubAllEnvs());

function checkpoint(): void {
  if (resultsPath !== undefined) writeExecutionCheckpoint(resultsPath, results, outputs, metadata);
}

async function observationFor(
  testCase: ExecutionPlanConformanceCase,
  directory: string,
  assigned: ReviewAgent,
  expect: Assertions,
): Promise<{ observation: ExecutionObservation; dispatchId?: string }> {
  if (replayPath !== undefined) {
    const saved = replay.find(item => item.case_id === testCase.id);
    if (saved === undefined) throw new Error('Missing raw replay observation');
    return {
      observation: { ...saved, dispatch_mode: 'replay' },
    };
  }
  if (PUBLIC_CLI)
    return {
      observation: {
        case_id: testCase.id,
        dispatch_mode: 'cli',
        output: await reviewThroughCli(testCase, directory, assigned, expect),
      },
    };
  const packet = packetFor(testCase, assigned);
  const execution = await runHeadlessReviewerWithProvenance(
    assigned,
    packet,
    directory,
    process.cwd(),
    {
      ...(model !== undefined && { model }),
      runDeadline: Date.now() + REVIEW_TIMEOUT_MS,
    },
  );
  return {
    observation: {
      case_id: testCase.id,
      dispatch_mode: 'headless',
      output: execution.output as ReviewerOutput,
      confirmed_model: execution.confirmedModel,
      attempt_timeout_ms: REVIEW_TIMEOUT_MS,
    },
    dispatchId: packet.dispatch_id,
  };
}

describe.skipIf(!CAN_RUN)('live Execution Plan semantic conformance', () => {
  it('requires one explicit reviewer identity and evidence destination', ({ expect }) => {
    expect(['claude', 'codex']).toContain(reviewer);
    expect(resultsPath).toBeTypeOf('string');
    expect(resultsPath).not.toBe('');
  });

  it.for(selectedCases)('$id', { timeout: LIVE_TEST_TIMEOUT_MS }, async (testCase, { expect }) => {
    expect.hasAssertions();
    if (reviewer !== 'claude' && reviewer !== 'codex') {
      throw new Error('SAFEWORD_EXECUTION_PLAN_LIVE_REVIEWER must be claude or codex');
    }
    const directory = createTemporaryDirectory();
    let passed = false;
    try {
      const { observation, dispatchId } = await observationFor(
        testCase,
        directory,
        reviewer,
        expect,
      );
      const output = observation.output;
      outputs.push(observation);
      try {
        assertCase(testCase, output, reviewer, dispatchId, expect);
      } catch (error) {
        process.stderr.write(
          `Execution Plan reviewer output:\n${JSON.stringify(output, undefined, 2)}\n`,
        );
        throw error;
      }
      passed = true;
    } finally {
      results.push({
        case_id: ACCEPTANCE_CASES ? `acceptance:${testCase.id}` : testCase.id,
        reviewer,
        ...(model !== undefined && { model }),
        passed,
      });
      checkpoint();
      removeTemporaryDirectory(directory);
    }
  });
});

/* eslint-enable unicorn/no-top-level-side-effects */
