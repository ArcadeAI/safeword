# Changed test-only guards and their real harness context

Baseline b7f2e9ff1 was reviewed as approved with warnings by cross-agent Claude receipt 84986cd6-6185-4053-b9cd-222369d6f2c0. This delta addresses source/destination alias and sidecar collisions, combined replay/retention input, misleading pairing diagnostics, missing on-disk metadata tests, corpus-order dependence and two valid rationale phrasings. The original paid matrices and expected judgments are unchanged.

Challenge whether the guard prevents overwriting original failed observations, whether tests are discriminating, and whether the lexical checks still make only their disclosed bounded claim. The supplied RED log has 10 intended failures and 20 passes; the GREEN log has 30 passes. The supplied BDD logs include a passing run and deliberate wrong-expectation failure. This is no claim of semantic qualification, original packet-dispatch binding for saved responses, or #5857 recovery. File-level retained provenance and the fixture writer accepting unknown test data remain deliberate limits.

```ts
const ACCEPTANCE_CASES = process.env.SAFEWORD_EXECUTION_PLAN_ACCEPTANCE === '1';
const cases = ACCEPTANCE_CASES ? EXECUTION_PLAN_SLICING_CASES : EXECUTION_PLAN_CONFORMANCE_CASES;

const PUBLIC_CLI = process.env.SAFEWORD_EXECUTION_PLAN_LIVE_CLI === '1';
const CAN_RUN = process.env.SAFEWORD_RUN_EXECUTION_PLAN_LIVE === '1';
if (CAN_RUN && ACCEPTANCE_CASES && !PUBLIC_CLI) {
  throw new Error('Semantic acceptance requires SAFEWORD_EXECUTION_PLAN_LIVE_CLI=1');
}
const REVIEW_TIMEOUT_MS = reviewTimeoutMilliseconds({ SAFEWORD_REVIEW_WORKER: '1' });
const LIVE_TEST_TIMEOUT_MS = REVIEW_TIMEOUT_MS + 60_000;
const reviewer = process.env.SAFEWORD_EXECUTION_PLAN_LIVE_REVIEWER as ReviewAgent | undefined;
const model = process.env.SAFEWORD_EXECUTION_PLAN_LIVE_MODEL?.trim() || undefined;
const resultsPath = process.env.SAFEWORD_EXECUTION_PLAN_RESULTS_PATH;
const replayPath = process.env.SAFEWORD_EXECUTION_PLAN_REPLAY_PATH;
const retainedPath = process.env.SAFEWORD_EXECUTION_PLAN_RETAINED_RESULTS_PATH;
if (CAN_RUN && replayPath !== undefined && retainedPath !== undefined) {
  throw new Error('Saved observation reuse cannot combine replay and retained inputs');
}
if (CAN_RUN && resultsPath !== undefined && retainedPath !== undefined) {
  const canonical = (path: string) =>
    existsSync(path) ? realpathSync(path) : nodePath.resolve(path);
  const carriers = (path: string) =>
    [path, `${path}.outputs.json`, `${path}.metadata.json`].map(canonical);
  const source = new Set(carriers(retainedPath));
  if (carriers(resultsPath).some(path => source.has(path))) {
    throw new Error('Saved evidence source and destination must be distinct');
  }
}
if (
  CAN_RUN &&
  (replayPath !== undefined || retainedPath !== undefined) &&
  (ACCEPTANCE_CASES || PUBLIC_CLI || model === undefined)
) {
  throw new Error('Saved observation reuse supports exact headless conformance only');
}

```

```ts
export function assertSlicingRationale(id: string, rationale: string, expect: Assertions): void {
  expect(rationale.trim()).not.toBe('');
  const patterns: Record<string, readonly RegExp[]> = {
    'one-coherent-change': [
      /coher|cohes|insepar|coupl|atomic|single boundary|same (?:boundary|contract|outcome)/iu,
      /review|judg|contract|command|result/iu,
      /split|separat|independen|insepar|indivis/iu,
    ],
    'several-ordered-changes': [
      /contract|schema/iu,
      /activat|rout/iu,
      /independent|separat|depend|order|before/iu,
    ],
  };
  const expectedPatterns = patterns[id] ?? [];
  for (const pattern of expectedPatterns) expect(rationale).toMatch(pattern);
  if (id === 'one-coherent-change') {
    const inseparability = [
      /\b(?:(?:cannot|can't|not|no)\s+(?:[\p{L}-]+\s+){0,4}(?:split|separat|independen)|inseparable|indivisible)/iu,
      /\b(?:splitting|separation)\s+is\s+(?:not possible|impossible)\b/iu,
      /\b(?:must|need to)\s+ship\s+together\b/iu,
    ];
    expect(
      inseparability.some(pattern => pattern.test(rationale)),
      'rationale must explain why separate changes cannot stand alone',
    ).toBe(true);
  }
}

```

```ts
beforeAll(() => {
  if (!CAN_RUN || (reviewer !== 'claude' && reviewer !== 'codex')) return;
  if (retained !== undefined) {
    for (const observation of retained.outputs) {
      const testCase = cases.find(candidate => candidate.id === observation.case_id);
      if (testCase === undefined) throw new Error('Unknown retained case');
      assertCase(
        testCase,
        observation.output,
        reviewer,
        // The original dispatch packet is not retained; do not assert an ID against itself.
        undefined,
        hookExpect,
      );
    }
    results.push(...retained.results);
    outputs.push(...retained.outputs);
    checkpoint();
  }
  if (replayPath !== undefined) return;
  if (!PUBLIC_CLI) vi.stubEnv('SAFEWORD_REVIEW_WORKER', '1');
  useLiveReviewerProfile(reviewer);
});

```

```ts
import { mkdirSync, mkdtempSync, readFileSync, rmSync, symlinkSync } from 'node:fs';
import { tmpdir } from 'node:os';
import nodePath from 'node:path';

import type * as Vitest from 'vitest';
import { afterEach, expect, it, vi } from 'vitest';

import { EXECUTION_PLAN_CONFORMANCE_CASES } from '../../src/review/execution-plan-conformance.js';
import { writeExecutionCheckpoint } from '../fixtures/execution-plan-live-checkpoint.js';

const harness = vi.hoisted(() => ({ setup: [] as (() => void)[] }));

// Capture the real live harness's setup without registering its paid test bodies.
// Assertions still use Vitest's real expect; no reviewer implementation is invoked.
vi.mock('vitest', async importOriginal => ({
  ...(await importOriginal<typeof Vitest>()),
  beforeAll: (setup: () => void) => {
    harness.setup.push(setup);
  },
  afterAll: () => {},
  describe: { skipIf: () => () => {} },
}));

vi.mock('../../src/review/runtime.js', async importOriginal => ({
  ...(await importOriginal<Record<string, unknown>>()),
  runHeadlessReviewerWithProvenance: () => {
    throw new Error('Paid inference is forbidden in this regression test');
  },
}));

const roots: string[] = [];
afterEach(() => {
  vi.unstubAllEnvs();
  vi.resetModules();
  harness.setup.length = 0;
  for (const root of roots.splice(0)) rmSync(root, { recursive: true, force: true });
});

it.each([false, true])(
  'checks retained output against the current oracle before replacing evidence (matches: %s)',
  async matchesOracle => {
    const root = mkdtempSync(nodePath.join(tmpdir(), 'execution-replay-oracle-'));
    roots.push(root);
    const retained = nodePath.join(root, 'retained.json');
    const destination = nodePath.join(root, 'current.json');
    const testCase = EXECUTION_PLAN_CONFORMANCE_CASES.find(row => row.id === 'generic-checklist');
    if (testCase === undefined) throw new Error('A rejection control is required');
    const { executionPlanConformanceDigests } =
      await import('../../src/review/execution-plan-conformance.js');
    writeExecutionCheckpoint(
      retained,
      [{ case_id: testCase.id, reviewer: 'claude', model: 'claude-opus-5', passed: true }],
      [
        {
          case_id: testCase.id,
          dispatch_mode: 'headless',
          confirmed_model: { provider: 'anthropic', model: 'claude-opus-5' },
          output: {
            schema_version: 1,
            dispatch_id: 'saved',
            reviewer_agent: 'claude',
            verdict: matchesOracle ? 'request_changes' : 'approve',
            summary: `Retained response: ${(testCase.expectation.finding_terms ?? []).join(' ')}`,
            findings: [],
            planning_destination: testCase.expectation.planning_destination,
            // The protocol requires a literal null record for rejected plans.
            // eslint-disable-next-line unicorn/no-null -- rejected reviewer protocol requires null
            execution_plan_record: null,
          },
        },
      ],
      {
        schema_version: 1,
        ...executionPlanConformanceDigests(),
        reviewer: 'claude',
        requested_model: 'claude-opus-5',
        oracle_sha256: 'older-oracle',
      },
    );
    writeExecutionCheckpoint(destination, [], [], { sentinel: 'must not be overwritten' });
    const original = readFileSync(`${destination}.metadata.json`, 'utf8');
    const environment = Object.entries({
      SAFEWORD_RUN_EXECUTION_PLAN_LIVE: '1',
      SAFEWORD_EXECUTION_PLAN_LIVE_REVIEWER: 'claude',
      SAFEWORD_EXECUTION_PLAN_LIVE_MODEL: 'claude-opus-5',
      SAFEWORD_EXECUTION_PLAN_RETAINED_RESULTS_PATH: retained,
      SAFEWORD_EXECUTION_PLAN_RESULTS_PATH: destination,
      SAFEWORD_EXECUTION_PLAN_ACCEPTANCE: '0',
      SAFEWORD_EXECUTION_PLAN_LIVE_CLI: '0',
    });
    for (const [key, value] of environment) vi.stubEnv(key, value);
    vi.stubEnv('SAFEWORD_EXECUTION_PLAN_REPLAY_PATH', undefined);
    await import('../smoke/execution-plan.live.test.js');
    expect(harness.setup).toHaveLength(1);
    if (matchesOracle) {
      harness.setup[0]?.();
      expect(JSON.parse(readFileSync(destination, 'utf8'))).toEqual(
        JSON.parse(readFileSync(retained, 'utf8')),
      );
      expect(
        JSON.parse(readFileSync(`${destination}.metadata.json`, 'utf8')).oracle_sha256,
      ).not.toBe('older-oracle');
    } else {
      expect(harness.setup[0]).toThrow(/approve|request_changes/u);
      expect(readFileSync(`${destination}.metadata.json`, 'utf8')).toBe(original);
    }
  },
);

it.each([
  'A coherent contract can split into independently reviewable results; I would use separate changes.',
  'One coherent review result. No further discussion; split into independent changes.',
])('rejects a one-change rationale that does not justify inseparability: %s', async rationale => {
  vi.stubEnv('SAFEWORD_RUN_EXECUTION_PLAN_LIVE', '0');
  const { assertSlicingRationale } = await import('../smoke/execution-plan.live.test.js');
  expect(() => {
    assertSlicingRationale('one-coherent-change', rationale, expect);
  }).toThrow();
});

it.each([
  'One cohesive contract has a single reviewable result. It cannot be split into independently provable changes.',
  'This cohesive contract yields a reviewable result; splitting is not possible.',
  'The cohesive contract is independently reviewable, but these changes must ship together.',
])('accepts an explicit cohesion and inseparability explanation: %s', async rationale => {
  expect.hasAssertions();
  vi.stubEnv('SAFEWORD_RUN_EXECUTION_PLAN_LIVE', '0');
  const { assertSlicingRationale } = await import('../smoke/execution-plan.live.test.js');
  assertSlicingRationale('one-coherent-change', rationale, expect);
});

it.each(['same', 'normalized alias', 'symlink alias', 'sidecar overlap', 'combined replay'])(
  'refuses saved-evidence reuse that can overwrite or duplicate source observations: %s',
  async kind => {
    const root = mkdtempSync(nodePath.join(tmpdir(), 'execution-source-preservation-'));
    roots.push(root);
    const retained = nodePath.join(root, 'retained.json');
    const alias = nodePath.join(root, 'alias.json');
    mkdirSync(nodePath.join(root, 'unused'));
    symlinkSync(retained, alias);
    const { executionPlanConformanceDigests } =
      await import('../../src/review/execution-plan-conformance.js');
    writeExecutionCheckpoint(
      retained,
      [{ case_id: 'generic-checklist', reviewer: 'claude', model: 'claude-opus-5', passed: false }],
      [
        {
          case_id: 'generic-checklist',
          dispatch_mode: 'headless',
          confirmed_model: { provider: 'anthropic', model: 'claude-opus-5' },
          output: {
            schema_version: 1,
            dispatch_id: 'failed-observation',
            reviewer_agent: 'claude',
            verdict: 'request_changes',
            summary: 'Recorded disagreement about the destination.',
            findings: [],
            planning_destination: 'plan-implementation',
            // eslint-disable-next-line unicorn/no-null -- rejected reviewer protocol requires null
            execution_plan_record: null,
          },
        },
      ],
      {
        schema_version: 1,
        ...executionPlanConformanceDigests(),
        reviewer: 'claude',
        requested_model: 'claude-opus-5',
      },
    );
    const paths = [retained, `${retained}.outputs.json`, `${retained}.metadata.json`];
    const originals = paths.map(path => readFileSync(path, 'utf8'));
    const destination = {
      same: retained,
      'normalized alias': `${root}/unused/../retained.json`,
      'symlink alias': alias,
      'sidecar overlap': `${retained}.outputs.json`,
      'combined replay': nodePath.join(root, 'destination.json'),
    }[kind];
    const environment = Object.entries({
      SAFEWORD_RUN_EXECUTION_PLAN_LIVE: '1',
      SAFEWORD_EXECUTION_PLAN_LIVE_REVIEWER: 'claude',
      SAFEWORD_EXECUTION_PLAN_LIVE_MODEL: 'claude-opus-5',
      SAFEWORD_EXECUTION_PLAN_RETAINED_RESULTS_PATH: retained,
      SAFEWORD_EXECUTION_PLAN_RESULTS_PATH: destination,
      SAFEWORD_EXECUTION_PLAN_ACCEPTANCE: '0',
      SAFEWORD_EXECUTION_PLAN_LIVE_CLI: '0',
    });
    for (const [key, value] of environment) vi.stubEnv(key, value);
    vi.stubEnv(
      'SAFEWORD_EXECUTION_PLAN_REPLAY_PATH',
      kind === 'combined replay' ? `${retained}.outputs.json` : undefined,
    );
    await expect(async () => {
      await import('../smoke/execution-plan.live.test.js');
      harness.setup[0]?.();
    }).rejects.toThrow(
      kind === 'combined replay'
        ? 'cannot combine replay and retained'
        : 'source and destination must be distinct',
    );
    expect(paths.map(path => readFileSync(path, 'utf8'))).toEqual(originals);
  },
);

```
