import { readFileSync } from 'node:fs';
import { createHash } from 'node:crypto';
import { executionPlanConformanceDigests, EXECUTION_PLAN_CONFORMANCE_CASES } from '../../packages/cli/src/review/execution-plan-conformance.ts';
import { readExecutionCheckpoint } from '../../packages/cli/tests/fixtures/execution-plan-live-checkpoint.ts';
const path = process.argv[2] ?? '/tmp/5139-green-qualified-claude.json';
const metadata = JSON.parse(readFileSync(`${path}.metadata.json`, 'utf8'));
const expected = { schema_version: 1, ...executionPlanConformanceDigests(), reviewer: 'claude', requested_model: 'claude-opus-5' };
const verified = readExecutionCheckpoint(path, expected, EXECUTION_PLAN_CONFORMANCE_CASES.map(c => c.id));
const sha256 = (bytes: Buffer) => createHash('sha256').update(bytes).digest('hex');
if (metadata.mode !== 'live' || metadata.oracle_sha256 !== sha256(readFileSync('packages/cli/tests/smoke/execution-plan.live.test.ts'))) throw new Error('Current live oracle provenance mismatch');
if (verified.results.length !== EXECUTION_PLAN_CONFORMANCE_CASES.length || verified.results.some(r => !r.passed)) throw new Error('Incomplete matrix');
const source = process.argv[3] ?? '.project/tmp/5139-claude-remaining.json';
const sourceVerified = readExecutionCheckpoint(source, expected, EXECUTION_PLAN_CONFORMANCE_CASES.map(c => c.id));
if (sourceVerified.results.length !== 62) throw new Error('Expected 62 retained current-identity passes');
for (const observation of sourceVerified.outputs) {
  const merged = verified.outputs.find(item => item.case_id === observation.case_id);
  if (JSON.stringify(merged) !== JSON.stringify(observation)) throw new Error('Retained raw observation changed in merged checkpoint');
}
for (const [key, suffix] of [['results_sha256', ''], ['outputs_sha256', '.outputs.json'], ['metadata_sha256', '.metadata.json']]) {
  if (metadata.retained_source[key] !== sha256(readFileSync(`${source}${suffix}`))) throw new Error(`Retained source mismatch: ${key}`);
}
const retained = JSON.parse(readFileSync(source, 'utf8'));
const retainedIds = new Set(retained.map(r => r.case_id));
const fresh = verified.results.filter(r => !retainedIds.has(r.case_id)).map(r => r.case_id);
if (retained.length !== 62 || fresh.length !== 1 || fresh[0] !== 'one-coherent-change') throw new Error('Unexpected paid collection boundary');
console.log(JSON.stringify({ verified: true, identity: expected, passed_cases: verified.results.length, confirmed_observations: verified.outputs.length, reused_cases: retained.length, retained_identity_checked: true, retained_raw_observations_unchanged: true, fresh_cases: fresh, source: verified.source }, null, 2));
