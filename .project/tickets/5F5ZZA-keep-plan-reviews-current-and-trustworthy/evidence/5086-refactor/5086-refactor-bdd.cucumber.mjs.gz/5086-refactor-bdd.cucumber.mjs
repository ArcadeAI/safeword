import base from '/Users/alex/.codex/worktrees/e24e/safeword/packages/cli/cucumber.mjs';
export default {
 ...base,
 paths: ['features/review-with-the-best-available-agent.feature', 'features/clarify-review-coverage.feature'],
};
