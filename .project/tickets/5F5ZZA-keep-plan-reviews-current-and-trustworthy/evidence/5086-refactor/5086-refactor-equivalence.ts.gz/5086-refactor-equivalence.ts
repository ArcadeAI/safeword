import { scoreCapabilityRun as before } from './5086-before-capability-eval.ts';
import { scoreCapabilityRun as after } from '/Users/alex/.codex/worktrees/e24e/safeword/packages/cli/src/review/capability-eval.ts';
const groupCases = [undefined, [], [[]], [['']], [[' ']], [['!!!']], [['test']], [['test'], ['receipt']], [['test', 'approval'], ['receipt']]];
const messages = ['', 'latest attest', 'test', 'testing receipt', 'TEST\nreceipt', 'approval-receipt', '! test receipt', 'approval', 'test', 'unicode café receipt'];
let checked=0;
for (const finding_groups of groupCases) for (const message of messages) for (const severity of ['error','warning','info'] as const) for (const verdict of ['approve','request_changes','invalid'] as const) for (const split of [false,true]) {
 const fixture={id:'x',verdict:'request_changes' as const,required:[],forbidden:[],finding_groups};
 const run={fixture_id:'x',run:1,verdict,findings:[{severity,message},...(split?[{severity:'error' as const,message:'receipt'}]:[])]};
 if(before(fixture,run)!==after(fixture,run)) throw Error(JSON.stringify({fixture,run}));
 checked++;
}
console.log(`${checked} before/after boundary comparisons equal`);
