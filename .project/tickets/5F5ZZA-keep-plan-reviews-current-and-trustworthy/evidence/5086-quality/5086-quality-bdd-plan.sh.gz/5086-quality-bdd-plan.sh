(
  safeword_plan_status=0
  ( cd '/Users/alex/.codex/worktrees/e24e/safeword' && bun run test:bdd ) || { safeword_lane_status=$?; [ "$safeword_plan_status" -ne 0 ] || safeword_plan_status=$safeword_lane_status; }
  exit "$safeword_plan_status"
)
