import { readFileSync, writeFileSync, mkdirSync, mkdtempSync, unlinkSync } from 'node:fs';
import { tmpdir } from 'node:os';
import path from 'node:path';
const root = process.cwd();
const relative = 'packages/cli/architecture.generated.md';
const before = readFileSync(path.join(root, relative), 'utf8');
writeFileSync('/tmp/5041-architecture-before-reconcile.md', before);
const purpose = 'Defines shared planning authority clauses, typed phase contracts, generated author identities, and installed author-copy integrity checks.';
if (before.split('No description yet — awaiting prose.').length !== 2) throw new Error('Expected exactly the new planning placeholder');
const reviewed = before.replace('No description yet — awaiting prose.', purpose);
const proseRoot = mkdtempSync(path.join(tmpdir(), '5041-reviewed-architecture-'));
mkdirSync(path.dirname(path.join(proseRoot, relative)), { recursive: true });
writeFileSync(path.join(proseRoot, relative), reviewed);
const { selfHealProjectPreservingProse } = await import(path.join(root, 'packages/cli/src/utils/architecture-document.ts'));
// Rebuild machine-owned structure and stamps from the live skeleton; retain reviewed human prose.
unlinkSync(path.join(root, relative));
console.log(JSON.stringify(selfHealProjectPreservingProse(root, proseRoot)));
const after = readFileSync(path.join(root, relative), 'utf8');
if (!after.includes(purpose) || after.includes('⚠ stale') || after.includes('No description yet')) throw new Error('Reconciliation is incomplete');
