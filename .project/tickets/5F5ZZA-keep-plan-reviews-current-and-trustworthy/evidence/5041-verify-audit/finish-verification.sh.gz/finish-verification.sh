verification_finish_status=0
run_closing_stage() {
  stage_name="$1"
  shift
  "$@" > "/tmp/5041-closing-$stage_name.log" 2>&1
  stage_status=$?
  printf '%s\t%s\n' "$stage_name" "$stage_status" >> /tmp/5041-closing-status.tsv
  if [ "$stage_status" -ne 0 ] && [ "$verification_finish_status" -eq 0 ]; then verification_finish_status="$stage_status"; fi
}
run_closing_stage collector scripts/dev bun run --cwd packages/retro-collector test
run_closing_stage cli scripts/dev bun run --cwd packages/cli test
run_closing_stage go-test scripts/dev bash -c 'cd experiments/go-skill-directive/checker && go test ./...'
run_closing_stage remaining scripts/dev bash /tmp/5041-verify-remaining.sh
exit "$verification_finish_status"
