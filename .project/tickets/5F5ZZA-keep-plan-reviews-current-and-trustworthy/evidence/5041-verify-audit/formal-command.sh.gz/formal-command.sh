PROJECT_DIR="$(
  top=$(git rev-parse --show-toplevel 2> /dev/null)
  if [ -f "$top/.safeword/SAFEWORD.md" ]; then echo "$top"; else echo "${CLAUDE_PROJECT_DIR:-${top:-$PWD}}"; fi
)"
cd "$PROJECT_DIR" || exit 1

# Local evidence preflight: many repo tests create throwaway git repos. Some
# agent sandboxes cannot initialize repos in temp dirs, which makes those tests
# fail for environment reasons instead of product reasons.
LOCAL_EVIDENCE_LIMITS=""
if GIT_PROBE_DIR="$(mktemp -d 2> /dev/null)" && git init "$GIT_PROBE_DIR" > /dev/null 2>&1; then
  find "$GIT_PROBE_DIR" -depth -delete
else
  LOCAL_EVIDENCE_LIMITS="${LOCAL_EVIDENCE_LIMITS}
- Temporary git repos: local environment cannot run git init in temp dirs. Treat git-backed test failures as local environment limitations until reproduced outside the sandbox or in CI."
  [ -d "${GIT_PROBE_DIR:-}" ] && find "$GIT_PROBE_DIR" -depth -delete
fi
if [ -n "$LOCAL_EVIDENCE_LIMITS" ]; then
  printf '%s\n' "Local evidence limits detected:${LOCAL_EVIDENCE_LIMITS}"
fi

# Resolve a test-plan-capable safeword CLI — prefer the locally installed one
# only if it actually supports test-plan.
supports_test_plan() {
  case "$CANDIDATE" in
    node_modules/.bin/safeword) node_modules/.bin/safeword project test-plan --help > /dev/null 2>&1 ;;
    "bun packages/cli/src/cli.ts") bun packages/cli/src/cli.ts project test-plan --help > /dev/null 2>&1 ;;
    "bunx safeword") bunx safeword project test-plan --help > /dev/null 2>&1 ;;
  esac
}

run_safeword() {
  case "$SW" in
    node_modules/.bin/safeword) node_modules/.bin/safeword "$@" ;;
    "bun packages/cli/src/cli.ts") bun packages/cli/src/cli.ts "$@" ;;
    "bunx safeword") bunx safeword "$@" ;;
  esac
}

# >>> run_plan (behavior covered by verify-skill.test.ts #487)
# Capture the plan, then check the generator's exit status BEFORE running it.
# `bash -c "$(...)"` discards the substitution's exit code, so a failed
# generator that prints nothing would leave `bash -c ""` — a false green (#487).
# Reads $plan_kind from the caller, not a bash positional parameter: in a
# command file Claude Code rewrites slash-command argument tokens before bash
# runs, so a positional would be clobbered. Plain assignment (never
# `local x=$(...)`, which masks `$?`); this block runs without `set -e`, so the
# explicit check is load-bearing. A successful empty plan stays a clean no-op
# (`bash -c ""` → exit 0).
run_plan() {
  plan="$(run_safeword project test-plan --kind "$plan_kind" --format sh)"
  rc=$?
  if [ "$rc" -ne 0 ]; then
    echo "❌ Evidence generation failed: safeword project test-plan --kind $plan_kind exited $rc (red, not a passed check)" >&2
    return "$rc"
  fi
  bash -c "$plan"
}
# <<< run_plan

CANDIDATE="node_modules/.bin/safeword"
if [ -x node_modules/.bin/safeword ] && supports_test_plan; then
  SW="node_modules/.bin/safeword"
elif CANDIDATE="bun packages/cli/src/cli.ts" && [ -f packages/cli/src/cli.ts ] && supports_test_plan; then
  SW="bun packages/cli/src/cli.ts"
elif CANDIDATE="bunx safeword" && supports_test_plan; then
  SW="bunx safeword"
else
  echo "No test-plan-capable safeword CLI found. Tried node_modules/.bin/safeword, packages/cli/src/cli.ts, and bunx safeword." >&2
  exit 1
fi

# >>> verification_lanes (behavior covered by verify-skill.test.ts)
# Run every lane for complete evidence, but preserve the first non-zero status
# so a later successful lane cannot turn the aggregate invocation green.
verification_status=0
record_verification_status() {
  if [ "$lane_status" -ne 0 ] && [ "$verification_status" -eq 0 ]; then
    verification_status="$lane_status"
  fi
}

# --- Test suite (resolved by safeword project test-plan — one source of truth) ---
plan_kind=verify
run_plan
lane_status=$?
record_verification_status

# --- Gherkin acceptance lane (resolved by safeword project test-plan --kind bdd:
#     cucumber-js, behave, … — godog/cucumber-rs fold into the Go/Rust test lanes).
#     Mirrors run_plan's generator exit-code check (#487) so a failed generator is
#     not read as an empty (skipped) lane. ---
bdd_plan="$(run_safeword project test-plan --kind bdd --format sh)"
rc=$?
if [ "$rc" -ne 0 ]; then
  echo "❌ Evidence generation failed: safeword project test-plan --kind bdd exited $rc (red, not a passed check)" >&2
  lane_status=$rc
  record_verification_status
elif [ -z "$bdd_plan" ]; then
  echo "Gherkin acceptance lane: ⏭️ Skipped — no acceptance lane detected"
else
  bash -c "$bdd_plan"
  lane_status=$?
  record_verification_status
fi

# --- Build check (resolved by safeword project test-plan) ---
plan_kind=build
run_plan
lane_status=$?
record_verification_status

# --- Typecheck: static type-check where the stack has one — `tsc --noEmit` for
#     TypeScript (the same signal CI's lint job runs, #436), mypy/pyright for
#     Python when configured, and `cargo clippy -- -D warnings` (the strict
#     lint-gate that subsumes `cargo check`) for Rust. A green targeted-test run
#     is NOT readiness if types are broken. Go is absent by design — its compiler
#     is the type checker, already covered by build. An empty plan is a silent
#     no-op; when the ticket touched TypeScript, run `$safeword:lint` (which runs tsc) so
#     it isn't a gap. ---
plan_kind=typecheck
run_plan
lane_status=$?
record_verification_status

# --- Supply-chain: JavaScript's package-manager audit, Python's `uv audit` or
#     `pip-audit`, Go's pinned `govulncheck`, and Rust's cargo-deny advisories.
#     A missing scanner prints a visible failure, never a false green. ---
plan_kind=deps
run_plan
lane_status=$?
record_verification_status

exit "$verification_status"
# <<< verification_lanes
