# R6 authenticated route-denial diagnostics

The installed phase-exit hook correctly discarded unwitnessed ledger stamps but
lost the authenticated receipt's rejection reason. It reported a generic missing
stamp even for a blocked review or an approval of the wrong review kind. Preserve
the existing verifier verdict through an optional callback and surface it only
when no satisfying phase stamp exists. An older rejected stamp must never defeat
a later valid approval. No approval policy, receipt authentication, route
selection, or exception is added.

Two accepted root examples (170 and 172) use actual installed Cursor hooks,
configuration, coordinator, authenticated job store, public status, stamp writer,
and ticket approval. Only the reviewer producer process is mocked. Both first
earn a valid approval and prove native phase admission; then forge only the
plaintext ledger locator to reference a real blocked job or genuine approval of
quality-review instead of plan-implementation. The gate must deny, identify the
same review and specific rejection, preserve ticket phase, and the writer must
refuse without changing the ledger. This is simulated-host evidence, not a live
host walkthrough. 'Ungated surface' is exercised as wrong review kind; it does
not establish a separate host-origin attestation field.

Initial fixture failures confused the generic Codex invocation and public plan
approval with native phase admission. Corrected real RED passed all setup steps
and failed both actor-visible message assertions. Independent executable RED
69a96a26-fa03-44be-8ead-94226e9ea227 approved that failure. Its invocation mistakenly
names a nonexistent ledger path; use it as executed functional RED evidence,
not as an eligible ledger checkbox transition. The final assertions additionally
require exact review ID and blocked status, addressing its loose-regex warning.

GREEN: 2 scenarios / 114 steps; broadened sequential controls: 10 scenarios /
570 steps. Receipt wiring and hook controls: 74 passing tests. All three package
typechecks pass. A concurrent control run initially had two infrastructure
failures while the Vitest build rewrote dist; the sequential rerun passes. That
failed run remains retained and is not counted as evidence.

Generated surfaces regenerated with the repository generator. Cursor lifecycle
tree hashes change with installed hook bytes; result_sha256 remains unchanged.
ESLint ignores template hooks by repository policy, so its exit zero with two
ignored-file warnings is not claimed as lint coverage. Template TypeScript and
runtime tests provide verification. Full normal verification will be recorded
separately; do not alter this review context after dispatch.

These two cases do not complete the whole typed-route outline or epic. Remaining
unbound scenarios, historical full-acceptance failures, deferred OpenCode/cloud,
and user-deferred retrieval proof remain visible. Changes to the shared When
fixture invalidate older review receipts that fingerprinted that supporting
file; do not represent them as current.
