Current PR5 complete unique-source review 16/19. Base 854a376861bc034d65cc81ddfa6a85d0ae55821e; head b722f9a27a1815abcfb08e6f6ca09dc7317efa46. Review actual correctness, authenticated approval, rejection findings and test discrimination. Every unique production source, template, test, step and generator changed in PR5 is supplied across these packets. Byte-identical installed mirrors and compiled bundles are omitted; all five generated surfaces passed at this head. Prior historical acceptance failures remain visible; full current run is in progress. Exactly 33 cases are user-deferred and unverified. This is source review, not native-host or merge approval. Flag only concrete in-scope defects; optional hardening does not block.

diff --git a/steps/keep-plan-reviews-independence.steps.ts b/steps/keep-plan-reviews-independence.steps.ts
new file mode 100644
index 000000000..deae84385
--- /dev/null
+++ b/steps/keep-plan-reviews-independence.steps.ts
@@ -0,0 +1,664 @@
+import { strict as assert } from 'node:assert';
+import { spawnSync } from 'node:child_process';
+import { existsSync, readFileSync, rmSync, writeFileSync } from 'node:fs';
+import path from 'node:path';
+
+import { After, Given, Then, When } from '@cucumber/cucumber';
+
+import { installedReviewCli } from '../packages/cli/tests/fixtures/execution-review.js';
+import { reviewerScript } from '../packages/cli/tests/fixtures/planning-reviewers.js';
+import {
+  cleanupTrustedReviewerDirectories,
+  createTrustedReviewerDirectory,
+} from '../packages/cli/tests/review-fixtures.js';
+import { fixtureProject } from './keep-plan-reviews-installed-context.steps.js';
+import { evaluateInstalledPhaseGate } from './keep-plan-reviews-stale-gates.steps.js';
+import type { SafewordWorld } from './world.js';
+
+const folder = '.project/tickets/CTX123-current-context';
+interface IndependentState {
+  root: string;
+  marker: string;
+  fallbackMarker?: string;
+  sameProcessReviewer?: 'claude' | 'codex';
+  env: Record<string, string>;
+  result?: {
+    data: {
+      status: string;
+      independence: string;
+      actual_reviewer: string;
+      review_id: string;
+      review_routes: {
+        reviewer: string;
+        model?: string;
+        independence: string;
+        status: string;
+        failure?: string;
+      }[];
+      continuation?: { tier: string; packet: { dispatch_id: string } };
+      continuation_attempts?: { tier: string; failure: string }[];
+    };
+    findings: { code: string; message: string }[];
+    errors: unknown[];
+  };
+  gate?: { exitCode: number; stdout: string; stderr: string };
+  evaluateGate?: () => Promise<{ exitCode: number; stdout: string; stderr: string }>;
+}
+const states = new WeakMap<SafewordWorld, IndependentState>();
+
+export async function prepare(world: SafewordWorld, verifiedAuthor: boolean) {
+  const bun = spawnSync('bun', ['-e', 'process.stdout.write(process.execPath)'], {
+    encoding: 'utf8',
+  });
+  assert.equal(bun.status, 0, bun.stderr);
+  const root = fixtureProject();
+  const reviewer = createTrustedReviewerDirectory('safeword-r6-independent-');
+  const marker = path.join(reviewer, 'invoked');
+  const state: IndependentState = {
+    root,
+    marker,
+    env: {
+      NODE_ENV: 'test',
+      PATH: `${reviewer}:${path.dirname(bun.stdout)}:${path.dirname(process.execPath)}:/usr/bin:/bin`,
+      SAFEWORD_AGENT_RUNTIME: 'claude',
+      CLAUDE_SESSION_ID: `r6-independent-${path.basename(root)}`,
+      CLAUDE_PROJECT_DIR: root,
+      CLAUDE_PLUGIN_ROOT: path.resolve(import.meta.dirname, '../plugin'),
+      PLUGIN_ROOT: path.resolve(import.meta.dirname, '../packages/cli/codex-plugin'),
+      SAFEWORD_AUTHOR_MODEL: verifiedAuthor ? 'claude-opus-5' : '',
+      SAFEWORD_REVIEW_KEY_ROOT: path.join(root, '.review-keys'),
+      XDG_STATE_HOME: path.join(root, '.review-keys'),
+      SAFEWORD_NO_UPDATE_CHECK: '1',
+    },
+  };
+  states.set(world, state);
+  const installed = await installedReviewCli(root)(
+    ['install', '--agents', 'cursor', '--offline', '--no-input', '--json', '--cwd', root],
+    { cwd: root, env: { NODE_ENV: 'test' } },
+  );
+  assert.equal(installed.exitCode, 0, installed.stdout);
+  const configPath = path.join(root, '.safeword/config.json');
+  const config = JSON.parse(readFileSync(configPath, 'utf8'));
+  writeFileSync(
+    configPath,
+    JSON.stringify({
+      ...config,
+      crossAgentReviewRoutes: { claude: [{ reviewer: 'codex', model: 'gpt-6.1-sol' }] },
+    }),
+  );
+  writeFileSync(
+    path.join(reviewer, 'codex'),
+    reviewerScript('codex', marker, path.join(reviewer, 'packet.json'), false, true),
+    { mode: 0o755 },
+  );
+  return state;
+}
+
+export async function coordinate(
+  state: IndependentState,
+  reviewer: 'codex' | 'claude' = 'codex',
+  status: 'approved' | 'changes_requested' | 'continuation_required' | 'blocked' = 'approved',
+) {
+  const result = await installedReviewCli(state.root)(
+    [
+      'review',
+      'run',
+      'plan-implementation',
+      `${folder}/impl-plan.md`,
+      '--context',
+      'features/current-context.feature',
+      '--context',
+      `${folder}/spec.md`,
+      '--json',
+      '--no-input',
+      '--cwd',
+      state.root,
+    ],
+    { cwd: state.root, env: state.env },
+  );
+  assert.equal(result.exitCode, status === 'approved' ? 0 : 2, result.stdout);
+  state.result = JSON.parse(result.stdout);
+  assert.ok(state.result);
+  if (status !== 'blocked') assert.deepEqual(state.result.errors, []);
+  assert.equal(state.result.data.status, status);
+  if (status === 'approved' || status === 'changes_requested')
+    assert.equal(state.result.data.actual_reviewer, reviewer);
+  assert.ok(existsSync(state.marker), 'The real coordinator must invoke the reviewer process');
+}
+
+function recordApproval(state: IndependentState) {
+  assert.ok(state.result);
+  const stamped = spawnSync(
+    'bun',
+    [
+      path.join(state.root, '.safeword/hooks/write-review-stamp.ts'),
+      '--ticket',
+      path.basename(folder),
+      '--phase',
+      'plan-implementation',
+      '--review-id',
+      state.result.data.review_id,
+      '--author-agent',
+      'claude',
+      '--reviewer-agent',
+      state.result.data.actual_reviewer,
+      '--independence',
+      state.result.data.independence,
+    ],
+    {
+      cwd: state.root,
+      env: { ...process.env, ...state.env },
+      encoding: 'utf8',
+      timeout: 60_000,
+    },
+  );
+  assert.equal(stamped.status, 0, stamped.stdout + stamped.stderr);
+}
+
+Given(
+  /^an approval is returned by (a different agent in a separate process using a model at least as capable as the author|a different agent when the author model cannot be verified)$/,
+  { timeout: 120_000 },
+  async function (this: SafewordWorld, identity: string) {
+    await prepare(this, identity.includes('at least as capable'));
+  },
+);
+
+When(
+  'the coordinator classifies its independence',
+  { timeout: 120_000 },
+  async function (this: SafewordWorld) {
+    const state = states.get(this);
+    assert.ok(state);
+    if (state.result === undefined) await coordinate(state);
+    else {
+      const receipt = await installedReviewCli(state.root)(
+        ['review', 'status', state.result.data.review_id, '--json', '--cwd', state.root],
+        { cwd: state.root, env: state.env },
+      );
+      assert.equal(JSON.parse(receipt.stdout).data.status, state.result.data.status);
+      assert.equal(JSON.parse(receipt.stdout).data.independence, state.result.data.independence);
+    }
+  },
+);
+
+Then('cross-agent independence is accepted', function (this: SafewordWorld) {
+  assert.equal(states.get(this)?.result?.data.independence, 'cross-agent');
+});
+
+Then('independent approval is refused', function (this: SafewordWorld) {
+  const state = states.get(this);
+  assert.ok(state?.result);
+  const result = state.result;
+  assert.notEqual(result.data.independence, 'cross-agent');
+  if (state.sameProcessReviewer !== undefined) {
+    assert.ok(result.data.continuation);
+    assert.equal(result.data.continuation.tier, 'self-review');
+    if (state.sameProcessReviewer === 'codex') {
+      assert.equal(result.data.status, 'blocked');
+      assert.equal(result.data.independence, 'none');
+      assert.ok(result.findings.some(finding => finding.code === 'REVIEW_ROUTES_EXHAUSTED'));
+      assert.deepEqual(result.data.continuation_attempts?.at(-1), {
+        tier: 'self-review',
+        failure: 'invalid_output',
+      });
+    } else {
+      assert.equal(result.data.status, 'approved');
+      assert.equal(result.data.independence, 'reduced');
+      assert.ok(
+        result.findings.some(
+          finding =>
+            finding.code === 'REVIEW_INDEPENDENCE_REDUCED' &&
+            finding.message.includes('own context'),
+        ),
+      );
+    }
+  } else {
+    assert.equal(result.data.independence, 'reduced');
+    assert.ok(result.findings.some(finding => finding.code === 'AUTHOR_CAPABILITY_UNKNOWN'));
+  }
+});
+
+Given(
+  'the review coordinator has returned an independent reviewer approval',
+  { timeout: 120_000 },
+  async function (this: SafewordWorld) {
+    const state = await prepare(this, true);
+    await coordinate(state);
+    assert.equal(state.result?.data.independence, 'cross-agent');
+    recordApproval(state);
+  },
+);
+
+Given(
+  /^the review coordinator has returned every configured independent route was attempted and returned a typed failure, then the permitted fallback (approves|declines)$/,
+  { timeout: 120_000 },
+  async function (this: SafewordWorld, verdict: string) {
+    const state = await prepare(this, true);
+    const directory = path.dirname(state.marker);
+    const configPath = path.join(state.root, '.safeword/config.json');
+    const config = JSON.parse(readFileSync(configPath, 'utf8'));
+    writeFileSync(
+      configPath,
+      JSON.stringify({
+        ...config,
+        crossAgentReviewRoutes: {
+          claude: [{ reviewer: 'codex', model: 'gpt-6.1-sol' }, { reviewer: 'claude' }],
+        },
+      }),
+    );
+    state.fallbackMarker = path.join(directory, 'same-agent-invoked');
+    writeFileSync(
+      path.join(directory, 'codex'),
+      reviewerScript('codex', state.marker, path.join(directory, 'codex-packet.json'), true, true),
+      { mode: 0o755 },
+    );
+    const approval = reviewerScript(
+      'claude',
+      state.fallbackMarker,
+      path.join(directory, 'claude-packet.json'),
+      false,
+      false,
+    );
+    const script =
+      verdict === 'approves'
+        ? approval
+        : approval.replace(
+            "verdict: 'approve', summary: 'Review approved.', findings: []",
+            "verdict: 'request_changes', summary: 'Review declined.', findings: [{ severity: 'error', message: 'The current plan requires repair.' }]",
+          );
+    if (verdict === 'declines') assert.notEqual(script, approval);
+    writeFileSync(path.join(directory, 'claude'), script, { mode: 0o755 });
+    await coordinate(state, 'claude', verdict === 'approves' ? 'approved' : 'changes_requested');
+    assert.ok(existsSync(state.fallbackMarker));
+    const independent = state.result?.data.review_routes.filter(
+      route => route.reviewer === 'codex',
+    );
+    assert.ok(independent?.length);
+    assert.ok(
+      independent.every(
+        route => route.status === 'attempted' && route.failure === 'process_failed',
+      ),
+    );
+    assert.equal(state.result?.data.independence, 'reduced');
+    if (verdict === 'approves') recordApproval(state);
+  },
+);
+
+async function hostContinuation(
+  world: SafewordWorld,
+  tier: 'fresh-context' | 'self-review',
+  reviewer: 'claude' | 'codex' = 'claude',
+) {
+  const state = await prepare(world, true);
+  const directory = path.dirname(state.marker);
+  const configPath = path.join(state.root, '.safeword/config.json');
+  const config = JSON.parse(readFileSync(configPath, 'utf8'));
+  writeFileSync(
+    configPath,
+    JSON.stringify({
+      ...config,
+      crossAgentReviewRoutes: {
+        claude: [{ reviewer: 'codex', model: 'gpt-6.1-sol' }, { reviewer: 'claude' }],
+      },
+    }),
+  );
+  state.fallbackMarker = path.join(directory, 'headless-failed');
+  writeFileSync(
+    path.join(directory, 'codex'),
+    reviewerScript('codex', state.marker, path.join(directory, 'codex-packet.json'), true, true),
+    { mode: 0o755 },
+  );
+  const script = reviewerScript(
+    'claude',
+    state.fallbackMarker,
+    path.join(directory, 'claude-packet.json'),
+    false,
+    false,
+  );
+  const failed = script.replace(
+    'function reviewOutput(packet)',
+    'process.exit(7);\nfunction reviewOutput(packet)',
+  );
+  assert.notEqual(failed, script);
+  writeFileSync(path.join(directory, 'claude'), failed, { mode: 0o755 });
+  await coordinate(state, 'claude', 'continuation_required');
+  assert.ok(existsSync(state.fallbackMarker));
+  assert.ok(state.result?.data.review_routes.some(item => item.reviewer === 'codex'));
+  assert.ok(state.result?.data.review_routes.some(item => item.reviewer === 'claude'));
+  assert.ok(
+    state.result?.data.review_routes.every(
+      item => item.status === 'attempted' && item.failure === 'process_failed',
+    ),
+    JSON.stringify(state.result?.data.review_routes),
+  );
+  assert.equal(state.result.data.continuation?.tier, 'fresh-context');
+  assert.ok(state.result.data.continuation);
+  const reviewId = state.result.data.review_id;
+  const dispatchId = state.result.data.continuation.packet.dispatch_id;
+  const cli = installedReviewCli(state.root);
+  if (tier === 'self-review') {
+    const failure = await cli(
+      [
+        'review',
+        'continue',
+        reviewId,
+        '--tier',
+        'fresh-context',
+        '--failure',
+        'process_failed',
+        '--offline',
+        '--json',
+        '--cwd',
+        state.root,
+      ],
+      { cwd: state.root, env: state.env },
+    );
+    assert.equal(failure.exitCode, 2, failure.stdout);
+    state.result = JSON.parse(failure.stdout);
+    assert.ok(state.result);
+    assert.equal(state.result.data.review_id, reviewId);
+    assert.equal(state.result.data.status, 'continuation_required');
+    assert.equal(state.result.data.continuation?.tier, 'self-review');
+    assert.deepEqual(state.result.data.continuation_attempts, [
+      { tier: 'fresh-context', failure: 'process_failed' },
+    ]);
+  }
+  assert.equal(state.result.data.continuation?.packet.dispatch_id, dispatchId);
+  writeFileSync(
+    path.join(state.root, 'host-review.json'),
+    JSON.stringify({
+      schema_version: 1,
+      dispatch_id: dispatchId,
+      reviewer_agent: reviewer,
+      verdict: 'approve',
+      summary: `Approved by host-reported ${tier}.`,
+      findings: [],
+      evidence_records: { schema_version: 1, records: [] },
+    }),
+  );
+  const completed = await cli(
+    [
+      'review',
+      'continue',
+      reviewId,
+      '--tier',
+      tier,
+      '--output',
+      'host-review.json',
+      '--offline',
+      '--json',
+      '--cwd',
+      state.root,
+    ],
+    { cwd: state.root, env: state.env },
+  );
+  assert.equal(completed.exitCode, reviewer === 'claude' ? 0 : 2, completed.stdout);
+  state.result = JSON.parse(completed.stdout);
+  assert.ok(state.result);
+  assert.equal(state.result.data.review_id, reviewId);
+  assert.equal(state.result.data.status, reviewer === 'claude' ? 'approved' : 'blocked');
+  if (reviewer === 'claude') {
+    assert.equal(state.result.data.actual_reviewer, reviewer);
+    assert.equal(state.result.data.independence, 'reduced');
+  }
+  assert.equal(state.result.data.continuation?.tier, tier);
+  assert.ok(state.result.data.continuation);
+  assert.equal(state.result.data.continuation.packet.dispatch_id, dispatchId);
+  if (reviewer === 'claude') recordApproval(state);
+  return state;
+}
+
+Given(
+  /^the review coordinator has returned (every independent route and same-agent headless review returned typed failures, then host-reported fresh-context review approves|every earlier route through host-reported fresh-context review returned typed failures, then bounded self-review approves)$/,
+  { timeout: 120_000 },
+  async function (this: SafewordWorld, route: string) {
+    await hostContinuation(
+      this,
+      route.includes('bounded self-review') ? 'self-review' : 'fresh-context',
+    );
+  },
+);
+
+Given(
+  /^an approval is returned by (a different agent in the same process using a model at least as capable as the author|the authoring agent in the same process)$/,
+  { timeout: 120_000 },
+  async function (this: SafewordWorld, identity: string) {
+    const reviewer = identity.startsWith('a different') ? 'codex' : 'claude';
+    const state = await hostContinuation(this, 'self-review', reviewer);
+    state.sameProcessReviewer = reviewer;
+  },
+);
+
+When('the phase gate evaluates the receipt', async function (this: SafewordWorld) {
+  const state = states.get(this);
+  if (!state) {
+    assert.ok(evaluateInstalledPhaseGate(this), 'A real coordinator receipt must be prepared');
+    return;
+  }
+  assert.ok(state.result);
+  state.gate = state.evaluateGate
+    ? await state.evaluateGate()
+    : await installedReviewCli(state.root)(
+        ['ticket', 'approve-plan', 'CTX123', '--json', '--no-input', '--cwd', state.root],
+        { cwd: state.root, env: state.env },
+      );
+});
+
+async function assertCurrentReceipt(
+  state: IndependentState,
+  expectedStatus: 'approved' | 'changes_requested',
+  reviewer: 'claude' | 'codex',
+  independence: 'cross-agent' | 'reduced',
+) {
+  assert.ok(state.result);
+  const status = await installedReviewCli(state.root)(
+    ['review', 'status', state.result.data.review_id, '--json', '--cwd', state.root],
+    { cwd: state.root, env: state.env },
+  );
+  assert.equal(status.exitCode, expectedStatus === 'approved' ? 0 : 2, status.stdout);
+  const receipt = JSON.parse(status.stdout).data;
+  assert.equal(receipt.review_id, state.result.data.review_id);
+  assert.equal(receipt.status, expectedStatus);
+  assert.equal(receipt.independence, independence);
+  assert.equal(receipt.actual_reviewer, reviewer);
+}
+
+Then(
+  'the review passes with cross-agent independence recorded',
+  async function (this: SafewordWorld) {
+    const state = states.get(this);
+    assert.ok(state?.gate && state.result);
+    assert.equal(state.gate.exitCode, 0, state.gate.stdout);
+    assert.equal(state.result.data.independence, 'cross-agent');
+    const rows = readFileSync(path.join(state.root, '.project/skill-invocations.log'), 'utf8')
+      .trim()
+      .split('\n');
+    const stamp = rows.find(row => row.endsWith(`review-id:${state.result?.data.review_id}`));
+    assert.ok(stamp, 'The real writer must persist this authenticated review ID');
+    assert.match(stamp, /author:claude reviewer:codex independence:cross-agent/u);
+    await assertCurrentReceipt(state, 'approved', 'codex', 'cross-agent');
+    assert.match(
+      readFileSync(path.join(state.root, folder, 'ticket.md'), 'utf8'),
+      /phase: plan-execution/u,
+    );
+  },
+);
+
+Then(
+  /^the review passes with reduced independence and (actual reviewer recorded without calling the capability degraded|the host-reported fresh-context reviewer recorded|the bounded self-reviewer recorded)$/,
+  async function (this: SafewordWorld, label: string) {
+    const state = states.get(this);
+    assert.ok(state?.gate && state.result);
+    if (label.includes('fresh-context') || label.includes('self-reviewer')) {
+      const tier = label.includes('fresh-context') ? 'fresh-context' : 'self-review';
+      assert.equal(state.result.data.continuation?.tier, tier);
+      assert.ok(
+        state.result.findings.some(
+          item =>
+            item.code === 'REVIEW_INDEPENDENCE_REDUCED' &&
+            item.message.includes(tier === 'fresh-context' ? 'fresh context' : 'own context'),
+        ),
+      );
+    }
+    assert.equal(state.gate.exitCode, 0, state.gate.stdout);
+    const stamp = readFileSync(path.join(state.root, '.project/skill-invocations.log'), 'utf8')
+      .trim()
+      .split('\n')
+      .find(row => row.endsWith(`review-id:${state.result?.data.review_id}`));
+    assert.ok(stamp);
+    assert.match(stamp, /author:claude reviewer:claude independence:reduced/u);
+    await assertCurrentReceipt(state, 'approved', 'claude', 'reduced');
+    assert.ok(
+      !state.result.findings.some(finding => finding.code === 'REVIEW_INDEPENDENCE_DEGRADED'),
+    );
+    assert.ok(!state.gate.stdout.includes('REVIEW_INDEPENDENCE_DEGRADED'));
+    assert.match(
+      readFileSync(path.join(state.root, folder, 'ticket.md'), 'utf8'),
+      /phase: plan-execution/u,
+    );
+  },
+);
+
+Given(
+  'the review coordinator has returned an unrecognized or unparseable reviewer result',
+  { timeout: 120_000 },
+  async function (this: SafewordWorld) {
+    const state = await prepare(this, true);
+    await coordinate(state);
+    recordApproval(state);
+    const approvedId = state.result?.data.review_id;
+    assert.ok(approvedId);
+    const cli = installedReviewCli(state.root);
+    const approved = await cli(
+      ['ticket', 'approve-plan', 'CTX123', '--json', '--no-input', '--cwd', state.root],
+      { cwd: state.root, env: state.env },
+    );
+    assert.equal(approved.exitCode, 0, approved.stdout);
+    const ticket = path.join(state.root, folder, 'ticket.md');
+    const advanced = readFileSync(ticket, 'utf8');
+    assert.match(advanced, /phase: plan-execution/u);
+    writeFileSync(ticket, advanced.replace('phase: plan-execution', 'phase: plan-implementation'));
+    const plan = path.join(state.root, folder, 'impl-plan.md');
+    writeFileSync(
+      plan,
+      `${readFileSync(plan, 'utf8')}\n<!-- current input for malformed-output proof -->\n`,
+    );
+    const superseded = await cli(['review', 'status', approvedId, '--json', '--cwd', state.root], {
+      cwd: state.root,
+      env: state.env,
+    });
+    assert.equal(JSON.parse(superseded.stdout).data.status, 'stale', superseded.stdout);
+    const configPath = path.join(state.root, '.safeword/config.json');
+    writeFileSync(
+      configPath,
+      JSON.stringify({
+        ...JSON.parse(readFileSync(configPath, 'utf8')),
+        crossAgentReview: 'require',
+      }),
+    );
+    const directory = path.dirname(state.marker);
+    const valid = reviewerScript(
+      'codex',
+      state.marker,
+      path.join(directory, 'packet.json'),
+      false,
+      true,
+    );
+    const malformed = valid
+      .replace(
+        'schema_version: 1, dispatch_id: packet.dispatch_id',
+        'schema_version: 0, dispatch_id: packet.dispatch_id',
+      )
+      .replace(
+        'findings: []',
+        "findings: [{ severity: 'error', message: 'Malformed producer finding must not escape.' }]",
+      );
+    assert.notEqual(malformed, valid);
+    rmSync(state.marker);
+    rmSync(path.join(directory, 'packet.json'));
+    writeFileSync(path.join(directory, 'codex'), malformed, { mode: 0o755 });
+    await coordinate(state, 'codex', 'blocked');
+    assert.deepEqual(state.result?.data.review_routes, [
+      {
+        reviewer: 'codex',
+        model: 'gpt-6.1-sol',
+        independence: 'cross-agent',
+        status: 'attempted',
+        failure: 'invalid_output',
+      },
+    ]);
+    assert.equal(state.result?.data.independence, 'none');
+    assert.ok(state.result && !('reviewer_output' in state.result.data));
+  },
+);
+
+Then('the phase remains blocked with no approval recorded', async function (this: SafewordWorld) {
+  const state = states.get(this);
+  assert.ok(state?.gate && state.result);
+  assert.equal(state.gate.exitCode, 2, state.gate.stdout);
+  if (state.result.data.status === 'changes_requested') {
+    assert.match(state.gate.stdout, /The current plan requires repair\./u);
+    await assertCurrentReceipt(state, 'changes_requested', 'claude', 'reduced');
+  } else {
+    assert.equal(state.result.data.status, 'blocked');
+    assert.equal(state.result.data.review_routes[0]?.failure, 'invalid_output');
+    const current = await installedReviewCli(state.root)(
+      ['review', 'status', state.result.data.review_id, '--json', '--cwd', state.root],
+      { cwd: state.root, env: state.env },
+    );
+    const receipt = JSON.parse(current.stdout).data;
+    assert.equal(receipt.review_id, state.result.data.review_id);
+    assert.equal(receipt.status, 'blocked', current.stdout);
+    assert.equal(receipt.independence, 'none');
+    assert.ok(!('reviewer_output' in receipt));
+    const ledgerPath = path.join(state.root, '.project/skill-invocations.log');
+    const ledgerBefore = readFileSync(ledgerPath, 'utf8');
+    const stamped = spawnSync(
+      'bun',
+      [
+        path.join(state.root, '.safeword/hooks/write-review-stamp.ts'),
+        '--ticket',
+        path.basename(folder),
+        '--phase',
+        'plan-implementation',
+        '--review-id',
+        receipt.review_id,
+        '--author-agent',
+        'claude',
+        '--reviewer-agent',
+        'codex',
+        '--independence',
+        'cross-agent',
+      ],
+      { cwd: state.root, env: { ...process.env, ...state.env }, encoding: 'utf8', timeout: 60_000 },
+    );
+    assert.equal(stamped.status, 1, stamped.stdout + stamped.stderr);
+    assert.match(stamped.stdout + stamped.stderr, /did not approve \(status: blocked\)/u);
+    assert.equal(readFileSync(ledgerPath, 'utf8'), ledgerBefore);
+    assert.ok(
+      !JSON.parse(state.gate.stdout).findings.some(
+        (finding: { code: string }) =>
+          finding.code === 'REVIEWER_FINDING' || finding.code === 'REVIEWER_SUMMARY',
+      ),
+      'An unrecognized result must not be rendered as reviewer findings',
+    );
+  }
+  assert.match(
+    readFileSync(path.join(state.root, folder, 'ticket.md'), 'utf8'),
+    /phase: plan-implementation/u,
+  );
+  const ledger = path.join(state.root, '.project/skill-invocations.log');
+  assert.ok(
+    !existsSync(ledger) ||
+      !readFileSync(ledger, 'utf8').includes(`review-id:${state.result.data.review_id}`),
+  );
+});
+
+After(function (this: SafewordWorld) {
+  const state = states.get(this);
+  if (state) {
+    rmSync(state.root, { recursive: true, force: true });
+    cleanupTrustedReviewerDirectories();
+  }
+  states.delete(this);
+});
diff --git a/steps/keep-plan-reviews-installed-context.steps.ts b/steps/keep-plan-reviews-installed-context.steps.ts
new file mode 100644
index 000000000..83e2b6804
--- /dev/null
+++ b/steps/keep-plan-reviews-installed-context.steps.ts
@@ -0,0 +1,663 @@
+import { strict as assert } from 'node:assert';
+import { spawnSync } from 'node:child_process';
+import { createHash } from 'node:crypto';
+import {
+  cpSync,
+  existsSync,
+  mkdirSync,
+  mkdtempSync,
+  readFileSync,
+  rmSync,
+  writeFileSync,
+} from 'node:fs';
+import { tmpdir } from 'node:os';
+import path from 'node:path';
+
+import { After, Given, Then, When } from '@cucumber/cucumber';
+
+import { SAFEWORD_SCHEMA } from '../packages/cli/src/schema.js';
+import { parsePlanningContract } from '../packages/cli/src/planning/phase-contract.js';
+import { extractPlanReviewRubric } from '../packages/cli/src/review/plan-rubric.js';
+import { writePlanningInventories } from '../packages/cli/tests/planning-fixtures.js';
+import {
+  createTrustedReviewerDirectory,
+  REVIEWER_CAPABILITIES,
+} from '../packages/cli/tests/review-fixtures.js';
+import type { SafewordWorld } from './world.js';
+
+const packageRoot = path.resolve(import.meta.dirname, '../packages/cli');
+const pluginRoot = path.resolve(import.meta.dirname, '../plugin');
+const ticketFolder = 'CTX123-current-context';
+const ticketRoot = `.project/tickets/${ticketFolder}`;
+
+interface InstalledContextState {
+  root: string;
+  reviewer: string;
+  overrideState: string;
+  runtimeRoot?: string;
+  gate?: ReturnType<typeof spawnSync>;
+  authorGate?: ReturnType<typeof spawnSync>;
+  reviewDispatch?: ReturnType<typeof spawnSync>;
+  contractCase?: 'reviewer-drift' | 'reviewer-missing' | 'canonical';
+  cosmeticContractChanged?: boolean;
+  reviewStatus?: ReturnType<typeof spawnSync>;
+  reviewId?: string;
+}
+const states = new WeakMap<SafewordWorld, InstalledContextState>();
+
+function copiedRuntimeReviewStatus(state: InstalledContextState) {
+  assert.ok(state.runtimeRoot && state.reviewId);
+  return spawnSync(
+    'bun',
+    [path.join(state.runtimeRoot, 'runtime/cli.js'), 'review', 'status', state.reviewId, '--json'],
+    {
+      cwd: state.root,
+      encoding: 'utf8',
+      timeout: 60_000,
+      env: {
+        ...process.env,
+        PATH: `${state.reviewer}:${process.env.PATH ?? ''}`,
+        CLAUDE_PROJECT_DIR: state.root,
+        CLAUDE_PLUGIN_ROOT: state.runtimeRoot,
+        CLAUDE_SESSION_ID: 'r3-installed',
+        SAFEWORD_AGENT_RUNTIME: 'claude',
+      },
+    },
+  );
+}
+
+export function fixtureProject(): string {
+  const root = mkdtempSync(path.join(tmpdir(), 'safeword-r3-installed-'));
+  writePlanningInventories(root);
+  mkdirSync(path.join(root, ticketRoot), { recursive: true });
+  mkdirSync(path.join(root, 'features'));
+  writeFileSync(path.join(root, 'package.json'), '{"name":"r3-installed","private":true}\n');
+  writeFileSync(
+    path.join(root, ticketRoot, 'ticket.md'),
+    `---\nid: CTX123\ntype: feature\nphase: plan-implementation\nstatus: in_progress\nproduct_plan_contract: v1\nscope: preserve authenticated approval\nout_of_scope: new approval authority\ndone_when: current context reaches review\nphase_anchors:\n  - scenario-gate: features/current-context.feature\n---\n# Ticket\n`,
+  );
+  writeFileSync(
+    path.join(root, ticketRoot, 'spec.md'),
+    `# Product Plan: Preserve approval\n\n<!-- safeword:product-plan-contract:v1 -->\n\n## Product Bet\n\n- **Expected outcome:** Builders advance with current approval.\n- **Persona outcome inventory:** Builder receives approval or a named refusal.\n- **Known facts:** Approval authenticates the current source.\n- **Assumptions:** Review latency is acceptable.\n- **Unresolved product decisions:** none\n- **Success threshold:** Current approval advances.\n- **Project non-goals:** No new approval authority.\n\n## Jobs To Be Done\n\n### approval.BU1 — Trust approval\n\n**Persona:** Builder (BU)\n\n> When I request approval, I want current evidence, so I can trust advancement.\n\n#### approval.BU1.R1 — Preserve approval\n\nOnly current approval advances.\n\n## Surfaces\n\nAffected:\n- Safeword CLI\n`,
+  );
+  writeFileSync(
+    path.join(root, ticketRoot, 'impl-plan.md'),
+    `# Implementation Plan: Preserve approval\n\n**Status:** planned\n\n## Approach\n\nUse the current review receipt to guard the transition.\n\n## Decisions\n\n### Recorded Decisions\n\n| Decision | Choice | Alternatives considered | Rejected because |\n| --- | --- | --- | --- |\n| review gate | current receipt | unchecked transition | stale approval can advance |\n\n## Design alignment\n\nskip: No additional principle trace applies to this fixture.\n\n## Architecture applicability\n\nskip: No durable architecture record applies.\n\n## Data applicability\n\nskip: No product data is stored.\n\n## Known deviations\n\nskip: No known deviations.\n\n## Doc impact\n\nskip: No documentation changes.\n\n## Assessment triggers\n\nRevisit when the approval authority changes.\n`,
+  );
+  writeFileSync(
+    path.join(root, 'features/current-context.feature'),
+    '@approval.BU1.R1 @surface.safeword-cli\nFeature: Trust current approval\n  Scenario: Approval\n    Given a current review\n    When the Builder requests approval\n    Then the current context reaches review\n',
+  );
+  return root;
+}
+
+function configure(root: string, override: string): void {
+  const configPath = path.join(root, '.safeword/config.json');
+  const installed = JSON.parse(readFileSync(configPath, 'utf8')) as Record<string, unknown>;
+  writeFileSync(
+    configPath,
+    JSON.stringify({
+      ...installed,
+      reviewGate: true,
+      crossAgentReview: 'prefer',
+      crossAgentReviewRoutes: { claude: [{ reviewer: 'opencode' }] },
+      paths: { ...(installed.paths as Record<string, unknown>), principles: override },
+      pathLineage: { principles: { packagedSourceVersion: SAFEWORD_SCHEMA.version } },
+    }),
+  );
+}
+
+export function reviewerExecutable(reviewer: string): void {
+  writeFileSync(
+    path.join(reviewer, 'opencode'),
+    String.raw`#!${process.execPath}
+if (process.argv.includes('--version')) { console.log('opencode 1.0.0'); process.exit(0); }
+if (process.argv.includes('--help')) { console.log(${JSON.stringify(REVIEWER_CAPABILITIES.opencode)}); process.exit(0); }
+let input = ''; process.stdin.setEncoding('utf8');
+process.stdin.on('data', chunk => { input += chunk; });
+process.stdin.on('end', () => {
+  const packet = JSON.parse(input.trim().split('\n').pop());
+  const output = { schema_version: 1, dispatch_id: packet.dispatch_id,
+    reviewer_agent: 'opencode', verdict: 'approve', summary: 'Current plan approved.',
+    findings: [], evidence_records: { schema_version: 1, records: [] } };
+  console.log(JSON.stringify({ type: 'text', part: { type: 'text', time: { end: 1 }, text: JSON.stringify(output) } }));
+});
+`,
+    { mode: 0o755 },
+  );
+}
+
+After(function (this: SafewordWorld) {
+  const state = states.get(this);
+  if (state) {
+    rmSync(state.root, { recursive: true, force: true });
+    rmSync(state.reviewer, { recursive: true, force: true });
+    if (state.runtimeRoot) rmSync(state.runtimeRoot, { recursive: true, force: true });
+  }
+  states.delete(this);
+});
+
+function establishApprovedPlanningContext(this: SafewordWorld, overrideState: string) {
+  const root = fixtureProject();
+  const reviewer = createTrustedReviewerDirectory('safeword-r3-reviewer-');
+  states.set(this, { root, reviewer, overrideState });
+  const install = spawnSync(
+    'bun',
+    [
+      path.join(packageRoot, 'src/cli.ts'),
+      'install',
+      '--agents=claude',
+      '--no-input',
+      '--no-modify',
+      '--json',
+      '--cwd',
+      root,
+    ],
+    {
+      cwd: root,
+      encoding: 'utf8',
+      timeout: 60_000,
+      env: {
+        ...process.env,
+        CLAUDE_CONFIG_DIR: path.join(root, 'claude'),
+        SAFEWORD_SKIP_INSTALL: '1',
+        SAFEWORD_SKIP_SKILLS: '1',
+      },
+    },
+  );
+  const installOutput = JSON.parse(install.stdout) as { errors: unknown[] };
+  assert.deepEqual(installOutput.errors, [], `${install.stdout}\n${install.stderr}`);
+  const override = 'docs/principles.md';
+  mkdirSync(path.join(root, 'docs'));
+  writeFileSync(path.join(root, override), '# Project principles\n\nKeep approval current.\n');
+  configure(root, override);
+  reviewerExecutable(reviewer);
+  const environment = {
+    ...process.env,
+    PATH: `${reviewer}:${process.env.PATH ?? ''}`,
+    CLAUDE_PROJECT_DIR: root,
+    CLAUDE_PLUGIN_ROOT: pluginRoot,
+    CLAUDE_SESSION_ID: 'r3-installed',
+    SAFEWORD_AGENT_RUNTIME: 'claude',
+  };
+  const reviewed = spawnSync(
+    'bun',
+    [
+      path.join(packageRoot, 'src/cli.ts'),
+      'review',
+      'run',
+      'plan-implementation',
+      `${ticketRoot}/impl-plan.md`,
+      '--json',
+      '--no-input',
+    ],
+    { cwd: root, encoding: 'utf8', timeout: 60_000, env: environment },
+  );
+  assert.equal(reviewed.status, 0, `${reviewed.stdout}\n${reviewed.stderr}`);
+  const result = JSON.parse(reviewed.stdout) as { data: { status: string; review_id: string } };
+  assert.equal(result.data.status, 'approved');
+  const state = states.get(this);
+  assert.ok(state);
+  state.reviewId = result.data.review_id;
+  const stamp = spawnSync(
+    'bun',
+    [
+      path.join(pluginRoot, 'runtime/hooks/write-review-stamp.ts'),
+      '--ticket',
+      ticketFolder,
+      '--author-agent',
+      'claude',
+      '--reviewer-agent',
+      'opencode',
+      '--independence',
+      'reduced',
+      '--review-id',
+      result.data.review_id,
+      'impl-plan',
+    ],
+    { cwd: root, encoding: 'utf8', timeout: 60_000, env: environment },
+  );
+  assert.equal(stamp.status, 0, `${stamp.stdout}\n${stamp.stderr}`);
+  const phaseStamp = spawnSync(
+    'bun',
+    [
+      path.join(pluginRoot, 'runtime/hooks/write-review-stamp.ts'),
+      '--ticket',
+      ticketFolder,
+      '--author-agent',
+      'claude',
+      '--reviewer-agent',
+      'opencode',
+      '--independence',
+      'reduced',
+      '--review-id',
+      result.data.review_id,
+      '--phase',
+      'plan-implementation',
+    ],
+    { cwd: root, encoding: 'utf8', timeout: 60_000, env: environment },
+  );
+  assert.equal(phaseStamp.status, 0, `${phaseStamp.stdout}\n${phaseStamp.stderr}`);
+  const current = spawnSync(
+    'bun',
+    [path.join(packageRoot, 'src/cli.ts'), 'review', 'status', result.data.review_id, '--json'],
+    { cwd: root, encoding: 'utf8', timeout: 60_000, env: environment },
+  );
+  const currentStatus = JSON.parse(current.stdout) as { data: { status: string } };
+  assert.equal(currentStatus.data.status, 'approved', `${current.stdout}\n${current.stderr}`);
+  if (overrideState === 'blank') writeFileSync(path.join(root, override), ' \n');
+  if (overrideState.startsWith('stale')) {
+    const configPath = path.join(root, '.safeword/config.json');
+    const config = JSON.parse(readFileSync(configPath, 'utf8')) as Record<string, unknown>;
+    writeFileSync(
+      configPath,
+      JSON.stringify({
+        ...config,
+        pathLineage: { principles: { packagedSourceVersion: '0.0.0' } },
+      }),
+    );
+  }
+}
+
+Given(
+  /^a planning phase with a current approving receipt has a required project-knowledge override that is (.+)$/,
+  establishApprovedPlanningContext,
+);
+
+Given(
+  /^a planning phase with a current approving receipt has an installed authoring contract that (.+)$/,
+  function (this: SafewordWorld, contractState: string) {
+    establishApprovedPlanningContext.call(this, 'current');
+    const state = states.get(this);
+    assert.ok(state);
+    state.runtimeRoot = mkdtempSync(path.join(tmpdir(), 'safeword-r5-installed-plugin-'));
+    cpSync(pluginRoot, state.runtimeRoot, { recursive: true });
+    if (contractState === 'matches the exact canonical bytes') return;
+    assert.equal(contractState, 'deletes one clause but retains the canonical version label');
+    const contractPath = path.join(state.runtimeRoot, 'skills/bdd/PLAN_IMPLEMENTATION.md');
+    const original = readFileSync(contractPath, 'utf8');
+    const clause = 'Accepted scope and exclusions belong to the user.';
+    assert.ok(
+      original.includes(clause),
+      'The installed contract must contain the canonical clause.',
+    );
+    writeFileSync(contractPath, original.replace(clause, ''));
+  },
+);
+
+Given(
+  /^the installed authoring contract (deletes one clause but retains the canonical version label|differs from the canonical source only in whitespace or comments|is absent)$/,
+  function (this: SafewordWorld, contractState: string) {
+    establishApprovedPlanningContext.call(this, 'current');
+    const state = states.get(this);
+    assert.ok(state);
+    state.runtimeRoot = mkdtempSync(path.join(tmpdir(), 'safeword-r5-installed-plugin-'));
+    cpSync(pluginRoot, state.runtimeRoot, { recursive: true });
+    const contractPath = path.join(state.runtimeRoot, 'skills/bdd/PLAN_IMPLEMENTATION.md');
+    if (contractState === 'is absent') {
+      rmSync(contractPath);
+      return;
+    }
+    const original = readFileSync(contractPath, 'utf8');
+    if (contractState === 'differs from the canonical source only in whitespace or comments') {
+      writeFileSync(contractPath, `<!-- editorial -->\n${original}`);
+      return;
+    }
+    const clause = 'Accepted scope and exclusions belong to the user.';
+    assert.ok(original.includes(clause));
+    writeFileSync(contractPath, original.replace(clause, ''));
+  },
+);
+
+Given(
+  /^the (generated reviewer rubric deletes one clause but retains the canonical version label|generated reviewer rubric is absent|authoring contract and reviewer rubric both match the exact canonical bytes)$/,
+  function (this: SafewordWorld, contractState: string) {
+    establishApprovedPlanningContext.call(this, 'current');
+    const state = states.get(this);
+    assert.ok(state);
+    state.runtimeRoot = mkdtempSync(path.join(tmpdir(), 'safeword-r5-installed-plugin-'));
+    cpSync(pluginRoot, state.runtimeRoot, { recursive: true });
+    state.contractCase =
+      contractState === 'generated reviewer rubric is absent'
+        ? 'reviewer-missing'
+        : contractState ===
+            'generated reviewer rubric deletes one clause but retains the canonical version label'
+          ? 'reviewer-drift'
+          : 'canonical';
+    if (state.contractCase === 'canonical') return;
+    const runtime = path.join(state.runtimeRoot, 'runtime/cli.js');
+    const source = readFileSync(runtime, 'utf8');
+    const start = source.indexOf('var PLAN_REVIEW_RUBRIC = `');
+    const end = source.indexOf('PLAN_REVIEW_RUBRIC_SHA256', start);
+    if (state.contractCase === 'reviewer-missing') {
+      const contentStart = start + 'var PLAN_REVIEW_RUBRIC = `'.length;
+      const contentEnd = source.lastIndexOf('`', end);
+      assert.ok(start >= 0 && contentEnd > contentStart);
+      writeFileSync(runtime, source.slice(0, contentStart) + source.slice(contentEnd));
+      return;
+    }
+    const clause = 'Accepted scope and exclusions belong to the user.';
+    const clauseIndex = source.indexOf(clause, start);
+    assert.ok(start >= 0 && clauseIndex > start && clauseIndex < end);
+    writeFileSync(
+      runtime,
+      source.slice(0, clauseIndex) + source.slice(clauseIndex + clause.length),
+    );
+  },
+);
+
+Given(
+  'a plan review is current and its authoring guidance changed only in comments outside the canonical contract after installed copies were generated',
+  function (this: SafewordWorld) {
+    establishApprovedPlanningContext.call(this, 'current');
+    const state = states.get(this);
+    assert.ok(state);
+    state.runtimeRoot = mkdtempSync(path.join(tmpdir(), 'safeword-r5-cosmetic-plugin-'));
+    cpSync(pluginRoot, state.runtimeRoot, { recursive: true });
+    const baseline = copiedRuntimeReviewStatus(state);
+    assert.equal(baseline.status, 0, `${baseline.stdout}\n${baseline.stderr}`);
+    assert.equal(
+      (JSON.parse(baseline.stdout) as { data?: { status?: string } }).data?.status,
+      'approved',
+    );
+    const installed = path.join(state.runtimeRoot, 'skills/bdd/PLAN_IMPLEMENTATION.md');
+    const template = path.join(state.runtimeRoot, 'templates/skills/bdd/PLAN_IMPLEMENTATION.md');
+    const oldBytes = readFileSync(installed);
+    const oldHash = createHash('sha256').update(oldBytes).digest('hex');
+    const newBytes = Buffer.concat([oldBytes, Buffer.from('\n<!-- editorial -->\n')]);
+    const newHash = createHash('sha256').update(newBytes).digest('hex');
+    assert.equal(
+      extractPlanReviewRubric(newBytes.toString('utf8')),
+      extractPlanReviewRubric(oldBytes.toString('utf8')),
+    );
+    const originalTemplate = readFileSync(template, 'utf8');
+    const changedTemplate = `${originalTemplate}\n<!-- editorial -->\n`;
+    assert.deepEqual(
+      parsePlanningContract('plan-implementation', changedTemplate),
+      parsePlanningContract('plan-implementation', originalTemplate),
+    );
+    writeFileSync(template, changedTemplate);
+    const runtime = path.join(state.runtimeRoot, 'runtime/cli.js');
+    const source = readFileSync(runtime, 'utf8');
+    const authorIdentity = `relativePath: "skills/bdd/PLAN_IMPLEMENTATION.md", sha256: "${oldHash}"`;
+    assert.ok(
+      source.includes(authorIdentity),
+      'the installed runtime must name the old author copy',
+    );
+    writeFileSync(
+      runtime,
+      source.replace(authorIdentity, authorIdentity.replace(oldHash, newHash)),
+    );
+    state.cosmeticContractChanged = true;
+  },
+);
+
+When(
+  'the content identity of every generated contract copy is recomputed',
+  function (this: SafewordWorld) {
+    const state = states.get(this);
+    assert.ok(state?.runtimeRoot);
+    const hook = path.join(state.runtimeRoot, 'runtime/hooks/pre-tool-quality.ts');
+    state.authorGate = spawnSync('bun', [hook], {
+      cwd: state.root,
+      encoding: 'utf8',
+      timeout: 60_000,
+      input: JSON.stringify({
+        session_id: 'r3-installed',
+        tool_name: 'Edit',
+        tool_input: {
+          file_path: path.join(state.root, ticketRoot, 'impl-plan.md'),
+          old_string: 'Use the current review receipt',
+          new_string: 'Use the authenticated current review receipt',
+        },
+      }),
+      env: {
+        ...process.env,
+        PATH: `${state.reviewer}:${process.env.PATH ?? ''}`,
+        CLAUDE_PROJECT_DIR: state.root,
+        CLAUDE_PLUGIN_ROOT: state.runtimeRoot,
+        CLAUDE_SESSION_ID: 'r3-installed',
+      },
+    });
+    state.gate = spawnSync('bun', [hook], {
+      cwd: state.root,
+      encoding: 'utf8',
+      timeout: 60_000,
+      input: JSON.stringify({
+        session_id: 'r3-installed',
+        tool_name: 'Edit',
+        tool_input: {
+          file_path: path.join(state.root, ticketRoot, 'ticket.md'),
+          old_string: 'phase: plan-implementation',
+          new_string: 'phase: plan-execution',
+        },
+      }),
+      env: {
+        ...process.env,
+        PATH: `${state.reviewer}:${process.env.PATH ?? ''}`,
+        CLAUDE_PROJECT_DIR: state.root,
+        CLAUDE_PLUGIN_ROOT: state.runtimeRoot,
+        CLAUDE_SESSION_ID: 'r3-installed',
+      },
+    });
+    if (state.contractCase) {
+      state.reviewDispatch = spawnSync(
+        'bun',
+        [
+          path.join(state.runtimeRoot, 'runtime/cli.js'),
+          'review',
+          'run',
+          'plan-implementation',
+          `${ticketRoot}/impl-plan.md`,
+          '--json',
+          '--no-input',
+        ],
+        {
+          cwd: state.root,
+          encoding: 'utf8',
+          timeout: 60_000,
+          env: {
+            ...process.env,
+            PATH: `${state.reviewer}:${process.env.PATH ?? ''}`,
+            CLAUDE_PROJECT_DIR: state.root,
+            CLAUDE_PLUGIN_ROOT: state.runtimeRoot,
+            CLAUDE_SESSION_ID: 'r3-installed',
+            SAFEWORD_AGENT_RUNTIME: 'claude',
+          },
+        },
+      );
+    }
+  },
+);
+
+Then(
+  /^authoring and approval are blocked until (?:the exact canonical contract bytes|the canonical contract) (?:are|is) restored$/,
+  function (this: SafewordWorld) {
+    const state = states.get(this);
+    assert.ok(state?.authorGate && state.gate);
+    for (const result of [state.authorGate, state.gate]) {
+      assert.equal(result.status, 0, result.stderr);
+      const output = JSON.parse(result.stdout) as {
+        hookSpecificOutput?: { permissionDecision?: string; permissionDecisionReason?: string };
+      };
+      assert.equal(output.hookSpecificOutput?.permissionDecision, 'deny');
+      assert.match(
+        output.hookSpecificOutput?.permissionDecisionReason ?? '',
+        /(?:canonical_contract_copy_mismatch|missing_generated_contract_copy)/,
+      );
+    }
+  },
+);
+
+Then(
+  /^review dispatch and approval are blocked until (?:the exact canonical contract bytes|the canonical contract) (?:are|is) restored$/,
+  function (this: SafewordWorld) {
+    const state = states.get(this);
+    assert.ok(state?.reviewDispatch && state.gate);
+    assert.notEqual(state.reviewDispatch.status, 0);
+    const dispatch = JSON.parse(state.reviewDispatch.stdout) as {
+      findings?: Array<{ code?: string; message?: string }>;
+    };
+    assert.ok(
+      dispatch.findings?.some(finding =>
+        /reviewer contract|canonical contract/.test(finding.message ?? ''),
+      ),
+      state.reviewDispatch.stdout,
+    );
+    assert.equal(state.gate.status, 0, state.gate.stderr);
+    assert.notEqual(state.gate.stdout.trim(), '', 'approval gate allowed a stale reviewer copy');
+    const approval = JSON.parse(state.gate.stdout) as {
+      hookSpecificOutput?: { permissionDecision?: string; permissionDecisionReason?: string };
+    };
+    assert.equal(approval.hookSpecificOutput?.permissionDecision, 'deny');
+    const code = 'canonical_contract_copy_mismatch';
+    assert.match(
+      dispatch.findings?.find(finding => finding.code === code)?.message ?? '',
+      /Restore the packaged decision-quality contract/,
+    );
+    assert.match(
+      approval.hookSpecificOutput?.permissionDecisionReason ?? '',
+      /Restore the packaged decision-quality contract/,
+    );
+    assert.ok(
+      dispatch.findings?.some(finding => finding.code === code),
+      state.reviewDispatch.stdout,
+    );
+    assert.match(
+      approval.hookSpecificOutput?.permissionDecisionReason ?? '',
+      new RegExp(`${code}.*plan-rubric\\.generated\\.ts`, 'su'),
+    );
+  },
+);
+
+Then(
+  'both copies recompute to the same identity and contract identity does not block authoring, dispatch, or approval',
+  function (this: SafewordWorld) {
+    const state = states.get(this);
+    assert.ok(state?.authorGate && state.reviewDispatch && state.gate);
+    assert.equal(state.authorGate.status, 0, state.authorGate.stderr);
+    assert.equal(state.authorGate.stdout.trim(), '', state.authorGate.stdout);
+    assert.equal(state.reviewDispatch.status, 0, state.reviewDispatch.stdout);
+    assert.equal(state.gate.status, 0, state.gate.stderr);
+    assert.equal(state.gate.stdout.trim(), '', state.gate.stdout);
+  },
+);
+
+When(
+  'actual lifecycle dispatch from installed local project hooks evaluates the phase transition with real configuration and collaborators, mocking only the reviewer process boundary',
+  function (this: SafewordWorld) {
+    const state = states.get(this);
+    assert.ok(state);
+    const ticketPath = path.join(state.root, ticketRoot, 'ticket.md');
+    const hook = path.join(state.runtimeRoot ?? pluginRoot, 'runtime/hooks/pre-tool-quality.ts');
+    assert.ok(existsSync(hook));
+    state.gate = spawnSync('bun', [hook], {
+      cwd: state.root,
+      encoding: 'utf8',
+      timeout: 60_000,
+      input: JSON.stringify({
+        session_id: 'r3-installed',
+        tool_name: 'Edit',
+        tool_input: {
+          file_path: ticketPath,
+          old_string: 'phase: plan-implementation',
+          new_string: 'phase: plan-execution',
+        },
+      }),
+      env: {
+        ...process.env,
+        PATH: `${state.reviewer}:${process.env.PATH ?? ''}`,
+        CLAUDE_PROJECT_DIR: state.root,
+        CLAUDE_PLUGIN_ROOT: state.runtimeRoot ?? pluginRoot,
+        CLAUDE_SESSION_ID: 'r3-installed',
+        SAFEWORD_AGENT_RUNTIME: 'claude',
+      },
+    });
+    if (state.cosmeticContractChanged) {
+      state.reviewStatus = copiedRuntimeReviewStatus(state);
+    }
+  },
+);
+
+Then('the phase transition proceeds', function (this: SafewordWorld) {
+  if (this.nativePlanningGate) {
+    const { host, output } = this.nativePlanningGate;
+    if (host === 'Cursor') assert.equal(JSON.parse(output).permission, 'allow', output);
+    else assert.equal(output, '', output);
+    return;
+  }
+  const gate = states.get(this)?.gate;
+  assert.ok(gate);
+  assert.equal(gate.status, 0, `${gate.stdout}\n${gate.stderr}`);
+  assert.equal(gate.stdout.trim(), '', gate.stdout);
+});
+
+Then(
+  'the phase remains blocked with canonical contract reconciliation named',
+  function (this: SafewordWorld) {
+    const gate = states.get(this)?.gate;
+    assert.ok(gate);
+    assert.equal(gate.status, 0, gate.stderr);
+    const output = JSON.parse(gate.stdout) as {
+      hookSpecificOutput?: { permissionDecision?: string; permissionDecisionReason?: string };
+    };
+    assert.equal(output.hookSpecificOutput?.permissionDecision, 'deny');
+    const reason = output.hookSpecificOutput?.permissionDecisionReason ?? '';
+    assert.ok(
+      reason.includes('canonical_contract_copy_mismatch'),
+      `Canonical contract reconciliation was not named at the installed phase gate. Actual reason: ${reason}`,
+    );
+    assert.ok(
+      reason.includes('skills/bdd/PLAN_IMPLEMENTATION.md'),
+      `The installed authoring contract path was not named at the phase gate. Actual reason: ${reason}`,
+    );
+  },
+);
+
+Then(
+  'the review receipt remains current and the phase remains blocked with canonical contract reconciliation named',
+  function (this: SafewordWorld) {
+    const state = states.get(this);
+    assert.ok(state?.reviewStatus && state.gate);
+    assert.equal(
+      state.reviewStatus.status,
+      0,
+      `cosmetic canonical copy drift incorrectly staled review: ${state.reviewStatus.stdout}\n${state.reviewStatus.stderr}`,
+    );
+    const status = JSON.parse(state.reviewStatus.stdout) as { data?: { status?: string } };
+    assert.equal(status.data?.status, 'approved');
+    assert.equal(state.gate.status, 0, state.gate.stderr);
+    const gate = JSON.parse(state.gate.stdout) as {
+      hookSpecificOutput?: { permissionDecision?: string; permissionDecisionReason?: string };
+    };
+    assert.equal(gate.hookSpecificOutput?.permissionDecision, 'deny');
+    assert.match(
+      gate.hookSpecificOutput?.permissionDecisionReason ?? '',
+      /canonical_contract_copy_mismatch.*skills\/bdd\/PLAN_IMPLEMENTATION\.md/su,
+    );
+  },
+);
+
+Then(
+  'the phase remains blocked with override reconciliation named',
+  function (this: SafewordWorld) {
+    const state = states.get(this);
+    const gate = state?.gate;
+    assert.ok(gate);
+    assert.ok(state);
+    assert.equal(gate.status, 0, gate.stderr);
+    const output = JSON.parse(gate.stdout) as {
+      hookSpecificOutput?: { permissionDecision?: string; permissionDecisionReason?: string };
+    };
+    assert.equal(output.hookSpecificOutput?.permissionDecision, 'deny');
+    const reason = output.hookSpecificOutput?.permissionDecisionReason ?? '';
+    const expected =
+      state.overrideState === 'blank'
+        ? 'Planning principles override at docs/principles.md needs reconciliation with the current packaged source.'
+        : 'Planning principles override at .safeword/config.json:pathLineage.principles needs reconciliation with the current packaged source.';
+    assert.ok(
+      reason.includes(expected),
+      `Override reconciliation was not named at the installed phase gate. Actual reason: ${reason}`,
+    );
+  },
+);
