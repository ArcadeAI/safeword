# R6 planning denial: visible recovery across host adapters

Final correction after planning-only review
11e4fd6b-3fb0-4ca5-8e93-28cbc9283a92 approved: the installed Cursor stale-receipt
case failed its existing recovery-command assertion because its adapter omits
the separate additionalContext field. Claude and Codex controls passed. Preserve
the concrete rerun command in the actor-visible reason itself; do not alter any
host adapter or weaken the acceptance check. Initial stale controls remain
retained: two passed, one failed, 170 passed steps and one failed assertion.

The existing verifier callback now carries the receipt it already read alongside
the unchanged verdict reason. This permits an accurate heading: reviewer-route
reconciliation only for blocked status with independence none; other authenticated
failures say review receipt reconciliation. No string parsing or new receipt
classification is introduced. As before, only plan-implementation/execution
exits with no verified stamp use the new reason; other phase messages and all
approval/authentication/policy decisions stay unchanged. Multiple rejected stamps
still report the last reason; do not expand this bounded diagnostic repair into
new selection or aggregation policy.

Final targeted controls: 98 tests pass, including 24 phase-gate cases and 74
receipt/helper controls. All five generated surfaces are regenerated, with
unchanged lifecycle result hashes. Root verification includes nine route cases,
nine installed Claude/Codex/Cursor pending/approval/fallback cases, and all three
installed stale-receipt cases. Results will be recorded outside this immutable
context. Supporting root proof is exactly the one approved by the prior reviews:
same real blocked job and forged plaintext locator; valid approval alongside the
rejected stamp remains admissible. Only reviewer producers are mocked.

The ungated-origin example stays undefined. Do not claim a wrong-kind fixture
proves origin, complete the typed-route outline, or claim a ledger transition
from the earlier functional RED whose ledger argument was incorrect. Other
acceptance gaps, historical failures, explicit host deferrals and R7 user
deferral stay open. Old approved reviews whose source/context fingerprints moved
are historical evidence, not current final-review authority. No Ready or merge.
