# R6 blocked-receipt denial: final repair

Scope: one accepted root example, typed no-independent-route-attempted (row172).
The installed Cursor phase hook discards an invalid plaintext ledger locator but
previously discarded the authenticated reason too. Preserve that reason via an
optional callback from the existing verifier. Use it only when no stamp survives
verification and the phase gate refuses advancement. When any stamp verifies,
retain the existing policy diagnostic. Authentication and approval policy do not
change.

The root proof earns a genuine qualified approval through the installed CLI and
real coordinator/job store, writes a real stamp, and proves both plan approval
and native Cursor phase admission. It then configures only the same-agent route,
which cannot be attempted before an independent route. The actual blocked job
has independence none and a single unattempted Claude route. No fallback producer
launches. A plaintext ledger locator is forged to reference this real blocked
job. The native phase gate denies and names that exact review and blocked status;
the real stamp writer refuses without modifying the ledger. Ticket phase stays
unchanged. A subsequent valid stamp alongside the rejected one must still permit
the native transition. Only reviewer processes are mocked; this is simulated-host
evidence, not a live-host walkthrough.

Initial two-case quality review c4b8b437-6f26-478e-a597-18e7daf79308 correctly
requested changes: a quality-review receipt tested kind rejection, not ungated
host origin. That Given binding was removed. The accepted ungated-origin example
remains undefined, with its outcome untouched. No acceptance credit is claimed
for the discarded fixture. The same review suggested avoiding historical receipt
errors when a verified stamp exists but current policy rejects it; that guard is
included. Do not broaden this into a new host-origin attestation mechanism.

Independent executable RED 69a96a26-fa03-44be-8ead-94226e9ea227 executed both initial
native cases and approved the intended message failure. Its command mistakenly
named a nonexistent ledger path, so it is functional failure evidence only,
not eligible ledger-transition evidence. A corrected single-case proof will be
required before completing the whole typed-route outline's ledger.

Earlier controls passed 10 scenarios/570 steps and 74 receipt/hook tests; all
three package typechecks passed. The initial concurrent root controls hit two
dist rebuild infrastructure failures; the sequential rerun passed. The first
full normal run was interrupted on receiving the review finding and is not a
pass. Final verification will be recorded separately without editing this
context. Repository ESLint ignores template hooks; its ignored-file warnings
are not lint coverage. Imported helpers are checked through package tests and
typechecking; the pre-tool script is exercised by real Bun hook execution.

All five generated surfaces are regenerated. Cursor lifecycle tree hashes track
the new hook bytes while result_sha256 stays identical. No schema exemption,
manual generated edit, paid requalification, exception or approval bypass was
introduced. Other acceptance gaps, historical six failures/585 unfinished,
sixteen deferred OpenCode/cloud cases and user-deferred R7 proof stay open. The
shared When callback changes old supporting-source fingerprints; older reviews
that included this file need renewed evidence before final stack readiness.
