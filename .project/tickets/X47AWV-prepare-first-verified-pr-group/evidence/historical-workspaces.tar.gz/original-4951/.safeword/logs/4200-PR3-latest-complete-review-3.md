Review the complete authored/source change for PR #5051 at exact current head 11867f743542616868fcb7ae2a59bae741c9c711, base 2f8a39d9d8047b1c5c92f5ca61995ec8a48b4620. Review semantic context identities, provenance, authentication and stale-approval refusal, meaningful tests, and tight scope. All changed files except the two compiled runtime bundles are included across the numbered parts. The excluded plugin/runtime/cli.js and packages/cli/codex-plugin/runtime/cli.js diffs exceed the packet budget; their complete source/generation changes and identities are supplied. Do not claim every compiled byte was inspected. This review supplies evidence for this exact slice only, not original full acceptance, merge or promotion authority. The user deferred OpenCode/cloud, retrieval producers, genuine weaker-model proofs and an unattempted eligible reviewer retry to named follow-on tickets; those remain unverified. PR5 owns the current installed canonical-contract currency regression and its pending correction. Do not invent that successor's completion or widen this PR through review. Existing review 9c3808bb approved the earlier source snapshot; this refresh covers the current material source change after integration. No new external dependency is introduced.

Part 3/3.

+    mkdirSync(nodePath.join(root, folder), { recursive: true });
+  writeFileSync(
+    nodePath.join(root, `${child}/ticket.md`),
+    `---\nid: OWN123\ntype: feature\nproduct_plan_contract: v1\nparent: 000123\nparent_job: approval.BU1\nmilestone: M1\nphase_anchors:\n  - scenario-gate: ${feature}\n---\n`,
+  );
+  writeFileSync(
+    nodePath.join(root, '.project/tickets/000123-parent/ticket.md'),
+    '---\nid: 000123\ntype: epic\n---\n',
+  );
+  writeFileSync(
+    nodePath.join(root, `${child}/spec.md`),
+    '# Child Contribution\n\n## Jobs To Be Done\n\n### approval.BU1 — Trust approval\n\n#### approval.BU1.R1 — Preserve approval\n\nOnly current approval advances.\n',
+  );
+  writeFileSync(nodePath.join(root, parentPath), parent);
+  writeFileSync(
+    nodePath.join(root, feature),
+    '@approval.BU1.R1 @surface.safeword-cli\nFeature: Trust approval\n  Scenario: Current approval\n    Given current evidence\n',
+  );
+  return root;
+}
+function identity(root: string) {
+  const prepared = prepareReviewPacket(root, 'scenario-gate', [feature], [`${child}/spec.md`]);
+  try {
+    return createPlanningReviewIdentity(prepared.packet);
+  } finally {
+    prepared.cleanup();
+  }
+}
+afterEach(() => {
+  for (const root of roots) rmSync(root, { recursive: true, force: true });
+  roots.length = 0;
+  vi.unstubAllEnvs();
+});
+
+describe('Scenario child selected-parent review identity', () => {
+  it('retains approval after an unrelated parent job and milestone edit', () => {
+    const root = project();
+    const before = identity(root);
+    writeFileSync(
+      nodePath.join(root, parentPath),
+      parent.replace(
+        'An unrelated delivery remains available.',
+        'An unrelated delivery can change.',
+      ),
+    );
+    expect(identity(root)).toEqual(before);
+  });
+  it('stales approval after a selected inherited outcome changes', () => {
+    const root = project();
+    const before = identity(root);
+    writeFileSync(
+      nodePath.join(root, parentPath),
+      parent.replace('Review is current.', 'Review is current and attributable.'),
+    );
+    expect(identity(root)).not.toEqual(before);
+  });
+  it('retains approval after an unreferenced persona changes', () => {
+    const root = project();
+    const personas = nodePath.join(root, '.project/personas.md');
+    const original =
+      '# Personas\n\n## Builder (BU)\n\n**Role:** Requests current approval.\n\n## Analyst (AN)\n\n**Role:** Reads unrelated reports.\n';
+    writeFileSync(personas, original);
+    const before = identity(root);
+    writeFileSync(
+      personas,
+      original.replace('Reads unrelated reports.', 'Reads unrelated metrics.'),
+    );
+    expect(identity(root)).toEqual(before);
+  });
+  it('stales approval after the referenced persona changes', () => {
+    const root = project();
+    const personas = nodePath.join(root, '.project/personas.md');
+    const original = '# Personas\n\n## Builder (BU)\n\n**Role:** Requests current approval.\n';
+    writeFileSync(personas, original);
+    const before = identity(root);
+    writeFileSync(personas, original.replace('current approval', 'authenticated approval'));
+    expect(identity(root)).not.toEqual(before);
+  });
+  it('stales approval after a Product Bet persona without a JTBD changes', () => {
+    const root = project();
+    const personas = nodePath.join(root, '.project/personas.md');
+    const original =
+      '# Personas\n\n## Builder (BU)\n\n**Role:** Requests current approval.\n\n## Analyst (AN)\n\n**Role:** Checks the outcome inventory.\n';
+    writeFileSync(personas, original);
+    writeFileSync(
+      nodePath.join(root, parentPath),
+      parent.replace(
+        'Builder receives current approval.',
+        'Builder receives current approval; Analyst (AN) can check the outcome.',
+      ),
+    );
+    const before = identity(root);
+    writeFileSync(
+      personas,
+      original.replace('Checks the outcome inventory.', 'Audits the outcome inventory.'),
+    );
+    expect(identity(root)).not.toEqual(before);
+  });
+  it('retains approval after an unreferenced surface changes', () => {
+    const root = project();
+    const surfaces = nodePath.join(root, '.project/surfaces.md');
+    const original =
+      '# Surfaces\n\n## Safeword CLI\n\n**Kind:** CLI\n**Description:** Requests approval.\n\n## Reports UI\n\n**Kind:** UI\n**Description:** Shows unrelated reports.\n';
+    writeFileSync(surfaces, original);
+    const before = identity(root);
+    writeFileSync(surfaces, original.replace('unrelated reports', 'unrelated metrics'));
+    expect(identity(root)).toEqual(before);
+  });
+  it('stales approval after the referenced surface changes', () => {
+    const root = project();
+    const surfaces = nodePath.join(root, '.project/surfaces.md');
+    const original =
+      '# Surfaces\n\n## Safeword CLI\n\n**Kind:** CLI\n**Description:** Requests approval.\n';
+    writeFileSync(surfaces, original);
+    const before = identity(root);
+    writeFileSync(surfaces, original.replace('Requests approval.', 'Presents approval.'));
+    expect(identity(root)).not.toEqual(before);
+  });
+  it('stores a canonical target when the caller uses an equivalent path', async () => {
+    const root = project();
+    const worker = nodePath.join(root, 'worker.mjs');
+    writeFileSync(worker, 'process.exit(0);\n');
+    vi.stubEnv('SAFEWORD_CLI_ENTRYPOINT', worker);
+    vi.stubEnv('SAFEWORD_REVIEW_FOREGROUND_MS', '0');
+    vi.stubEnv('SAFEWORD_REVIEW_KEY_ROOT', nodePath.join(root, 'keys'));
+    await expect(
+      startReviewJob({
+        cwd: root,
+        kind: 'scenario-gate',
+        targets: [`./${feature}`],
+        context: [`${child}/spec.md`],
+      }),
+    ).resolves.toBeDefined();
+    const jobs = nodePath.join(root, '.safeword/state/reviews');
+    const record = readdirSync(jobs).find(name => name.endsWith('.json'));
+    expect(record).toBeDefined();
+    const saved = JSON.parse(readFileSync(nodePath.join(jobs, record ?? ''), 'utf8')) as {
+      targets: string[];
+    };
+    expect(saved.targets).toEqual([feature]);
+  });
+  it('resolves an equivalent scenario path in the ticket anchor', () => {
+    const root = project();
+    const ticket = nodePath.join(root, `${child}/ticket.md`);
+    writeFileSync(
+      ticket,
+      readFileSync(ticket, 'utf8').replace(feature, './features/child.feature'),
+    );
+    expect(identity(root)?.dependencies).toEqual(
+      expect.arrayContaining([expect.objectContaining({ role: 'scenarios', path: feature })]),
+    );
+  });
+  it('resolves the canonical scenario source when the ticket has no anchor', () => {
+    const root = project();
+    const ticket = nodePath.join(root, `${child}/ticket.md`);
+    writeFileSync(
+      ticket,
+      readFileSync(ticket, 'utf8').replace(`phase_anchors:\n  - scenario-gate: ${feature}\n`, ''),
+    );
+    expect(identity(root)?.dependencies).toEqual(
+      expect.arrayContaining([expect.objectContaining({ role: 'scenarios', path: feature })]),
+    );
+  });
+  it('keeps a generic scenario review outside owned tickets runnable', async () => {
+    const root = project();
+    writeFileSync(nodePath.join(root, 'spec.md'), '# Generic spec\n\nNo owned ticket.\n');
+    const worker = nodePath.join(root, 'worker.mjs');
+    writeFileSync(worker, 'process.exit(0);\n');
+    vi.stubEnv('SAFEWORD_CLI_ENTRYPOINT', worker);
+    vi.stubEnv('SAFEWORD_REVIEW_FOREGROUND_MS', '0');
+    vi.stubEnv('SAFEWORD_REVIEW_KEY_ROOT', nodePath.join(root, 'keys'));
+    await expect(
+      startReviewJob({
+        cwd: root,
+        kind: 'scenario-gate',
+        targets: [feature],
+        context: ['spec.md'],
+      }),
+    ).resolves.toBeDefined();
+  });
+  it('retains approval after an unrelated persona edit with AC-style criteria', () => {
+    const root = project();
+    const childSpec = nodePath.join(root, `${child}/spec.md`);
+    const featurePath = nodePath.join(root, feature);
+    writeFileSync(childSpec, readFileSync(childSpec, 'utf8').replaceAll('.R1', '.AC1'));
+    writeFileSync(featurePath, readFileSync(featurePath, 'utf8').replaceAll('.R1', '.AC1'));
+    const personas = nodePath.join(root, '.project/personas.md');
+    const original =
+      '# Personas\n\n## Builder (BU)\n\n**Role:** Requests approval.\n\n## Analyst (AN)\n\n**Role:** Reads unrelated reports.\n';
+    writeFileSync(personas, original);
+    const before = identity(root);
+    writeFileSync(
+      personas,
+      original.replace('Reads unrelated reports.', 'Reads unrelated metrics.'),
+    );
+    expect(identity(root)).toEqual(before);
+  });
+});
diff --git a/packages/cli/tests/review/standalone-ticket-identity.test.ts b/packages/cli/tests/review/standalone-ticket-identity.test.ts
new file mode 100644
index 000000000..d7bbf8904
--- /dev/null
+++ b/packages/cli/tests/review/standalone-ticket-identity.test.ts
@@ -0,0 +1,53 @@
+import { describe, expect, it } from 'vitest';
+
+import type { ReviewPacket } from '../../src/review/contract.js';
+import { productParentContextIdentity } from '../../src/review/planning-context-identity.js';
+
+const ticketPath = '.project/tickets/OWN123-owned/ticket.md';
+const ticket =
+  '---\nid: OWN123\ntype: feature\nphase: intake\nstatus: in_progress\nlast_modified: yesterday\nproduct_plan_contract: v1\nscope: preserve approval\nout_of_scope: anonymous approval\ndone_when: current approval advances\n---\n# Ticket\n\nPreserve authentication.\n';
+
+function projected(content: string) {
+  const packet: ReviewPacket = {
+    schema_version: 1,
+    dispatch_id: 'standalone-ticket-identity',
+    kind: 'quality-review',
+    planning_phase: 'product-plan',
+    planning_context: {
+      schema_version: 1,
+      ticket_id: 'OWN123',
+      ticket_path: ticketPath,
+      dependencies: [{ role: 'ticket', path: ticketPath }],
+      absences: [],
+    },
+    logical_files: [{ path: '.project/tickets/OWN123-owned/spec.md', content: '# Product Plan' }],
+    context_files: [{ path: ticketPath, content }],
+  };
+  const value = productParentContextIdentity(packet).get(ticketPath);
+  expect(value).toEqual(expect.any(String));
+  return value;
+}
+
+describe('standalone ticket semantic projection', () => {
+  it.each([
+    ['phase: intake', 'phase: define-behavior'],
+    ['status: in_progress', 'status: done'],
+    ['last_modified: yesterday', 'last_modified: today'],
+    ['scope: preserve approval', 'scope: "preserve approval"'],
+    ['# Ticket', '<!-- editorial -->\n\n# Ticket'],
+  ])('ignores cosmetic or administrative %s', (before, after) => {
+    const changed = ticket.replace(before, () => after);
+    expect(changed).not.toBe(ticket);
+    expect(projected(changed)).toBe(projected(ticket));
+  });
+  it.each([
+    ['scope: preserve approval', 'scope: permit anonymous approval'],
+    ['out_of_scope: anonymous approval', 'out_of_scope: none'],
+    ['done_when: current approval advances', 'done_when: any approval advances'],
+    ['Preserve authentication.', 'Remove authentication.'],
+  ])('retains decision-bearing %s', (before, after) => {
+    const changed = ticket.replace(before, () => after);
+    expect(changed).not.toBe(ticket);
+    expect(projected(changed)).not.toBe(projected(ticket));
+  });
+});
diff --git a/packages/cli/tests/smoke/execution-plan.live.test.ts b/packages/cli/tests/smoke/execution-plan.live.test.ts
index 9fbfc7a92..2be194ed3 100644
--- a/packages/cli/tests/smoke/execution-plan.live.test.ts
+++ b/packages/cli/tests/smoke/execution-plan.live.test.ts
@@ -1,6 +1,8 @@
 import { randomUUID } from 'node:crypto';
-import { writeFileSync } from 'node:fs';
+import { mkdirSync, readFileSync, writeFileSync } from 'node:fs';
+import nodePath from 'node:path';
 import process from 'node:process';
+import { setTimeout as delay } from 'node:timers/promises';
 
 import { afterAll, describe, expect, it } from 'vitest';
 
@@ -16,7 +18,12 @@ import {
   type ExecutionPlanConformanceResult,
 } from '../../src/review/execution-plan-conformance.js';
 import { reviewTimeoutMilliseconds, runHeadlessReviewer } from '../../src/review/runtime.js';
-import { createTemporaryDirectory, removeTemporaryDirectory } from '../helpers.js';
+import {
+  assertTestCliFresh,
+  createTemporaryDirectory,
+  removeTemporaryDirectory,
+  runCli,
+} from '../helpers.js';
 
 const CAN_RUN = process.env.SAFEWORD_RUN_EXECUTION_PLAN_LIVE === '1';
 const REVIEW_TIMEOUT_MS = reviewTimeoutMilliseconds({});
@@ -92,6 +99,13 @@ function assertCase(
 ): void {
   expect(output.reviewer_agent).toBe(assigned);
   expect(output.dispatch_id).toBe(dispatchId);
+  assertSemanticOutcome(testCase, output);
+}
+
+function assertSemanticOutcome(
+  testCase: ExecutionPlanConformanceCase,
+  output: ReviewerOutput,
+): void {
   expect(output.planning_destination).toBe(testCase.expectation.planning_destination);
   if (testCase.expectation.verdict === 'approve') assertApproval(testCase, output);
   else assertDenial(testCase, output);
@@ -147,3 +161,144 @@ describe.skipIf(!CAN_RUN)('live Execution Plan semantic conformance', () => {
     LIVE_TEST_TIMEOUT_MS,
   );
 });
+
+// Exercise the public coordinator as well as the external semantic judgment.
+// This is deliberately opt-in: default acceptance must not masquerade as a live eval.
+const CLI_LIVE = process.env.SAFEWORD_RUN_EXECUTION_PLAN_CLI_LIVE === '1';
+const CLI_CASES = process.env.SAFEWORD_EXECUTION_PLAN_CLI_LIVE_CASES?.split(',') ?? [];
+const selectedCases = EXECUTION_PLAN_CONFORMANCE_CASES.filter(testCase =>
+  CLI_CASES.includes(testCase.id),
+);
+if (
+  CLI_LIVE &&
+  (CLI_CASES.length === 0 ||
+    new Set(CLI_CASES).size !== CLI_CASES.length ||
+    selectedCases.length !== CLI_CASES.length)
+) {
+  throw new Error('CLI live proof requires unique named conformance cases');
+}
+
+const CLI_REVIEW_BOUND_MS = 240_000;
+
+describe.skipIf(!CLI_LIVE)('installed CLI semantic conformance', () => {
+  it.each(selectedCases)(
+    '$id',
+    // eslint-disable-next-line complexity -- One bounded public CLI journey owns dispatch, pending status, judgment, and cancellation.
+    async testCase => {
+      assertTestCliFresh();
+      expect(reviewer).toBe('claude');
+      expect(model).toBeTruthy();
+      if (reviewer !== 'claude' || model === undefined) {
+        throw new Error('CLI live proof requires an explicit Claude reviewer and model');
+      }
+      const liveProfile = process.env.SAFEWORD_EXECUTION_PLAN_LIVE_CLAUDE_CONFIG_DIR;
+      if (!liveProfile)
+        throw new Error('CLI live proof requires its explicitly authenticated Claude profile');
+      const directory = createTemporaryDirectory();
+      const env = {
+        // Only this opt-in review subprocess uses the supplied profile; lifecycle fixtures stay sandboxed.
+        CLAUDE_CONFIG_DIR: liveProfile,
+        SAFEWORD_AGENT_RUNTIME: 'codex',
+        SAFEWORD_REVIEW_FOREGROUND_MS: '100',
+        SAFEWORD_NO_UPDATE_CHECK: '1',
+        SAFEWORD_REVIEW_RUN_BOUND_MS: String(CLI_REVIEW_BOUND_MS),
+        SAFEWORD_REVIEW_TIMEOUT_MS: String(CLI_REVIEW_BOUND_MS - 60_000),
+      };
+      let pendingId: string | undefined;
+      const invoke = (args: string[]) =>
+        runCli(['--json', '--no-input', 'review', ...args, '--cwd', directory], {
+          cwd: directory,
+          env,
+          timeout: 30_000,
+          // Empty selects cwd in Claude; remove the override for its default profile.
+          unsetEnv: liveProfile === 'default' ? ['CLAUDE_CONFIG_DIR'] : [],
+        });
+      try {
+        mkdirSync(nodePath.join(directory, '.safeword'));
+        writeFileSync(
+          nodePath.join(directory, '.safeword/config.json'),
+          JSON.stringify({
+            crossAgentReviewRoutes: { codex: [{ reviewer, model }] },
+          }),
+        );
+        const ticketPath = '.project/tickets/LIVE01-semantic-proof';
+        mkdirSync(nodePath.join(directory, ticketPath), { recursive: true });
+        writeFileSync(
+          nodePath.join(directory, ticketPath, 'ticket.md'),
+          '---\nid: LIVE01\ntype: feature\nphase: plan-execution\nstatus: in_progress\n---\n',
+        );
+        writeFileSync(
+          nodePath.join(directory, ticketPath, 'execution-plan.md'),
+          testCase.execution_plan,
+        );
+        writeFileSync(
+          nodePath.join(directory, ticketPath, 'impl-plan.md'),
+          testCase.implementation_plan,
+        );
+        writeFileSync(nodePath.join(directory, 'scenario.feature'), testCase.scenario);
+        let result = await invoke([
+          'run',
+          'plan-execution',
+          `${ticketPath}/execution-plan.md`,
+          '--context',
+          `${ticketPath}/impl-plan.md`,
+          '--context',
+          'scenario.feature',
+        ]);
+        let response = JSON.parse(result.stdout);
+        const deadline = Date.now() + CLI_REVIEW_BOUND_MS + 15_000;
+        while (response.data?.status === 'pending') {
+          pendingId = response.data.review_id;
+          if (typeof pendingId !== 'string') throw new Error('Pending review omitted its ID');
+          if (Date.now() >= deadline)
+            throw new Error(`Live review ${pendingId} exceeded its bound`);
+          await delay(1000);
+          result = await invoke(['status', pendingId]);
+          response = JSON.parse(result.stdout);
+        }
+        pendingId = undefined;
+        process.stdout.write(`Live CLI evidence ${testCase.id}: ${JSON.stringify(response)}\n`);
+        expect(result.timedOut).toBe(false);
+        expect(response.errors, JSON.stringify(response)).toEqual([]);
+        expect(response.data?.actual_reviewer).toBe(reviewer);
+        expect(response.data?.independence).toBe('cross-agent');
+        expect(response.data?.status).toBe(
+          testCase.expectation.verdict === 'approve' ? 'approved' : 'changes_requested',
+        );
+        const output = response.data?.reviewer_output as ReviewerOutput;
+        expect(output, JSON.stringify(response)).toBeDefined();
+        expect(output.reviewer_agent).toBe(reviewer);
+        assertSemanticOutcome(testCase, output);
+        if (testCase.id.includes('discovery-returns-to-implementation-planning')) {
+          const applied = await runCli(
+            ['--json', '--no-input', 'ticket', 'approve-plan', 'LIVE01', '--cwd', directory],
+            {
+              cwd: directory,
+              env,
+              timeout: 30_000,
+              unsetEnv: liveProfile === 'default' ? ['CLAUDE_CONFIG_DIR'] : [],
+            },
+          );
+          const transition = JSON.parse(applied.stdout);
+          expect(transition.errors, applied.stdout).toEqual([]);
+          expect(transition.findings).toContainEqual(
+            expect.objectContaining({ code: 'EXECUTION_DISCOVERY_APPLIED' }),
+          );
+          expect(transition.data.planning_destination).toBe('plan-implementation');
+          expect(readFileSync(nodePath.join(directory, ticketPath, 'ticket.md'), 'utf8')).toContain(
+            'phase: plan-implementation',
+          );
+        }
+      } finally {
+        // The fixture owns exactly one job, including when initial dispatch times out
+        // before returning its ID. Cancel the latest local job before removing it.
+        const cancelled = await invoke(
+          pendingId === undefined ? ['cancel'] : ['cancel', pendingId],
+        );
+        expect(cancelled.timedOut, 'cancellation must settle before fixture cleanup').toBe(false);
+        removeTemporaryDirectory(directory);
+      }
+    },
+    CLI_REVIEW_BOUND_MS + 60_000,
+  );
+});
diff --git a/packages/cli/tsup.config.ts b/packages/cli/tsup.config.ts
index 4e87f8d32..a4fc216e1 100644
--- a/packages/cli/tsup.config.ts
+++ b/packages/cli/tsup.config.ts
@@ -222,7 +222,7 @@ export default defineConfig({
   // Exclude devDependencies that have native bindings from bundling
   // Recovery commands must still start when they are upgrading an older
   // dependency tree that predates our TOML parser dependency.
-  noExternal: ['smol-toml'],
+  noExternal: ['smol-toml', 'prettier/plugins/markdown'],
   skipNodeModulesBundle: true,
   define: {
     __SAFEWORD_BUILD_COMMIT__: JSON.stringify(buildCommit),
diff --git a/packages/website/src/content/docs/reference/cli.mdx b/packages/website/src/content/docs/reference/cli.mdx
index 53f5485c7..7d253a9b9 100644
--- a/packages/website/src/content/docs/reference/cli.mdx
+++ b/packages/website/src/content/docs/reference/cli.mdx
@@ -55,6 +55,7 @@ canonical commands below.
 | `ticket new`                            | mutate      | Create a project ticket                                                                                                                          |
 | `ticket reconcile-parent`               | mutate      | Record the current parent Product Plan contract                                                                                                  |
 | `ticket approve-plan`                   | mutate      | Record human authority for the current reviewed Implementation Plan                                                                              |
+| `ticket record-review-disposition`      | mutate      | Decline one optional reviewed suggestion                                                                                                         |
 | `ticket planning-contract-check`        | observe     | Check active planning author-copy integrity                                                                                                      |
 | `ticket delivery-checklist`             | observe     | Report feature delivery readiness                                                                                                                |
 | `ticket execution-prerequisite`         | observe     | Check whether feature execution planning is admitted                                                                                             |
diff --git a/plugin/identity.json b/plugin/identity.json
index 5d8e5e7eb..c63e76e67 100644
--- a/plugin/identity.json
+++ b/plugin/identity.json
@@ -2,5 +2,5 @@
   "schema_version": 1,
   "plugin_version": "1.1.0",
   "hook_manifest_sha256": "566e99f2ec53278b400dae1e54085940594048f0423787cc6863f3f543422756",
-  "inventory_sha256": "5464623e6dc2b3d2c808bc5d2ca7a2770bcb800a9a8e8df31811125366a2e6e7"
+  "inventory_sha256": "3f978b7294cec8676795d597867482b28535c72a0de08ad0b43ebbbe4d69c15e"
 }
diff --git a/plugin/inventory.json b/plugin/inventory.json
index a871782a1..172f7f800 100644
--- a/plugin/inventory.json
+++ b/plugin/inventory.json
@@ -155,7 +155,7 @@
     },
     {
       "path": "runtime/cli.js",
-      "sha256": "11b66874efe16834567ae6fba8f5fd8f66e1e35ea34339fe40c0c8b042685ebc"
+      "sha256": "38857d297c764b43ad3b6ece240ac1288a3cc0f056d510d7232bda0094c01643"
     },
     {
       "path": "runtime/dispatch.js",
diff --git a/steps/plan-implementation-phase.steps.ts b/steps/plan-implementation-phase.steps.ts
index 86d10abbe..b62ac024a 100644
--- a/steps/plan-implementation-phase.steps.ts
+++ b/steps/plan-implementation-phase.steps.ts
@@ -852,6 +852,16 @@ Given(
   function (this: PlanWorld) {
     createProject(this);
     seedTicket(this, { phase: 'plan-implementation', spec: true });
+    for (const [role, content] of Object.entries({
+      principles:
+        '# Principles\n\n## Preserve approval authority\n\nCurrent authenticated approval controls advancement.\n',
+      personas:
+        '# Personas\n\n## Builder (BU)\n\n**Role:** A builder requesting planning approval.\n**Context:** Needs current authenticated approval before advancement.\n',
+      surfaces:
+        '# Surfaces\n\n## Safeword CLI\n\n**Kind:** CLI\n**Description:** Requests and presents planning approval.\n**Audience:** Builder (BU)\n',
+    })) {
+      writeFileSync(nodePath.join(this.projectDirectory!, '.project', `${role}.md`), content);
+    }
     writeFileSync(ticketArtifact(this, 'impl-plan.md'), VALID_PLAN);
     const controlPluginRoot = nodePath.join(this.projectDirectory!, 'control-codex-plugin');
     const missingPluginRoot = nodePath.join(this.projectDirectory!, 'missing-codex-plugin');
