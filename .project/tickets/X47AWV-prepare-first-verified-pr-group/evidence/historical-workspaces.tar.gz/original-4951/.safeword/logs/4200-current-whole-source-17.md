Current PR5 complete unique-source review 17/19. Base 854a376861bc034d65cc81ddfa6a85d0ae55821e; head b722f9a27a1815abcfb08e6f6ca09dc7317efa46. Review actual correctness, authenticated approval, rejection findings and test discrimination. Every unique production source, template, test, step and generator changed in PR5 is supplied across these packets. Byte-identical installed mirrors and compiled bundles are omitted; all five generated surfaces passed at this head. Prior historical acceptance failures remain visible; full current run is in progress. Exactly 33 cases are user-deferred and unverified. This is source review, not native-host or merge approval. Flag only concrete in-scope defects; optional hardening does not block.

diff --git a/steps/keep-plan-reviews-native-disposition.steps.ts b/steps/keep-plan-reviews-native-disposition.steps.ts
new file mode 100644
index 000000000..a50613868
--- /dev/null
+++ b/steps/keep-plan-reviews-native-disposition.steps.ts
@@ -0,0 +1,347 @@
+import { strict as assert } from 'node:assert';
+import { spawnSync } from 'node:child_process';
+import { mkdirSync, readFileSync, readdirSync, rmSync, writeFileSync } from 'node:fs';
+import path from 'node:path';
+
+import { After, Given, Status, Then, When } from '@cucumber/cucumber';
+
+import { prepareReviewPacket } from '../packages/cli/src/review/packet.js';
+import { SAFEWORD_SCHEMA } from '../packages/cli/src/schema.js';
+import { resolveConfiguredPath } from '../packages/cli/src/utils/configured-paths.js';
+import { target } from '../packages/cli/tests/fixtures/planning-disposition.js';
+import { runCliWithLiteralArguments } from '../packages/cli/tests/helpers.js';
+import { createTrustedReviewerDirectory } from '../packages/cli/tests/review-fixtures.js';
+import {
+  prepareRecordedSuggestion,
+  recordedSuggestion,
+} from './keep-plan-reviews-disposition.steps.js';
+import {
+  dispatchInstalledPhaseExit,
+  nativeReviewEnvironment,
+  runJudgedNativeReview,
+  type NativeScopeState,
+} from './keep-plan-reviews-native-scope.steps.js';
+import { completeNativeScopeProject } from './support/planning-scope-project.js';
+import type { SafewordWorld } from './world.js';
+
+interface NativeDispositionState extends NativeScopeState {
+  captureDirectory: string;
+  reviewerSearchPath: string;
+  ticketBeforeReview: string;
+}
+const states = new WeakMap<SafewordWorld, NativeDispositionState>();
+
+function sentReviewPackets(state: NativeDispositionState) {
+  const packets = readdirSync(state.captureDirectory)
+    .map(file => readFileSync(path.join(state.captureDirectory, file), 'utf8').trim())
+    .flatMap(input =>
+      input
+        .split('\n')
+        .filter(Boolean)
+        .map(line => JSON.parse(line)),
+    )
+    .filter(message => message.method === 'turn/start')
+    .flatMap(message => message.params.input)
+    .filter(input => input.type === 'text')
+    .map(input => JSON.parse(input.text.trim().split('\n').at(-1)!));
+  assert.equal(packets.length, 3, 'Capture all three actual reviewer requests.');
+  return packets;
+}
+
+function shellQuote(value: string): string {
+  return `'${value.replaceAll("'", `'"'"'`)}'`;
+}
+
+function dispositionDispatch(root: string): string {
+  return dispatchInstalledPhaseExit(
+    root,
+    `${path.dirname(target)}/ticket.md`,
+    'plan-implementation',
+    'plan-execution',
+  );
+}
+
+async function prepareNativeDisposition(this: SafewordWorld, decision: 'declined' | 'pending') {
+  // The existing trusted reviewer process supplies only this initial warning.
+  // The later review under test uses the real qualified independent producer.
+  await prepareRecordedSuggestion(this);
+  const disposition = recordedSuggestion(this);
+  const { project } = disposition;
+  const installed = await runCliWithLiteralArguments(
+    ['install', '--agents', 'cursor', '--offline', '--no-input', '--json', '--cwd', project.root],
+    { cwd: project.root, env: nativeReviewEnvironment(project.root) },
+  );
+  assert.equal(installed.exitCode, 0, installed.stdout + installed.stderr);
+  mkdirSync(path.join(project.root, '.claude'), { recursive: true });
+  writeFileSync(
+    path.join(project.root, '.claude/settings.json'),
+    JSON.stringify(SAFEWORD_SCHEMA.jsonMerges['.claude/settings.json'].merge({})),
+  );
+  const configPath = path.join(project.root, '.safeword/config.json');
+  const config = JSON.parse(readFileSync(configPath, 'utf8'));
+  config.crossAgentReviewRoutes = { claude: [{ reviewer: 'codex', model: 'gpt-6.1-sol' }] };
+  writeFileSync(configPath, JSON.stringify(config));
+  const nativeProject = {
+    root: project.root,
+    planPath: target.replace('spec.md', 'impl-plan.md'),
+    input: { context: '', reviewed_plan: '' },
+  };
+  nativeProject.input = {
+    context: JSON.stringify(
+      prepareReviewPacket(project.root, 'plan-implementation', [nativeProject.planPath]).packet,
+    ),
+    reviewed_plan: readFileSync(path.join(project.root, nativeProject.planPath), 'utf8'),
+  };
+  // Completion reads this captured input to check that it preserves scope.
+  completeNativeScopeProject(nativeProject);
+  const planFile = path.join(project.root, nativeProject.planPath);
+  const plan = `${readFileSync(planFile, 'utf8')}
+
+## Accepted receipt and recovery decisions
+
+After the guarded write succeeds, the endpoint and CLI receipt identify the authenticated consenting owner using the existing trusted session owner label, never a caller-supplied label or a consent credential. The CLI-to-endpoint proof checks that the success receipt names that owner and discloses no token. Refusal, pre-commit failure and an uncertain post-commit result must not present a confirmed-success receipt.
+
+The recovery proof drives the real CLI through a pre-commit transient endpoint failure, establishes unchanged account state, then retries the same target change with valid owner consent and establishes one successful mutation. This sequence must fail if the failed attempt consumes consent or prevents recovery. It is separate from the post-commit uncertain-result proof, which permits no automatic retry or false no-mutation claim.
+`;
+  writeFileSync(planFile, plan);
+  // This is an explicit synthetic fixture premise, not a vendor claim.
+  const resolvedArchitecture = resolveConfiguredPath(project.root, 'architecture');
+  writeFileSync(
+    resolvedArchitecture,
+    `${readFileSync(resolvedArchitecture, 'utf8')}
+The existing authenticated session includes the consenting owner's display label; account-change presentation uses that trusted label and never accepts a caller-supplied replacement.
+`,
+  );
+  // The authenticated warning and explicit decline refer to the completed
+  // baseline. No fixture completion or plan correction follows the decline.
+  const seeded = await project.run([
+    'review',
+    'run',
+    'plan-implementation',
+    nativeProject.planPath,
+  ]);
+  assert.equal(seeded.exitCode, 0, seeded.stdout + seeded.stderr);
+  const seed = JSON.parse(seeded.stdout).data;
+  assert.equal(seed.status, 'approved');
+  assert.deepEqual(seed.reviewer_output.findings, [
+    { severity: 'warning', message: 'Consider adding optional multi-region failover.' },
+  ]);
+  const reviewId = seed.review_id;
+  disposition.plan = plan;
+  disposition.reviewId = reviewId;
+  if (decision === 'declined') {
+    const declined = project.terminal('y', reviewId);
+    assert.equal(declined.status, 0, declined.stdout + declined.stderr);
+    assert.match(declined.stdout, /"status":"recorded"/u);
+  }
+  assert.equal(readFileSync(planFile, 'utf8'), disposition.plan);
+  const packet = prepareReviewPacket(project.root, 'plan-implementation', [
+    nativeProject.planPath,
+  ]).packet;
+  const record = packet.review_disposition_context?.records[0];
+  if (decision === 'declined') {
+    assert.ok(record);
+    assert.equal(record.review_id, reviewId);
+    assert.equal(record.disposition, 'declined');
+    assert.equal(record.boundary_status, 'current');
+    assert.equal(record.message, 'Consider adding optional multi-region failover.');
+  } else {
+    assert.equal(record, undefined, 'An outstanding choice must not become a decline.');
+  }
+  nativeProject.input = {
+    context: JSON.stringify(packet),
+    reviewed_plan: readFileSync(path.join(project.root, nativeProject.planPath), 'utf8'),
+  };
+  assert.match(dispositionDispatch(project.root), /safeword review run plan-implementation/u);
+  const located = spawnSync('/bin/sh', ['-c', 'command -v codex'], { encoding: 'utf8' });
+  assert.equal(located.status, 0, located.stderr);
+  const binary = located.stdout.trim();
+  assert.ok(path.isAbsolute(binary), 'A real caller-selected Codex executable is required.');
+  const observer = createTrustedReviewerDirectory('safeword-r14-real-codex-');
+  const captureDirectory = path.join(project.root, '.safeword/state/r14-review-inputs');
+  mkdirSync(captureDirectory, { recursive: true });
+  // A local wire observer, not a reviewer mock: stdin is copied byte-for-byte
+  // to the actual caller-selected executable, with its stdout/exit unchanged.
+  writeFileSync(
+    path.join(observer, 'codex'),
+    `#!/bin/sh
+if [ "$1" = "app-server" ]; then
+  /usr/bin/tee ${shellQuote(path.join(captureDirectory, 'input-'))}"$$".txt | ${shellQuote(binary)} "$@"
+else
+  exec ${shellQuote(binary)} "$@"
+fi
+`,
+    { mode: 0o755 },
+  );
+  states.set(this, {
+    roots: [observer],
+    project: nativeProject,
+    caseId: decision === 'declined' ? 'r14-declined-strengthening' : 'r14-pending-strengthening',
+    runs: [],
+    captureDirectory,
+    reviewerSearchPath: `${observer}:${process.env.PATH ?? ''}`,
+    ticketBeforeReview: readFileSync(project.ticketPath, 'utf8'),
+  });
+}
+
+Given(
+  'the user recorded a decline for an optional strengthening under the current accepted boundary and left the plan unchanged',
+  { timeout: 60_000 },
+  async function (this: SafewordWorld) {
+    await prepareNativeDisposition.call(this, 'declined');
+  },
+);
+
+Given(
+  'a nonblocking suggestion outside the accepted boundary awaits a user decision',
+  { timeout: 60_000 },
+  async function (this: SafewordWorld) {
+    await prepareNativeDisposition.call(this, 'pending');
+  },
+);
+
+When(
+  'the unchanged plan is re-reviewed while that decision remains outstanding',
+  { timeout: 240_000 },
+  async function (this: SafewordWorld) {
+    const state = states.get(this);
+    assert.ok(state);
+    await runJudgedNativeReview(state, {
+      kind: 'plan-implementation',
+      phase: 'plan-implementation',
+      dispatch: dispositionDispatch,
+      reviewerSearchPath: state.reviewerSearchPath,
+    });
+  },
+);
+
+Then(
+  'the reviewed plan bytes remain unchanged, the gate does not block on or silently add the suggestion, and the outstanding choice is re-presented for the user to decide',
+  { timeout: 60_000 },
+  async function (this: SafewordWorld) {
+    const state = states.get(this);
+    assert.ok(state);
+    assert.ok(
+      state.runs.filter(
+        run =>
+          run.correct &&
+          run.output.verdict === 'approve' &&
+          run.output.findings.every(
+            finding =>
+              !/failover/iu.test(finding.message) || ['warning', 'info'].includes(finding.severity),
+          ) &&
+          run.stampStatus === 0 &&
+          !/deny/u.test(run.gate),
+      ).length >= 2,
+      JSON.stringify(state.runs),
+    );
+    const disposition = recordedSuggestion(this);
+    const presented = await disposition.project.run([
+      'ticket',
+      'record-review-disposition',
+      'DIS123',
+      disposition.reviewId,
+      '1',
+      '--reason',
+      'Outside the accepted scope.',
+    ]);
+    const result = JSON.parse(presented.stdout);
+    assert.equal(result.state, 'action_required');
+    assert.equal(result.data.status, 'pending');
+    assert.equal(result.data.review_id, disposition.reviewId);
+    assert.equal(result.data.finding, 'Consider adding optional multi-region failover.');
+    assert.equal(readFileSync(disposition.project.ticketPath, 'utf8'), state.ticketBeforeReview);
+    assert.equal(
+      readFileSync(path.join(state.project.root, state.project.planPath), 'utf8'),
+      disposition.plan,
+    );
+    const packet = prepareReviewPacket(state.project.root, 'plan-implementation', [
+      state.project.planPath,
+    ]).packet;
+    assert.equal(packet.review_disposition_context?.records.length ?? 0, 0);
+    for (const dispatched of sentReviewPackets(state))
+      assert.equal(
+        dispatched.review_disposition_context?.records.length ?? 0,
+        0,
+        'The actual reviewer must not receive an invented decline.',
+      );
+  },
+);
+
+When(
+  'a later judged re-review runs through installed local project hooks with real configuration and collaborators, mocking only non-reviewer process boundaries',
+  { timeout: 240_000 },
+  async function (this: SafewordWorld) {
+    const state = states.get(this);
+    assert.ok(state);
+    await runJudgedNativeReview(state, {
+      kind: 'plan-implementation',
+      phase: 'plan-implementation',
+      dispatch: dispositionDispatch,
+      reviewerSearchPath: state.reviewerSearchPath,
+    });
+  },
+);
+
+Then(
+  'the decline is supplied to the reviewer, the suggestion remains nonblocking, and any approval is recorded against the unchanged plan bytes',
+  function (this: SafewordWorld) {
+    const state = states.get(this);
+    assert.ok(state);
+    assert.ok(
+      state.runs.filter(
+        run =>
+          run.correct &&
+          run.output.verdict === 'approve' &&
+          run.output.findings.every(
+            finding =>
+              !/failover/iu.test(finding.message) || ['warning', 'info'].includes(finding.severity),
+          ) &&
+          run.stampStatus === 0 &&
+          !/deny/u.test(run.gate),
+      ).length >= 2,
+      JSON.stringify(state.runs),
+    );
+    for (const packet of sentReviewPackets(state)) {
+      assert.ok(
+        packet.review_disposition_context.records.some(
+          (record: {
+            review_id: string;
+            disposition: string;
+            boundary_status: string;
+            message: string;
+          }) =>
+            record.review_id === recordedSuggestion(this).reviewId &&
+            record.disposition === 'declined' &&
+            record.boundary_status === 'current' &&
+            record.message === 'Consider adding optional multi-region failover.',
+        ),
+        'The real dispatched packet must contain the current decline.',
+      );
+    }
+    const packet = prepareReviewPacket(state.project.root, 'plan-implementation', [
+      state.project.planPath,
+    ]).packet;
+    assert.equal(packet.review_disposition_context?.records[0]?.disposition, 'declined');
+    assert.equal(packet.review_disposition_context?.records[0]?.boundary_status, 'current');
+    assert.equal(
+      readFileSync(path.join(state.project.root, state.project.planPath), 'utf8'),
+      state.project.input.reviewed_plan,
+    );
+    assert.equal(
+      readFileSync(path.join(state.project.root, state.project.planPath), 'utf8'),
+      recordedSuggestion(this).plan,
+    );
+  },
+);
+
+After(function (this: SafewordWorld, scenario) {
+  if (scenario.result?.status === Status.FAILED) {
+    console.error(
+      `Retained reviewer inputs: ${states.get(this)?.captureDirectory ?? 'setup failed'}`,
+    );
+  }
+  for (const observer of states.get(this)?.roots ?? [])
+    rmSync(observer, { recursive: true, force: true });
+  states.delete(this);
+});
diff --git a/steps/keep-plan-reviews-native-product.steps.ts b/steps/keep-plan-reviews-native-product.steps.ts
new file mode 100644
index 000000000..28c7faf73
--- /dev/null
+++ b/steps/keep-plan-reviews-native-product.steps.ts
@@ -0,0 +1,191 @@
+import { strict as assert } from 'node:assert';
+import { mkdirSync, readFileSync, rmSync, writeFileSync } from 'node:fs';
+import path from 'node:path';
+
+import { After, Given, Then, When } from '@cucumber/cucumber';
+
+import { prepareReviewPacket } from '../packages/cli/src/review/packet.js';
+import { SAFEWORD_SCHEMA } from '../packages/cli/src/schema.js';
+import { resolveConfiguredPath } from '../packages/cli/src/utils/configured-paths.js';
+import { evaluateFeatureTicketReadiness } from '../packages/cli/templates/hooks/lib/active-ticket.js';
+import { planningContractCases } from '../packages/cli/tests/fixtures/planning-contracts-eval.js';
+import { runCliWithLiteralArguments } from '../packages/cli/tests/helpers.js';
+import { fixtureProject } from './keep-plan-reviews-installed-context.steps.js';
+import {
+  dispatchInstalledPhaseExit,
+  nativeReviewEnvironment,
+  runJudgedNativeReview,
+  type NativeScopeState,
+} from './keep-plan-reviews-native-scope.steps.js';
+import type { SafewordWorld } from './world.js';
+
+const folder = 'CTX123-current-context';
+const states = new WeakMap<SafewordWorld, NativeScopeState>();
+
+function productDispatch(root: string): string {
+  return dispatchInstalledPhaseExit(
+    root,
+    `.project/tickets/${folder}/ticket.md`,
+    'intake',
+    'define-behavior',
+  );
+}
+
+Given(
+  /^a Product Plan in the installed Claude Code workflow (inventories every accepted persona's consequential outcomes|omits the Non-Technical Builder's recovery outcome)$/u,
+  { timeout: 60_000 },
+  async function (this: SafewordWorld, inventory: string) {
+    const root = fixtureProject();
+    const planPath = `.project/tickets/${folder}/spec.md`;
+    const caseId = inventory.startsWith('inventories')
+      ? 'r16-complete-persona-outcomes'
+      : 'r16-missing-persona-recovery';
+    const evaluation = planningContractCases.find(item => item.id === caseId);
+    assert.ok(evaluation);
+    const state: NativeScopeState = {
+      roots: [root],
+      project: { root, planPath, input: { context: '', reviewed_plan: '' } },
+      caseId,
+      runs: [],
+    };
+    states.set(this, state);
+    const installed = await runCliWithLiteralArguments(
+      ['install', '--agents', 'cursor', '--offline', '--no-input', '--json', '--cwd', root],
+      { cwd: root, env: nativeReviewEnvironment(root) },
+    );
+    assert.equal(installed.exitCode, 0, installed.stdout + installed.stderr);
+    mkdirSync(path.join(root, '.claude'), { recursive: true });
+    writeFileSync(
+      path.join(root, '.claude/settings.json'),
+      JSON.stringify(SAFEWORD_SCHEMA.jsonMerges['.claude/settings.json'].merge({})),
+    );
+    const configPath = path.join(root, '.safeword/config.json');
+    const config = JSON.parse(readFileSync(configPath, 'utf8'));
+    config.crossAgentReviewRoutes = { claude: [{ reviewer: 'codex', model: 'gpt-6.1-sol' }] };
+    writeFileSync(configPath, JSON.stringify(config));
+    writeFileSync(
+      path.join(root, '.project/tickets', folder, 'ticket.md'),
+      `---
+id: CTX123
+type: feature
+phase: intake
+status: in_progress
+product_plan_contract: v1
+scope: manual owner-authorized account changes for Technical Builder and Non-Technical Builder
+out_of_scope: automatic migration, background mutation, batching and token disclosure
+done_when: authorized changes succeed and denied changes leave the account intact for both personas
+---
+`,
+    );
+    writeFileSync(
+      resolveConfiguredPath(root, 'personas'),
+      '# Personas\n\n## Technical Builder (TB)\n\n**Role:** Developer using the manual account CLI.\n**Context:** Needs owner-authorized changes and recovery.\n\n## Non-Technical Builder (NTB)\n\n**Role:** Operator using the manual account CLI.\n**Context:** Needs owner-authorized changes and recovery.\n',
+    );
+    writeFileSync(
+      resolveConfiguredPath(root, 'surfaces'),
+      '# Surfaces\n\n## Account CLI\n\n**Kind:** CLI\n**Description:** Requests a manual account change and presents its receipt or refusal.\n**Audience:** Technical Builder (TB), Non-Technical Builder (NTB)\n',
+    );
+    const jobs = ['Technical Builder (TB)', 'Non-Technical Builder (NTB)']
+      .map((persona, index) => {
+        const id = `account.${index === 0 ? 'TB' : 'NTB'}1`;
+        return `### ${id} — Make an owner-authorized account change
+**Persona:** ${persona}
+> When I request a manual account change, I want only an explicitly authorized change to take effect, so I can trust the account remains intact on refusal or failure.
+#### ${id}.R1 — Preserve owner consent
+The owner authorizes one target change. Absent, expired or mismatched consent permits no mutation. The receipt names the consenting owner without exposing the token.
+`;
+      })
+      .join('\n');
+    const plan = `# Product Plan: Safe manual account changes
+<!-- safeword:product-plan-contract:v1 -->
+## Intake Brief
+Both named builders need to make a manual change safely. A refused or failed change must not alter the account. This behavior is reversible before acceptance; no shipping claim is made.
+## Product Bet
+- **Expected outcome:** Both accepted personas can make a safe manual account change.
+- **Persona outcome inventory:** ${evaluation.reviewed_plan.replace('Non-Technical Builder recovery is absent. ', '')}
+- **Known facts:** Account changes require explicit owner authorization.
+- **Assumptions:** The existing consent-token API can support the approved experience.
+- **Unresolved product decisions:** The exact approval copy remains with the product owner before shipping.
+- **Success threshold:** Authorized changes succeed; refused or failed changes leave the account intact.
+- **Project non-goals:** No automatic migration, background mutation, batching or token disclosure.
+## Jobs To Be Done
+${jobs}
+## Shape
+### M1 — Safe manual changes
+- **Outcome:** Each accepted persona receives a manual authorized change or a named refusal/error.
+- **Non-goals:** Automatic migration, background mutation, batching and token disclosure.
+## Surfaces
+Affected:
+- Account CLI
+`;
+    writeFileSync(path.join(root, planPath), plan);
+    writeFileSync(
+      path.join(root, '.project/tickets', folder, 'dimensions.md'),
+      '# Behavior dimensions\n\n| Dimension | Partitions |\n| --- | --- |\n| Persona | Technical Builder, Non-Technical Builder |\n| Consent | valid, refused, expired, mismatched |\n| Endpoint | success, transient failure |\n\nThese are prospective partitions for scenario definition; no scenario coverage or execution is claimed.\n',
+    );
+    const readiness = evaluateFeatureTicketReadiness(root, folder);
+    assert.equal(readiness.ok, true, JSON.stringify(readiness.issues));
+    assert.match(productDispatch(root), /deny/u, 'No review receipt exists before dispatch.');
+    const packet = prepareReviewPacket(root, 'quality-review', [planPath]).packet;
+    assert.equal(packet.planning_phase, 'product-plan');
+    state.project.input = { context: JSON.stringify(packet), reviewed_plan: plan };
+  },
+);
+
+When(
+  'actual lifecycle dispatch from installed local project hooks runs its judged Product Plan review with real configuration and collaborators, mocking only non-reviewer process boundaries',
+  { timeout: 240_000 },
+  async function (this: SafewordWorld) {
+    const state = states.get(this);
+    assert.ok(state);
+    await runJudgedNativeReview(state, {
+      kind: 'quality-review',
+      phase: 'intake',
+      dispatch: productDispatch,
+    });
+  },
+);
+
+Then('Product Plan approval proceeds', function (this: SafewordWorld) {
+  const state = states.get(this);
+  assert.ok(state);
+  assert.ok(
+    state.runs.filter(
+      run =>
+        run.correct &&
+        run.output.verdict === 'approve' &&
+        run.stampStatus === 0 &&
+        !/deny/u.test(run.gate),
+    ).length >= 2,
+    JSON.stringify(state.runs),
+  );
+});
+
+Then(
+  'Product Plan approval remains blocked with the missing persona outcome named',
+  function (this: SafewordWorld) {
+    const state = states.get(this);
+    assert.ok(state);
+    assert.ok(
+      state.runs.filter(
+        run =>
+          run.correct &&
+          run.output.verdict === 'request_changes' &&
+          run.stampStatus !== 0 &&
+          /did not approve \(status: changes_requested\)/u.test(run.stampOutput) &&
+          /deny/u.test(run.gate) &&
+          run.output.findings.some(finding =>
+            /Non[- ]Technical Builder.*recover|recover.*Non[- ]Technical Builder/iu.test(
+              finding.message,
+            ),
+          ),
+      ).length >= 2,
+      JSON.stringify(state.runs),
+    );
+  },
+);
+
+After(function (this: SafewordWorld) {
+  for (const root of states.get(this)?.roots ?? []) rmSync(root, { recursive: true, force: true });
+  states.delete(this);
+});
diff --git a/steps/keep-plan-reviews-native-scope.steps.ts b/steps/keep-plan-reviews-native-scope.steps.ts
new file mode 100644
index 000000000..6f37a1f51
--- /dev/null
+++ b/steps/keep-plan-reviews-native-scope.steps.ts
@@ -0,0 +1,426 @@
+import { strict as assert } from 'node:assert';
+import { spawnSync } from 'node:child_process';
+import { mkdirSync, readFileSync, rmSync, writeFileSync } from 'node:fs';
+import path from 'node:path';
+
+import { After, Given, Status, Then, When } from '@cucumber/cucumber';
+
+import { planningJudgePrompt } from '../packages/cli/scripts/lib/planning-contracts-eval.js';
+import { callClaude } from '../packages/cli/scripts/lib/planning-eval-provider.js';
+import { SAFEWORD_SCHEMA } from '../packages/cli/src/schema.js';
+import { prepareReviewPacket } from '../packages/cli/src/review/packet.js';
+import { parseImplPlan } from '../packages/cli/templates/hooks/lib/impl-plan.js';
+import type { ReviewerOutput } from '../packages/cli/src/review/contract.js';
+import { runCliWithLiteralArguments } from '../packages/cli/tests/helpers.js';
+import { planningContractCases } from '../packages/cli/tests/fixtures/planning-contracts-eval.js';
+import {
+  completeNativeScopeProject,
+  createScopeContextProject,
+} from './support/planning-scope-project.js';
+import type { SafewordWorld } from './world.js';
+
+const hostClaudeConfigDir = process.env.CLAUDE_CONFIG_DIR;
+const hostCodexHome = process.env.CODEX_HOME;
+const folder = 'CTX123-current-context';
+const states = new WeakMap<SafewordWorld, NativeScopeState>();
+
+export interface NativeScopeState {
+  roots: string[];
+  project: ReturnType<typeof createScopeContextProject>;
+  caseId: string;
+  runs: {
+    output: ReviewerOutput;
+    correct: boolean;
+    judgeReason: string;
+    gate: string;
+    stampStatus: number | null;
+    stampOutput: string;
+  }[];
+}
+
+export function nativeReviewEnvironment(root: string): Record<string, string> {
+  return {
+    NODE_ENV: 'test',
+    XDG_STATE_HOME: path.join(root, '.review-keys'),
+    CLAUDE_PROJECT_DIR: root,
+    CLAUDE_SESSION_ID: 'r12-native-scope',
+    // Use the current generated distribution, outside the reviewed project.
+    // The released plugin has a different planning contract from this branch.
+    CLAUDE_PLUGIN_ROOT: path.resolve(import.meta.dirname, '../plugin'),
+    // The author/session boundary is the only simulated collaborator. The
+    // coordinator launches a real, independently qualified Sol reviewer.
+    SAFEWORD_AGENT_RUNTIME: 'claude',
+    SAFEWORD_AUTHOR_MODEL: 'claude-opus-5',
+    SAFEWORD_NO_UPDATE_CHECK: '1',
+    PATH: process.env.PATH ?? '',
+    ...(hostClaudeConfigDir === undefined ? {} : { CLAUDE_CONFIG_DIR: hostClaudeConfigDir }),
+  };
+}
+
+export function dispatchInstalledPhaseExit(
+  root: string,
+  ticketPath: string,
+  from: string,
+  to: string,
+): string {
+  const settings = JSON.parse(readFileSync(path.join(root, '.claude/settings.json'), 'utf8'));
+  const command = settings.hooks.PreToolUse.flatMap(
+    (group: { hooks: { command: string }[] }) => group.hooks,
+  ).find((hook: { command: string }) => hook.command.includes('pre-tool-quality.ts')).command;
+  const result = spawnSync('/bin/sh', ['-c', command], {
+    cwd: root,
+    env: { ...process.env, ...nativeReviewEnvironment(root) },
+    encoding: 'utf8',
+    timeout: 60_000,
+    input: JSON.stringify({
+      cwd: root,
+      session_id: 'r12-native-scope',
+      hook_event_name: 'PreToolUse',
+      tool_name: 'Edit',
+      tool_input: {
+        file_path: path.join(root, ticketPath),
+        old_string: `phase: ${from}`,
+        new_string: `phase: ${to}`,
+      },
+    }),
+  });
+  assert.equal(result.error, undefined, result.error?.message);
+  assert.equal(result.status, 0, result.stderr);
+  return result.stdout.trim();
+}
+
+function dispatch(root: string): string {
+  return dispatchInstalledPhaseExit(
+    root,
+    `.project/tickets/${folder}/ticket.md`,
+    'plan-implementation',
+    'plan-execution',
+  );
+}
+
+async function prepareNativeScope(world: SafewordWorld, caseId: string) {
+  const roots: string[] = [];
+  const project = createScopeContextProject(
+    caseId.startsWith('r12-') ? caseId : 'r12-complete-scope-context',
+    roots,
+  );
+  states.set(world, { roots, project, caseId, runs: [] });
+  const installed = await runCliWithLiteralArguments(
+    ['install', '--agents', 'cursor', '--offline', '--no-input', '--json', '--cwd', project.root],
+    { cwd: project.root, env: nativeReviewEnvironment(project.root) },
+  );
+  assert.equal(installed.exitCode, 0, installed.stdout + installed.stderr);
+  mkdirSync(path.join(project.root, '.claude'), { recursive: true });
+  writeFileSync(
+    path.join(project.root, '.claude/settings.json'),
+    JSON.stringify(SAFEWORD_SCHEMA.jsonMerges['.claude/settings.json'].merge({})),
+  );
+  const configPath = path.join(project.root, '.safeword/config.json');
+  const config = JSON.parse(readFileSync(configPath, 'utf8'));
+  config.crossAgentReviewRoutes = { claude: [{ reviewer: 'codex', model: 'gpt-6.1-sol' }] };
+  writeFileSync(configPath, JSON.stringify(config));
+  completeNativeScopeProject(project);
+  if (caseId === 'r11-unmet-accepted-requirement' || caseId === 'r13-in-scope-omission') {
+    const file = path.join(project.root, project.planPath);
+    const plan = readFileSync(file, 'utf8');
+    const authorization =
+      'checks a consent token linked to the requesting user and target account before any write';
+    assert.ok(plan.includes(authorization));
+    writeFileSync(
+      file,
+      plan.replace(
+        authorization,
+        'writes account changes without checking consent, leaving the user/target authorization binding unresolved',
+      ),
+    );
+  }
+  if (caseId === 'r13-out-of-scope-addition') {
+    const file = path.join(project.root, project.planPath);
+    writeFileSync(
+      file,
+      readFileSync(file, 'utf8') +
+        '\n## Additional capability\nImplement automatic migration of existing accounts as part of this feature, despite the ticket exclusion.\n',
+    );
+  }
+  const reconciled = await runCliWithLiteralArguments(
+    ['ticket', 'reconcile-parent', 'CTX123', '--accept', '--json', '--cwd', project.root],
+    { cwd: project.root, env: nativeReviewEnvironment(project.root) },
+  );
+  assert.equal(reconciled.exitCode, 0, reconciled.stdout + reconciled.stderr);
+  const packet = prepareReviewPacket(
+    project.root,
+    'plan-implementation',
+    [project.planPath],
+    [],
+  ).packet;
+  project.input = {
+    context: JSON.stringify({
+      planning_context: packet.planning_context,
+      logical_files: packet.logical_files,
+      context_files: packet.context_files,
+    }),
+    reviewed_plan: readFileSync(path.join(project.root, project.planPath), 'utf8'),
+  };
+  assert.deepEqual(parseImplPlan(project.input.reviewed_plan).errors, []);
+  const initialGate = dispatch(project.root);
+  assert.match(initialGate, /deny/u);
+  assert.match(initialGate, /safeword review run plan-implementation/u);
+}
+
+Given(
+  /^an Implementation Plan in the installed Claude Code workflow has a review packet that (contains every binding scope source|omits the project non-goals)$/u,
+  async function (this: SafewordWorld, context: string) {
+    await prepareNativeScope(
+      this,
+      context === 'contains every binding scope source'
+        ? 'r12-complete-scope-context'
+        : 'r12-missing-project-non-goals',
+    );
+  },
+);
+
+Given(
+  /^an Implementation Plan in the installed Claude Code workflow (satisfies every requirement accepted upstream|leaves a requirement accepted upstream unmet|covers every accepted behavior without adding excluded behavior|omits an accepted behavior|adds an excluded behavior)$/u,
+  async function (this: SafewordWorld, state: string) {
+    const cases: Record<string, string> = {
+      'satisfies every requirement accepted upstream': 'r13-conforming-boundary',
+      'leaves a requirement accepted upstream unmet': 'r11-unmet-accepted-requirement',
+      'covers every accepted behavior without adding excluded behavior': 'r13-conforming-boundary',
+      'omits an accepted behavior': 'r13-in-scope-omission',
+      'adds an excluded behavior': 'r13-out-of-scope-addition',
+    };
+    await prepareNativeScope(this, cases[state]);
+  },
+);
+
+export async function runJudgedNativeReview(
+  state: NativeScopeState,
+  options: {
+    kind: 'plan-implementation' | 'quality-review';
+    phase: 'plan-implementation' | 'intake';
+    dispatch: (root: string) => string;
+    reviewerSearchPath?: string;
+  },
+): Promise<void> {
+  const { project } = state;
+  const original = readFileSync(path.join(project.root, project.planPath), 'utf8');
+  const evaluationCase = planningContractCases.find(item => item.id === state.caseId);
+  assert.ok(evaluationCase);
+  const judgeCase = {
+    ...evaluationCase,
+    ...project.input,
+    accepted_boundary: evaluationCase.accepted_boundary.replaceAll(
+      'manual.BU1.R1',
+      'approval.BU1.CTX123.R1',
+    ),
+    allowed_finding_authority: evaluationCase.allowed_finding_authority.replaceAll(
+      'manual.BU1.R1',
+      'approval.BU1.CTX123.R1',
+    ),
+  };
+  const judgeEnvironment = { ...process.env };
+  if (hostClaudeConfigDir === undefined) delete judgeEnvironment.CLAUDE_CONFIG_DIR;
+  else judgeEnvironment.CLAUDE_CONFIG_DIR = hostClaudeConfigDir;
+  const schema = {
+    type: 'object',
+    additionalProperties: false,
+    properties: { correct: { type: 'boolean' }, reason: { type: 'string' } },
+    required: ['correct', 'reason'],
+  };
+  const calibration = callClaude(
+    'claude-sonnet-5',
+    planningJudgePrompt(
+      judgeCase,
+      {
+        verdict: evaluationCase.expected_verdict === 'approve' ? 'request_changes' : 'approve',
+        summary: 'Require automatic migration outside accepted scope.',
+        findings: ['Require automatic migration.'],
+      },
+      'codex',
+    ),
+    schema,
+    judgeEnvironment,
+  ) as { correct: boolean };
+  assert.equal(calibration.correct, false, 'The judge must reject known-bad output.');
+  for (let index = 0; index < 3; index++) {
+    const result = await runCliWithLiteralArguments(
+      [
+        'review',
+        'run',
+        options.kind,
+        project.planPath,
+        '--json',
+        '--no-input',
+        '--cwd',
+        project.root,
+      ],
+      {
+        cwd: project.root,
+        env: {
+          ...nativeReviewEnvironment(project.root),
+          ...(options.reviewerSearchPath === undefined ? {} : { PATH: options.reviewerSearchPath }),
+          ...(hostCodexHome === undefined ? {} : { CODEX_HOME: hostCodexHome }),
+        },
+        unsetEnv: [
+          ...(hostClaudeConfigDir === undefined ? ['CLAUDE_CONFIG_DIR'] : []),
+          ...(hostCodexHome === undefined ? ['CODEX_HOME'] : []),
+        ],
+        timeout: 120_000,
+      },
+    );
+    const data = JSON.parse(result.stdout).data;
+    assert.ok(data.reviewer_output, result.stdout + result.stderr);
+    assert.equal(data.actual_reviewer, 'codex');
+    assert.equal(data.reviewer_model, 'gpt-6.1-sol');
+    assert.deepEqual(data.confirmed_reviewer_model, { provider: 'openai', model: 'gpt-6.1-sol' });
+    assert.equal(data.independence, 'cross-agent');
+    // The coordinator authenticated this dispatch. The separately prepared
+    // fixture packet has the same semantic inputs but its own correlation ID.
+    const dispatchedCase = {
+      ...judgeCase,
+      context: JSON.stringify({
+        ...JSON.parse(judgeCase.context),
+        dispatch_id: data.reviewer_output.dispatch_id,
+      }),
+    };
+    const grade = callClaude(
+      'claude-sonnet-5',
+      planningJudgePrompt(dispatchedCase, data.reviewer_output, 'codex'),
+      schema,
+      judgeEnvironment,
+    ) as { correct: boolean; reason: string };
+    assert.equal(typeof grade.correct, 'boolean');
+    assert.equal(typeof grade.reason, 'string');
+    const stamped = spawnSync(
+      'bun',
+      [
+        path.join(project.root, '.safeword/hooks/write-review-stamp.ts'),
+        '--ticket',
+        path.basename(path.dirname(project.planPath)),
+        '--phase',
+        options.phase,
+        '--review-id',
+        data.review_id,
+        '--author-agent',
+        data.author_agent,
+        '--reviewer-agent',
+        data.actual_reviewer,
+        '--independence',
+        data.independence,
+        '--model',
+        data.reviewer_model,
+      ],
+      {
+        cwd: project.root,
+        env: { ...process.env, ...nativeReviewEnvironment(project.root) },
+        encoding: 'utf8',
+        timeout: 60_000,
+      },
+    );
+    assert.equal(stamped.error, undefined, stamped.error?.message);
+    state.runs.push({
+      output: data.reviewer_output,
+      correct: grade.correct,
+      judgeReason: grade.reason,
+      gate: options.dispatch(project.root),
+      stampStatus: stamped.status,
+      stampOutput: stamped.stdout + stamped.stderr,
+    });
+    assert.equal(readFileSync(path.join(project.root, project.planPath), 'utf8'), original);
+  }
+}
+
+When(
+  'actual lifecycle dispatch from installed local project hooks runs its judged Implementation Plan review with real configuration and collaborators, mocking only non-reviewer process boundaries',
+  { timeout: 240_000 },
+  async function (this: SafewordWorld) {
+    const state = states.get(this);
+    assert.ok(state);
+    await runJudgedNativeReview(state, {
+      kind: 'plan-implementation',
+      phase: 'plan-implementation',
+      dispatch,
+    });
+  },
+);
+
+Then('Implementation Plan review dispatch proceeds', function (this: SafewordWorld) {
+  const state = states.get(this);
+  assert.ok(state);
+  assert.ok(
+    state.runs.filter(
+      run =>
+        run.correct && run.output.verdict === 'approve' && run.output.reviewer_agent === 'codex',
+    ).length >= 2,
+    JSON.stringify(state.runs),
+  );
+});
+
+Then('Implementation Plan approval proceeds', function (this: SafewordWorld) {
+  const state = states.get(this);
+  assert.ok(state);
+  assert.ok(
+    state.runs.filter(
+      run =>
+        run.correct &&
+        run.output.verdict === 'approve' &&
+        run.stampStatus === 0 &&
+        !/deny/u.test(run.gate),
+    ).length >= 2,
+    JSON.stringify(state.runs),
+  );
+});
+
+Then(
+  /^Implementation Plan approval remains blocked with (the violated Rule and unmet requirement|the omission|the overreach) named$/u,
+  function (this: SafewordWorld, defect: string) {
+    const state = states.get(this);
+    assert.ok(state);
+    const namedDefect =
+      defect === 'the overreach'
+        ? /(?:automatic|automatically).{0,40}migrat/iu
+        : defect === 'the omission'
+          ? /consent|authoriz/iu
+          : /(?=.*approval\.BU1\.CTX123\.R1)(?=.*(?:consent|authoriz))(?=.*(?:unresolved|binding|bound|unchecked|without))/isu;
+    assert.ok(
+      state.runs.filter(
+        run =>
+          run.correct &&
+          run.output.verdict === 'request_changes' &&
+          run.stampStatus !== 0 &&
+          /did not approve \(status: changes_requested\)/u.test(run.stampOutput) &&
+          /deny/u.test(run.gate) &&
+          run.output.findings.some(finding => namedDefect.test(finding.message)),
+      ).length >= 2,
+      JSON.stringify(state.runs),
+    );
+  },
+);
+
+Then(
+  'Implementation Plan approval remains blocked with the missing project boundary named',
+  function (this: SafewordWorld) {
+    const state = states.get(this);
+    assert.ok(state);
+    assert.ok(
+      state.runs.filter(
+        run =>
+          run.correct &&
+          run.output.verdict === 'request_changes' &&
+          run.stampStatus !== 0 &&
+          /did not approve \(status: changes_requested\)/u.test(run.stampOutput) &&
+          /deny/u.test(run.gate) &&
+          run.output.findings.some(finding => /project non.goals?/iu.test(finding.message)),
+      ).length >= 2,
+      JSON.stringify(state.runs),
+    );
+  },
+);
+
+After(function (this: SafewordWorld, { result }) {
+  const state = states.get(this);
+  if (state && result?.status === Status.FAILED)
+    console.error(`Native scope diagnostic fixture retained: ${state.project.root}`);
+  else if (state) for (const root of state.roots) rmSync(root, { recursive: true, force: true });
+  states.delete(this);
+});
diff --git a/steps/keep-plan-reviews-persona-coverage.steps.ts b/steps/keep-plan-reviews-persona-coverage.steps.ts
new file mode 100644
index 000000000..920d9bc93
--- /dev/null
+++ b/steps/keep-plan-reviews-persona-coverage.steps.ts
@@ -0,0 +1,56 @@
+import { strict as assert } from 'node:assert';
+
+import { Given, Then, When } from '@cucumber/cucumber';
+
+import {
+  assertPlanningEval,
+  runPlanningEval,
+  selectPlanningEval,
+} from './support/planning-eval.js';
+import type { SafewordWorld } from './world.js';
+
+const cases = {
+  'has at least one accepted scenario for every applicable outcome':
+    'r16-scenario-complete-coverage',
+  'has no accepted scenario for the Non-Technical Builder recovery outcome':
+    'r16-scenario-missing-recovery',
+} as const;
+
+Given(
+  /^an approved Product Plan persona-outcome inventory (.+)$/u,
+  function (this: SafewordWorld, coverage: keyof typeof cases) {
+    const selected = selectPlanningEval(this, cases[coverage]);
+    assert.equal(selected.kind, 'scenario-gate');
+    assert.match(
+      selected.context,
+      /Non-Technical Builder recovery returns to a pending change after obtaining fresh consent/u,
+    );
+    const hasRecovery = selected.reviewed_plan.includes('Scenario: Non-Technical Builder Recovery');
+    assert.equal(hasRecovery, selected.expected_verdict === 'approve');
+  },
+);
+
+When(
+  'the scenario gate evaluates behavior coverage',
+  { timeout: 240_000 },
+  function (this: SafewordWorld) {
+    runPlanningEval(this);
+  },
+);
+
+Then('scenario coverage does not block approval', function (this: SafewordWorld) {
+  assertPlanningEval(this, 'approve');
+});
+
+Then(
+  'scenario approval is blocked with that uncovered recovery outcome named',
+  function (this: SafewordWorld) {
+    const runs = assertPlanningEval(this, 'request_changes');
+    const namesRecovery = /Non[- ]Technical Builder.*recover|recover.*Non[- ]Technical Builder/iu;
+    assert.ok(
+      runs.filter(run => run.reviewer.findings.some(finding => namesRecovery.test(finding)))
+        .length >= 2,
+      'At least two correct judged rejections must name this persona and recovery in one finding.',
+    );
+  },
+);
diff --git a/steps/keep-plan-reviews-premature-fallback.steps.ts b/steps/keep-plan-reviews-premature-fallback.steps.ts
new file mode 100644
index 000000000..e8db3f763
--- /dev/null
+++ b/steps/keep-plan-reviews-premature-fallback.steps.ts
@@ -0,0 +1,184 @@
+import { strict as assert } from 'node:assert';
+import { existsSync, readFileSync, writeFileSync } from 'node:fs';
+import path from 'node:path';
+
+import { After, Given, Then, When } from '@cucumber/cucumber';
+
+import { installedReviewCli } from '../packages/cli/tests/fixtures/execution-review.js';
+import { reviewerScript } from '../packages/cli/tests/fixtures/planning-reviewers.js';
+import { prepare } from './keep-plan-reviews-independence.steps.js';
+import type { SafewordWorld } from './world.js';
+
+type State = Awaited<ReturnType<typeof prepare>> & { release: string; reviewId?: string };
+const states = new WeakMap<SafewordWorld, State>();
+const folder = '.project/tickets/CTX123-current-context';
+
+Given(
+  'at least one independent reviewer route remains available and unattempted',
+  { timeout: 120_000 },
+  async function (this: SafewordWorld) {
+    const base = await prepare(this, true);
+    const release = `${base.marker}-release`;
+    const state = Object.assign(base, { release });
+    states.set(this, state);
+    const configPath = path.join(state.root, '.safeword/config.json');
+    const config = JSON.parse(readFileSync(configPath, 'utf8'));
+    config.crossAgentReviewRoutes.claude = [
+      { reviewer: 'claude' },
+      { reviewer: 'codex', model: 'gpt-6.1-sol' },
+    ];
+    writeFileSync(configPath, JSON.stringify(config));
+    state.fallbackMarker = `${state.marker}-headless`;
+    writeFileSync(
+      path.join(path.dirname(state.marker), 'claude'),
+      reviewerScript(
+        'claude',
+        state.fallbackMarker,
+        `${state.fallbackMarker}.packet`,
+        false,
+        false,
+      ),
+      { mode: 0o755 },
+    );
+    const producer = reviewerScript('codex', state.marker, `${state.marker}.packet`, false, true);
+    const held = producer.replace(
+      'function reviewOutput(packet) {',
+      `function reviewOutput(packet) {
+    const deadline = Date.now() + 30000;
+    while (!require('node:fs').existsSync(${JSON.stringify(release)})) {
+      if (Date.now() > deadline) process.exit(7);
+      Atomics.wait(new Int32Array(new SharedArrayBuffer(4)), 0, 0, 20);
+    }
+    process.exit(7);`,
+    );
+    assert.notEqual(held, producer);
+    writeFileSync(path.join(path.dirname(state.marker), 'codex'), held, { mode: 0o755 });
+    assert.equal(existsSync(state.marker), false);
+    assert.equal(existsSync(state.fallbackMarker), false);
+  },
+);
+
+When(
+  'the permitted fallback is requested',
+  { timeout: 60_000 },
+  async function (this: SafewordWorld) {
+    const state = states.get(this);
+    assert.ok(state);
+    // The caller ranks headless first; the public coordinator must still dispatch
+    // independent review first. Only courtesy waiting is shortened, not funding.
+    const result = await installedReviewCli(state.root)(
+      [
+        'review',
+        'run',
+        'plan-implementation',
+        `${folder}/impl-plan.md`,
+        '--context',
+        'features/current-context.feature',
+        '--context',
+        `${folder}/spec.md`,
+        '--json',
+        '--no-input',
+        '--cwd',
+        state.root,
+      ],
+      { cwd: state.root, env: { ...state.env, SAFEWORD_REVIEW_FOREGROUND_MS: '100' } },
+    );
+    assert.equal(result.exitCode, 2, result.stdout);
+    const output = JSON.parse(result.stdout);
+    state.reviewId = output.data.review_id;
+    assert.equal(output.data.status, 'pending', result.stdout);
+    const deadline = Date.now() + 10000;
+    while (!existsSync(state.marker) && !existsSync(state.fallbackMarker!) && Date.now() < deadline)
+      await new Promise(resolve => setTimeout(resolve, 100));
+    const refused = await installedReviewCli(state.root)(
+      [
+        'review',
+        'continue',
+        state.reviewId!,
+        '--tier',
+        'fresh-context',
+        '--failure',
+        'process_failed',
+        '--json',
+        '--cwd',
+        state.root,
+      ],
+      { cwd: state.root, env: state.env },
+    );
+    assert.equal(refused.exitCode, 1, refused.stdout);
+    assert.deepEqual(
+      JSON.parse(refused.stdout).errors.map((error: { code: string }) => error.code),
+      ['REVIEW_JOB_INVALID'],
+    );
+  },
+);
+
+Then(
+  'fallback is refused and the phase remains blocked pending independent review',
+  { timeout: 60_000 },
+  async function (this: SafewordWorld) {
+    const state = states.get(this);
+    assert.ok(state?.reviewId && state.fallbackMarker);
+    const cli = installedReviewCli(state.root);
+    const blocked = await cli(
+      ['ticket', 'approve-plan', 'CTX123', '--json', '--no-input', '--cwd', state.root],
+      { cwd: state.root, env: state.env },
+    );
+    assert.equal(blocked.exitCode, 2, blocked.stdout);
+    const pending = await cli(['review', 'status', state.reviewId, '--json', '--cwd', state.root], {
+      cwd: state.root,
+      env: state.env,
+    });
+    assert.equal(JSON.parse(pending.stdout).data.status, 'pending');
+    assert.equal(existsSync(state.marker), true, 'The independent route is actually working.');
+    assert.equal(
+      existsSync(state.fallbackMarker),
+      false,
+      'Funded headless review must wait for independent exhaustion.',
+    );
+    assert.match(
+      readFileSync(path.join(state.root, folder, 'ticket.md'), 'utf8'),
+      /phase: plan-implementation/u,
+    );
+    writeFileSync(state.release, 'release');
+    let completion;
+    const deadline = Date.now() + 10000;
+    do {
+      await new Promise(resolve => setTimeout(resolve, 100));
+      const result = await cli(
+        ['review', 'status', state.reviewId, '--json', '--cwd', state.root],
+        { cwd: state.root, env: state.env },
+      );
+      completion = JSON.parse(result.stdout).data;
+    } while (completion.status === 'pending' && Date.now() < deadline);
+    assert.equal(completion.status, 'approved', JSON.stringify(completion));
+    assert.equal(completion.independence, 'reduced');
+    assert.deepEqual(completion.review_routes, [
+      {
+        reviewer: 'codex',
+        model: 'gpt-6.1-sol',
+        independence: 'cross-agent',
+        status: 'attempted',
+        failure: 'process_failed',
+      },
+      { reviewer: 'claude', independence: 'degraded', status: 'attempted' },
+    ]);
+    assert.equal(
+      existsSync(state.fallbackMarker),
+      true,
+      'Fallback becomes callable after the independent failure.',
+    );
+  },
+);
+
+After(async function (this: SafewordWorld) {
+  const state = states.get(this);
+  if (!state) return;
+  if (existsSync(path.dirname(state.release))) writeFileSync(state.release, 'release');
+  if (state.reviewId)
+    await installedReviewCli(state.root)(
+      ['review', 'cancel', state.reviewId, '--json', '--cwd', state.root],
+      { cwd: state.root, env: state.env },
+    );
+  states.delete(this);
+});
diff --git a/steps/keep-plan-reviews-product-outcomes.steps.ts b/steps/keep-plan-reviews-product-outcomes.steps.ts
new file mode 100644
index 000000000..243cd80f9
--- /dev/null
+++ b/steps/keep-plan-reviews-product-outcomes.steps.ts
@@ -0,0 +1,93 @@
+import { strict as assert } from 'node:assert';
+
+import { Given, Then, When } from '@cucumber/cucumber';
+
+import {
+  assertPlanningEval,
+  runPlanningEval,
+  selectPlanningEval,
+} from './support/planning-eval.js';
+import type { SafewordWorld } from './world.js';
+
+const inventories = {
+  "inventories every accepted persona's consequential success, refusal, failure, approval, trust, and recovery outcomes":
+    'r16-complete-persona-outcomes',
+  "marks the Non-Technical Builder's approval outcome explicitly inapplicable with a stated reason and inventories the rest":
+    'r16-explicitly-inapplicable-approval',
+  "omits the Non-Technical Builder's recovery outcome": 'r16-missing-persona-recovery',
+} as const;
+
+Given(
+  /^the Product Plan accepts a Technical Builder and a Non-Technical Builder and (.+)$/,
+  function (this: SafewordWorld, inventory: keyof typeof inventories) {
+    const caseId = inventories[inventory];
+    assert.ok(caseId, `Unknown persona inventory: ${inventory}`);
+    const packet = selectPlanningEval(this, caseId);
+    assert.match(packet.context, /Technical Builder and Non-Technical Builder/u);
+    assert.match(packet.reviewed_plan, /recovery/u);
+    if (caseId === 'r16-explicitly-inapplicable-approval') {
+      assert.match(packet.reviewed_plan, /approval is inapplicable because/u);
+      assert.doesNotMatch(packet.reviewed_plan, /each have defined.*approval/u);
+      assert.match(packet.reviewed_plan, /observer-only persona cannot authorize/u);
+    }
+    if (caseId === 'r16-missing-persona-recovery')
+      assert.match(packet.reviewed_plan, /Non-Technical Builder recovery is absent/u);
+  },
+);
+
+Given(
+  /^the Product Plan contains known facts, assumptions, and unresolved product decisions and (presents an assumption as a known fact|keeps known facts, assumptions, and unresolved product decisions distinct)$/,
+  function (this: SafewordWorld, epistemicState: string) {
+    const packet = selectPlanningEval(
+      this,
+      epistemicState.startsWith('presents')
+        ? 'r16-assumption-as-fact'
+        : 'r16-complete-persona-outcomes',
+    );
+    assert.match(packet.reviewed_plan, /Known fact:/u);
+    assert.match(packet.reviewed_plan, /Assumption(?:s)?:/u);
+    assert.match(packet.reviewed_plan, /Unresolved (?:product )?decision(?:s)?:/u);
+    if (epistemicState.startsWith('presents'))
+      assert.match(
+        packet.reviewed_plan,
+        /Known fact: Every builder can recover an expired consent token without assistance/u,
+      );
+  },
+);
+
+When(
+  'a judged semantic reviewer evaluation applies the canonical Product Plan completeness rubric',
+  { timeout: 240_000 },
+  function (this: SafewordWorld) {
+    runPlanningEval(this);
+  },
+);
+
+Then(
+  'persona-outcome completeness does not block Product Plan approval',
+  function (this: SafewordWorld) {
+    assertPlanningEval(this, 'approve');
+  },
+);
+
+Then('epistemic status does not block Product Plan approval', function (this: SafewordWorld) {
+  assertPlanningEval(this, 'approve');
+});
+
+Then(
+  'Product Plan approval is blocked naming that missing recovery outcome and reports no scenario-coverage verdict',
+  function (this: SafewordWorld) {
+    assertPlanningEval(this, 'request_changes', /Non-Technical Builder.{0,90}recovery/isu);
+  },
+);
+
+Then(
+  'Product Plan approval is blocked with the epistemic-status defect named',
+  function (this: SafewordWorld) {
+    assertPlanningEval(
+      this,
+      'request_changes',
+      /(?=.*(?:assum|unsupported|unproven))(?=.*fact)/isu,
+    );
+  },
+);
diff --git a/steps/keep-plan-reviews-receipt-provenance.steps.ts b/steps/keep-plan-reviews-receipt-provenance.steps.ts
new file mode 100644
index 000000000..1d6c97f21
--- /dev/null
+++ b/steps/keep-plan-reviews-receipt-provenance.steps.ts
@@ -0,0 +1,173 @@
+import { strict as assert } from 'node:assert';
+import { spawnSync } from 'node:child_process';
+import { cpSync, readFileSync, rmSync, writeFileSync } from 'node:fs';
+import path from 'node:path';
+
+import { After, Given, Then, When } from '@cucumber/cucumber';
+
+import {
+  admitThroughInstalledCli,
+  executionPlan,
+  featureFixture,
+  installedReviewCli,
+} from '../packages/cli/tests/fixtures/execution-review.js';
+import { cleanupTrustedReviewerDirectories } from '../packages/cli/tests/review-fixtures.js';
+import type { SafewordWorld } from './world.js';
+
+// A committed pre-fix plugin can run the identical assertions as a regression control.
+const pluginRoot = path.resolve(
+  process.env.SAFEWORD_RECEIPT_PROOF_PLUGIN_ROOT ?? path.resolve(import.meta.dirname, '../plugin'),
+);
+const ticketFolder = 'ABC123-feature';
+const implementation =
+  '# Implementation Plan\n\n**Status:** planned\n\n## Approach\nUse the authenticated current plan review.\n\n## Decisions\nskip: No unresolved decision.\n\n## Design alignment\nskip: No additional principle trace applies.\n\n## Known deviations\nskip: No known deviations.\n\n## Assessment triggers\nRevisit when approval authority changes.\n';
+
+interface ReceiptState {
+  root: string;
+  reviewer: string;
+  gate?: ReturnType<typeof spawnSync>;
+}
+const states = new WeakMap<SafewordWorld, ReceiptState>();
+
+Given(
+  /^the Execution Plan gate receives (.+)$/,
+  { timeout: 60_000 },
+  async function (this: SafewordWorld, identity: string) {
+    const root = featureFixture();
+    const current = { root, reviewer: '' };
+    states.set(this, current);
+    const ticketDirectory = path.join(root, '.project', 'tickets', ticketFolder);
+    writeFileSync(
+      path.join(ticketDirectory, 'ticket.md'),
+      '---\nid: ABC123\ntype: feature\nphase: plan-execution\n---\n',
+    );
+    writeFileSync(path.join(ticketDirectory, 'impl-plan.md'), implementation);
+    if (identity === 'an Implementation Plan approval for the current ticket and same plan bytes') {
+      const commonPlan = `${implementation}\n${executionPlan().replace(/^\*\*Status:\*\*.*\n/gmu, '')}`;
+      writeFileSync(path.join(ticketDirectory, 'impl-plan.md'), commonPlan);
+      writeFileSync(path.join(ticketDirectory, 'execution-plan.md'), commonPlan);
+    }
+    const runCli = installedReviewCli(root);
+    current.reviewer = await admitThroughInstalledCli(runCli, root);
+    const positive = await runCli(
+      ['ticket', 'coding-authorization', 'ABC123', '--json', '--cwd', root],
+      {
+        cwd: root,
+        env: {
+          NODE_ENV: 'test',
+          SAFEWORD_REVIEW_KEY_ROOT: path.join(root, '.review-keys'),
+        },
+      },
+    );
+    assert.equal(positive.exitCode, 0, positive.stdout);
+    assert.equal(JSON.parse(positive.stdout).data.coding_authorization, 'authorized');
+    if (
+      identity === 'an Execution Plan approval for the current ticket and exact current plan bytes'
+    )
+      return;
+
+    const ledgerPath = path.join(root, '.project', 'skill-invocations.log');
+    const rows = readFileSync(ledgerPath, 'utf8').trim().split('\n');
+    let alias: string;
+    if (identity === 'an Implementation Plan approval for the current ticket and same plan bytes') {
+      const receipt = rows.find(row => row.includes(':phase@plan-implementation '));
+      assert.ok(receipt);
+      assert.equal(
+        readFileSync(path.join(ticketDirectory, 'impl-plan.md'), 'utf8'),
+        readFileSync(path.join(ticketDirectory, 'execution-plan.md'), 'utf8'),
+      );
+      alias = receipt.replace(':phase@plan-implementation ', ':phase@plan-execution ');
+    } else {
+      assert.equal(identity, 'an Execution Plan approval for a sibling ticket and same plan bytes');
+      const sibling = 'XYZ789-feature';
+      const siblingDirectory = path.join(root, '.project', 'tickets', sibling);
+      cpSync(ticketDirectory, siblingDirectory, { recursive: true });
+      writeFileSync(
+        path.join(siblingDirectory, 'ticket.md'),
+        '---\nid: XYZ789\ntype: feature\nphase: plan-execution\n---\n',
+      );
+      await admitThroughInstalledCli(runCli, root, ['plan-execution'], { ticketFolder: sibling });
+      assert.equal(
+        readFileSync(path.join(siblingDirectory, 'execution-plan.md'), 'utf8'),
+        readFileSync(path.join(ticketDirectory, 'execution-plan.md'), 'utf8'),
+      );
+      alias = readFileSync(ledgerPath, 'utf8')
+        .trim()
+        .replace(`review:${sibling}:`, `review:${ticketFolder}:`);
+    }
+    writeFileSync(
+      ledgerPath,
+      `${[...rows.filter(row => !row.includes(':phase@plan-execution ')), alias].join('\n')}\n`,
+    );
+  },
+);
+
+When('the gate validates receipt provenance', function (this: SafewordWorld) {
+  const current = states.get(this);
+  assert.ok(current);
+  current.gate = spawnSync('bun', [path.join(pluginRoot, 'runtime/hooks/pre-tool-quality.ts')], {
+    cwd: current.root,
+    encoding: 'utf8',
+    timeout: 60_000,
+    input: JSON.stringify({
+      session_id: 'r9-receipt',
+      tool_name: 'Edit',
+      tool_input: {
+        file_path: path.join(current.root, '.project', 'tickets', ticketFolder, 'ticket.md'),
+        old_string: 'phase: plan-execution',
+        new_string: 'phase: implement',
+      },
+    }),
+    env: {
+      ...process.env,
+      NODE_ENV: 'test',
+      XDG_STATE_HOME: path.join(current.root, '.review-keys'),
+      SAFEWORD_REVIEW_KEY_ROOT: path.join(current.root, '.review-keys'),
+      PATH: `${current.reviewer}:${process.env.PATH ?? ''}`,
+      CLAUDE_PROJECT_DIR: current.root,
+      CLAUDE_PLUGIN_ROOT: pluginRoot,
+      CLAUDE_SESSION_ID: 'r9-receipt',
+      SAFEWORD_AGENT_RUNTIME: 'claude',
+    },
+  });
+});
+
+Then('the matching receipt does not block the phase transition', function (this: SafewordWorld) {
+  const gate = states.get(this)?.gate;
+  assert.ok(gate);
+  assert.equal(gate.status, 0, gate.stderr);
+  assert.equal(gate.stdout.trim(), '', gate.stdout);
+});
+
+Then(
+  /^the phase remains blocked with the mismatched (review kind|ticket) and re-review named$/,
+  function (this: SafewordWorld, mismatch: string) {
+    const current = states.get(this);
+    assert.ok(current?.gate);
+    assert.equal(current.gate.status, 0, current.gate.stderr);
+    const result = JSON.parse(current.gate.stdout);
+    assert.equal(result.hookSpecificOutput.permissionDecision, 'deny');
+    const message = result.hookSpecificOutput.permissionDecisionReason;
+    for (const name of mismatch === 'ticket'
+      ? [ticketFolder, 'XYZ789-feature']
+      : ['plan-implementation', 'plan-execution'])
+      assert.ok(message.includes(name), message);
+    assert.match(result.hookSpecificOutput.additionalContext, /review run plan-execution/u);
+    assert.match(
+      readFileSync(
+        path.join(current.root, '.project', 'tickets', ticketFolder, 'ticket.md'),
+        'utf8',
+      ),
+      /phase: plan-execution/u,
+    );
+  },
+);
+
+After(function (this: SafewordWorld) {
+  const current = states.get(this);
+  if (current) {
+    rmSync(current.root, { recursive: true, force: true });
+    cleanupTrustedReviewerDirectories();
+  }
+  states.delete(this);
+});
