Review every authored/source change in PR4. Base 23ddfba; exact head d0cd14c0651595d9f81b6f9e2f4c4c0af51cb8ec. The complete diff has 169 files. All 167 non-bundled diffs are included here, including changed source, tests, plans, guides and generation identities. The two compiled runtime diffs total 4938088 bytes, exceeding the coordinator per-file and aggregate limits. Their raw diff is retained locally, and all five generator checks are being run at this head; this review covers their complete source changes and derivation mechanism, not every compiled byte. Judge semantic correctness, authentication/currency, trusted routing and scope. Do not mistake this coverage for raw bundle inspection. CI for the new documentation-only head is pending; preceding source-identical CI passed. Legacy migration and whole-epic acceptance remain unfinished. Claude exact Execution qualification failed 6 of 63 (57 pass, zero unfinished); no Claude Execution admission or production default change has been made. The human chose both-review invalidation on 2026-10-04. No merge or Ready promotion authorization.

diff --git a/packages/cli/tests/fixtures/reviewer-capability-evidence/claude-opus-5.json b/packages/cli/tests/fixtures/reviewer-capability-evidence/claude-opus-5.json
new file mode 100644
index 000000000..12a470176
--- /dev/null
+++ b/packages/cli/tests/fixtures/reviewer-capability-evidence/claude-opus-5.json
@@ -0,0 +1,409 @@
+{
+  "provider": "anthropic",
+  "model": "claude-opus-5",
+  "corpus_digest": "f76edddd71868835e161d06987bce170fb395a71849412dd96c2b6d18c698b24",
+  "rubric_digest": "b9d97005601dcaaa38caefb84716497d792170da6d5d4a0076b039691df9594f",
+  "settings_digest": "acd5a69993710ae8483c78771a67a6d61e061707f39f450a24a9a10511f7bf4d",
+  "evidence_date": "2026-09-29",
+  "runs": [
+    {
+      "fixture_id": "product-approve",
+      "run": 1,
+      "verdict": "request_changes",
+      "findings": [
+        {
+          "severity": "error",
+          "message": "Undefined display for a concluded review with no blocking findings and no valid authenticated receipt. The plan defines Pending as \"the current review has not finished\", Approved as requiring \"an authenticated approval receipt\", and Rejected as \"concluded with blocking findings\". The done state explicitly contemplates that a receipt may be \"missing or stale\", so the state of a finished review whose receipt is absent or fails authentication is reachable within accepted scope, yet it matches none of the three definitions. Triggering condition: the review job completes producing no blocking findings while no authenticated receipt is available. Two reasonable implementations follow — display Pending, or display Rejected — and both falsely report the accepted claim. Pending tells the builder the review has not finished when it has, so the builder waits indefinitely instead of exercising the accepted repair-and-retry path; Rejected promises \"those actual findings\" when none exist, breaking the accepted done-state requirement that a rejected review shows the actual blocking findings. Define the product behavior for this state (for example, an explicit fourth outcome, or an accepted mapping onto one existing status with its definition widened to match) so the display cannot claim a status whose own accepted definition is false."
+        },
+        {
+          "severity": "warning",
+          "message": "The staleness boundary is stated but not bounded as a product decision. \"A stale approval is a receipt for a different review job or different plan bytes\" leaves what counts as different plan bytes to the implementation. Byte-exact comparison and any normalization (trailing whitespace, line endings, formatting-only edits) are both reasonable readings, and they differ in whether a builder who makes a cosmetic edit after approval sees Approved or must re-review. This does not permit a missing or stale receipt to appear as approval, so it does not violate the accepted invariant, but the user-visible consequence of a trivial edit is currently an unresolved product choice presented as settled by \"no product choice remains open\"."
+        },
+        {
+          "severity": "warning",
+          "message": "The Rejected display promises \"those actual findings\" with no accepted boundary on volume or truncation. For a review with a large number of blocking findings, showing all of them and showing a truncated set with an indication of the remainder are both consistent with the current wording, and they differ in what the builder can act on in the CLI surface. Naming the accepted expectation (complete findings, or truncation with an explicit remainder indicator) would close this without adding implementation design."
+        }
+      ]
+    },
+    {
+      "fixture_id": "product-approve",
+      "run": 2,
+      "verdict": "approve",
+      "findings": [
+        {
+          "severity": "warning",
+          "message": "Abnormal termination has no named status. The plan defines Pending as \"the current review has not finished\" and Rejected as a review that \"concluded with blocking findings\". A review that ends without concluding — crash, timeout, or cancellation — satisfies neither definition cleanly and would display as Pending indefinitely, leaving the builder with no stated repair or retry path (the retry path is attached only to Rejected). This does not let a stale or missing receipt appear as approval, and none of the four accepted scenarios cover it, so it is non-blocking. Naming the intended outcome for a review that ends without a conclusion would close the ambiguity before scenario definition."
+        },
+        {
+          "severity": "warning",
+          "message": "The exclusion of the never-requested state (\"The display begins only after a review is requested; a never-requested state is outside this ticket\") is asserted by the plan, not traceable to the ticket or the accepted scenarios, which are silent on it. Accepted scope and exclusions belong to the user, so an exclusion originating in the plan should be confirmed as a user decision rather than recorded as settled; the plan's claim that \"no product choice remains open\" currently absorbs it without that confirmation."
+        },
+        {
+          "severity": "info",
+          "message": "Scenario 4's stale-approval case is fully covered by the plan's definition of stale (\"a receipt for a different review job or different plan bytes\"): such a receipt is by construction not the current review's, so the current review is either unfinished (Pending) or concluded with blocking findings (Rejected). There is no unmapped concluded-but-unapproved state arising from staleness."
+        },
+        {
+          "severity": "info",
+          "message": "Prohibited content check is clean: the plan names no storage schema, display component, delivery task order, or ordering of implementation work, and it does not claim that scenarios, downstream plans, or implementation are approved. Existing approval authority and storage are correctly framed as untouched constraints rather than as work being accepted here."
+        }
+      ]
+    },
+    {
+      "fixture_id": "product-approve",
+      "run": 3,
+      "verdict": "approve",
+      "findings": [
+        {
+          "severity": "warning",
+          "message": "The plan enumerates exactly three current outcomes but does not say how a review that terminates without a decision (for example, a review that fails or aborts and produces no blocking findings) is presented. Two reasonable readings exist: such a review stays Pending indefinitely, or it is shown as Rejected with an empty findings list. The second reading would violate the plan's own statement that Rejected means 'concluded with blocking findings' and would show a builder an empty findings view. This is a warning rather than an error because the accepted scope names three statuses and the ticket does not claim coverage of abnormal termination; naming the intended outcome (or explicitly excluding it) in the plan would remove the ambiguity before scenario definition."
+        },
+        {
+          "severity": "warning",
+          "message": "'Evidence and decisions' mixes a supported project constraint (the existing authenticated receipt), a non-promise ('No quantitative target is promised'), and a closure claim ('no product choice remains open') in three sentences without separating supported facts from assumptions. The contract asks that supported facts, assumptions, and unresolved decisions be kept distinct. Nothing here appears mislabeled, but the section carries no assumption list at all, which makes the closure claim unverifiable from the plan alone."
+        },
+        {
+          "severity": "info",
+          "message": "The exclusion of the never-requested state is scoped narrowly and consistently ('the display begins only after a review is requested'), which matches the ticket goal of distinguishing review outcomes rather than describing pre-review UI. Worth confirming during scenario definition that no accepted scenario implicitly starts from a never-requested state, since scenario 4's 'request a new review' step brushes against that edge."
+        }
+      ]
+    },
+    {
+      "fixture_id": "product-reject",
+      "run": 1,
+      "verdict": "request_changes",
+      "findings": [
+        {
+          "severity": "error",
+          "message": "spec.md omits the Rejected status entirely. The ticket goal states a builder must distinguish Pending, Approved, and Rejected, and that rejected reviews show the actual blocking findings and permit repair and retry; accepted scenario 3 requires a completed review with blocking findings to display Rejected with those findings. With only 'Pending means the review has not finished' and 'Approved means ... approval receipt' accepted, a completed-and-rejected review is not covered: an implementation may display it as Pending (it never reached approval) and still satisfy every accepted statement in the plan. Observable consequence: a builder sees a blocked review as still in progress, with no findings to repair, while the implementation reports the accepted behavior as satisfied. The plan must accept the Rejected state, the display of the actual blocking findings, and the repair-and-retry outcome, or explicitly exclude them from user-owned scope — which the ticket does not permit."
+        },
+        {
+          "severity": "error",
+          "message": "The Approved definition has no currency requirement: 'Approved means the review has an authenticated approval receipt.' Accepted scenario 2 requires a *current* authenticated approval, and scenario 4 requires that after a plan is repaired a stale approval cannot approve it. As written, two reasonable implementations are permitted — one that checks receipt currency against the reviewed plan and one that checks only that some authenticated receipt exists. The second displays Approved for a plan that has been changed since the receipt was issued, falsely reporting the accepted user-facing claim. The plan must state that Approved requires the authenticated approval receipt to correspond to the current plan state, and that a superseded receipt does not display Approved."
+        },
+        {
+          "severity": "warning",
+          "message": "The observable done state, 'A builder can distinguish Pending from Approved', is non-discriminating with respect to the accepted goal: it can be demonstrated in full while the Rejected status and stale-approval behavior are entirely broken or absent. Once the states above are accepted, restate the done state so it fails when a rejected review, its blocking findings, or a superseded approval is displayed incorrectly."
+        },
+        {
+          "severity": "info",
+          "message": "Required Product Plan content is otherwise present (persona, surface, scope and exclusions), and the plan correctly avoids implementation design, task sequencing, and claims of scenario or design approval. The plan also does not separate supported facts from assumptions and unresolved decisions; if the currency semantics of the approval receipt are an open product question rather than settled, record it explicitly as unresolved rather than leaving it implied."
+        }
+      ]
+    },
+    {
+      "fixture_id": "product-reject",
+      "run": 2,
+      "verdict": "request_changes",
+      "findings": [
+        {
+          "severity": "error",
+          "message": "spec.md omits the Rejected review state entirely. The ticket goal is that a builder can distinguish Pending, Approved, and Rejected, and accepted scenario 3 requires a completed review with blocking findings to display Rejected with those actual findings. Because the plan names no Rejected behavior, two reasonable implementations exist: one that renders a third Rejected state with its findings, and one that renders only Pending/Approved and shows a completed-with-findings review as Pending or as nothing. The second implementation passes every condition stated in the plan while the accepted user-facing behavior is false. Add Rejected as accepted behavior, including that the display shows the actual blocking findings rather than a generic failure label."
+        },
+        {
+          "severity": "error",
+          "message": "The observable done state — 'A builder can distinguish Pending from Approved' — is narrower than the accepted behavior it is supposed to make observable. It cannot detect the missing Rejected state, the required display of actual blocking findings (scenario 3), or the repair-and-retry path (scenario 4). This done state is non-discriminating proof: the claimed behavior can be entirely broken for rejected reviews while the stated done condition still holds. Restate the done state so it fails when any of the three statuses, the findings display, or retry after repair is absent."
+        },
+        {
+          "severity": "error",
+          "message": "'Approved means the review has an authenticated approval receipt' states no currency boundary, but accepted scenario 4 requires that after a plan is repaired, a stale approval cannot approve it. Without that condition in the accepted behavior, an implementation that checks only receipt authenticity — not whether the receipt corresponds to the current plan — would display Approved for a changed plan. That is a path that reports the accepted user-facing claim (this review is approved) as satisfied when it is not. Specify that Approved requires an authenticated approval receipt for the current plan, and that changing the plan returns it to a non-approved state."
+        },
+        {
+          "severity": "warning",
+          "message": "Scope and exclusions cover new approval authority and notifications, but the ticket also excludes any new storage system. Since the currency requirement above may imply persisting what a receipt was issued against, the plan should carry the ticket's storage exclusion forward explicitly so the boundary is not quietly expanded during design."
+        },
+        {
+          "severity": "info",
+          "message": "The plan does not separate supported facts from assumptions and unresolved decisions as the Product Plan contract requires. Nothing in the current text appears to be an unstated assumption, but if the Rejected state or the approval-currency rule depends on behavior not yet confirmed in the CLI, record that distinction rather than presenting it as settled."
+        }
+      ]
+    },
+    {
+      "fixture_id": "product-reject",
+      "run": 3,
+      "verdict": "request_changes",
+      "findings": [
+        {
+          "severity": "error",
+          "message": "spec.md omits the Rejected state entirely. The ticket's goal is that a builder can distinguish Pending, Approved, and Rejected, that Rejected reviews show the actual blocking findings, and that repair and retry are permitted; none of this appears in Accepted behavior or in Scope and exclusions, and Rejected is not listed as an exclusion either. The observable done state is narrowed to 'distinguish Pending from Approved', so an implementation that renders a completed review with blocking findings as Pending (not finished approving) or as an unlabelled terminal state would satisfy every stated criterion while the accepted user-facing claim — the builder can tell a rejected review from an unfinished one and see why — is false. Two reasonable implementations are permitted and one falsely reports the accepted behavior as met. Restore Rejected, the display of the actual blocking findings, and the repair/retry outcome to the accepted behavior and to the observable done state, or state explicitly and with justification that the user has excluded them."
+        },
+        {
+          "severity": "error",
+          "message": "spec.md defines 'Approved means the review has an authenticated approval receipt' with no requirement that the receipt be current for the plan under review. The ticket preserves the existing authenticated approval receipt but the plan's own heading is 'Show current review status', and the plan nowhere binds a receipt to the reviewed plan revision. Under this wording an implementation that retains an approval receipt issued against a prior plan revision and continues to display Approved after the plan changes is conformant, which would present an unreviewed plan as approved to the builder. This is a trust-boundary failure in the accepted surface, not speculative hardening: the plan must state that Approved requires an authenticated approval receipt that is current for the plan revision being displayed, and that a superseded receipt does not display Approved."
+        },
+        {
+          "severity": "warning",
+          "message": "spec.md does not separate supported facts from assumptions and unresolved decisions, which the Product Plan contract requires as distinct content. In particular the display treatment for a review whose approval has been superseded, and whether an in-flight retry after repair renders as Pending or as a distinct state, are left implicit rather than recorded as open product choices. This does not by itself permit a wrong shipped outcome once the two errors above are repaired, but the omissions should be recorded so scenario definition does not have to infer them."
+        },
+        {
+          "severity": "info",
+          "message": "Persona, surface, scope, and exclusions are stated and the exclusions ('New approval authority and notifications are excluded') match the ticket's exclusions. The plan correctly contains no implementation design, no delivery sequencing, and no claim that scenarios, downstream plans, or implementation are approved."
+        }
+      ]
+    },
+    {
+      "fixture_id": "implementation-approve",
+      "run": 1,
+      "verdict": "approve",
+      "findings": [
+        {
+          "severity": "warning",
+          "message": "Contract coherence: the CLI status contract is declared as \"exactly Pending, Approved, and Rejected,\" but failure behavior introduces a fourth outcome — \"a failed status read reports unavailable state.\" The plan does not decide whether unavailable is a distinct displayed value or is folded into Pending with an error detail. This is not an error because every reasonable reading of the sentence forbids reporting Approved on a failed read, so the accepted user-facing claim (a missing or stale receipt cannot appear as approval) cannot be falsely satisfied either way. Still, Execution Planning would otherwise be choosing a user-visible status vocabulary that Implementation Planning owns; name the read-failure outcome explicitly in the status contract."
+        },
+        {
+          "severity": "warning",
+          "message": "Concurrency surface: the plan decides that \"only the job currently bound to the plan may drive the displayed status\" and that concurrent retries may finish in any order, which correctly prevents a stale or losing job from supplying Approved. It does not state what the builder sees for the losing retry — whether it is silently ignored, shown as superseded, or surfaced on the next status read. The persona's recovery need (repair and retry) is still covered by the binding rule, and no outcome here can show a false Approved, so this is non-blocking; adding the losing-retry display consequence would close the last observable gap in the retry path."
+        },
+        {
+          "severity": "info",
+          "message": "Proof strategy stays inside the Implementation Planning boundary: it names the behavior, the real CLI-and-coordinator boundary, the proof type, and an explicit confidence limit (an isolated mapper test cannot prove public wiring), with no test paths or commands leaking in from Execution Planning. The stale-receipt and actual-rejection-findings cases are discriminating rather than ceremonial — a mapper that synthesized rejection text or honored a prior receipt would fail them."
+        },
+        {
+          "severity": "info",
+          "message": "Applicability skips are justified rather than bare: the Data skip enumerates the subjects it disclaims (store, schema, ownership, retention, migration, cross-system flow) and is consistent with the plan creating no second store, and the Measurement skip is grounded in the Product Plan's stated absence of a quantitative target. The no-durable-architecture-record judgment matches the significance rule — this is a reversible feature-local presentation change that adds no shared API and moves no data owner."
+        }
+      ]
+    },
+    {
+      "fixture_id": "implementation-approve",
+      "run": 2,
+      "verdict": "approve",
+      "findings": [
+        {
+          "severity": "warning",
+          "message": "Internal inconsistency in the declared status contract. The plan states \"The CLI status contract has exactly Pending, Approved, and Rejected\" and then, one sentence later, \"A failed status read reports unavailable state rather than inventing approval.\" Unavailable is a fourth user-visible outcome that the enumerated contract excludes. This is not an error because the safe direction is preserved (a read failure cannot produce Approved, and the Product Plan's done state is not violated), but two reasonable implementations follow from the text as written: one surfaces a distinct unavailable state, another collapses read failure into Pending. Those differ for the builder, who in the collapsed case sees Pending for a review that may already be terminal. Owner: Implementation Planning. Resolve by either enumerating unavailable in the contract or stating explicitly that read failure presents as Pending with its actual error state, consistent with the earlier 'running or interrupted review' decision."
+        },
+        {
+          "severity": "warning",
+          "message": "Project principles are neither named nor dismissed in the plan, and the configured principles file was not supplied in this packet, so I could not verify whether an applicable principle was missed. The rubric requires challenging whether the plan identified the actually applicable principles using that supplied file; with the file absent I can only record the gap. Owner: whoever assembles the review packet. One action that resumes this check: supply the configured principles file alongside spec.md so the principle-to-consequence-to-proof chain can be verified."
+        },
+        {
+          "severity": "warning",
+          "message": "The configured personas file and surfaces file were not supplied in this packet. I resolved the persona (the builder requesting a plan review) and surface (the CLI review status display) from spec.md only, and against that source the coverage is complete: trust (stale receipt cannot approve), operation (three current outcomes), approval (existing authenticated receipt is sole source), and recovery (repair and retry with the old rejection demoted to history), each with a named design consequence and a stated confidence limit on the integration proof. If the configured files enumerate any additional persona or surface for this ticket, that coverage is unverified here."
+        },
+        {
+          "severity": "info",
+          "message": "Load-bearing risk ordering is correct: the plan leads with job-identifier and plan-digest binding, which is the mechanism that carries the ticket's central trust claim, rather than with presentation mechanics. The 'no load-bearing external library choice' skip does not contradict the plan's own load-bearing choice, because the one significant choice (read existing trusted coordinator records versus persist a separate CLI status) is recorded with its rejected alternative and the reason it lost, and it introduces no third-party dependency requiring version, license, or security evidence."
+        },
+        {
+          "severity": "info",
+          "message": "The judgment that no durable architecture record is needed holds under the significance test applied to behavioral consequences rather than file count: no shared API, data owner, or migration compatibility change occurs, the coordinator record and CLI exit codes are explicitly unchanged, the added Rejected label is additive, and the mapper is a reversible feature-local presentation choice."
+        }
+      ]
+    },
+    {
+      "fixture_id": "implementation-approve",
+      "run": 3,
+      "verdict": "approve",
+      "findings": [
+        {
+          "severity": "warning",
+          "message": "Status contract enumerates exactly Pending, Approved, and Rejected, but failure behavior adds a fourth observable outcome: \"A failed status read reports unavailable state rather than inventing approval.\" The plan does not say whether unavailable is rendered as Pending or as an out-of-band message distinct from the three values, so two reasonable implementations exist. This is a warning rather than an error because both readings satisfy the accepted user-facing claim — neither can display Approved without a current authenticated receipt — so no path reports the accepted claim falsely. Naming which of the two the mapper produces would close the gap without widening scope."
+        },
+        {
+          "severity": "info",
+          "message": "Persona coverage is complete for the single accepted persona (the builder requesting a plan review): trust is bound by job identifier and plan digest, operation and approval by the authenticated receipt as sole Approved source, and recovery by the retry path that creates a new review for repaired bytes while prior rejections stay historical evidence. The Product Plan's out-of-scope never-requested display state is correctly left unaddressed rather than silently designed."
+        },
+        {
+          "severity": "info",
+          "message": "Plan-state truthfulness holds: every statement is phrased as a proposed decision or a stated existing constraint (the coordinator's receipt and job records), with no implemented-fact, proof-obtained, or downstream-approval claims asserted. Approval here establishes readiness for Execution Planning only and does not approve delivery sequencing, coding, verification, merge, or deployment."
+        }
+      ]
+    },
+    {
+      "fixture_id": "implementation-reject",
+      "run": 1,
+      "verdict": "request_changes",
+      "findings": [
+        {
+          "severity": "error",
+          "message": "Approach decision contradicts accepted product behavior and permits false approval. impl-plan.md states \"The reviewer output verdict is enough to display Approved, even before an authenticated approval receipt exists.\" The accepted Product Plan states \"Approved means the current review has an authenticated approval receipt\" and \"A missing or stale receipt cannot appear as approval\"; the ticket states \"Approval still requires the existing authenticated approval receipt.\" The plan also contradicts itself: its contract paragraph says \"Missing or stale receipt means no approval,\" and its Pending decision says an interrupted review without a terminal receipt never displays Approved. Two reasonable implementations follow from these conflicting statements, and one displays Approved for a review with no authenticated receipt — falsely reporting the accepted user-facing claim as satisfied, and effectively creating a second approval authority the ticket excludes. The named proof (\"a stale receipt and actual rejection findings\") does not discriminate here: an implementation that approves on verdict alone can still pass a stale-receipt case, because the stale-receipt case tests receipt binding rather than receipt presence. Missing/incorrect decision: the single authority for Approved. Accepted decision owner: the user, via the already-accepted spec — this is not an open product choice, so the plan must conform rather than the user re-deciding. Consequence of leaving it unresolved: the CLI can display Approved for a plan that was never authenticated, defeating the ticket's core guarantee. Action that resumes review: remove the verdict-suffices decision, state that Approved requires a current authenticated approval receipt bound to the current job identifier and plan digest, and add a proof case where a terminal approve verdict exists with no receipt and the display must remain Pending."
+        },
+        {
+          "severity": "warning",
+          "message": "The contract paragraph declares \"exactly Pending, Approved, and Rejected\" but then says a failed status read \"reports unavailable state,\" which is a fourth displayed outcome not present in the accepted three-status contract. The direction is safe (it never fabricates approval), so this is non-blocking, but the plan should either name unavailable as an explicit fourth display state with its user-visible consequence or state that read failure surfaces as Pending with an error detail. The same ambiguity appears in \"displays Pending with its actual error state,\" which does not say whether the error detail is part of the status value or adjacent output."
+        },
+        {
+          "severity": "warning",
+          "message": "Architecture applicability names the CLI-to-coordinator contract as affected yet concludes no durable architecture record is needed, justified only as \"a reversible local presentation change.\" The reasoning is credible for a presentation mapper, but the plan does not say whether the CLI status vocabulary itself is a consumed contract (for example by scripts keying on output). If it is, the additive Rejected label is a compatibility-relevant shared-contract change rather than a purely local one. The plan already asserts exit codes are unchanged, which likely contains the blast radius; a one-line statement that no machine-readable consumer keys on the human-readable status label would close this."
+        }
+      ]
+    },
+    {
+      "fixture_id": "implementation-reject",
+      "run": 2,
+      "verdict": "request_changes",
+      "findings": [
+        {
+          "severity": "error",
+          "message": "Approach decision creates approval authority the user did not accept. The plan states \"The reviewer output verdict is enough to display Approved, even before an authenticated approval receipt exists.\" The accepted Product Plan defines Approved as \"the current review has an authenticated approval receipt,\" and the ticket scope says \"Approval still requires the existing authenticated approval receipt. No new approval authority ... is in scope.\" Triggering condition: a reviewer completes with a non-blocking verdict and no authenticated receipt has been issued. Observable consequence: the CLI displays Approved, so scenario 2 and the invariant \"A missing or stale receipt cannot appear as approval\" are both violated while the feature reports success — independent review is presented as human approval. This also contradicts the plan's own later sentence \"Missing or stale receipt means no approval,\" so two reasonable implementations exist and one falsely reports the accepted user-facing claim. Decision owner: the user (accepted scope). Repair: delete this decision and state that Approved requires the current authenticated approval receipt bound to the current job identifier and plan digest; a terminal reviewer verdict without that receipt displays Pending. Resuming action: restate the Approved precondition in impl-plan.md as receipt-bound and resubmit for approach review."
+        },
+        {
+          "severity": "warning",
+          "message": "The status contract is declared as \"exactly Pending, Approved, and Rejected,\" but failure behavior says \"A failed status read reports unavailable state rather than inventing approval.\" The plan does not decide whether unavailable is a fourth displayed value, a mapping onto Pending, or a non-zero-exit error path. It cannot produce a false Approved, so it is non-blocking, but two implementations differ visibly to the builder; name the resolved representation in the contract section."
+        },
+        {
+          "severity": "info",
+          "message": "Proof coverage is stated as a single sentence spanning all accepted scenarios plus a real CLI/coordinator wiring proof with a named confidence limit, which satisfies the proof-strategy boundary. Naming the real boundary per scenario — specifically the stale-receipt case in scenario 4 — would make the non-discriminating-proof risk easier to rule out without adding execution detail."
+        }
+      ]
+    },
+    {
+      "fixture_id": "implementation-reject",
+      "run": 3,
+      "verdict": "request_changes",
+      "findings": [
+        {
+          "severity": "error",
+          "message": "Contradictory and scope-violating approval contract. Approach decisions state \"The reviewer output verdict is enough to display Approved, even before an authenticated approval receipt exists,\" while the contracts section states \"Missing or stale receipt means no approval.\" Two reasonable implementations satisfy this plan, and one displays Approved for a review with no authenticated receipt. That outcome violates the accepted spec (\"Approved means the current review has an authenticated approval receipt\"), the ticket constraint (\"Approval still requires the existing authenticated approval receipt\"), and the observable done state (\"A missing or stale receipt cannot appear as approval\"), and it creates the new approval authority the ticket excludes. Missing/incorrect decision: which single artifact authorizes the Approved label. Decision owner: the user, via the accepted Product Plan, which has already decided it is the authenticated receipt — the plan author must conform, not re-decide. Consequence if unresolved: the CLI can report a plan as Approved when no human approval authority exists, which is the exact trust failure this ticket was written to prevent. Resuming action: delete the reviewer-verdict-is-enough decision and state that Approved requires the current job's authenticated approval receipt bound to the current plan digest, with scenario 2 proved across the real CLI-plus-coordinator boundary using a review that has a reviewer verdict but no receipt."
+        },
+        {
+          "severity": "warning",
+          "message": "Asserted concurrency and crash invariants have no matching proof. The plan claims the coordinator \"atomically binds each retry to its new job identifier and plan digest,\" that only the currently bound job may drive the display under out-of-order concurrent retries, and that a crash before binding leaves the prior terminal state visible and never falsely Approved. The proof strategy only names per-scenario CLI-and-coordinator exercises including a stale receipt and actual findings; nothing discriminates the interleaved-retry or pre-binding-crash paths, so those invariants could be broken while every named check passes. Either name a proof that orders two retries and one that interrupts before binding, or state these as confidence limits rather than established behavior."
+        },
+        {
+          "severity": "info",
+          "message": "Plan-state labeling is uniformly proposed-tense with no implemented-fact or independent-review claims, and the durable-record skip is justified as a reversible local presentation change, which is consistent with the reversibility standard. Data, Measurement, Architecture applicability, doc impact, deviations, and the reassessment trigger are each present with concrete reasons, and the deletion test finds little removable text."
+        }
+      ]
+    },
+    {
+      "fixture_id": "execution-approve",
+      "run": 1,
+      "verdict": "approve",
+      "findings": [
+        {
+          "severity": "warning",
+          "message": "The documentation obligation (status-9, 'Update CLI status help text for all three states') resolves to the same cli-status-integration proof, but the step list only says to 'update CLI help text and rerun the integration proof' without naming an assertion on the help-text output. The slice completion signal does require that the help text name all three states, so the obligation is owned and signalled; still, the integration fixture should carry an explicit help-text assertion so this obligation is discriminating rather than resting on inference. This is an execution mechanic inside the unchanged accepted proof boundary and is non-blocking."
+        },
+        {
+          "severity": "info",
+          "message": "The accepted Implementation Plan records data applicability as skip (no store, schema, retention, or migration change), while the checklist retains status-5 for coordinator storage and CLI exit-code compatibility. Keeping that item matches the accepted compatibility statement and is not a scope expansion."
+        },
+        {
+          "severity": "info",
+          "message": "This approval covers only the Execution Planning phase decision: it authorizes the bounded delivery of Slice 1 and does not establish implementation, verification, merge, promotion, or deployment completion. The plan states this and keeps contributor work separate from any later human merge authority (status-10)."
+        }
+      ]
+    },
+    {
+      "fixture_id": "execution-approve",
+      "run": 2,
+      "verdict": "approve",
+      "findings": [
+        {
+          "severity": "info",
+          "message": "Decision statuses and the obligation owner are recorded as a closing prose sentence rather than a table. The content is complete and readable (all seven accepted decisions named as unchanged, Slice 1 named as owner), so this is a presentation note only."
+        },
+        {
+          "severity": "info",
+          "message": "Scenarios 1 and 2 (Pending for an unfinished current review, Approved for a current authenticated receipt) are covered by the completion signal's 'all four accepted scenarios' plus the receipt-bound assertions, but are less explicitly enumerated in the step narrative than scenarios 3 and 4. Non-blocking."
+        }
+      ]
+    },
+    {
+      "fixture_id": "execution-approve",
+      "run": 3,
+      "verdict": "approve",
+      "findings": [
+        {
+          "severity": "info",
+          "message": "The plan correctly records the accepted Implementation Plan's stated proof limit (an isolated mapper test cannot prove public wiring) by routing every obligation through the CLI integration boundary rather than a unit-level substitute."
+        },
+        {
+          "severity": "info",
+          "message": "Data and measurement categories were recorded as inapplicable by the accepted Implementation Plan; the execution checklist correspondingly carries compatibility (status-5) rather than inventing placeholder migration or measurement tasks. This is consistent with the accepted scope and is not a coverage gap."
+        }
+      ]
+    },
+    {
+      "fixture_id": "execution-reject",
+      "run": 1,
+      "verdict": "request_changes",
+      "findings": [
+        {
+          "severity": "error",
+          "message": "Slice 1's completion signal covers only two accepted states: \"Pending and Approved pass through the CLI entry point and the status help text names those two states.\" Accepted scenarios 3 (Rejected displays the actual blocking findings) and 4 (repair and retry; a stale approval cannot approve the new review) have no completion signal in any slice. A contributor can satisfy every stated signal while Rejected and retry behavior is absent, so accepted behavior obligations status-1, status-7 and status-9 are only partially mapped."
+        },
+        {
+          "severity": "error",
+          "message": "The supplied proof is non-discriminating. The only proof, cli-status-integration, is described as \"The integration fixture covers Pending and Approved states.\" Checklist status-4 claims it will \"Prove all four accepted scenarios through the CLI and coordinator\" and status-7 claims it will \"Reject stale or missing approval receipts and preserve actual findings,\" but the named command (bun run test tests/integration/review-status.test.ts in packages/cli) as scoped cannot fail when a stale receipt displays Approved or when recorded rejection findings are synthesized or hidden. The Implementation Plan's accepted invariant that a missing or stale receipt never appears as approval can be broken while the single named check still passes. Enumerate per-scenario fixture cases — Pending, Approved, terminal Rejected with verbatim recorded findings, and retry where the prior job's receipt does not approve the new plan digest — and state each expected assertion."
+        },
+        {
+          "severity": "error",
+          "message": "The first RED step is not startable for the full accepted behavior. It names the fixture, the command, and a pre-edit failure observation, but its stated failure signal is only \"the missing Pending/Approved assertions fail.\" The highest-risk accepted behavior is the stale-receipt approval boundary, not the Pending/Approved happy path. The RED step must name the stale-receipt and Rejected-findings assertions and their expected failure signal before any production edit, or the implementer invents that proof boundary coverage."
+        },
+        {
+          "severity": "warning",
+          "message": "Internal contradiction in documentation scope: checklist status-9 requires \"Update CLI status help text for all three states,\" while Slice 1's completion signal requires the help text to name only \"those two states.\" Resolve to the three accepted statuses."
+        },
+        {
+          "severity": "info",
+          "message": "The slicing decision (one_pull_request, one slice, relies_on_unmerged_successor false), the prerequisite list, the proof-specification table placement before the checklist, and the decision-status note that the coordinator/receipt source of truth is unchanged are all acceptable as written; no accepted decision is reopened and no product scope is expanded. Only proof coverage and completion signals block approval."
+        }
+      ]
+    },
+    {
+      "fixture_id": "execution-reject",
+      "run": 2,
+      "verdict": "request_changes",
+      "findings": [
+        {
+          "severity": "error",
+          "message": "Non-discriminating proof for accepted scenarios 3 and 4. Slice 1 states \"The integration fixture covers Pending and Approved states\" and its completion signal is \"Pending and Approved pass through the CLI entry point.\" The only proof, cli-status-integration, is therefore specified to exercise two of the four accepted scenarios. Checklist items status-1, status-4, and status-7 claim Rejected with actual blocking findings, retry after repair, and rejection of stale or missing receipts, all resolving to that same proof. As written, an implementation that never renders Rejected, synthesizes rejection text instead of passing the coordinator's recorded findings verbatim, or lets a stale receipt display Approved would still satisfy every named check and the stated completion signal. Extend the fixture and completion signal to exercise a terminal rejected job with its recorded findings and a retry where a receipt bound to a different job identifier or different plan digest does not yield Approved."
+        },
+        {
+          "severity": "error",
+          "message": "The first RED does not begin with the highest-risk case. The plan instructs the implementer to \"observe the missing Pending/Approved assertions fail before editing production code.\" The highest-risk accepted behavior in this ticket is the stale-receipt invariant (\"A stale approval never changes the current review to Approved\") and verbatim rejection findings. The named RED must state the fixture, command, and failure signal for that case before any production edit."
+        },
+        {
+          "severity": "error",
+          "message": "Recorded Decisions are only partially accounted for. The plan supplies one decision status: \"the Implementation Plan's existing coordinator/receipt source of truth is unchanged.\" The accepted Implementation Plan records further load-bearing decisions: binding the display to the current job identifier and plan digest; supplying terminal rejected findings verbatim without synthesis or suppression; retry creating a new review with the old rejection and receipt as historical evidence only; atomic retry binding with concurrent retries and crash-before-binding never displaying Approved; and a running or interrupted review without a terminal receipt displaying Pending with its actual error state. Each needs an explicit status entry of `unchanged`."
+        },
+        {
+          "severity": "error",
+          "message": "The documentation obligation conflicts with the slice completion signal. Checklist item status-9 requires updating CLI status help text \"for all three states,\" while Slice 1's completion signal requires only that \"the status help text names those two states.\" The completion signal can be satisfied with help text that omits Rejected, leaving status-9 unproven. Align the completion signal with the three-state contract."
+        },
+        {
+          "severity": "warning",
+          "message": "Checklist item status-6 (\"Report status-read failures without inventing approval\") and the Implementation Plan's \"A failed status read reports unavailable state rather than inventing approval\" have no named step or fixture case in Slice 1. Name the failure-injection case in the integration fixture so this obligation has a discriminating check rather than relying on the same happy-path assertions."
+        },
+        {
+          "severity": "info",
+          "message": "The slicing decision, one-slice count, `relies_on_unmerged_successor: false`, empty prerequisite list, proof specifications table placed before the Delivery Checklist, and the versioned checklist with unique IDs across all eleven default categories are each present and internally consistent. The rationale is grounded in conceptual cohesion rather than size."
+        }
+      ]
+    },
+    {
+      "fixture_id": "execution-reject",
+      "run": 3,
+      "verdict": "request_changes",
+      "findings": [
+        {
+          "severity": "error",
+          "message": "Non-discriminating proof for accepted scenarios 3 and 4. Slice 1 states \"The integration fixture covers Pending and Approved states,\" and cli-status-integration is the only proof. Scenario 3 (a completed review with blocking findings displays Rejected and those actual findings) and scenario 4 (retry a repaired plan; a stale approval cannot approve it) are never exercised. The mapper could synthesize or drop rejection findings, or display Approved from a stale receipt bound to a different job identifier or plan digest, and `bun run test tests/integration/review-status.test.ts` would still exit 0. Specify fixture cases in that same integration file for a terminal rejected job with recorded error findings asserted verbatim, and for a retry that binds a new job identifier and plan digest while a prior receipt is present and must not yield Approved."
+        },
+        {
+          "severity": "error",
+          "message": "Checklist item status-4 (\"Prove all four accepted scenarios through the CLI and coordinator\") cites cli-status-integration, but the plan's own description of that fixture covers two scenarios. As written the obligation can be recorded satisfied while two accepted scenarios are unproven. Either the fixture description must name all four scenario cases or status-4 must cite a proof that does."
+        },
+        {
+          "severity": "error",
+          "message": "Checklist item status-7 (security and privacy: \"Reject stale or missing approval receipts and preserve actual findings\") resolves to the same fixture, which exercises neither a stale receipt nor a missing receipt nor rejection findings. The Implementation Plan makes \"a stale approval never changes the current review to Approved\" a load-bearing contract; with no case exercising it, the accepted user-facing claim can be false while the named check passes."
+        },
+        {
+          "severity": "error",
+          "message": "Slice 1's completion signal is narrower than its own obligations and internally contradictory: it reads \"Pending and Approved pass through the CLI entry point and the status help text names those two states,\" while status-9 requires help text for all three states and status-1 requires Rejected with actual blocking findings and retry. A contributor satisfying the stated completion signal would ship without Rejected. Restate the completion signal to cover all three displayed states, the verbatim rejection findings, and the retry/stale-receipt path."
+        },
+        {
+          "severity": "warning",
+          "message": "The first RED is named and startable (add the failing fixture, run the stated command from packages/cli, observe the missing assertions fail before production edits), but it names only the Pending/Approved assertions as the failure signal. Once the Rejected and stale-receipt cases are added, the highest-risk RED should be the stale-approval case, since that is the invariant whose violation is unrecoverable for the user."
+        },
+        {
+          "severity": "info",
+          "message": "Non-blocking and correct as supplied: exactly one slice matching the one_pull_request decision with a rationale grounded in conceptual cohesion rather than size; no prerequisites and relies_on_unmerged_successor: false, consistent with a single slice; the proof specifications table precedes the delivery checklist; the v1 checklist marker, unique IDs, and all eleven default categories are present with honest open/missing dispositions; and the decision-status line preserves the coordinator/receipt source of truth without reopening it. No accepted decision is changed, which is why routing is plan-execution rather than plan-implementation."
+        }
+      ]
+    }
+  ],
+  "results_digest": "9085e0194fa82420b5e87f67fae1b5d361747cd6064379ab0730b32a9d814078"
+}
diff --git a/packages/cli/tests/fixtures/reviewer-capability-evidence/gpt-6-astra.json b/packages/cli/tests/fixtures/reviewer-capability-evidence/gpt-6-astra.json
new file mode 100644
index 000000000..62dc1ba51
--- /dev/null
+++ b/packages/cli/tests/fixtures/reviewer-capability-evidence/gpt-6-astra.json
@@ -0,0 +1,192 @@
+{
+  "provider": "openai",
+  "model": "gpt-6-astra",
+  "corpus_digest": "f76edddd71868835e161d06987bce170fb395a71849412dd96c2b6d18c698b24",
+  "rubric_digest": "b9d97005601dcaaa38caefb84716497d792170da6d5d4a0076b039691df9594f",
+  "settings_digest": "acd5a69993710ae8483c78771a67a6d61e061707f39f450a24a9a10511f7bf4d",
+  "evidence_date": "2026-09-29",
+  "runs": [
+    {
+      "fixture_id": "product-approve",
+      "run": 1,
+      "verdict": "approve",
+      "findings": []
+    },
+    {
+      "fixture_id": "product-approve",
+      "run": 2,
+      "verdict": "approve",
+      "findings": []
+    },
+    {
+      "fixture_id": "product-approve",
+      "run": 3,
+      "verdict": "approve",
+      "findings": []
+    },
+    {
+      "fixture_id": "product-reject",
+      "run": 1,
+      "verdict": "request_changes",
+      "findings": [
+        {
+          "severity": "error",
+          "message": "spec.md omits Rejected from accepted behavior and the observable done state. A completed review with blocking findings could remain Pending or hide its findings while satisfying this plan. Define Rejected, require display of the actual blocking findings, and preserve the builder's ability to repair and request another review, as required by the ticket."
+        },
+        {
+          "severity": "error",
+          "message": "spec.md defines Approved solely by possession of an authenticated approval receipt, without requiring that it apply to the current plan and review. After repair and retry, an implementation could display Approved using a stale receipt while meeting this definition. Require current applicable approval and specify that stale approval cannot approve the repaired plan."
+        }
+      ]
+    },
+    {
+      "fixture_id": "product-reject",
+      "run": 2,
+      "verdict": "request_changes",
+      "findings": [
+        {
+          "severity": "error",
+          "message": "spec.md omits Rejected, actual blocking findings, and repair-and-retry behavior required by CAP100. A completed review with blocking findings could remain Pending or hide its findings while satisfying the plan's done state. Define the rejected outcome, display of actual blocking findings, and ability to request another review after repair."
+        },
+        {
+          "severity": "error",
+          "message": "spec.md defines Approved solely by possession of an authenticated approval receipt, without requiring that receipt to apply to the current plan and review. After repair, an implementation could reuse a stale receipt and falsely display Approved while meeting this definition. Require current applicable approval and explicitly exclude stale approvals."
+        }
+      ]
+    },
+    {
+      "fixture_id": "product-reject",
+      "run": 3,
+      "verdict": "request_changes",
+      "findings": [
+        {
+          "severity": "error",
+          "message": "spec.md omits Rejected from accepted behavior and the done state. A completed review with blocking findings could remain Pending or hide its findings while satisfying this plan. Require Rejected to display the actual blocking findings and permit repair and retry, as required by CAP100."
+        },
+        {
+          "severity": "error",
+          "message": "spec.md defines Approved by the existence of an authenticated approval receipt without requiring it to apply to the current reviewed plan. After repair and retry, an implementation could display Approved using a stale receipt while satisfying this definition. Require current applicable approval and explicitly exclude stale approvals from approving the revised plan."
+        }
+      ]
+    },
+    {
+      "fixture_id": "implementation-approve",
+      "run": 1,
+      "verdict": "approve",
+      "findings": []
+    },
+    {
+      "fixture_id": "implementation-approve",
+      "run": 2,
+      "verdict": "approve",
+      "findings": []
+    },
+    {
+      "fixture_id": "implementation-approve",
+      "run": 3,
+      "verdict": "approve",
+      "findings": []
+    },
+    {
+      "fixture_id": "implementation-reject",
+      "run": 1,
+      "verdict": "request_changes",
+      "findings": [
+        {
+          "severity": "error",
+          "message": "The decision that reviewer output alone can display Approved permits a current review to appear approved before an authenticated approval receipt exists. This violates the Product Plan and ticket's existing approval authority, and contradicts the plan's own missing-receipt and authorization contracts. Implementation Planning owns repairing this decision within the already accepted Product boundary: require a current authenticated approval receipt bound to the job identifier and plan digest. Include CLI-to-coordinator proof that an approving reviewer verdict without that receipt cannot display Approved; successful authenticated approval and stale-receipt checks alone do not discriminate this failure."
+        }
+      ]
+    },
+    {
+      "fixture_id": "implementation-reject",
+      "run": 2,
+      "verdict": "request_changes",
+      "findings": [
+        {
+          "severity": "error",
+          "message": "impl-plan.md permits a reviewer verdict to display Approved before an authenticated approval receipt exists. When a reviewer returns approve but receipt authentication or persistence is incomplete or fails, the CLI could report Approved without the authority required by the accepted Product Plan. This also contradicts the plan's own missing-receipt and authorization contracts. Implementation Planning owns repairing this decision: require a current authenticated receipt bound to both the active job and plan digest before displaying Approved. Include a real CLI/coordinator proof where an approve verdict exists without that receipt and verify that Approved is withheld."
+        }
+      ]
+    },
+    {
+      "fixture_id": "implementation-reject",
+      "run": 3,
+      "verdict": "request_changes",
+      "findings": [
+        {
+          "severity": "error",
+          "message": "impl-plan.md permits a reviewer output verdict to display Approved before an authenticated approval receipt exists. When a reviewer returns approve but receipt authentication or issuance has not completed, the CLI could falsely report approval. This contradicts the accepted Product Plan and the plan’s own missing-receipt and authorization rules. The Implementation Plan owner must remove verdict-only approval and consistently require a current authenticated receipt bound to the current job and plan digest. Include proof at the real CLI/coordinator boundary that an approve verdict without that receipt cannot display Approved; the named happy-path and stale-receipt checks do not establish this."
+        }
+      ]
+    },
+    {
+      "fixture_id": "execution-approve",
+      "run": 1,
+      "verdict": "approve",
+      "findings": []
+    },
+    {
+      "fixture_id": "execution-approve",
+      "run": 2,
+      "verdict": "approve",
+      "findings": []
+    },
+    {
+      "fixture_id": "execution-approve",
+      "run": 3,
+      "verdict": "approve",
+      "findings": []
+    },
+    {
+      "fixture_id": "execution-reject",
+      "run": 1,
+      "verdict": "request_changes",
+      "findings": [
+        {
+          "severity": "error",
+          "message": "Slice 1's fixture and completion signal cover only Pending and Approved. All named checks could pass while Rejected omits actual blocking findings, repaired plans cannot be retried, or a stale receipt falsely grants approval. Checklist rows status-1, status-4, and status-7 do not supply the missing executable proof. Specify real CLI/coordinator fixtures, actions, and assertions for rejection with verbatim findings, repair and retry, missing or unauthenticated receipts, and receipts bound to a different job or plan digest. Begin production work with a named highest-risk RED and its concrete failure assertion."
+        },
+        {
+          "severity": "error",
+          "message": "Slice 1's generic instruction to implement the mapper and CLI wiring leaves accepted decision-derived obligations without concrete tasks or completion signals: current-job/digest binding, concurrent retries finishing out of order, a crash before retry binding, interrupted reviews with their actual error state, status-read failures, and unchanged CLI exit codes. The broad source-of-truth decision statement does not account for these accepted decisions. Map each to explicit execution actions, prerequisites, observable assertions, and unchanged decision statuses; otherwise delivery can finish while violating the accepted coordinator contract."
+        },
+        {
+          "severity": "error",
+          "message": "Slice 1 explicitly completes when CLI help names only Pending and Approved, contradicting status-9 and the accepted three-state documentation requirement. Require help text and its completion check to include Rejected, alongside the other two states."
+        }
+      ]
+    },
+    {
+      "fixture_id": "execution-reject",
+      "run": 2,
+      "verdict": "request_changes",
+      "findings": [
+        {
+          "severity": "error",
+          "message": "Slice 1's executable work, fixture, and completion signal cover only Pending and Approved, and its help-text completion signal names only those states. Accepted scenarios 3 and 4 require Rejected, verbatim blocking findings, and retry after repair. Checklist entries status-1, status-4, and status-9 do not supply the missing execution steps or assertions. Add concrete CLI/coordinator fixture actions, implementation tasks, and completion assertions for rejection, actual findings, retry, and help text covering all three states. Otherwise the slice can finish while builders cannot see or retry a rejected review."
+        },
+        {
+          "severity": "error",
+          "message": "The cli-status-integration proof specifies no discriminating fixtures or assertions for job/digest binding, missing or stale receipts, unauthenticated verdicts, concurrent retry completion, a crash before retry binding, interrupted reviews, or status-read failures. Pending/Approved happy-path assertions can pass even if an old receipt falsely approves repaired plan bytes. Specify real CLI/coordinator setup, actions, and observable assertions for these accepted decisions, plus exit-code compatibility; map each decision to Slice 1 and explicitly retain its unchanged status. Make the highest-risk false-approval case the initial RED, with its expected failure before production edits."
+        }
+      ]
+    },
+    {
+      "fixture_id": "execution-reject",
+      "run": 3,
+      "verdict": "request_changes",
+      "findings": [
+        {
+          "severity": "error",
+          "message": "Slice 1 and cli-status-integration cover only Pending and Approved, and the completion signal explicitly requires help text for only those two states. All named assertions could pass while a rejected review hides blocking findings or a repaired plan cannot be retried, violating accepted scenarios 3–4 and obligations status-1, status-4, and status-9. Add concrete implementation and real CLI/coordinator fixture steps for Rejected, verbatim blocking findings, and repair/retry; require all three states in help text and the completion signal."
+        },
+        {
+          "severity": "error",
+          "message": "Slice 1 provides no executable fixtures or assertions for the accepted authority and failure contracts: receipts bound to both current job and plan digest, missing or unauthenticated approval, concurrent retries finishing out of order, a crash before retry binding, interrupted reviews, and failed status reads. Its generic mapper/wiring step and two-state proof permit stale approval to display Approved while every specified check passes. Preserve these existing decisions explicitly and specify fixture setup, actions, and observable assertions through the CLI/coordinator boundary, including unchanged exit-code compatibility. Map these obligations and each accepted approach decision to the slice and its completion evidence; the single source-of-truth decision-status statement does not account for them."
+        }
+      ]
+    }
+  ],
+  "results_digest": "c9b154c8b1f43481f99448f2de7ed2a1f416cd1df6a672d27967b8f87f7fdc56"
+}
diff --git a/packages/cli/tests/hooks/review-ledger.test.ts b/packages/cli/tests/hooks/review-ledger.test.ts
index 366d89d0b..9f655123a 100644
--- a/packages/cli/tests/hooks/review-ledger.test.ts
+++ b/packages/cli/tests/hooks/review-ledger.test.ts
@@ -17,6 +17,7 @@ import {
   parseReviewStamps,
   readCrossAgentReviewPolicy,
   reviewGateAppliesToPhase,
+  reviewGateForIndependentDesign,
   reviewGateForNextAsset,
   reviewScope,
   type ReviewStamp,
@@ -25,6 +26,34 @@ import {
 /** A coordinator review id, as write-review-stamp.ts records it. */
 const REVIEW_ID = 'b3f1c2d4-0000-4000-8000-000000000001';
 
+describe('independent design review gate', () => {
+  const scope = reviewScope('DES123', 'impl-plan', hashArtifact('plan'));
+  const reduced: ReviewStamp = {
+    scope,
+    reviewId: REVIEW_ID,
+    author: 'claude',
+    reviewer: 'claude',
+    independence: 'reduced',
+  };
+
+  it('rejects an authenticated reduced receipt', () => {
+    expect(reviewGateForIndependentDesign(scope, [reduced]).ok).toBe(false);
+  });
+
+  it('accepts an independent receipt or an explicit reasoned skip', () => {
+    expect(
+      reviewGateForIndependentDesign(scope, [
+        { ...reduced, reviewer: 'codex', independence: 'cross-agent' },
+      ]),
+    ).toEqual({ ok: true });
+    expect(
+      reviewGateForIndependentDesign(scope, [
+        { scope, skipReason: 'Reviewed by architecture owner' },
+      ]),
+    ).toEqual({ ok: true });
+  });
+});
+
 describe('reviewGateForNextAsset (TB1.AC1 — per-asset stamp gates the next asset)', () => {
   it('unstamped_prior_blocks_next: denies, naming the unreviewed prior asset', () => {
     const verdict = reviewGateForNextAsset('jtbd', []);
diff --git a/packages/cli/tests/integration/architecture-review-gate.test.ts b/packages/cli/tests/integration/architecture-review-gate.test.ts
index b32c6ae93..f395639b5 100644
--- a/packages/cli/tests/integration/architecture-review-gate.test.ts
+++ b/packages/cli/tests/integration/architecture-review-gate.test.ts
@@ -55,6 +55,7 @@ function writeReviewResponse(
   status: string,
   model?: string,
   reviewId = REVIEW_ID,
+  independence: 'cross-agent' | 'reduced' = 'cross-agent',
 ): void {
   writeFileSync(
     nodePath.join(shared.pluginDirectory, `response-${reviewId}.json`),
@@ -64,7 +65,7 @@ function writeReviewResponse(
         status,
         review_kind: 'plan-implementation',
         review_targets: [`.project/tickets/${id}/impl-plan.md`],
-        independence: 'cross-agent',
+        independence,
         author_agent: 'codex',
         actual_reviewer: 'claude',
         reviewer_model: model,
@@ -162,6 +163,7 @@ function writeStamp(
     hashOf?: string;
     witnessed?: boolean;
     reviewId?: string;
+    independence?: 'cross-agent' | 'reduced';
   } = {},
 ): void {
   const scope = reviewScope(
@@ -175,7 +177,7 @@ function writeStamp(
     options.model,
     options.witnessed ? 'codex' : undefined,
     options.witnessed ? 'claude' : undefined,
-    options.witnessed ? 'cross-agent' : undefined,
+    options.witnessed ? (options.independence ?? 'cross-agent') : undefined,
     options.witnessed ? (options.reviewId ?? REVIEW_ID) : undefined,
   )}`;
   appendFileSync(
@@ -255,10 +257,11 @@ describe('architecture review gate (MR5M3A)', () => {
     expect(runStopHook('ARG003')).toContain(REVIEW_MSG);
   });
 
-  it('allows when cited and a matching stamp exists', () => {
+  it('allows when cited and a matching independent review receipt exists', () => {
     setConfig({ architectureReviewGate: true });
     writeTicket('ARG004', 'feature', CITED);
-    writeStamp('ARG004', CITED);
+    writeReviewResponse('ARG004', 'approved');
+    writeStamp('ARG004', CITED, { witnessed: true });
     const reason = runStopHook('ARG004');
     expect(reason).not.toContain(CITATION_MSG);
     expect(reason).not.toContain(REVIEW_MSG);
@@ -286,7 +289,7 @@ describe('architecture review gate (MR5M3A)', () => {
     writeTicket('ARG006B', 'feature', CITED);
     writeStamp('ARG006B', CITED, { model: 'claude-sonnet-4-6' });
     expect(runStopHook('ARG006B', { SAFEWORD_AUTHOR_MODEL: 'claude-opus-4-8' })).toContain(
-      CROSS_MODEL_MSG,
+      REVIEW_MSG,
     );
   });
 
@@ -313,7 +316,8 @@ describe('architecture review gate (MR5M3A)', () => {
   it('blocks under cross-model when the stamp records no model (fails closed)', () => {
     setConfig({ architectureReviewGate: true, crossModelReview: true });
     writeTicket('ARG008', 'feature', CITED);
-    writeStamp('ARG008', CITED);
+    writeReviewResponse('ARG008', 'approved');
+    writeStamp('ARG008', CITED, { witnessed: true });
     expect(runStopHook('ARG008', { SAFEWORD_AUTHOR_MODEL: 'claude-opus-4-8' })).toContain(
       CROSS_MODEL_MSG,
     );
@@ -339,7 +343,8 @@ describe('architecture review gate (MR5M3A)', () => {
     setConfig({ architectureReviewGate: true });
     const skipPlan = plan('skip: one obvious choice, nothing to weigh');
     writeTicket('ARG011', 'feature', skipPlan);
-    writeStamp('ARG011', skipPlan);
+    writeReviewResponse('ARG011', 'approved');
+    writeStamp('ARG011', skipPlan, { witnessed: true });
     const reason = runStopHook('ARG011');
     expect(reason).not.toContain(CITATION_MSG);
     expect(reason).not.toContain(REVIEW_MSG);
@@ -424,6 +429,15 @@ describe('architecture review gate (MR5M3A)', () => {
     expect(runStopHook('ARG019')).not.toContain(REVIEW_MSG);
   });
 
+  it('rejects an authenticated reduced receipt at the opt-in independent architecture gate', () => {
+    setConfig({ architectureReviewGate: true, crossAgentReview: 'prefer' });
+    writeTicket('ARG021', 'feature', CITED);
+    writeReviewResponse('ARG021', 'approved', undefined, REVIEW_ID, 'reduced');
+    writeStamp('ARG021', CITED, { witnessed: true, independence: 'reduced' });
+
+    expect(runStopHook('ARG021')).toContain(REVIEW_MSG);
+  });
+
   it('rejects a hand-written coordinator claim when the receipt did not approve', () => {
     setConfig({ architectureReviewGate: true });
     writeTicket('ARG020', 'feature', CITED);
diff --git a/packages/cli/tests/integration/coding-authorization.test.ts b/packages/cli/tests/integration/coding-authorization.test.ts
index 2fc950566..7cdbbf9d3 100644
--- a/packages/cli/tests/integration/coding-authorization.test.ts
+++ b/packages/cli/tests/integration/coding-authorization.test.ts
@@ -225,7 +225,7 @@ async function refreshReviews(
       { bin },
     );
     stamps.push(
-      `2026-09-18T00:01:01.000Z fixture review:${ticketFolder}:phase@scenario-gate author:codex reviewer:claude independence:cross-agent review-id:${reviewId}`,
+      `2026-09-18T00:01:01.000Z fixture review:${ticketFolder}:phase@scenario-gate author:codex reviewer:claude independence:reduced review-id:${reviewId}`,
     );
   }
   if (from === 'scenario' || from === 'implementation') {
@@ -237,7 +237,7 @@ async function refreshReviews(
       { bin },
     );
     stamps.push(
-      `2026-09-18T00:01:02.000Z fixture review:${ticketFolder}:phase@plan-implementation author:codex reviewer:claude independence:cross-agent review-id:${reviewId}`,
+      `2026-09-18T00:01:02.000Z fixture review:${ticketFolder}:phase@plan-implementation author:codex reviewer:claude independence:reduced review-id:${reviewId}`,
     );
   }
   const plan = readFileSync(nodePath.join(root, executionTarget), 'utf8');
@@ -252,7 +252,7 @@ async function refreshReviews(
     },
   );
   stamps.push(
-    `2026-09-18T00:01:03.000Z fixture review:${ticketFolder}:phase@plan-execution author:codex reviewer:claude independence:cross-agent review-id:${reviewId}`,
+    `2026-09-18T00:01:03.000Z fixture review:${ticketFolder}:phase@plan-execution author:codex reviewer:claude independence:reduced review-id:${reviewId}`,
   );
   const ledgerPath = nodePath.join(root, '.project', 'skill-invocations.log');
   writeFileSync(ledgerPath, `${readFileSync(ledgerPath, 'utf8')}${stamps.join('\n')}\n`);
@@ -323,8 +323,8 @@ async function featureFixture(
     { bin },
   );
   const reviewStamps = [
-    `2026-09-18T00:00:02.000Z fixture review:${ticketFolder}:phase@scenario-gate author:codex reviewer:claude independence:cross-agent review-id:${scenarioReviewId}`,
-    `2026-09-18T00:00:03.000Z fixture review:${ticketFolder}:phase@plan-implementation author:codex reviewer:claude independence:cross-agent review-id:${implementationReviewId}`,
+    `2026-09-18T00:00:02.000Z fixture review:${ticketFolder}:phase@scenario-gate author:codex reviewer:claude independence:reduced review-id:${scenarioReviewId}`,
+    `2026-09-18T00:00:03.000Z fixture review:${ticketFolder}:phase@plan-implementation author:codex reviewer:claude independence:reduced review-id:${implementationReviewId}`,
   ];
   if (includeExecutionPlan) {
     const plan = executionPlan();
@@ -336,7 +336,7 @@ async function featureFixture(
       { bin, executionPlanRecord: executionReviewRecord(plan, designApprovalGate) },
     );
     reviewStamps.push(
-      `2026-09-18T00:00:04.000Z fixture review:${ticketFolder}:phase@plan-execution author:codex reviewer:claude independence:cross-agent review-id:${executionReviewId}`,
+      `2026-09-18T00:00:04.000Z fixture review:${ticketFolder}:phase@plan-execution author:codex reviewer:claude independence:reduced review-id:${executionReviewId}`,
     );
   }
   writeFileSync(
@@ -480,7 +480,7 @@ describe('coding authorization', () => {
       data: {
         command: 'ticket coding-authorization',
         coding_authorization: 'authorized',
-        achieved_independence: 'cross-agent',
+        achieved_independence: 'reduced',
         grants_authority: false,
       },
     });
@@ -494,7 +494,7 @@ describe('coding authorization', () => {
     expect(result.exitCode).toBe(0);
     expect(result.data).toMatchObject({
       coding_authorization: 'authorized',
-      achieved_independence: 'cross-agent',
+      achieved_independence: 'reduced',
       grants_authority: false,
     });
     expect(
@@ -636,7 +636,7 @@ describe('coding authorization', () => {
             }));
             rewriteExecutionReviewStamp(root, line =>
               line.replace(
-                'author:codex reviewer:claude independence:cross-agent',
+                'author:codex reviewer:claude independence:reduced',
                 'author:codex reviewer:codex independence:degraded',
               ),
             );
@@ -752,7 +752,7 @@ describe('coding authorization', () => {
     const reviewLedger = nodePath.join(root, '.project', 'skill-invocations.log');
     writeFileSync(
       reviewLedger,
-      `${readFileSync(reviewLedger, 'utf8')}2026-09-18T00:01:02.000Z fixture review:ABC123-feature:phase@plan-implementation author:codex reviewer:claude independence:cross-agent review-id:${implementationReviewId}\n`,
+      `${readFileSync(reviewLedger, 'utf8')}2026-09-18T00:01:02.000Z fixture review:ABC123-feature:phase@plan-implementation author:codex reviewer:claude independence:reduced review-id:${implementationReviewId}\n`,
     );
 
     const staleReceipt = await runCli(['review', 'status', originalExecutionReviewId ?? ''], {
@@ -795,7 +795,7 @@ describe('coding authorization', () => {
     const unchangedLedger = nodePath.join(unchangedRoot, '.project', 'skill-invocations.log');
     writeFileSync(
       unchangedLedger,
-      `${readFileSync(unchangedLedger, 'utf8')}2026-09-18T00:01:02.000Z fixture review:ABC123-feature:phase@plan-implementation author:codex reviewer:claude independence:cross-agent review-id:${unchangedImplementationReviewId}\n`,
+      `${readFileSync(unchangedLedger, 'utf8')}2026-09-18T00:01:02.000Z fixture review:ABC123-feature:phase@plan-implementation author:codex reviewer:claude independence:reduced review-id:${unchangedImplementationReviewId}\n`,
     );
     const contentIdenticalRereview = await codingAuthorization(unchangedRoot);
     expect(contentIdenticalRereview.exitCode).toBe(0);
@@ -934,7 +934,7 @@ describe('coding authorization', () => {
     }));
     rewriteExecutionReviewStamp(root, line =>
       line.replace(
-        'author:codex reviewer:claude independence:cross-agent',
+        'author:codex reviewer:claude independence:reduced',
         'author:codex reviewer:codex independence:degraded',
       ),
     );
diff --git a/packages/cli/tests/integration/delivery-execution-prerequisite.test.ts b/packages/cli/tests/integration/delivery-execution-prerequisite.test.ts
index 979d76b0c..2fc44b94f 100644
--- a/packages/cli/tests/integration/delivery-execution-prerequisite.test.ts
+++ b/packages/cli/tests/integration/delivery-execution-prerequisite.test.ts
@@ -302,7 +302,7 @@ async function admitThroughInstalledCli(
     const id = (JSON.parse(reviewed.stdout) as { data: { review_id: string } }).data.review_id;
     expect(id).toBeTypeOf('string');
     stamps.push(
-      `2026-09-13T00:00:00.000Z fixture review:ABC123-feature:phase@${reviewKind} author:codex reviewer:claude independence:cross-agent review-id:${id}`,
+      `2026-09-13T00:00:00.000Z fixture review:ABC123-feature:phase@${reviewKind} author:codex reviewer:claude independence:reduced review-id:${id}`,
     );
   }
   writeFileSync(nodePath.join(root, '.project', 'skill-invocations.log'), `${stamps.join('\n')}\n`);
diff --git a/packages/cli/tests/integration/installed-planning-copy-admission.test.ts b/packages/cli/tests/integration/installed-planning-copy-admission.test.ts
index 7ddfb0762..5d2f96499 100644
--- a/packages/cli/tests/integration/installed-planning-copy-admission.test.ts
+++ b/packages/cli/tests/integration/installed-planning-copy-admission.test.ts
@@ -132,7 +132,7 @@ process.stdin.on('end', () => {
         '--reviewer-agent',
         'claude',
         '--independence',
-        'cross-agent',
+        'reduced',
         '--review-id',
         id,
         ...artifact,
diff --git a/packages/cli/tests/integration/plan-design-approval.test.ts b/packages/cli/tests/integration/plan-design-approval.test.ts
index 1a01f3964..f967f3a91 100644
--- a/packages/cli/tests/integration/plan-design-approval.test.ts
+++ b/packages/cli/tests/integration/plan-design-approval.test.ts
@@ -288,8 +288,8 @@ function fixture(designApprovalGate: boolean, reviewState: ReviewState = 'approv
   writeFileSync(
     ledgerPath,
     `${existingLedger}${[
-      `2026-09-11T00:00:00.000Z fixture review:${scope} author:codex reviewer:claude independence:cross-agent review-id:${reviewId}`,
-      `2026-09-11T00:00:01.000Z fixture review:${TICKET_FOLDER}:phase@plan-implementation author:codex reviewer:claude independence:cross-agent review-id:${reviewId}`,
+      `2026-09-11T00:00:00.000Z fixture review:${scope} author:codex reviewer:claude independence:reduced review-id:${reviewId}`,
+      `2026-09-11T00:00:01.000Z fixture review:${TICKET_FOLDER}:phase@plan-implementation author:codex reviewer:claude independence:reduced review-id:${reviewId}`,
       '',
     ].join('\n')}`,
   );
@@ -364,8 +364,8 @@ function appendCurrentReview(project: Fixture, plan: string): void {
   writeFileSync(
     project.ledgerPath,
     `${readFileSync(project.ledgerPath, 'utf8')}${[
-      `2026-09-11T00:01:00.000Z fixture review:${scope} author:codex reviewer:claude independence:cross-agent review-id:${reviewId}`,
-      `2026-09-11T00:01:01.000Z fixture review:${TICKET_FOLDER}:phase@plan-implementation author:codex reviewer:claude independence:cross-agent review-id:${reviewId}`,
+      `2026-09-11T00:01:00.000Z fixture review:${scope} author:codex reviewer:claude independence:reduced review-id:${reviewId}`,
+      `2026-09-11T00:01:01.000Z fixture review:${TICKET_FOLDER}:phase@plan-implementation author:codex reviewer:claude independence:reduced review-id:${reviewId}`,
       '',
     ].join('\n')}`,
   );
@@ -464,8 +464,8 @@ function addReviewedTicket(project: Fixture, ticketId: string, suffix: string):
   writeFileSync(
     project.ledgerPath,
     `${readFileSync(project.ledgerPath, 'utf8')}${[
-      `2026-09-11T00:02:00.000Z fixture review:${scope} author:codex reviewer:claude independence:cross-agent review-id:${reviewId}`,
-      `2026-09-11T00:02:01.000Z fixture review:${folder}:phase@plan-implementation author:codex reviewer:claude independence:cross-agent review-id:${reviewId}`,
+      `2026-09-11T00:02:00.000Z fixture review:${scope} author:codex reviewer:claude independence:reduced review-id:${reviewId}`,
+      `2026-09-11T00:02:01.000Z fixture review:${folder}:phase@plan-implementation author:codex reviewer:claude independence:reduced review-id:${reviewId}`,
       '',
     ].join('\n')}`,
   );
@@ -578,7 +578,7 @@ describe('installed CLI human design authority follows configuration', () => {
     const payload = JSON.parse(result.stdout) as { data?: Record<string, unknown> };
     expect(payload.data).toMatchObject({
       approval_status: 'not-required',
-      achieved_independence: 'cross-agent',
+      achieved_independence: 'reduced',
     });
     expect(readFileSync(project.ledgerPath, 'utf8')).toContain('human-approval:not-required');
     expect(approvalEvents(project.ledgerPath)).toEqual([]);
@@ -847,7 +847,7 @@ describe('Implementation Plan review admission controls Execution Planning', ()
     expect(result.exitCode, result.stdout).toBe(0);
     expect(phase(project.ticketPath)).toBe('plan-execution');
     expect(JSON.parse(result.stdout)).toMatchObject({
-      data: { approval_status: 'not-required', achieved_independence: 'cross-agent' },
+      data: { approval_status: 'not-required', achieved_independence: 'reduced' },
     });
     expect(result.stdout).not.toContain('Implementation Plan review is blocked');
   });
@@ -952,8 +952,8 @@ describe('Implementation Plan review admission controls Execution Planning', ()
     writeFileSync(
       project.ledgerPath,
       `${readFileSync(project.ledgerPath, 'utf8')}${[
-        `2026-09-11T00:01:00.000Z fixture review:${scope} author:codex reviewer:claude independence:cross-agent review-id:${project.reviewId}`,
-        `2026-09-11T00:01:01.000Z fixture review:${TICKET_FOLDER}:phase@plan-implementation author:codex reviewer:claude independence:cross-agent review-id:${project.reviewId}`,
+        `2026-09-11T00:01:00.000Z fixture review:${scope} author:codex reviewer:claude independence:reduced review-id:${project.reviewId}`,
+        `2026-09-11T00:01:01.000Z fixture review:${TICKET_FOLDER}:phase@plan-implementation author:codex reviewer:claude independence:reduced review-id:${project.reviewId}`,
         '',
       ].join('\n')}`,
     );
@@ -1003,7 +1003,7 @@ describe('Implementation Plan review admission controls Execution Planning', ()
   it('rejects assurance text that disagrees with the authenticated review', async () => {
     const project = fixture(false);
     rewriteReviewStamps(project, line =>
-      line.replace('independence:cross-agent', 'independence:degraded'),
+      line.replace('independence:reduced', 'independence:degraded'),
     );
 
     const result = await runCli(['--json', '--no-input', 'ticket', 'approve-plan', TICKET_ID], {
@@ -1024,9 +1024,12 @@ describe('Implementation Plan review admission controls Execution Planning', ()
       ...data,
       author_agent: 'claude',
       actual_reviewer: 'claude',
+      independence: 'cross-agent',
     }));
     rewriteReviewStamps(project, line =>
-      line.replace('author:codex reviewer:claude', 'author:claude reviewer:claude'),
+      line
+        .replace('author:codex reviewer:claude', 'author:claude reviewer:claude')
+        .replace('independence:reduced', 'independence:cross-agent'),
     );
 
     const result = await runCli(['--json', '--no-input', 'ticket', 'approve-plan', TICKET_ID], {
@@ -1045,7 +1048,7 @@ describe('Implementation Plan review admission controls Execution Planning', ()
     const project = fixture(false);
     mutateReview(project, data => ({ ...data, independence: 'degraded' }));
     rewriteReviewStamps(project, line =>
-      line.replace('independence:cross-agent', 'independence:degraded'),
+      line.replace('independence:reduced', 'independence:degraded'),
     );
 
     const result = await runCli(['--json', '--no-input', 'ticket', 'approve-plan', TICKET_ID], {
diff --git a/packages/cli/tests/integration/plan-execution-journey.test.ts b/packages/cli/tests/integration/plan-execution-journey.test.ts
index ca5d2173a..187c39fd8 100644
--- a/packages/cli/tests/integration/plan-execution-journey.test.ts
+++ b/packages/cli/tests/integration/plan-execution-journey.test.ts
@@ -544,7 +544,7 @@ describe('Execution Plan cold-start journey', () => {
             '--reviewer-agent',
             'claude',
             '--independence',
-            'cross-agent',
+            'reduced',
             '--review-id',
             result.data.review_id,
           ],
diff --git a/packages/cli/tests/integration/planning-documentation.test.ts b/packages/cli/tests/integration/planning-documentation.test.ts
new file mode 100644
index 000000000..e99988e62
--- /dev/null
+++ b/packages/cli/tests/integration/planning-documentation.test.ts
@@ -0,0 +1,47 @@
+import { readFileSync } from 'node:fs';
+import nodePath from 'node:path';
+
+import { describe, expect, it } from 'vitest';
+
+const root = nodePath.resolve(import.meta.dirname, '../../../..');
+
+describe('planning fallback documentation', () => {
+  it('marks the older coordinator decision as superseded in part', () => {
+    const architecture = readFileSync(nodePath.join(root, 'ARCHITECTURE.md'), 'utf8');
+    const olderRecord = architecture
+      .split('**Date:** 2026-08-02', 2)[1]
+      ?.split('**OpenCode extension', 1)[0];
+    expect(olderRecord).toContain(
+      'Superseded in part by the 2026-09-20 planning fallback decision',
+    );
+    expect(olderRecord).toContain('immutable coordinator packet');
+  });
+
+  it('describes reduced fallback honestly in the public overview', () => {
+    const readme = readFileSync(nodePath.join(root, 'README.md'), 'utf8');
+    expect(readme).toContain('reduced independence');
+    expect(readme).toContain('Cursor itself has no headless reviewer route');
+    expect(readme).toContain('A current receipt is still required at the phase');
+    expect(readme).not.toContain('Both read the live worktree, so');
+    expect(readme).toContain('opt-in `architectureReviewGate`');
+    expect(readme).toContain('reasoned skip');
+  });
+
+  it('distinguishes planning approval from the later independent architecture gate', () => {
+    const guidance = readFileSync(
+      nodePath.join(root, 'packages/cli/templates/skills/bdd/PLAN_IMPLEMENTATION.md'),
+      'utf8',
+    );
+    expect(guidance).toMatch(/does not clear\s+the later architecture gate/u);
+    expect(guidance).toContain('reasoned skip');
+  });
+
+  it('describes the Cursor Cloud transition boundary without claiming stop hooks are absent', () => {
+    const guidance = readFileSync(
+      nodePath.join(root, 'packages/cli/templates/skills/bdd/PLAN_IMPLEMENTATION.md'),
+      'utf8',
+    );
+    expect(guidance).toContain('Cursor Cloud Agents run command-based `preToolUse` and stop hooks');
+    expect(guidance).toContain('enforcement\n   rides the transition gate');
+  });
+});
diff --git a/packages/cli/tests/integration/planning-review-fallback.test.ts b/packages/cli/tests/integration/planning-review-fallback.test.ts
new file mode 100644
index 000000000..c62c0c522
--- /dev/null
+++ b/packages/cli/tests/integration/planning-review-fallback.test.ts
@@ -0,0 +1,296 @@
+import { spawnSync } from 'node:child_process';
+import { mkdirSync, readFileSync, rmSync, symlinkSync, writeFileSync } from 'node:fs';
+import nodePath from 'node:path';
+
+import { afterEach, describe, expect, it } from 'vitest';
+
+import {
+  createConfiguredProject,
+  createTemporaryDirectory,
+  runCli,
+  testCliPath,
+} from '../helpers.js';
+import { writePlanningInventories } from '../planning-fixtures.js';
+import { PLANNING_ROLE_PRODUCT } from '../planning-role-fixtures.js';
+import {
+  cleanupTrustedReviewerDirectories,
+  createTrustedReviewerDirectory,
+  REVIEWER_CAPABILITIES,
+} from '../review-fixtures.js';
+
+const projects: string[] = [];
+
+afterEach(() => {
+  for (const project of projects) rmSync(project, { recursive: true, force: true });
+  projects.length = 0;
+  cleanupTrustedReviewerDirectories();
+});
+
+describe('planning fallback after independent route exhaustion', () => {
+  // eslint-disable-next-line complexity -- The fixture exercises one end-to-end review and admission path across host variants.
+  async function reviewThroughAdmission(
+    hostContinuation: boolean,
+    author: 'claude' | 'cursor' | 'opencode' = 'claude',
+    independentOnly = false,
+    failedFirstSameAgent = false,
+  ): Promise<Record<string, unknown>> {
+    const project = createTemporaryDirectory();
+    projects.push(project);
+    await createConfiguredProject(project);
+    writePlanningInventories(project);
+    if (independentOnly || failedFirstSameAgent) {
+      const configPath = nodePath.join(project, '.safeword/config.json');
+      const config = JSON.parse(readFileSync(configPath, 'utf8'));
+      writeFileSync(
+        configPath,
+        JSON.stringify({
+          ...config,
+          crossAgentReviewRoutes: {
+            [author]: failedFirstSameAgent
+              ? [
+                  { reviewer: 'codex' },
+                  { reviewer: 'claude', model: 'no-such-model' },
+                  { reviewer: 'claude' },
+                ]
+              : [{ reviewer: 'codex', model: 'gpt-6-astra' }],
+          },
+        }),
+      );
+    }
+    const ticket = '.project/tickets/FAL123-fallback';
+    mkdirSync(nodePath.join(project, ticket), { recursive: true });
+    writeFileSync(
+      nodePath.join(project, ticket, 'ticket.md'),
+      '---\nid: FAL123\ntype: feature\nphase: plan-implementation\nstatus: in_progress\nproduct_plan_contract: v1\nscope: preserve approval\nout_of_scope: anonymous approval\ndone_when: current review advances\nphase_anchors:\n  - scenario-gate: features/fallback.feature\n---\n',
+    );
+    writeFileSync(nodePath.join(project, ticket, 'spec.md'), PLANNING_ROLE_PRODUCT);
+    writeFileSync(
+      nodePath.join(project, ticket, 'impl-plan.md'),
+      '# Implementation Plan\n\n**Status:** planned\n\n## Approach\n\nPreserve authenticated approval.\n\n## Decisions\n\nUse the current review receipt.\n\n## Design alignment\n\nEnsure review is honest.\n\n## Architecture applicability\n\nskip: no architecture records apply\n\n## Data applicability\n\nskip: no product data changes\n\n## Known deviations\n\nskip: none\n\n## Doc impact\n\nskip: no customer docs change\n\n## Assessment triggers\n\nRevisit if review authority changes.\n',
+    );
+    mkdirSync(nodePath.join(project, 'features'), { recursive: true });
+    writeFileSync(
+      nodePath.join(project, 'features/fallback.feature'),
+      '@fallback.BU1.R1\nFeature: Honest fallback\n  Scenario: Current review advances\n    Given a current review\n    When the builder advances\n    Then the achieved independence is recorded\n',
+    );
+    const reviewer = createTrustedReviewerDirectory('safeword-planning-fallback-');
+    mkdirSync(nodePath.join(reviewer, 'runtime'));
+    symlinkSync(testCliPath, nodePath.join(reviewer, 'runtime/cli.js'));
+    const bun = spawnSync('which', ['bun'], { encoding: 'utf8' });
+    expect(bun.status).toBe(0);
+    symlinkSync(bun.stdout.trim(), nodePath.join(reviewer, 'bun'));
+    writeFileSync(
+      nodePath.join(reviewer, 'codex'),
+      `#!${process.execPath}\nif (process.argv.includes('--version')) { console.log('codex 1.0.0'); process.exit(0); }\nif (process.argv.includes('--help')) { console.log(${JSON.stringify(REVIEWER_CAPABILITIES.codex)}); process.exit(0); }\nprocess.exit(7);\n`,
+      { mode: 0o755 },
+    );
+    writeFileSync(
+      nodePath.join(reviewer, 'claude'),
+      `#!${process.execPath}\nif (process.argv.includes('--version')) { console.log('claude 1.0.0'); process.exit(0); }\nif (process.argv.includes('--help')) { console.log(${JSON.stringify(REVIEWER_CAPABILITIES.claude)}); process.exit(0); }\nif (${hostContinuation} || process.argv.includes('no-such-model')) process.exit(7);\nlet input = ''; process.stdin.setEncoding('utf8'); process.stdin.on('data', chunk => { input += chunk; }); process.stdin.on('end', () => { const packet = JSON.parse(input.trim().split('\\n').pop()); console.log(JSON.stringify({ structured_output: { schema_version: 1, dispatch_id: packet.dispatch_id, reviewer_agent: 'claude', verdict: 'approve', summary: 'Current plan approved.', findings: [] } })); });\n`,
+      { mode: 0o755 },
+    );
+    const target = `${ticket}/impl-plan.md`;
+    const keyRoot = nodePath.join(project, '.review-keys');
+    const environment = {
+      PATH: `${reviewer}:/usr/bin:/bin`,
+      SAFEWORD_AGENT_RUNTIME: author,
+      CLAUDE_PLUGIN_ROOT: reviewer,
+      SAFEWORD_REVIEW_KEY_ROOT: keyRoot,
+      SAFEWORD_REVIEW_TIMEOUT_MS: '3000',
+      SAFEWORD_REVIEW_RUN_BOUND_MS: '10000',
+      SAFEWORD_NO_UPDATE_CHECK: '1',
+    };
+    const result = await runCli(
+      [
+        'review',
+        'run',
+        'plan-implementation',
+        target,
+        '--context',
+        `${ticket}/spec.md`,
+        '--cwd',
+        project,
+        '--json',
+        '--no-input',
+      ],
+      {
+        cwd: project,
+        env: environment,
+      },
+    );
+    const output = JSON.parse(result.stdout);
+    if (failedFirstSameAgent) {
+      expect(result.exitCode, result.stdout).toBe(0);
+      expect(output.data.review_routes).toMatchObject([
+        { reviewer: 'codex', status: 'attempted' },
+        {
+          reviewer: 'claude',
+          model: 'no-such-model',
+          status: 'attempted',
+          failure: expect.any(String),
+        },
+        { reviewer: 'claude', status: 'attempted' },
+      ]);
+    }
+    if (hostContinuation) {
+      expect(output.data).toMatchObject({
+        status: 'continuation_required',
+        continuation: { tier: 'fresh-context', packet: { kind: 'plan-implementation' } },
+      });
+      const pending = await runCli(
+        ['ticket', 'approve-plan', 'FAL123', '--cwd', project, '--json', '--no-input'],
+        { cwd: project, env: environment },
+      );
+      expect(pending.exitCode).toBe(2);
+      expect(readFileSync(nodePath.join(project, ticket, 'ticket.md'), 'utf8')).toContain(
+        'phase: plan-implementation',
+      );
+      const reviewOutput = {
+        schema_version: 1,
+        dispatch_id: output.data.continuation.packet.dispatch_id,
+        reviewer_agent: author,
+        verdict: 'approve',
+        summary: 'Current plan approved in a fresh host context.',
+        findings: [],
+      };
+      writeFileSync(
+        nodePath.join(project, 'host-review.json'),
+        `${JSON.stringify(reviewOutput)}\n`,
+      );
+      const continued = await runCli(
+        [
+          'review',
+          'continue',
+          output.data.review_id,
+          '--tier',
+          'fresh-context',
+          '--output',
+          'host-review.json',
+          '--offline',
+          '--cwd',
+          project,
+          '--json',
+          '--no-input',
+        ],
+        { cwd: project, env: environment },
+      );
+      expect(continued.exitCode, continued.stdout).toBe(0);
+      Object.assign(output, JSON.parse(continued.stdout));
+    }
+    expect(output.data).toMatchObject({
+      status: 'approved',
+      review_kind: 'plan-implementation',
+      actual_reviewer: author === 'opencode' ? 'claude' : author,
+      independence: 'reduced',
+    });
+    expect(output.findings).not.toContainEqual(
+      expect.objectContaining({ code: 'REVIEW_INDEPENDENCE_DEGRADED' }),
+    );
+    if (author === 'cursor') {
+      const shellGate = spawnSync('bun', ['.safeword/hooks/cursor/before-shell-execution.ts'], {
+        cwd: project,
+        encoding: 'utf8',
+        input: JSON.stringify({
+          workspace_roots: [project],
+          conversation_id: 'fallback-fixture',
+          command: `bun "${project}/.safeword/hooks/write-review-stamp.ts" --phase plan-implementation`,
+        }),
+        env: { ...process.env, ...environment },
+      });
+      expect(shellGate.status, shellGate.stderr).toBe(0);
+      expect(JSON.parse(shellGate.stdout)).toEqual({ permission: 'allow' });
+    }
+    const stampArguments = [
+      nodePath.join(project, '.safeword/hooks/write-review-stamp.ts'),
+      '--ticket',
+      'FAL123-fallback',
+      '--author-agent',
+      author,
+      '--reviewer-agent',
+      author === 'opencode' ? 'claude' : author,
+      '--independence',
+      'reduced',
+      '--review-id',
+      output.data.review_id,
+      '--phase',
+      'plan-implementation',
+    ];
+    const stampOptions = {
+      cwd: project,
+      encoding: 'utf8' as const,
+      env: {
+        ...process.env,
+        ...environment,
+        CLAUDE_PROJECT_DIR: project,
+        CLAUDE_SESSION_ID: author === 'opencode' ? undefined : 'fallback-fixture',
+        CLAUDE_CODE_SESSION_ID: undefined,
+        CODEX_THREAD_ID: undefined,
+      },
+    };
+    if (author === 'opencode') {
+      const unclaimed = [...stampArguments];
+      unclaimed.splice(unclaimed.indexOf('--independence'), 2);
+      const missingClaim = spawnSync('bun', unclaimed, stampOptions);
+      expect(missingClaim.status).not.toBe(0);
+      expect(missingClaim.stdout).toContain('missing run identity');
+      const skipped = spawnSync(
+        'bun',
+        [...stampArguments, '--skip', 'review is unnecessary'],
+        stampOptions,
+      );
+      expect(skipped.status).not.toBe(0);
+      expect(skipped.stdout).toContain('missing run identity');
+      const forged = [...stampArguments];
+      forged[forged.indexOf('--review-id') + 1] = '00000000-0000-4000-8000-000000000000';
+      const rejected = spawnSync('bun', forged, stampOptions);
+      expect(rejected.status).not.toBe(0);
+      expect(rejected.stdout).toContain('did not approve');
+    }
+    const stamp = spawnSync('bun', stampArguments, stampOptions);
+    if (stamp.status !== 0) {
+      throw new Error(`stamp failed: ${stamp.stdout}\n${stamp.stderr}\n${stamp.error ?? ''}`);
+    }
+    const approved = await runCli(
+      ['ticket', 'approve-plan', 'FAL123', '--cwd', project, '--json', '--no-input'],
+      { cwd: project, env: environment },
+    );
+    expect(approved.exitCode, approved.stdout).toBe(0);
+    expect(JSON.parse(approved.stdout).data).toMatchObject({ achieved_independence: 'reduced' });
+    expect(readFileSync(nodePath.join(project, ticket, 'ticket.md'), 'utf8')).toContain(
+      'phase: plan-execution',
+    );
+    return JSON.parse(approved.stdout).data as Record<string, unknown>;
+  }
+
+  it('records a successful same-agent headless review as reduced independence', async () => {
+    expect(await reviewThroughAdmission(false)).toMatchObject({ achieved_independence: 'reduced' });
+  });
+
+  it('keeps a completed same-agent fallback after an earlier same-agent route fails', async () => {
+    expect(await reviewThroughAdmission(false, 'claude', false, true)).toMatchObject({
+      achieved_independence: 'reduced',
+    });
+  });
+
+  it('admits a sealed fresh-host review only after independent and headless routes fail', async () => {
+    expect(await reviewThroughAdmission(true)).toMatchObject({ achieved_independence: 'reduced' });
+  });
+
+  it('admits fresh-host review after all configured independent routes fail without a headless route', async () => {
+    expect(await reviewThroughAdmission(true, 'claude', true)).toMatchObject({
+      achieved_independence: 'reduced',
+    });
+  });
+
+  it('admits a Cursor host review after independent routes fail without inventing a Cursor CLI', async () => {
+    expect(await reviewThroughAdmission(true, 'cursor')).toMatchObject({
+      achieved_independence: 'reduced',
+    });
+  });
+
+  it('admits an OpenCode-authored review through its authenticated receipt without a Claude session', async () => {
+    expect(await reviewThroughAdmission(false, 'opencode')).toMatchObject({
+      achieved_independence: 'reduced',
+    });
+  });
+});
diff --git a/packages/cli/tests/integration/planning-review-host-gates.test.ts b/packages/cli/tests/integration/planning-review-host-gates.test.ts
new file mode 100644
index 000000000..492ab9d53
--- /dev/null
+++ b/packages/cli/tests/integration/planning-review-host-gates.test.ts
@@ -0,0 +1,199 @@
+import { spawnSync } from 'node:child_process';
+import { existsSync, mkdirSync, readFileSync, rmSync, writeFileSync } from 'node:fs';
+import nodePath from 'node:path';
+
+import { afterEach, expect, it } from 'vitest';
+
+import { createConfiguredProject, createTemporaryDirectory, runCli } from '../helpers.js';
+import { writePlanningInventories } from '../planning-fixtures.js';
+import { PLANNING_ROLE_PRODUCT } from '../planning-role-fixtures.js';
+import {
+  cleanupTrustedReviewerDirectories,
+  createTrustedReviewerDirectory,
+  REVIEWER_CAPABILITIES,
+} from '../review-fixtures.js';
+
+const projects: string[] = [];
+
+function capturedClaudeAuthorModel(project: string, model: string): string {
+  const envFile = nodePath.join(project, 'claude-session.env');
+  const started = spawnSync(
+    'bun',
+    [nodePath.join(project, '.safeword/hooks/session-author-model.ts')],
+    {
+      cwd: project,
+      encoding: 'utf8',
+      input: JSON.stringify({ hook_event_name: 'SessionStart', model }),
+      env: { ...process.env, CLAUDE_ENV_FILE: envFile },
+    },
+  );
+  expect(started.status, started.stderr).toBe(0);
+  const captured = /^SAFEWORD_AUTHOR_MODEL=(.+)$/mu.exec(readFileSync(envFile, 'utf8'))?.[1];
+  expect(captured).toBe(model);
+  return captured ?? '';
+}
+
+function confirmedCodexReviewer(invoked: string): string {
+  return String.raw`#!${process.execPath}
+const { writeFileSync } = require('node:fs');
+if (process.argv.includes('--version')) { console.log('codex 1.0.0'); process.exit(0); }
+if (process.argv.includes('--help')) { console.log(process.argv.includes('app-server') ? '--stdio --config' : ${JSON.stringify(REVIEWER_CAPABILITIES.codex)}); process.exit(0); }
+writeFileSync(${JSON.stringify(invoked)}, 'yes');
+let input = ''; process.stdin.setEncoding('utf8'); process.stdin.on('data', chunk => { input += chunk; let end; while ((end = input.indexOf('\n')) !== -1) { const message = JSON.parse(input.slice(0, end)); input = input.slice(end + 1); if (message.id === 1) console.log(JSON.stringify({ id: 1, result: {} })); if (message.id === 2) console.log(JSON.stringify({ id: 2, result: { thread: { id: 'thread-1' }, model: message.params.model, modelProvider: 'openai' } })); if (message.id === 3) { const prompt = message.params.input[0].text; const packet = JSON.parse(prompt.slice(prompt.lastIndexOf('\n') + 1)); const output = { schema_version: 1, dispatch_id: packet.dispatch_id, reviewer_agent: 'codex', verdict: 'approve', summary: 'Reviewer approval.', findings: [{ severity: 'warning', message: 'Check the migration note.' }] }; console.log(JSON.stringify({ id: 3, result: { turn: { id: 'turn-1' } } })); console.log(JSON.stringify({ method: 'turn/completed', params: { threadId: 'thread-1', turn: { id: 'turn-1', status: 'completed', items: [{ type: 'agentMessage', phase: 'final_answer', text: JSON.stringify(output) }] } } })); } } });
+`;
+}
+
+afterEach(() => {
+  for (const project of projects) rmSync(project, { recursive: true, force: true });
+  projects.length = 0;
+  cleanupTrustedReviewerDirectories();
+});
+
+function expectCapabilityFinding(
+  output: {
+    readonly data: Record<string, unknown>;
+    readonly findings: readonly { readonly code: string }[];
+  },
+  qualified: boolean,
+  unknownAuthor: boolean,
+): void {
+  if (qualified) {
+    expect(output.data.capability_failure).toBeUndefined();
+    expect(output.findings).toContainEqual(
+      expect.objectContaining({ code: 'REVIEW_INDEPENDENCE' }),
+    );
+    return;
+  }
+  expect(output.findings).toContainEqual(
+    expect.objectContaining({
+      code: unknownAuthor ? 'AUTHOR_CAPABILITY_UNKNOWN' : 'REVIEWER_CAPABILITY_UNKNOWN',
+    }),
+  );
+}
+
+it.each([
+  ['codex', 'prefer', undefined, false],
+  ['codex', 'require', undefined, false],
+  ['cursor', 'prefer', undefined, false],
+  ['cursor', 'require', undefined, false],
+  ['opencode', 'prefer', undefined, false],
+  ['opencode', 'require', undefined, false],
+  ['claude', 'prefer', undefined, false],
+  ['claude', 'require', undefined, false],
+  ['claude', 'prefer', 'claude-opus-5', false],
+  ['claude', 'require', 'claude-opus-5', false],
+  ['claude', 'prefer', 'claude-opus-5', true],
+  ['claude', 'require', 'claude-opus-5', true],
+] as const)(
+  'labels a %s-authored planning review under %s with author model %s and confirmed reviewer %s',
+  // eslint-disable-next-line complexity, sonarjs/cognitive-complexity -- The host matrix keeps routing and admission assertions on one installed fixture.
+  async (author, policy, authorModel, confirmedReviewer) => {
+    const reviewerAgent = author === 'claude' ? 'codex' : 'claude';
+    const project = createTemporaryDirectory();
+    projects.push(project);
+    await createConfiguredProject(project);
+    writePlanningInventories(project);
+    const configPath = nodePath.join(project, '.safeword/config.json');
+    const config = JSON.parse(readFileSync(configPath, 'utf8'));
+    writeFileSync(
+      configPath,
+      JSON.stringify({
+        ...config,
+        crossAgentReview: policy,
+        crossAgentReviewRoutes: {
+          [author]: [
+            { reviewer: reviewerAgent, ...(confirmedReviewer && { model: 'gpt-6-astra' }) },
+          ],
+        },
+      }),
+    );
+    const ticket = '.project/tickets/AUT123-unknown-author-capability';
+    mkdirSync(nodePath.join(project, ticket), { recursive: true });
+    writeFileSync(
+      nodePath.join(project, ticket, 'ticket.md'),
+      '---\nid: AUT123\ntype: feature\nphase: plan-implementation\nstatus: in_progress\nproduct_plan_contract: v1\nscope: preserve approval\nout_of_scope: anonymous approval\ndone_when: unknown author capability is explicit\nphase_anchors:\n  - scenario-gate: features/author-capability.feature\n---\n',
+    );
+    writeFileSync(nodePath.join(project, ticket, 'spec.md'), PLANNING_ROLE_PRODUCT);
+    writeFileSync(
+      nodePath.join(project, ticket, 'impl-plan.md'),
+      '# Implementation Plan\n\n**Status:** planned\n\n## Approach\n\nPreserve authenticated approval.\n\n## Decisions\n\nUse the current review receipt.\n\n## Design alignment\n\nEnsure independent review is attempted first.\n\n## Architecture applicability\n\nskip: no architecture records apply\n\n## Data applicability\n\nskip: no product data changes\n\n## Known deviations\n\nskip: none\n\n## Doc impact\n\nskip: no customer docs change\n\n## Assessment triggers\n\nRevisit if review authority changes.\n',
+    );
+    mkdirSync(nodePath.join(project, 'features'), { recursive: true });
+    writeFileSync(
+      nodePath.join(project, 'features/author-capability.feature'),
+      `@author-capability.BU1.R1\nFeature: Capability truth\n  Scenario: Unverified capability\n    Given the author model is ${authorModel ?? 'unknown'}\n    When a different reviewer approves\n    Then independence remains unverified\n`,
+    );
+    const reviewer = createTrustedReviewerDirectory('safeword-author-capability-');
+    const invoked = nodePath.join(reviewer, 'invoked');
+    writeFileSync(
+      nodePath.join(reviewer, reviewerAgent),
+      confirmedReviewer
+        ? confirmedCodexReviewer(invoked)
+        : `#!${process.execPath}\nconst { writeFileSync } = require('node:fs');\nif (process.argv.includes('--version')) { console.log('${reviewerAgent} 1.0.0'); process.exit(0); }\nif (process.argv.includes('--help')) { console.log(${JSON.stringify(REVIEWER_CAPABILITIES[reviewerAgent])}); process.exit(0); }\nwriteFileSync(${JSON.stringify(invoked)}, 'yes');\nlet input = ''; process.stdin.setEncoding('utf8'); process.stdin.on('data', chunk => { input += chunk; }); process.stdin.on('end', () => { const packet = JSON.parse(input.trim().split('\\n').pop()); const output = { schema_version: 1, dispatch_id: packet.dispatch_id, reviewer_agent: '${reviewerAgent}', verdict: 'approve', summary: 'Reviewer approval.', findings: [{ severity: 'warning', message: 'Check the migration note.' }] }; if ('${reviewerAgent}' === 'claude') { console.log(JSON.stringify({ type: 'assistant', message: { model: 'claude-opus-5' } })); console.log(JSON.stringify({ type: 'result', subtype: 'success', structured_output: output, modelUsage: { 'claude-opus-5': { canonicalModel: 'claude-opus-5', provider: 'firstParty' } } })); } else console.log(JSON.stringify({ type: 'item.completed', item: { type: 'agent_message', text: JSON.stringify(output) } })); });\n`,
+      { mode: 0o755 },
+    );
+    const reviewed = await runCli(
+      [
+        'review',
+        'run',
+        'plan-implementation',
+        `${ticket}/impl-plan.md`,
+        '--context',
+        `${ticket}/spec.md`,
+        '--cwd',
+        project,
+        '--json',
+        '--no-input',
+      ],
+      {
+        cwd: project,
+        env: {
+          PATH: `${reviewer}:/usr/bin:/bin`,
+          SAFEWORD_AGENT_RUNTIME: author,
+          SAFEWORD_NO_UPDATE_CHECK: '1',
+          ...(author === 'claude' &&
+            authorModel !== undefined && {
+              SAFEWORD_AUTHOR_MODEL: capturedClaudeAuthorModel(project, authorModel),
+            }),
+        },
+      },
+    );
+    const output = JSON.parse(reviewed.stdout);
+    const unknownAuthor = authorModel === undefined;
+    const qualified = authorModel !== undefined && confirmedReviewer;
+    const admitted = qualified || (unknownAuthor && policy === 'prefer');
+    const continuationRequired =
+      author === 'claude' && policy === 'prefer' && authorModel !== undefined && !confirmedReviewer;
+    let expectedStatus = admitted ? 'approved' : 'blocked';
+    if (continuationRequired) expectedStatus = 'continuation_required';
+    expect(reviewed.exitCode).toBe(admitted ? 0 : 2);
+    expect(output.state).toBe(admitted ? 'healthy' : 'action_required');
+    expect(output.data).toMatchObject({
+      status: expectedStatus,
+      independence: admitted ? 'reduced' : 'none',
+      ...(qualified && { independence: 'cross-agent' }),
+      ...(!continuationRequired && { actual_reviewer: reviewerAgent }),
+      ...(reviewerAgent === 'claude' && {
+        confirmed_reviewer_model: { provider: 'anthropic', model: 'claude-opus-5' },
+      }),
+      ...(!qualified &&
+        !continuationRequired && {
+          capability_failure: unknownAuthor
+            ? 'author_capability_unknown'
+            : 'reviewer_capability_unknown',
+        }),
+    });
+    if (continuationRequired) {
+      expect(output.data.continuation).toMatchObject({ tier: 'fresh-context' });
+      expect(output.data.review_routes).toContainEqual(
+        expect.objectContaining({ failure: 'reviewer_capability_unknown' }),
+      );
+    }
+    if (author === 'cursor') expect(output.data.review_routes).toHaveLength(1);
+    if (!continuationRequired) expectCapabilityFinding(output, qualified, unknownAuthor);
+    expect(output.findings).toContainEqual(
+      expect.objectContaining({ code: 'REVIEWER_FINDING', message: 'Check the migration note.' }),
+    );
+    expect(existsSync(invoked)).toBe(true);
+  },
+);
diff --git a/packages/cli/tests/integration/planning-review-route-order.test.ts b/packages/cli/tests/integration/planning-review-route-order.test.ts
new file mode 100644
index 000000000..ac971e5d1
--- /dev/null
+++ b/packages/cli/tests/integration/planning-review-route-order.test.ts
@@ -0,0 +1,199 @@
+import { existsSync, mkdirSync, readFileSync, rmSync, writeFileSync } from 'node:fs';
+import nodePath from 'node:path';
+
+import { afterEach, expect, it } from 'vitest';
+
+import { createConfiguredProject, createTemporaryDirectory, runCli } from '../helpers.js';
+import { writePlanningInventories } from '../planning-fixtures.js';
+import { PLANNING_ROLE_PRODUCT } from '../planning-role-fixtures.js';
+import {
+  cleanupTrustedReviewerDirectories,
+  createTrustedReviewerDirectory,
+  REVIEWER_CAPABILITIES,
+} from '../review-fixtures.js';
+
+const projects: string[] = [];
+
+afterEach(() => {
+  for (const project of projects) rmSync(project, { recursive: true, force: true });
+  projects.length = 0;
+  cleanupTrustedReviewerDirectories();
+});
+
+function reviewerScript(
+  agent: 'claude' | 'codex',
+  marker: string,
+  packetPath: string,
+  codexFails: boolean,
+  codexConfirmed: boolean,
+): string {
+  const help =
+    agent === 'codex' && codexConfirmed
+      ? `process.argv.includes('app-server') ? '--stdio --config' : ${JSON.stringify(REVIEWER_CAPABILITIES.codex)}`
+      : JSON.stringify(REVIEWER_CAPABILITIES[agent]);
+  const review =
+    agent === 'codex' && codexConfirmed
+      ? String.raw`let buffer = '';
+process.stdin.setEncoding('utf8');
+process.stdin.on('data', chunk => {
+  buffer += chunk;
+  let index;
+  while ((index = buffer.indexOf('\n')) !== -1) {
+    const message = JSON.parse(buffer.slice(0, index));
+    buffer = buffer.slice(index + 1);
+    if (message.id === 1) console.log(JSON.stringify({ id: 1, result: {} }));
+    if (message.id === 2) console.log(JSON.stringify({ id: 2, result: { thread: { id: 'thread-1' }, model: message.params.model, modelProvider: 'openai' } }));
+    if (message.id === 3) {
+      const packet = JSON.parse(message.params.input[0].text.trim().split('\n').pop());
+      console.log(JSON.stringify({ id: 3, result: { turn: { id: 'turn-1' } } }));
+      console.log(JSON.stringify({ method: 'turn/completed', params: { threadId: 'thread-1', turn: { id: 'turn-1', status: 'completed', items: [{ type: 'agentMessage', phase: 'final_answer', text: JSON.stringify(reviewOutput(packet)) }] } } }));
+    }
+  }
+});`
+      : String.raw`let input = '';
+process.stdin.setEncoding('utf8');
+process.stdin.on('data', chunk => { input += chunk; });
+process.stdin.on('end', () => {
+  const packet = JSON.parse(input.trim().split('\n').pop());
+  const output = reviewOutput(packet);
+  console.log(JSON.stringify('${agent}' === 'codex' ? { type: 'item.completed', item: { type: 'agent_message', text: JSON.stringify(output) } } : { structured_output: output }));
+});`;
+  return `#!${process.execPath}
+const { writeFileSync } = require('node:fs');
+if (process.argv.includes('--version')) { console.log('${agent} 1.0.0'); process.exit(0); }
+if (process.argv.includes('--help')) { console.log(${help}); process.exit(0); }
+writeFileSync(${JSON.stringify(marker)}, 'yes');
+${agent === 'codex' && codexFails ? 'process.exit(7);' : ''}
+function reviewOutput(packet) {
+  writeFileSync(${JSON.stringify(packetPath)}, JSON.stringify(packet));
+  return { schema_version: 1, dispatch_id: packet.dispatch_id, reviewer_agent: '${agent}', verdict: 'approve', summary: 'Review approved.', findings: [] };
+}
+${review}
+`;
+}
+
+it.each([
+  ['claude', 'codex', false, 'absent', false],
+  ['claude', 'codex', false, 'empty', false],
+  ['codex', 'claude', false, 'absent', false],
+  ['claude', 'codex', true, 'absent', false],
+  ['codex', 'claude', true, 'absent', false],
+  ['codex', 'claude', false, 'known', false],
+  ['codex', 'claude', false, 'known', true],
+] as const)(
+  'tries the independent reviewer before fallback when %s precedes %s, codex failure is %s, author model is %s, and model is confirmed %s',
+  // eslint-disable-next-line complexity -- The route-order matrix shares one real CLI fixture.
+  async (first, second, codexFails, authorModelState, codexConfirmed) => {
+    const authorKnown = authorModelState === 'known';
+    const project = createTemporaryDirectory();
+    projects.push(project);
+    await createConfiguredProject(project);
+    writePlanningInventories(project);
+    const configPath = nodePath.join(project, '.safeword/config.json');
+    const config = JSON.parse(readFileSync(configPath, 'utf8'));
+    writeFileSync(
+      configPath,
+      JSON.stringify({
+        ...config,
+        crossAgentReviewRoutes: {
+          claude: [
+            {
+              reviewer: first,
+              ...(first === 'codex' && codexConfirmed && { model: 'gpt-6-astra' }),
+            },
+            { reviewer: second },
+          ],
+        },
+      }),
+    );
+    const ticket = '.project/tickets/ORD123-independent-first';
+    mkdirSync(nodePath.join(project, ticket), { recursive: true });
+    writeFileSync(
+      nodePath.join(project, ticket, 'ticket.md'),
+      '---\nid: ORD123\ntype: feature\nphase: plan-implementation\nstatus: in_progress\nproduct_plan_contract: v1\nscope: preserve independent review\nout_of_scope: bypassing review\ndone_when: independent review runs first\nphase_anchors:\n  - scenario-gate: features/independent-first.feature\n---\n',
+    );
+    writeFileSync(nodePath.join(project, ticket, 'spec.md'), PLANNING_ROLE_PRODUCT);
+    writeFileSync(
+      nodePath.join(project, ticket, 'impl-plan.md'),
+      '# Implementation Plan\n\n**Status:** planned\n\n## Approach\n\nPreserve independent-first review.\n\n## Decisions\n\nUse the current review receipt.\n\n## Design alignment\n\nEnsure independent review is attempted first.\n\n## Architecture applicability\n\nskip: no architecture records apply\n\n## Data applicability\n\nskip: no product data changes\n\n## Known deviations\n\nskip: none\n\n## Doc impact\n\nskip: no customer docs change\n\n## Assessment triggers\n\nRevisit if review authority changes.\n',
+    );
+    mkdirSync(nodePath.join(project, 'features'), { recursive: true });
+    writeFileSync(
+      nodePath.join(project, 'features/independent-first.feature'),
+      '@independent-first.BU1.R1\nFeature: Independent first\n  Scenario: Available independent route\n    Given both routes are available\n    When review runs\n    Then independent review runs first\n',
+    );
+    const reviewer = createTrustedReviewerDirectory('safeword-route-order-');
+    const sameAgentInvoked = nodePath.join(reviewer, 'same-agent-invoked');
+    const independentInvoked = nodePath.join(reviewer, 'independent-invoked');
+    const packets = {
+      claude: nodePath.join(reviewer, 'claude-packet.json'),
+      codex: nodePath.join(reviewer, 'codex-packet.json'),
+    };
+    for (const agent of ['claude', 'codex'] as const) {
+      const marker = agent === 'claude' ? sameAgentInvoked : independentInvoked;
+      writeFileSync(
+        nodePath.join(reviewer, agent),
+        reviewerScript(agent, marker, packets[agent], codexFails, codexConfirmed),
+        { mode: 0o755 },
+      );
+    }
+    const reviewed = await runCli(
+      [
+        'review',
+        'run',
+        'plan-implementation',
+        `${ticket}/impl-plan.md`,
+        '--context',
+        `${ticket}/spec.md`,
+        '--cwd',
+        project,
+        '--json',
+        '--no-input',
+      ],
+      {
+        cwd: project,
+        env: {
+          PATH: `${reviewer}:/usr/bin:/bin`,
+          SAFEWORD_AGENT_RUNTIME: 'claude',
+          SAFEWORD_NO_UPDATE_CHECK: '1',
+          ...(authorKnown && { SAFEWORD_AUTHOR_MODEL: 'claude-opus-5' }),
+          ...(authorModelState === 'empty' && { SAFEWORD_AUTHOR_MODEL: '' }),
+        },
+      },
+    );
+    const output = JSON.parse(reviewed.stdout);
+    expect(output.data).toMatchObject({
+      status: 'approved',
+      actual_reviewer: codexFails || (authorKnown && !codexConfirmed) ? 'claude' : 'codex',
+      independence: codexConfirmed ? 'cross-agent' : 'reduced',
+    });
+    expect(existsSync(independentInvoked)).toBe(true);
+    expect(existsSync(sameAgentInvoked)).toBe(codexFails || (authorKnown && !codexConfirmed));
+    if (authorKnown && !codexConfirmed) {
+      expect(JSON.parse(readFileSync(packets.claude, 'utf8'))).toEqual(
+        JSON.parse(readFileSync(packets.codex, 'utf8')),
+      );
+      expect(output.data.review_routes).toContainEqual(
+        expect.objectContaining({
+          reviewer: 'codex',
+          failure: 'reviewer_capability_unknown',
+          status: 'attempted',
+        }),
+      );
+    }
+    if (codexFails || (authorKnown && !codexConfirmed)) {
+      expect(output.findings).toContainEqual(
+        expect.objectContaining({ code: 'REVIEW_INDEPENDENCE_REDUCED' }),
+      );
+      expect(
+        output.findings.some(
+          (finding: { code: string; message: string }) =>
+            /degraded/iu.test(`${finding.code} ${finding.message}`) ||
+            /was not independent/iu.test(finding.message),
+        ),
+      ).toBe(false);
+    } else if (!codexConfirmed) {
+      expect(output.data.capability_failure).toBe('author_capability_unknown');
+    }
+  },
+);
diff --git a/packages/cli/tests/integration/planning-review-unavailable-independent.test.ts b/packages/cli/tests/integration/planning-review-unavailable-independent.test.ts
new file mode 100644
index 000000000..cd9885ebb
--- /dev/null
+++ b/packages/cli/tests/integration/planning-review-unavailable-independent.test.ts
@@ -0,0 +1,91 @@
+import { existsSync, mkdirSync, readFileSync, rmSync, writeFileSync } from 'node:fs';
+import nodePath from 'node:path';
+
+import { afterEach, expect, it } from 'vitest';
+
+import { createConfiguredProject, createTemporaryDirectory, runCli } from '../helpers.js';
+import { writePlanningInventories } from '../planning-fixtures.js';
+import { PLANNING_ROLE_PRODUCT } from '../planning-role-fixtures.js';
+import {
+  cleanupTrustedReviewerDirectories,
+  createTrustedReviewerDirectory,
+  REVIEWER_CAPABILITIES,
+} from '../review-fixtures.js';
+
+const projects: string[] = [];
+
+afterEach(() => {
+  for (const project of projects) rmSync(project, { recursive: true, force: true });
+  projects.length = 0;
+  cleanupTrustedReviewerDirectories();
+});
+
+it('blocks planning fallback when the configured independent route is unavailable', async () => {
+  const project = createTemporaryDirectory();
+  projects.push(project);
+  await createConfiguredProject(project);
+  writePlanningInventories(project);
+  const configPath = nodePath.join(project, '.safeword/config.json');
+  const config = JSON.parse(readFileSync(configPath, 'utf8'));
+  writeFileSync(
+    configPath,
+    JSON.stringify({
+      ...config,
+      crossAgentReviewRoutes: { claude: [{ reviewer: 'codex' }, { reviewer: 'claude' }] },
+    }),
+  );
+  const ticket = '.project/tickets/UNA123-unavailable-independent-route';
+  mkdirSync(nodePath.join(project, ticket), { recursive: true });
+  writeFileSync(
+    nodePath.join(project, ticket, 'ticket.md'),
+    '---\nid: UNA123\ntype: feature\nphase: plan-implementation\nstatus: in_progress\nproduct_plan_contract: v1\nscope: preserve approval\nout_of_scope: anonymous approval\ndone_when: independent review precedes fallback\nphase_anchors:\n  - scenario-gate: features/unavailable-independent.feature\n---\n',
+  );
+  writeFileSync(nodePath.join(project, ticket, 'spec.md'), PLANNING_ROLE_PRODUCT);
+  writeFileSync(
+    nodePath.join(project, ticket, 'impl-plan.md'),
+    '# Implementation Plan\n\n**Status:** planned\n\n## Approach\n\nPreserve authenticated approval.\n\n## Decisions\n\nUse the current review receipt.\n\n## Design alignment\n\nEnsure independent review is attempted first.\n\n## Architecture applicability\n\nskip: no architecture records apply\n\n## Data applicability\n\nskip: no product data changes\n\n## Known deviations\n\nskip: none\n\n## Doc impact\n\nskip: no customer docs change\n\n## Assessment triggers\n\nRevisit if review authority changes.\n',
+  );
+  mkdirSync(nodePath.join(project, 'features'), { recursive: true });
+  writeFileSync(
+    nodePath.join(project, 'features/unavailable-independent.feature'),
+    '@unavailable-independent.BU1.R1\nFeature: Independent first\n  Scenario: Independent route unavailable\n    Given the independent reviewer is not installed\n    When review runs\n    Then approval remains blocked\n',
+  );
+  const reviewer = createTrustedReviewerDirectory('safeword-unavailable-independent-');
+  const invoked = nodePath.join(reviewer, 'invoked');
+  writeFileSync(
+    nodePath.join(reviewer, 'claude'),
+    `#!${process.execPath}\nconst { writeFileSync } = require('node:fs');\nif (process.argv.includes('--version')) { console.log('claude 1.0.0'); process.exit(0); }\nif (process.argv.includes('--help')) { console.log(${JSON.stringify(REVIEWER_CAPABILITIES.claude)}); process.exit(0); }\nwriteFileSync(${JSON.stringify(invoked)}, 'yes');\nlet input = ''; process.stdin.setEncoding('utf8'); process.stdin.on('data', chunk => { input += chunk; }); process.stdin.on('end', () => { const packet = JSON.parse(input.trim().split('\\n').pop()); console.log(JSON.stringify({ structured_output: { schema_version: 1, dispatch_id: packet.dispatch_id, reviewer_agent: 'claude', verdict: 'approve', summary: 'Same-agent approval.', findings: [] } })); });\n`,
+    { mode: 0o755 },
+  );
+  const reviewed = await runCli(
+    [
+      'review',
+      'run',
+      'plan-implementation',
+      `${ticket}/impl-plan.md`,
+      '--context',
+      `${ticket}/spec.md`,
+      '--cwd',
+      project,
+      '--json',
+      '--no-input',
+    ],
+    {
+      cwd: project,
+      env: {
+        PATH: `${reviewer}:/usr/bin:/bin`,
+        SAFEWORD_AGENT_RUNTIME: 'claude',
+        SAFEWORD_NO_UPDATE_CHECK: '1',
+      },
+    },
+  );
+  const output = JSON.parse(reviewed.stdout);
+  expect(output.data).toMatchObject({ status: 'blocked', independence: 'none' });
+  expect(output.findings).toContainEqual(
+    expect.objectContaining({ code: 'REVIEW_ROUTES_EXHAUSTED' }),
+  );
+  expect(output.data.review_routes).toContainEqual(
+    expect.objectContaining({ reviewer: 'codex', status: 'unavailable' }),
+  );
+  expect(existsSync(invoked)).toBe(false);
+});
diff --git a/packages/cli/tests/integration/planning-review-weaker-route.test.ts b/packages/cli/tests/integration/planning-review-weaker-route.test.ts
new file mode 100644
index 000000000..3a1cc647f
--- /dev/null
+++ b/packages/cli/tests/integration/planning-review-weaker-route.test.ts
@@ -0,0 +1,257 @@
+import { mkdirSync, readFileSync, rmSync, writeFileSync } from 'node:fs';
+import nodePath from 'node:path';
+
+import { afterEach, expect, it, vi } from 'vitest';
+
+import { runReview } from '../../src/review/coordinator.js';
+import { createConfiguredProject, createTemporaryDirectory } from '../helpers.js';
+import { writePlanningInventories } from '../planning-fixtures.js';
+import { PLANNING_ROLE_PRODUCT } from '../planning-role-fixtures.js';
+
+vi.mock('../../src/review/capability-catalogue.js', async importOriginal => ({
+  ...(await importOriginal<Record<string, unknown>>()),
+  reviewerCapabilityFailure: (_author: unknown, requestedModel: string | undefined) => {
+    if (requestedModel === undefined) return 'reviewer_capability_unknown';
+    return requestedModel === 'gpt-6-luna' ? 'reviewer_capability_weaker' : undefined;
+  },
+}));
+
+const dispatchedPackets = vi.hoisted(() => [] as { dispatch_id: string }[]);
+
+vi.mock('../../src/review/runtime.js', async importOriginal => {
+  const actual = await importOriginal<Record<string, unknown>>();
+  const RuntimeError = actual.ReviewRuntimeError as new (failure: string, message: string) => Error;
+  return {
+    ...actual,
+    runHeadlessReviewerWithProvenance: (
+      reviewer: string,
+      packet: { dispatch_id: string },
+      _workspace: unknown,
+      _sourceRoot: unknown,
+      options: { model?: string },
+    ) => {
+      dispatchedPackets.push(packet);
+      if (process.env.SAFEWORD_TEST_REVIEWERS_FAIL === '1')
+        return Promise.reject(new RuntimeError('process_failed', 'fixture reviewer failure'));
+      return Promise.resolve({
+        output: {
+          schema_version: 1,
+          dispatch_id: packet.dispatch_id,
+          reviewer_agent: reviewer,
+          verdict: options.model === 'gpt-6-astra' ? 'request_changes' : 'approve',
+          summary:
+            {
+              'gpt-6-luna': 'Weak approval.',
+              'gpt-6-astra': 'Qualified rejection.',
+            }[options.model ?? ''] ?? 'Runtime-default approval.',
+          findings: [],
+        },
+        confirmedModel:
+          options.model === undefined ? undefined : { provider: 'openai', model: options.model },
+      });
+    },
+  };
+});
+
+const projects: string[] = [];
+
+afterEach(() => {
+  vi.unstubAllEnvs();
+  dispatchedPackets.length = 0;
+  for (const project of projects) rmSync(project, { recursive: true, force: true });
+  projects.length = 0;
+});
+
+it('discards a weaker approval and continues to the next independent route', async () => {
+  const project = createTemporaryDirectory();
+  projects.push(project);
+  await createConfiguredProject(project);
+  writePlanningInventories(project);
+  const configPath = nodePath.join(project, '.safeword/config.json');
+  const config = JSON.parse(readFileSync(configPath, 'utf8'));
+  writeFileSync(
+    configPath,
+    JSON.stringify({
+      ...config,
+      crossAgentReviewRoutes: {
+        claude: [
+          { reviewer: 'codex', model: 'gpt-6-luna' },
+          { reviewer: 'codex', model: 'gpt-6-astra' },
+        ],
+      },
+    }),
+  );
+  const ticket = '.project/tickets/WEK123-weaker-reviewer';
+  mkdirSync(nodePath.join(project, ticket), { recursive: true });
+  writeFileSync(
+    nodePath.join(project, ticket, 'ticket.md'),
+    '---\nid: WEK123\ntype: feature\nphase: plan-implementation\nstatus: in_progress\nproduct_plan_contract: v1\nscope: truthful review\nout_of_scope: weaker approval\ndone_when: weaker reviewer is refused\nphase_anchors:\n  - scenario-gate: features/weaker-reviewer.feature\n---\n',
+  );
+  writeFileSync(nodePath.join(project, ticket, 'spec.md'), PLANNING_ROLE_PRODUCT);
+  writeFileSync(
+    nodePath.join(project, ticket, 'impl-plan.md'),
+    '# Implementation Plan\n\n**Status:** planned\n\n## Approach\n\nKeep review evidence truthful.\n\n## Decisions\n\nRequire qualified independent review.\n\n## Design alignment\n\nUse the current plan.\n\n## Architecture applicability\n\nskip: no architecture records apply\n\n## Data applicability\n\nskip: no product data changes\n\n## Known deviations\n\nskip: none\n\n## Doc impact\n\nskip: no customer docs change\n\n## Assessment triggers\n\nRevisit if review authority changes.\n',
+  );
+  mkdirSync(nodePath.join(project, 'features'), { recursive: true });
+  writeFileSync(
+    nodePath.join(project, 'features/weaker-reviewer.feature'),
+    '@weaker-reviewer.BU1.R1\nFeature: Weaker reviewer\n  Scenario: Weaker approval\n    Given a weaker reviewer approves\n    When another independent reviewer requests changes\n    Then the weaker approval is discarded\n',
+  );
+
+  vi.stubEnv('SAFEWORD_AGENT_RUNTIME', 'claude');
+  vi.stubEnv('SAFEWORD_AUTHOR_MODEL', 'claude-opus-5');
+  const result = await runReview({
+    cwd: project,
+    kind: 'plan-implementation',
+    targets: [`${ticket}/impl-plan.md`],
+    context: [`${ticket}/spec.md`],
+  });
+
+  expect(result.state).toBe('action_required');
+  expect(result.data).toMatchObject({
+    status: 'changes_requested',
+    independence: 'cross-agent',
+    review_routes: [
+      { model: 'gpt-6-luna', status: 'attempted', failure: 'reviewer_capability_weaker' },
+      { model: 'gpt-6-astra', status: 'attempted' },
+    ],
+    reviewer_output: { summary: 'Qualified rejection.', verdict: 'request_changes' },
+  });
+  expect(JSON.stringify(result)).not.toContain('Weak approval.');
+
+  writeFileSync(
+    configPath,
+    JSON.stringify({
+      ...config,
+      crossAgentReviewRoutes: { claude: [{ reviewer: 'codex', model: 'gpt-6-luna' }] },
+    }),
+  );
+  const exhausted = await runReview({
+    cwd: project,
+    kind: 'plan-implementation',
+    targets: [`${ticket}/impl-plan.md`],
+    context: [`${ticket}/spec.md`],
+  });
+  expect(exhausted.data).toMatchObject({
+    status: 'continuation_required',
+    continuation: { tier: 'fresh-context' },
+    review_routes: [{ model: 'gpt-6-luna', failure: 'reviewer_capability_weaker' }],
+  });
+  expect(exhausted.findings).toContainEqual(
+    expect.objectContaining({ code: 'REVIEW_CONTINUATION_REQUIRED' }),
+  );
+  expect(JSON.stringify(exhausted)).not.toContain('Weak approval.');
+
+  writeFileSync(configPath, JSON.stringify(config));
+  const defaulted = await runReview({
+    cwd: project,
+    kind: 'plan-implementation',
+    targets: [`${ticket}/impl-plan.md`],
+    context: [`${ticket}/spec.md`],
+  });
+  expect(defaulted.data).toMatchObject({
+    status: 'approved',
+    actual_reviewer: 'claude',
+    independence: 'reduced',
+    review_routes: [
+      { reviewer: 'codex', status: 'attempted', failure: 'reviewer_capability_unknown' },
+      { reviewer: 'opencode', status: 'attempted', failure: 'reviewer_capability_unknown' },
+      { reviewer: 'claude', status: 'attempted' },
+    ],
+  });
+
+  writeFileSync(
+    nodePath.join(project, ticket, 'spec.md'),
+    '# Product Plan: Truthful review\n\n<!-- safeword:product-plan-contract:v1 -->\n\n## Product Bet\n\n- **Problem / Why now:** Builders need trustworthy planning review.\n- **Expected outcome:** Only current qualified approval advances.\n- **Success threshold:** Unverified review is labeled reduced.\n- **Project non-goals:** Inventing independent assurance.\n- **Persona outcome inventory:** Builder receives approval or a named refusal.\n- **Known facts:** The fixture has one Builder and one CLI surface.\n- **Assumptions:** none\n- **Unresolved product decisions:** none\n\n## Jobs To Be Done\n\n### approval.BU1 — Trust review\n\n**Persona:** Builder (BU)\n\n> When I request review, I want actual assurance reported, so I can decide whether to advance.\n\n#### approval.BU1.R1 — Preserve truthful assurance\n\nOnly current qualified approval advances.\n\n## Shape\n\n### M1 — Trust review\n\n- **Outcome:** Current review is labeled honestly.\n- **Non-goals:** Unqualified independence.\n\n## Surfaces\n\nAffected:\n- Safeword CLI\n',
+  );
+  const product = await runReview({
+    cwd: project,
+    kind: 'quality-review',
+    targets: [`${ticket}/spec.md`],
+  });
+  expect(product.data).toMatchObject({
+    status: 'approved',
+    actual_reviewer: 'claude',
+    independence: 'reduced',
+    review_routes: [
+      { reviewer: 'codex', status: 'attempted', failure: 'reviewer_capability_unknown' },
+      { reviewer: 'opencode', status: 'attempted', failure: 'reviewer_capability_unknown' },
+      { reviewer: 'claude', status: 'attempted' },
+    ],
+  });
+
+  writeFileSync(nodePath.join(project, 'notes.md'), '# Ordinary review\n\nNo planning contract.\n');
+  const ordinary = await runReview({
+    cwd: project,
+    kind: 'quality-review',
+    targets: ['notes.md'],
+  });
+  expect(ordinary.data).toMatchObject({
+    status: 'approved',
+    actual_reviewer: 'codex',
+    independence: 'cross-agent',
+  });
+  expect((ordinary.data as Record<string, unknown>).review_routes).toBeUndefined();
+
+  writeFileSync(configPath, JSON.stringify({ ...config, crossAgentReview: 'off' }));
+  for (const [kind, target] of [
+    ['quality-review', `${ticket}/spec.md`],
+    ['plan-implementation', `${ticket}/impl-plan.md`],
+  ] as const) {
+    const disabled = await runReview({ cwd: project, kind, targets: [target] });
+    expect(disabled.state).toBe('action_required');
+    expect(disabled.findings).toContainEqual(
+      expect.objectContaining({ code: 'PLANNING_REVIEW_POLICY_OFF' }),
+    );
+    expect(disabled.data).toMatchObject({ status: 'blocked', review_policy: 'off' });
+  }
+  const ordinaryOff = await runReview({
+    cwd: project,
+    kind: 'quality-review',
+    targets: ['notes.md'],
+  });
+  expect(ordinaryOff.data).toMatchObject({ status: 'existing_route' });
+
+  vi.stubEnv('SAFEWORD_TEST_REVIEWERS_FAIL', '1');
+  writeFileSync(
+    configPath,
+    JSON.stringify({
+      ...config,
+      crossAgentReview: 'prefer',
+      crossAgentReviewRoutes: {
+        claude: [{ reviewer: 'codex', model: 'gpt-6-astra' }, { reviewer: 'claude' }],
+      },
+    }),
+  );
+  const continuation = await runReview({
+    cwd: project,
+    kind: 'plan-implementation',
+    targets: [`${ticket}/impl-plan.md`],
+    context: [`${ticket}/spec.md`],
+  });
+  expect(continuation.data).toMatchObject({
+    status: 'continuation_required',
+    independence: 'none',
+    continuation: {
+      tier: 'fresh-context',
+      instructions: expect.stringContaining('Review only the bounded files in this packet.'),
+      packet: { dispatch_id: expect.any(String) },
+    },
+    review_routes: [
+      { reviewer: 'codex', status: 'attempted', failure: 'process_failed' },
+      { reviewer: 'claude', status: 'attempted', failure: 'process_failed' },
+    ],
+  });
+  expect(dispatchedPackets.at(-1)).toBe(dispatchedPackets.at(-2));
+
+  const requireConfig = JSON.parse(readFileSync(configPath, 'utf8'));
+  writeFileSync(configPath, JSON.stringify({ ...requireConfig, crossAgentReview: 'require' }));
+  const required = await runReview({
+    cwd: project,
+    kind: 'plan-implementation',
+    targets: [`${ticket}/impl-plan.md`],
+    context: [`${ticket}/spec.md`],
+  });
+  expect(required.data).toMatchObject({ status: 'blocked' });
+  expect((required.data as Record<string, unknown>).continuation).toBeUndefined();
+});
diff --git a/packages/cli/tests/integration/planning-review-zero-independent.test.ts b/packages/cli/tests/integration/planning-review-zero-independent.test.ts
new file mode 100644
index 000000000..a50be699f
--- /dev/null
+++ b/packages/cli/tests/integration/planning-review-zero-independent.test.ts
@@ -0,0 +1,93 @@
+import { existsSync, mkdirSync, readFileSync, rmSync, writeFileSync } from 'node:fs';
+import nodePath from 'node:path';
+
+import { afterEach, expect, it } from 'vitest';
+
+import { createConfiguredProject, createTemporaryDirectory, runCli } from '../helpers.js';
+import { writePlanningInventories } from '../planning-fixtures.js';
+import { PLANNING_ROLE_PRODUCT } from '../planning-role-fixtures.js';
+import {
+  cleanupTrustedReviewerDirectories,
+  createTrustedReviewerDirectory,
+  REVIEWER_CAPABILITIES,
+} from '../review-fixtures.js';
+
+const projects: string[] = [];
+
+afterEach(() => {
+  for (const project of projects) rmSync(project, { recursive: true, force: true });
+  projects.length = 0;
+  cleanupTrustedReviewerDirectories();
+});
+
+it.each(['claude', 'cursor'] as const)(
+  'blocks %s planning approval when no independent route was attempted',
+  async author => {
+    const project = createTemporaryDirectory();
+    projects.push(project);
+    await createConfiguredProject(project);
+    writePlanningInventories(project);
+    const configPath = nodePath.join(project, '.safeword/config.json');
+    const config = JSON.parse(readFileSync(configPath, 'utf8'));
+    writeFileSync(
+      configPath,
+      JSON.stringify({
+        ...config,
+        crossAgentReviewRoutes: {
+          [author]: [{ reviewer: author === 'claude' ? 'claude' : 'codex' }],
+        },
+      }),
+    );
+    const ticket = '.project/tickets/ZER123-no-independent-route';
+    mkdirSync(nodePath.join(project, ticket), { recursive: true });
+    writeFileSync(
+      nodePath.join(project, ticket, 'ticket.md'),
+      '---\nid: ZER123\ntype: feature\nphase: plan-implementation\nstatus: in_progress\nproduct_plan_contract: v1\nscope: preserve approval\nout_of_scope: anonymous approval\ndone_when: independent review precedes fallback\nphase_anchors:\n  - scenario-gate: features/zero-independent.feature\n---\n',
+    );
+    writeFileSync(nodePath.join(project, ticket, 'spec.md'), PLANNING_ROLE_PRODUCT);
+    writeFileSync(
+      nodePath.join(project, ticket, 'impl-plan.md'),
+      '# Implementation Plan\n\n**Status:** planned\n\n## Approach\n\nPreserve authenticated approval.\n\n## Decisions\n\nUse the current review receipt.\n\n## Design alignment\n\nEnsure independent review is attempted first.\n\n## Architecture applicability\n\nskip: no architecture records apply\n\n## Data applicability\n\nskip: no product data changes\n\n## Known deviations\n\nskip: none\n\n## Doc impact\n\nskip: no customer docs change\n\n## Assessment triggers\n\nRevisit if review authority changes.\n',
+    );
+    mkdirSync(nodePath.join(project, 'features'), { recursive: true });
+    writeFileSync(
+      nodePath.join(project, 'features/zero-independent.feature'),
+      '@zero-independent.BU1.R1\nFeature: Independent first\n  Scenario: No independent route\n    Given no independent route\n    When review runs\n    Then approval remains blocked\n',
+    );
+    const reviewer = createTrustedReviewerDirectory('safeword-zero-independent-');
+    const invoked = nodePath.join(reviewer, 'invoked');
+    writeFileSync(
+      nodePath.join(reviewer, 'claude'),
+      `#!${process.execPath}\nconst { writeFileSync } = require('node:fs');\nif (process.argv.includes('--version')) { console.log('claude 1.0.0'); process.exit(0); }\nif (process.argv.includes('--help')) { console.log(${JSON.stringify(REVIEWER_CAPABILITIES.claude)}); process.exit(0); }\nwriteFileSync(${JSON.stringify(invoked)}, 'yes');\nlet input = ''; process.stdin.setEncoding('utf8'); process.stdin.on('data', chunk => { input += chunk; }); process.stdin.on('end', () => { const packet = JSON.parse(input.trim().split('\\n').pop()); console.log(JSON.stringify({ structured_output: { schema_version: 1, dispatch_id: packet.dispatch_id, reviewer_agent: 'claude', verdict: 'approve', summary: 'Same-agent approval.', findings: [] } })); });\n`,
+      { mode: 0o755 },
+    );
+    const reviewed = await runCli(
+      [
+        'review',
+        'run',
+        'plan-implementation',
+        `${ticket}/impl-plan.md`,
+        '--context',
+        `${ticket}/spec.md`,
+        '--cwd',
+        project,
+        '--json',
+        '--no-input',
+      ],
+      {
+        cwd: project,
+        env: {
+          PATH: `${reviewer}:/usr/bin:/bin`,
+          SAFEWORD_AGENT_RUNTIME: author,
+          SAFEWORD_NO_UPDATE_CHECK: '1',
+        },
+      },
+    );
+    const output = JSON.parse(reviewed.stdout);
+    expect(output.data).toMatchObject({ status: 'blocked', independence: 'none' });
+    expect(output.findings).toContainEqual(
+      expect.objectContaining({ code: 'REVIEW_ROUTES_EXHAUSTED' }),
+    );
+    expect(existsSync(invoked)).toBe(false);
+  },
+);
diff --git a/packages/cli/tests/review/capability-catalogue.test.ts b/packages/cli/tests/review/capability-catalogue.test.ts
new file mode 100644
index 000000000..04efea6b4
--- /dev/null
+++ b/packages/cli/tests/review/capability-catalogue.test.ts
@@ -0,0 +1,125 @@
+import { describe, expect, it } from 'vitest';
+
+import {
+  compareReviewerCapability,
+  reviewerCapabilityFailure,
+} from '../../src/review/capability-catalogue.js';
+
+const current = {
+  corpus_digest: 'corpus-1',
+  rubric_digest: 'rubric-1',
+  settings_digest: 'settings-1',
+};
+
+const qualified = {
+  author_provider: 'vendor-a',
+  reviewer_provider: 'vendor-b',
+  author_model: 'vendor-a/author-1',
+  reviewer_model: 'vendor-b/reviewer-2',
+  direction: 'not_weaker' as const,
+  qualification: 'pinned-corpus' as const,
+  evidence_date: '2026-09-28',
+  results_digest: 'results-1',
+  ...current,
+};
+
+function compare(
+  authorModel: string,
+  reviewerModel: string,
+  records: Parameters<typeof compareReviewerCapability>[3],
+) {
+  return compareReviewerCapability(
+    { provider: authorModel.split('/', 1)[0] ?? '', model: authorModel },
+    { provider: reviewerModel.split('/', 1)[0] ?? '', model: reviewerModel },
+    current,
+    records,
+  );
+}
+
+describe('reviewer capability comparison', () => {
+  it('binds both providers as well as their exact model IDs', () => {
+    const author = { provider: 'vendor-a', model: 'vendor-a/author-1' };
+    const reviewer = { provider: 'vendor-b', model: 'vendor-b/reviewer-2' };
+    expect(compareReviewerCapability(author, reviewer, current, [qualified])).toBe('not_weaker');
+    expect(
+      compareReviewerCapability({ ...author, provider: 'vendor-c' }, reviewer, current, [
+        qualified,
+      ]),
+    ).toBe('unknown');
+    expect(
+      compareReviewerCapability(author, { ...reviewer, provider: 'vendor-c' }, current, [
+        qualified,
+      ]),
+    ).toBe('unknown');
+  });
+  it('admits only a qualified current exact ordered pair', () => {
+    expect(compare('vendor-a/author-1', 'vendor-b/reviewer-2', [qualified])).toBe('not_weaker');
+    expect(compare('vendor-b/reviewer-2', 'vendor-a/author-1', [qualified])).toBe('unknown');
+    expect(compare('vendor-a/author-1', 'vendor-b/reviewer-3', [qualified])).toBe('unknown');
+  });
+
+  it('does not inherit stale or unqualified evidence', () => {
+    expect(
+      compare('vendor-a/author-1', 'vendor-b/reviewer-2', [
+        { ...qualified, corpus_digest: 'old-corpus' },
+      ]),
+    ).toBe('unknown');
+    expect(
+      compare('vendor-a/author-1', 'vendor-b/reviewer-2', [
+        { ...qualified, qualification: 'unqualified' },
+      ]),
+    ).toBe('unknown');
+  });
+
+  it('preserves a qualified weaker result and rejects conflicting records', () => {
+    expect(
+      compare('vendor-a/author-1', 'vendor-b/reviewer-2', [{ ...qualified, direction: 'weaker' }]),
+    ).toBe('weaker');
+    expect(
+      compare('vendor-a/author-1', 'vendor-b/reviewer-2', [
+        qualified,
+        { ...qualified, direction: 'weaker' },
+      ]),
+    ).toBe('unknown');
+  });
+
+  it('distinguishes a proven weaker reviewer from missing identity or pair evidence', () => {
+    const author = { provider: 'vendor-a', model: 'vendor-a/author-1' };
+    const reviewer = { provider: 'vendor-b', model: 'vendor-b/reviewer-2' };
+    expect(
+      reviewerCapabilityFailure(author, reviewer.model, reviewer, current, [qualified]),
+    ).toBeUndefined();
+    expect(
+      reviewerCapabilityFailure(author, reviewer.model, reviewer, current, [
+        { ...qualified, direction: 'weaker' },
+      ]),
+    ).toBe('reviewer_capability_weaker');
+    expect(reviewerCapabilityFailure(author, reviewer.model, undefined, current, [qualified])).toBe(
+      'reviewer_capability_unknown',
+    );
+    expect(reviewerCapabilityFailure(author, 'other-model', reviewer, current, [qualified])).toBe(
+      'reviewer_capability_unknown',
+    );
+    expect(reviewerCapabilityFailure(author, reviewer.model, reviewer, current, [])).toBe(
+      'reviewer_capability_unknown',
+    );
+  });
+
+  it('never uses within-provider ordering as cross-provider evidence', () => {
+    expect(
+      compare('vendor-a/author-1', 'vendor-b/reviewer-2', [
+        { ...qualified, qualification: 'provider-order' },
+      ]),
+    ).toBe('unknown');
+    expect(
+      compare('vendor-a/author-1', 'vendor-a/reviewer-2', [
+        {
+          ...qualified,
+          reviewer_provider: 'vendor-a',
+          reviewer_model: 'vendor-a/reviewer-2',
+          qualification: 'provider-order',
+        },
+      ]),
+    ).toBe('not_weaker');
+  });
+});
diff --git a/packages/cli/tests/review/capability-corpus.test.ts b/packages/cli/tests/review/capability-corpus.test.ts
new file mode 100644
index 000000000..b720e130c
--- /dev/null
+++ b/packages/cli/tests/review/capability-corpus.test.ts
@@ -0,0 +1,78 @@
+import { describe, expect, it } from 'vitest';
+
+import {
+  createExecutionPlanDeliveryDefinition,
+  normalizedExecutionPlanDigest,
+  parseDeliveryPlanContract,
+} from '../../src/execution-plan/delivery-checklist.js';
+import { reviewTimeoutMilliseconds, runBoundMs } from '../../src/review/runtime.js';
+import { REVIEWER_CAPABILITY_MANIFEST } from '../fixtures/reviewer-capability-corpus.js';
+
+describe('pinned reviewer capability corpus', () => {
+  it('uses the production background-worker review deadline', () => {
+    const settings = REVIEWER_CAPABILITY_MANIFEST.settings;
+    const environment = {
+      SAFEWORD_REVIEW_WORKER: '1',
+      SAFEWORD_REVIEW_TIMEOUT_MS: settings.review_timeout_ms,
+      SAFEWORD_REVIEW_RUN_BOUND_MS: settings.review_run_bound_ms,
+    };
+    expect(reviewTimeoutMilliseconds(environment)).toBe(600_000);
+    expect(runBoundMs(environment)).toBe(1_800_000);
+  });
+
+  it('pairs an approval and a blocking defect in each planning phase', () => {
+    const fixtures = REVIEWER_CAPABILITY_MANIFEST.fixtures;
+    expect(fixtures.map(({ label }) => label.id)).toEqual([
+      'product-approve',
+      'product-reject',
+      'implementation-approve',
+      'implementation-reject',
+      'execution-approve',
+      'execution-reject',
+    ]);
+    for (let index = 0; index < fixtures.length; index += 2) {
+      const approval = fixtures[index];
+      const rejection = fixtures[index + 1];
+      if (approval === undefined || rejection === undefined) throw new Error('Incomplete pair');
+      expect(approval.label.verdict).toBe('approve');
+      expect(rejection.label.verdict).toBe('request_changes');
+      expect(rejection.label.required.length).toBeGreaterThan(0);
+      expect(approval.packet.kind).toBe(rejection.packet.kind);
+      expect(approval.packet.planning_phase).toBe(rejection.packet.planning_phase);
+      expect(approval.packet.context_files).toEqual(rejection.packet.context_files);
+      expect(approval.packet.logical_files).not.toEqual(rejection.packet.logical_files);
+      expect(approval.packet.dispatch_id).toBe(approval.label.id);
+      expect(rejection.packet.dispatch_id).toBe(rejection.label.id);
+    }
+  });
+
+  it('derives each Execution packet identity and delivery definition from its own plan', () => {
+    const executionFixtures = REVIEWER_CAPABILITY_MANIFEST.fixtures.slice(-2);
+    for (const { packet } of executionFixtures) {
+      const plan = packet.logical_files[0]?.content;
+      if (plan === undefined) throw new Error('Missing Execution Plan');
+      const parsed = parseDeliveryPlanContract(plan);
+      expect(parsed.ok).toBe(true);
+      if (!parsed.ok) continue;
+      expect(packet.execution_plan_delivery_definition).toEqual(
+        createExecutionPlanDeliveryDefinition(parsed, false),
+      );
+      expect(packet.execution_plan_normalized_digest).toBe(normalizedExecutionPlanDigest(plan));
+    }
+  });
+
+  it('requires the approved Execution proof to exercise accepted failure boundaries', () => {
+    const plan = REVIEWER_CAPABILITY_MANIFEST.fixtures.find(
+      fixture => fixture.label.id === 'execution-approve',
+    )?.packet.logical_files[0]?.content;
+    expect(plan).toContain('crash before retry binding');
+    expect(plan).toContain('interrupted review');
+    expect(plan).toContain('failed status read');
+    expect(plan).toContain('actual error state');
+    expect(plan).toContain('receipt for another job');
+    expect(plan).toContain('different plan digest under the current job');
+    expect(plan).toContain('unauthenticated approval verdict');
+    expect(plan).toContain('CLI process exit codes');
+    expect(plan).toContain('coordinator records');
+  });
+});
diff --git a/packages/cli/tests/review/capability-eval.test.ts b/packages/cli/tests/review/capability-eval.test.ts
new file mode 100644
index 000000000..126730a65
--- /dev/null
+++ b/packages/cli/tests/review/capability-eval.test.ts
@@ -0,0 +1,309 @@
+import { describe, expect, it } from 'vitest';
+
+import {
+  type CapabilityFixture,
+  type CapabilityManifest,
+  capabilityRevision,
+  type CapabilityRun,
+  collectCapabilityResults,
+  compareCapabilityRuns,
+  compareSealedCapabilityResults,
+  scoreCapabilityRun,
+  sealCapabilityResults,
+} from '../../src/review/capability-eval.js';
+
+const fixtures: CapabilityFixture[] = [
+  { id: 'product-approve', verdict: 'approve', required: [], forbidden: ['invented-scope'] },
+  {
+    id: 'product-reject',
+    verdict: 'request_changes',
+    required: ['missing-outcome'],
+    forbidden: ['invented-scope'],
+  },
+  {
+    id: 'implementation-approve',
+    verdict: 'approve',
+    required: [],
+    forbidden: ['invented-design'],
+  },
+  {
+    id: 'implementation-reject',
+    verdict: 'request_changes',
+    required: ['missing-boundary'],
+    forbidden: [],
+  },
+  { id: 'execution-approve', verdict: 'approve', required: [], forbidden: ['invented-proof'] },
+  {
+    id: 'execution-reject',
+    verdict: 'request_changes',
+    required: ['missing-slice'],
+    forbidden: [],
+  },
+];
+
+const floor = { runs_per_fixture: 3, minimum_fixture_passes: 2, minimum_total_percent: 90 };
+
+const manifest: CapabilityManifest = {
+  schema_version: 1,
+  owner: 'Safeword release maintainers',
+  floor,
+  settings: { tools: 'none', reasoning: 'medium' },
+  fixtures: fixtures.map(label => ({
+    label,
+    packet: {
+      schema_version: 1,
+      dispatch_id: label.id,
+      kind: 'plan-implementation',
+      logical_files: [{ path: 'impl-plan.md', content: `Reviewed plan for ${label.id}` }],
+    },
+  })),
+};
+
+const rubrics = {
+  product: 'product rubric',
+  implementation: 'implementation rubric',
+  execution: 'execution rubric',
+};
+
+function runs(): CapabilityRun[] {
+  return fixtures.flatMap(fixture =>
+    [1, 2, 3].map(run => ({
+      fixture_id: fixture.id,
+      run,
+      verdict: fixture.verdict,
+      findings: fixture.required.map(message => ({ severity: 'error' as const, message })),
+    })),
+  );
+}
+
+function withVerdict(
+  source: readonly CapabilityRun[],
+  index: number,
+  verdict: CapabilityRun['verdict'],
+): CapabilityRun[] {
+  const changed = [...source];
+  const previous = changed[index];
+  if (previous === undefined) throw new Error(`Missing test run ${index}`);
+  changed[index] = { ...previous, verdict };
+  return changed;
+}
+
+describe('reviewer capability evaluation', () => {
+  it('records all three attempts per packet and refuses unconfirmed or mismatched models', async () => {
+    const attempts: string[] = [];
+    const results = await collectCapabilityResults({
+      manifest,
+      rubrics,
+      provider: 'anthropic',
+      model: 'claude-opus-5',
+      evidenceDate: '2026-09-28',
+      review: packet => {
+        attempts.push(packet.dispatch_id);
+        return Promise.resolve({
+          output: {
+            schema_version: 1,
+            dispatch_id: packet.dispatch_id,
+            reviewer_agent: 'claude',
+            verdict: 'approve',
+            summary: 'reviewed',
+            findings: [],
+          },
+          ...(attempts.length !== 1 && {
+            confirmedModel: { provider: 'anthropic', model: 'claude-opus-5' },
+          }),
+        });
+      },
+    });
+    expect(attempts).toHaveLength(fixtures.length * 3);
+    expect(results.runs[0]).toMatchObject({
+      fixture_id: 'product-approve',
+      run: 1,
+      verdict: 'invalid',
+      failure: 'model_unconfirmed',
+    });
+    expect(results.runs[1]).toMatchObject({ fixture_id: 'product-approve', run: 2 });
+    expect(compareSealedCapabilityResults(manifest, rubrics, results, results)).toBe('unknown');
+  });
+
+  it('counts process failure, a different exact model, and a wrong dispatch as failed attempts', async () => {
+    const oneFixture = { ...manifest, fixtures: manifest.fixtures.slice(0, 1) };
+    let attempt = 0;
+    const result = await collectCapabilityResults({
+      manifest: oneFixture,
+      rubrics,
+      provider: 'anthropic',
+      model: 'claude-opus-5',
+      evidenceDate: '2026-09-28',
+      review: packet => {
+        attempt += 1;
+        if (attempt === 1) return Promise.reject(new Error('review failed'));
+        return Promise.resolve({
+          confirmedModel: {
+            provider: 'anthropic',
+            model: attempt === 2 ? 'claude-sonnet-5' : 'claude-opus-5',
+          },
+          output: {
+            schema_version: 1,
+            dispatch_id: attempt === 3 ? 'different-dispatch' : packet.dispatch_id,
+            reviewer_agent: 'claude',
+            verdict: 'approve',
+            summary: 'reviewed',
+            findings: [],
+          },
+        });
+      },
+    });
+    expect(result.runs.map(run => run.failure)).toEqual([
+      'review_failed',
+      'model_unconfirmed',
+      'identity_mismatch',
+    ]);
+    expect(compareSealedCapabilityResults(oneFixture, rubrics, result, result)).toBe('unknown');
+  });
+
+  it('requires the verdict and every labelled finding without forbidden findings', () => {
+    const fixture = fixtures[1];
+    const run = runs()[3];
+    if (fixture === undefined || run === undefined) throw new Error('Missing test fixture');
+    expect(scoreCapabilityRun(fixture, run)).toBe(true);
+    expect(
+      scoreCapabilityRun(fixture, {
+        ...run,
+        findings: [
+          { severity: 'error', message: 'The builder plan has a MISSING-OUTCOME for recovery.' },
+        ],
+      }),
+    ).toBe(true);
+    expect(
+      scoreCapabilityRun(fixture, {
+        ...run,
+        findings: [{ severity: 'warning', message: 'The builder plan has a missing-outcome.' }],
+      }),
+    ).toBe(false);
+    expect(scoreCapabilityRun(fixture, { ...run, verdict: 'approve' })).toBe(false);
+    expect(scoreCapabilityRun(fixture, { ...run, findings: [] })).toBe(false);
+    const approvingFixture = fixtures[0];
+    if (approvingFixture === undefined) throw new Error('Missing approval fixture');
+    expect(
+      scoreCapabilityRun(approvingFixture, {
+        fixture_id: approvingFixture.id,
+        run: 1,
+        verdict: 'approve',
+        findings: [{ severity: 'error', message: 'A real blocking defect.' }],
+      }),
+    ).toBe(false);
+    expect(
+      scoreCapabilityRun(fixture, {
+        ...run,
+        findings: [
+          { severity: 'error', message: 'missing-outcome' },
+          { severity: 'warning', message: 'invented-scope' },
+        ],
+      }),
+    ).toBe(false);
+  });
+
+  it('qualifies a candidate only when every fixture and the predeclared 90% floor pass', () => {
+    const author = withVerdict(runs(), 0, 'request_changes');
+    const candidate = withVerdict(runs(), 0, 'request_changes');
+    expect(compareCapabilityRuns(fixtures, author, candidate, floor)).toBe('not_weaker');
+
+    expect(
+      compareCapabilityRuns(fixtures, author, withVerdict(candidate, 1, 'request_changes'), floor),
+    ).toBe('unknown');
+  });
+
+  it('calibrates a known weaker candidate against an author-reliable fixture', () => {
+    const candidate = withVerdict(runs(), 1, 'request_changes');
+    expect(compareCapabilityRuns(fixtures, runs(), candidate, floor)).toBe('weaker');
+  });
+
+  it('refuses incomplete or duplicated three-run evidence', () => {
+    const candidate = runs();
+    expect(compareCapabilityRuns(fixtures, runs(), candidate.slice(1), floor)).toBe('unknown');
+    const previous = candidate[1];
+    if (previous === undefined) throw new Error('Missing test run');
+    candidate[1] = { ...previous, run: 1 };
+    expect(compareCapabilityRuns(fixtures, runs(), candidate, floor)).toBe('unknown');
+  });
+
+  it('invalidates old results when the floor, packet, rubric, or settings changes', () => {
+    const revision = capabilityRevision(manifest, rubrics);
+    const author = sealCapabilityResults(
+      'anthropic',
+      'claude-exact',
+      revision,
+      runs(),
+      '2026-09-28',
+    );
+    const candidate = sealCapabilityResults(
+      'openai',
+      'codex-exact',
+      revision,
+      runs(),
+      '2026-09-28',
+    );
+    expect(compareSealedCapabilityResults(manifest, rubrics, author, candidate)).toBe('not_weaker');
+
+    expect(
+      compareSealedCapabilityResults(
+        { ...manifest, floor: { ...floor, minimum_total_percent: 95 } },
+        rubrics,
+        author,
+        candidate,
+      ),
+    ).toBe('unknown');
+    const first = manifest.fixtures[0];
+    if (first === undefined) throw new Error('Missing test fixture');
+    expect(
+      compareSealedCapabilityResults(
+        {
+          ...manifest,
+          fixtures: [
+            { ...first, packet: { ...first.packet, dispatch_id: 'changed' } },
+            ...manifest.fixtures.slice(1),
+          ],
+        },
+        rubrics,
+        author,
+        candidate,
+      ),
+    ).toBe('unknown');
+    expect(
+      compareSealedCapabilityResults(
+        manifest,
+        { ...rubrics, product: 'changed' },
+        author,
+        candidate,
+      ),
+    ).toBe('unknown');
+    expect(
+      compareSealedCapabilityResults(
+        { ...manifest, settings: { ...manifest.settings, reasoning: 'high' } },
+        rubrics,
+        author,
+        candidate,
+      ),
+    ).toBe('unknown');
+  });
+
+  it('rejects altered result evidence even when its verdicts still look qualified', () => {
+    const revision = capabilityRevision(manifest, rubrics);
+    const author = sealCapabilityResults(
+      'anthropic',
+      'claude-exact',
+      revision,
+      runs(),
+      '2026-09-28',
+    );
+    const candidate = sealCapabilityResults(
+      'openai',
+      'codex-exact',
+      revision,
+      runs(),
+      '2026-09-28',
+    );
+    const altered = { ...candidate, runs: withVerdict(candidate.runs, 0, 'request_changes') };
+    expect(compareSealedCapabilityResults(manifest, rubrics, author, altered)).toBe('unknown');
+  });
+});
diff --git a/packages/cli/tests/review/codex-app-server-proof.test.ts b/packages/cli/tests/review/codex-app-server-proof.test.ts
new file mode 100644
index 000000000..2cdbff565
--- /dev/null
+++ b/packages/cli/tests/review/codex-app-server-proof.test.ts
@@ -0,0 +1,127 @@
+import { describe, expect, it } from 'vitest';
+
+import {
+  codexAppServerFailedTurn,
+  codexAppServerProof,
+} from '../../src/review/codex-app-server-proof.js';
+
+const threadStart = {
+  id: 2,
+  result: { thread: { id: 'thread-1' }, model: 'gpt-6-astra', modelProvider: 'openai' },
+};
+const turnStart = { id: 3, result: { turn: { id: 'turn-1' } } };
+const completed = {
+  method: 'turn/completed',
+  params: {
+    threadId: 'thread-1',
+    turn: {
+      id: 'turn-1',
+      status: 'completed',
+      items: [{ type: 'agentMessage', phase: 'final_answer', text: '{"verdict":"approve"}' }],
+    },
+  },
+};
+
+describe('Codex app-server reviewer proof', () => {
+  it('binds the final answer and exact model to the acknowledged completed turn', () => {
+    expect(codexAppServerProof([threadStart, turnStart, completed], 'gpt-6-astra')).toEqual({
+      text: '{"verdict":"approve"}',
+      confirmedModel: { provider: 'openai', model: 'gpt-6-astra' },
+    });
+  });
+
+  it('keeps a completed review but does not confirm a mismatched or rerouted model', () => {
+    const rerouted = {
+      method: 'model/rerouted',
+      params: {
+        threadId: 'thread-1',
+        turnId: 'turn-1',
+        fromModel: 'gpt-6-astra',
+        toModel: 'gpt-6-sol',
+      },
+    };
+    expect(codexAppServerProof([threadStart, turnStart, completed], 'gpt-6-sol')).toEqual({
+      text: '{"verdict":"approve"}',
+    });
+    expect(
+      codexAppServerProof([threadStart, turnStart, rerouted, completed], 'gpt-6-astra'),
+    ).toEqual({ text: '{"verdict":"approve"}' });
+    expect(
+      codexAppServerProof(
+        [
+          { ...threadStart, result: { ...threadStart.result, modelProvider: 'anthropic' } },
+          turnStart,
+          completed,
+        ],
+        'gpt-6-astra',
+      ),
+    ).toEqual({ text: '{"verdict":"approve"}' });
+  });
+
+  it('refuses to bind an answer from another thread or unfinished turn', () => {
+    expect(
+      codexAppServerProof(
+        [
+          threadStart,
+          turnStart,
+          { ...completed, params: { ...completed.params, threadId: 'thread-2' } },
+        ],
+        'gpt-6-astra',
+      ),
+    ).toBeUndefined();
+    expect(
+      codexAppServerProof(
+        [
+          threadStart,
+          turnStart,
+          {
+            ...completed,
+            params: {
+              ...completed.params,
+              turn: { ...completed.params.turn, id: 'turn-2' },
+            },
+          },
+        ],
+        'gpt-6-astra',
+      ),
+    ).toBeUndefined();
+    expect(
+      codexAppServerProof(
+        [
+          threadStart,
+          turnStart,
+          {
+            ...completed,
+            params: {
+              ...completed.params,
+              turn: { ...completed.params.turn, status: 'failed' },
+            },
+          },
+        ],
+        'gpt-6-astra',
+      ),
+    ).toBeUndefined();
+  });
+
+  it('recognizes failure only for the acknowledged turn', () => {
+    const failed = {
+      ...completed,
+      params: { ...completed.params, turn: { ...completed.params.turn, status: 'failed' } },
+    };
+    expect(codexAppServerFailedTurn([threadStart, turnStart, failed])).toBe(true);
+    expect(
+      codexAppServerFailedTurn([
+        threadStart,
+        turnStart,
+        { ...failed, params: { ...failed.params, threadId: 'thread-2' } },
+      ]),
+    ).toBe(false);
+    expect(
+      codexAppServerFailedTurn([
+        threadStart,
+        turnStart,
+        { ...failed, params: { ...failed.params, turn: { ...failed.params.turn, id: 'turn-2' } } },
+      ]),
+    ).toBe(false);
+  });
+});
diff --git a/packages/cli/tests/review/execution-plan-output.test.ts b/packages/cli/tests/review/execution-plan-output.test.ts
index eee746df3..051ab1c0e 100644
--- a/packages/cli/tests/review/execution-plan-output.test.ts
+++ b/packages/cli/tests/review/execution-plan-output.test.ts
@@ -193,18 +193,19 @@ describe('Execution Plan output schema', () => {
       ]),
     );
     expect(reviewOutputSchema('plan-execution')).not.toBe(reviewOutputSchema('quality-review'));
+    expect(reviewOutputSchema('plan-execution')).not.toContain('"oneOf"');
   });
 
-  it('gives Claude the selected strict schema without changing legacy arguments', () => {
+  it('gives Claude the selected strict schema in its planning output format', () => {
     const legacy = reviewerArguments('claude', undefined, undefined, {}, 'quality-review');
     const execution = reviewerArguments('claude', undefined, undefined, {}, 'plan-execution');
     const schemaIndex = execution.indexOf('--json-schema') + 1;
 
     expect(execution[schemaIndex]).toBe(reviewOutputSchema('plan-execution'));
     expect(legacy[schemaIndex]).toBe(reviewOutputSchema('quality-review'));
-    expect(execution.filter((_argument, index) => index !== schemaIndex)).toEqual(
-      legacy.filter((_argument, index) => index !== schemaIndex),
-    );
+    expect(execution).toContain('stream-json');
+    expect(execution).toContain('--verbose');
+    expect(legacy).toContain('json');
   });
 
   it('parses the record only under the internal plan-execution kind', () => {
diff --git a/packages/cli/tests/review/finish-review-contract.test.ts b/packages/cli/tests/review/finish-review-contract.test.ts
index 2cf637e68..924e8b68e 100644
--- a/packages/cli/tests/review/finish-review-contract.test.ts
+++ b/packages/cli/tests/review/finish-review-contract.test.ts
@@ -28,25 +28,25 @@ function required<T>(value: T | undefined, message: string): T {
   return value;
 }
 
-describe('best-available host review contract', () => {
-  it('enters only for typed route exhaustion and advances each degraded route once', () => {
+describe('job-bound host review continuation contract', () => {
+  it('enters only for a sealed continuation and advances each host tier once', () => {
     const skill = read(skillPath);
     const normalizedSkill = skill.replaceAll(/\s+/gu, ' ');
 
     expect(skill).toContain('user-invocable: false');
     expect(skill).toContain("allowed-tools: '*'");
-    expect(skill).toContain('REVIEW_ROUTES_EXHAUSTED');
-    expect(skill).toContain('with `status: blocked` and `independence: none`');
-    expect(normalizedSkill).toContain('reports completed or satisfied independent review');
-    expect(skill).toContain('return the original coordinator result unchanged');
+    expect(skill).toContain('REVIEW_CONTINUATION_REQUIRED');
+    expect(skill).toContain('continuation_required');
+    expect(skill).toContain('review_id');
+    expect(skill).toContain('continuation.packet');
+    expect(skill).toContain('review continue');
+    expect(normalizedSkill).toContain('same sealed packet');
     expect(skill).toMatch(/one fresh-context reviewer/i);
     expect(skill).toMatch(/one main-thread self-review/i);
     expect(skill).toContain('host timeout');
-    expect(skill).toContain('Never return timed-out, failed, or invalid reviewer output');
-    expect(skill).toMatch(/never (restart|rerun).*coordinator/i);
-    expect(skill.replaceAll(/\s+/gu, ' ')).toContain(
-      'Invalid terminal output returns the original `REVIEW_ROUTES_EXHAUSTED` coordinator result unchanged.',
-    );
+    expect(skill).toContain('invalid reviewer output');
+    expect(normalizedSkill).toMatch(/never (restart|rerun).*coordinator/i);
+    expect(skill).toContain('REVIEW_ROUTES_EXHAUSTED');
   });
 
   it('pins structured output, hostile-input containment, policy, verdict, and assurance', () => {
@@ -54,6 +54,9 @@ describe('best-available host review contract', () => {
     const contract = read(contractPath);
     const normalizedSkill = skill.replaceAll(/^>\s?/gmu, '').replaceAll(/\s+/gu, ' ');
     const normalizedContract = contract.replaceAll(/\s+/gu, ' ');
+    expect(contract).toContain('"schema_version": 1');
+    expect(contract).toContain('"dispatch_id"');
+    expect(contract).toContain('"reviewer_agent"');
     expect(contract).toContain('"verdict": "approve" | "request_changes"');
     expect(contract).toContain('"findings"');
     expect(contract).toContain('untrusted review material');
@@ -61,32 +64,26 @@ describe('best-available host review contract', () => {
     expect(normalizedContract).toContain('credentials, or secrets');
     expect(contract).toContain('cannot independently prove');
     expect(contract).toContain('not a structural sandbox guarantee');
-    expect(normalizedSkill).toContain(
-      'Provide supplemental review feedback in this foreground session.',
-    );
-    expect(normalizedSkill).toContain('Required independent coverage remains unsatisfied.');
-    expect(normalizedSkill).not.toContain('This review was not independent.');
-    expect(normalizedSkill).toContain('Host-mandated project context may have loaded');
-    expect(normalizedSkill).toContain('source integrity was not revalidated');
-    expect(normalizedSkill).toContain('Supplemental feedback came from the main agent');
-    expect(normalizedSkill).toContain('Use an environment with a usable independent reviewer.');
-    expect(normalizedSkill).toContain(
-      "Include the coordinator's recovery command exactly as provided.",
-    );
-    expect(normalizedSkill).toContain('Alternatively, explicitly choose `prefer`.');
-    expect(normalizedSkill).toContain('map `approve` to `State: approved`');
-    expect(normalizedSkill).toContain('and `request_changes` to `State: action required`');
-    expect(normalizedSkill).toContain(
-      'Take `review_policy` only from the trusted coordinator envelope',
-    );
+    expect(normalizedSkill).toContain('Read only the sealed packet');
+    expect(normalizedSkill).toContain('actual reviewer and reduced independence');
     expect(normalizedSkill).toContain('.safeword/skills/finish-review/REVIEWER.md');
     expect(normalizedSkill).not.toContain('sibling `REVIEWER.md`');
-    expect(skill).toContain('Coordinator: `REVIEW_ROUTES_EXHAUSTED`');
-    expect(skill).toContain('Policy:');
-    expect(skill).toContain('State:');
     expect(skill).not.toContain('write-review-stamp');
   });
 
+  it('preserves supplemental non-planning review without creating a machine receipt', () => {
+    const skill = read(skillPath);
+    const contract = read(contractPath);
+    const agent = read(agentPath);
+    expect(skill).toContain('legacy non-planning supplemental path');
+    expect(skill).toContain('source integrity is not revalidated');
+    expect(skill).toContain('no machine receipt or review stamp');
+    expect(skill).toContain('Under `require`, the independent gate remains');
+    expect(contract).toContain('omit `schema_version`');
+    expect(contract).toContain('read only the accepted target');
+    expect(agent).toContain('legacy non-planning');
+  });
+
   it('ships one reviewer contract and host-native assets on every supported surface', () => {
     const agent = read(agentPath);
     const contract = read(contractPath);
diff --git a/packages/cli/tests/review/job.test.ts b/packages/cli/tests/review/job.test.ts
index 0f450aa39..0c4faaf53 100644
--- a/packages/cli/tests/review/job.test.ts
+++ b/packages/cli/tests/review/job.test.ts
@@ -29,9 +29,11 @@ import {
   relayManagedWorkerStderr,
   reviewJobStatus,
   startReviewJob,
+  submitReviewContinuation,
 } from '../../src/review/job.js';
 import { readReviewReceipt } from '../../templates/hooks/lib/read-receipt.js';
 import { receiptGateVerdict } from '../../templates/hooks/lib/review-receipt.js';
+import { runCli } from '../helpers.js';
 import { writePlanningInventories } from '../planning-fixtures.js';
 import {
   cleanupTrustedReviewerDirectories,
@@ -91,6 +93,32 @@ const REQUEST_CHANGES_WORKER = COMPLETE_WORKER.replace(
   .replace("verdict: 'approve'", "verdict: 'request_changes'")
   .replace('findings: []', "findings: [{ severity: 'error', message: 'Unsafe retry' }]");
 
+const CONTINUATION_WORKER = `${COMPLETE_WORKER.slice(0, COMPLETE_WORKER.indexOf('record.result = {'))}
+record.result = {
+  schemaVersion: 1, ok: true, state: 'action_required', changed: false,
+  findings: [{ code: 'REVIEW_CONTINUATION_REQUIRED', message: 'Fresh-context review is next.', severity: 'warning' }],
+  effects: { files: [], packages: [], configuration: [], network: [], destructive: [] },
+  errors: [], recovery: [], nextActions: [],
+  data: {
+    command: 'review run', status: 'continuation_required',
+    author_agent: 'claude', review_policy: 'prefer', independence: 'none',
+    continuation: {
+      tier: 'fresh-context',
+      instructions: 'Review only the bounded files in this packet.',
+      packet: {
+        schema_version: 1, dispatch_id: 'fixture-dispatch', kind: record.kind,
+        planning_phase: 'product-plan',
+        logical_files: record.targets.map(path => ({ path, content: readFileSync(path, 'utf8') })),
+      },
+    },
+    review_routes: [
+      { reviewer: 'codex', independence: 'cross-agent', status: 'attempted', failure: 'process_failed' },
+      { reviewer: 'claude', independence: 'degraded', status: 'attempted', failure: 'process_failed' },
+    ],
+  },
+};
+${COMPLETE_WORKER.slice(COMPLETE_WORKER.indexOf('const canonicalProject'))}`;
+
 const APPROVED_RED_ATTESTATION =
   'execution_attestation: { source_fingerprint: record.source_fingerprint, expected_failure: { matched: true }, termination: { exit_code: 1, timed_out: false } }, reviewer_output: {';
 
@@ -234,6 +262,262 @@ afterEach(() => {
 });
 
 describe('durable review jobs', () => {
+  it('retains a packet-bound host continuation in the authenticated job result', async () => {
+    const cwd = project();
+    writePlanningInventories(cwd);
+    const ticket = '.project/tickets/CON123-host-continuation';
+    mkdirSync(nodePath.join(cwd, ticket), { recursive: true });
+    writeFileSync(
+      nodePath.join(cwd, ticket, 'ticket.md'),
+      '---\nid: CON123\ntype: feature\nphase: intake\nstatus: in_progress\nproduct_plan_contract: v1\nscope: truthful review\nout_of_scope: unverified independence\ndone_when: host continuation is authenticated\n---\n',
+    );
+    writeFileSync(
+      nodePath.join(cwd, ticket, 'spec.md'),
+      '# Product Plan: Truthful review\n\n<!-- safeword:product-plan-contract:v1 -->\n\n## Product Bet\n\n- **Problem / Why now:** Builders need trustworthy planning review.\n- **Expected outcome:** Only current approval advances.\n- **Success threshold:** Host continuation retains packet identity.\n- **Project non-goals:** Inventing independent assurance.\n- **Persona outcome inventory:** Builder receives approval or refusal.\n- **Known facts:** This fixture has one Builder.\n- **Assumptions:** none\n- **Unresolved product decisions:** none\n\n## Jobs To Be Done\n\n### review.BU1 — Trust review\n\n**Persona:** Builder (BU)\n\n> When I request review, I want current evidence, so I can trust the result.\n\n#### review.BU1.R1 — Preserve review provenance\n\nOnly current review advances.\n\n## Shape\n\n### M1 — Trust review\n\n- **Outcome:** Current review is authenticated.\n- **Non-goals:** Unqualified independence.\n\n## Surfaces\n\nAffected:\n- Safeword CLI\n',
+    );
+    vi.stubEnv('SAFEWORD_CLI_ENTRYPOINT', worker(cwd, CONTINUATION_WORKER));
+    vi.stubEnv('SAFEWORD_REVIEW_FOREGROUND_MS', '3000');
+    const result = await startReviewJob({
+      cwd,
+      kind: 'quality-review',
+      targets: [`${ticket}/spec.md`],
+    });
+
+    expect(result.state).toBe('action_required');
+    expect(result.data).toMatchObject({
+      status: 'continuation_required',
+      continuation: {
+        tier: 'fresh-context',
+        packet: {
+          dispatch_id: 'fixture-dispatch',
+          planning_phase: 'product-plan',
+          logical_files: [{ path: `${ticket}/spec.md` }],
+        },
+      },
+    });
+    expect(reviewJobStatus(cwd, (result.data as { review_id: string }).review_id).data).toEqual(
+      result.data,
+    );
+    const id = (result.data as { review_id: string }).review_id;
+    const specPath = nodePath.join(cwd, ticket, 'spec.md');
+    const original = readFileSync(specPath, 'utf8');
+    writeFileSync(specPath, `${original}\n## Changed decision\n\nA new boundary.\n`);
+    expect(reviewJobStatus(cwd, id).findings[0]?.code).toBe('REVIEW_STALE');
+    expect(
+      submitReviewContinuation(
+        cwd,
+        id,
+        'fresh-context',
+        {
+          schema_version: 1,
+          dispatch_id: 'fixture-dispatch',
+          reviewer_agent: 'claude',
+          verdict: 'approve',
+          summary: 'Stale approval',
+          findings: [],
+        },
+        { origin: 'claude' },
+      ).findings[0]?.code,
+    ).toBe('REVIEW_STALE');
+    writeFileSync(specPath, original);
+
+    const recordPath = nodePath.join(cwd, '.safeword/state/reviews', `${id}.json`);
+    const sealedRecord = readFileSync(recordPath, 'utf8');
+    const record = JSON.parse(sealedRecord) as {
+      result: { data: { continuation: { packet: { dispatch_id: string } } } };
+    };
+    record.result.data.continuation.packet.dispatch_id = 'forged-dispatch';
+    writeFileSync(recordPath, `${JSON.stringify(record)}\n`);
+    expect(reviewJobStatus(cwd, id).errors[0]?.code).toBe('REVIEW_JOB_INVALID');
+    writeFileSync(recordPath, sealedRecord);
+
+    const baseOutput = {
+      schema_version: 1 as const,
+      dispatch_id: 'fixture-dispatch',
+      reviewer_agent: 'claude' as const,
+      verdict: 'approve' as const,
+      summary: 'The saved product decision is coherent.',
+      findings: [],
+    };
+    const completed = submitReviewContinuation(cwd, id, 'fresh-context', baseOutput, {
+      origin: 'claude',
+    });
+    expect(completed.data).toMatchObject({
+      status: 'approved',
+      independence: 'reduced',
+      actual_reviewer: 'claude',
+      reviewer_output: { dispatch_id: 'fixture-dispatch' },
+    });
+    expect(reviewJobStatus(cwd, id).data).toEqual(completed.data);
+    expect(
+      submitReviewContinuation(
+        cwd,
+        id,
+        'fresh-context',
+        {
+          schema_version: 1,
+          dispatch_id: 'fixture-dispatch',
+          reviewer_agent: 'claude',
+          verdict: 'approve',
+          summary: 'Replay',
+          findings: [],
+        },
+        { origin: 'claude' },
+      ).errors[0]?.code,
+    ).toBe('REVIEW_CONTINUATION_ALREADY_USED');
+
+    const next = await startReviewJob({
+      cwd,
+      kind: 'quality-review',
+      targets: [`${ticket}/spec.md`],
+    });
+    const nextId = (next.data as { review_id: string }).review_id;
+    const escalated = submitReviewContinuation(
+      cwd,
+      nextId,
+      'fresh-context',
+      {
+        ...baseOutput,
+        dispatch_id: 'wrong-dispatch',
+      },
+      { origin: 'claude' },
+    );
+    expect(escalated.data).toMatchObject({
+      status: 'continuation_required',
+      continuation: { tier: 'self-review', packet: { dispatch_id: 'fixture-dispatch' } },
+    });
+    expect(reviewJobStatus(cwd, nextId).data).toEqual(escalated.data);
+    expect(
+      submitReviewContinuation(cwd, nextId, 'fresh-context', baseOutput, { origin: 'claude' })
+        .errors[0]?.code,
+    ).toBe('REVIEW_CONTINUATION_TIER_INVALID');
+    const final = submitReviewContinuation(
+      cwd,
+      nextId,
+      'self-review',
+      {
+        ...baseOutput,
+        findings: [{ severity: 'error', message: 'Blocking defect' }],
+      },
+      { origin: 'claude' },
+    );
+    expect(final.data).toMatchObject({ status: 'blocked', independence: 'none' });
+    expect(reviewJobStatus(cwd, nextId).data).toEqual(final.data);
+
+    const publicJob = await startReviewJob({
+      cwd,
+      kind: 'quality-review',
+      targets: [`${ticket}/spec.md`],
+    });
+    const publicId = (publicJob.data as { review_id: string }).review_id;
+    writeFileSync(nodePath.join(cwd, 'host-review.json'), `${JSON.stringify(baseOutput)}\n`);
+    const submitted = await runCli(
+      [
+        'review',
+        'continue',
+        publicId,
+        '--tier',
+        'fresh-context',
+        '--output',
+        'host-review.json',
+        '--offline',
+        '--json',
+        '--no-input',
+        '--cwd',
+        cwd,
+      ],
+      { cwd, env: { SAFEWORD_AGENT_RUNTIME: 'claude' } },
+    );
+    expect(submitted.exitCode).toBe(0);
+    expect(JSON.parse(submitted.stdout)).toMatchObject({
+      effects: { network: [] },
+      data: { status: 'approved', review_id: publicId, independence: 'reduced' },
+    });
+    expect(reviewJobStatus(cwd, publicId).data).toMatchObject({
+      status: 'approved',
+      independence: 'reduced',
+    });
+
+    const unavailableJob = await startReviewJob({
+      cwd,
+      kind: 'quality-review',
+      targets: [`${ticket}/spec.md`],
+    });
+    const unavailableId = (unavailableJob.data as { review_id: string }).review_id;
+    const unavailable = await runCli(
+      [
+        'review',
+        'continue',
+        unavailableId,
+        '--tier',
+        'fresh-context',
+        '--failure',
+        'unsupported',
+        '--offline',
+        '--json',
+        '--no-input',
+        '--cwd',
+        cwd,
+      ],
+      { cwd, env: { SAFEWORD_AGENT_RUNTIME: 'claude' } },
+    );
+    expect(unavailable.exitCode).toBe(2);
+    expect(JSON.parse(unavailable.stdout)).toMatchObject({
+      state: 'action_required',
+      effects: { network: [] },
+      errors: [],
+      data: {
+        status: 'continuation_required',
+        continuation: { tier: 'self-review' },
+        continuation_attempts: [{ tier: 'fresh-context', failure: 'unsupported' }],
+      },
+    });
+  });
+
+  it('does not admit a host Execution Plan approval with an invalid delivery record', async () => {
+    const cwd = executionPlanProject();
+    vi.stubEnv(
+      'SAFEWORD_CLI_ENTRYPOINT',
+      worker(
+        cwd,
+        CONTINUATION_WORKER.replace(
+          "planning_phase: 'product-plan'",
+          "planning_phase: 'plan-execution'",
+        ),
+      ),
+    );
+    vi.stubEnv('SAFEWORD_REVIEW_FOREGROUND_MS', '3000');
+    const pending = await startReviewJob({
+      cwd,
+      kind: 'plan-execution',
+      targets: ['execution-plan.md'],
+      context: ['impl-plan.md', 'behavior.feature'],
+    });
+    const id = (pending.data as { review_id: string }).review_id;
+
+    const result = submitReviewContinuation(
+      cwd,
+      id,
+      'fresh-context',
+      {
+        schema_version: 1,
+        dispatch_id: 'fixture-dispatch',
+        reviewer_agent: 'claude',
+        verdict: 'approve',
+        summary: 'Looks complete.',
+        findings: [],
+        planning_destination: 'plan-execution',
+        execution_plan_record: {},
+      },
+      { origin: 'claude' },
+    );
+    expect(result.data).toMatchObject({
+      status: 'continuation_required',
+      independence: 'none',
+      continuation: { tier: 'self-review' },
+    });
+  });
+
   it('contains managed child-stderr errors and removes the scoped listener on close', async () => {
     const stderr = new PassThrough();
     const child = { stderr } as unknown as ChildProcess;
diff --git a/packages/cli/tests/review/packaged-capability.release.test.ts b/packages/cli/tests/review/packaged-capability.release.test.ts
new file mode 100644
index 000000000..bfcdd072d
--- /dev/null
+++ b/packages/cli/tests/review/packaged-capability.release.test.ts
@@ -0,0 +1,68 @@
+import { createHash } from 'node:crypto';
+import { readFileSync } from 'node:fs';
+import nodePath from 'node:path';
+
+import { describe, expect, it } from 'vitest';
+
+import {
+  PACKAGED_CAPABILITY_PAIRS,
+  PACKAGED_CAPABILITY_REVISION,
+} from '../../src/review/capability-catalogue.js';
+import {
+  capabilityRevision,
+  compareSealedCapabilityResults,
+  type SealedCapabilityResults,
+} from '../../src/review/capability-eval.js';
+import {
+  REVIEWER_CAPABILITY_MANIFEST,
+  REVIEWER_CAPABILITY_RUBRICS,
+} from '../fixtures/reviewer-capability-corpus.js';
+
+function evidence(model: string): SealedCapabilityResults {
+  const path = nodePath.join(
+    import.meta.dirname,
+    '../fixtures/reviewer-capability-evidence',
+    `${model}.json`,
+  );
+  return JSON.parse(readFileSync(path, 'utf8')) as SealedCapabilityResults;
+}
+
+describe('packaged reviewer capability evidence', () => {
+  it('qualifies both shipped default cross-provider orderings from current sealed results', () => {
+    const claude = evidence('claude-opus-5');
+    const codex = evidence('gpt-6-astra');
+    const revision = capabilityRevision(REVIEWER_CAPABILITY_MANIFEST, REVIEWER_CAPABILITY_RUBRICS);
+    expect(PACKAGED_CAPABILITY_REVISION).toEqual(revision);
+    expect(PACKAGED_CAPABILITY_PAIRS).toHaveLength(2);
+
+    for (const [author, reviewer] of [
+      [claude, codex],
+      [codex, claude],
+    ] as const) {
+      const direction = compareSealedCapabilityResults(
+        REVIEWER_CAPABILITY_MANIFEST,
+        REVIEWER_CAPABILITY_RUBRICS,
+        author,
+        reviewer,
+      );
+      expect(direction).not.toBe('unknown');
+      const resultsDigest = createHash('sha256')
+        .update(`${author.results_digest}\0${reviewer.results_digest}`)
+        .digest('hex');
+      expect(PACKAGED_CAPABILITY_PAIRS).toContainEqual({
+        ...revision,
+        author_provider: author.provider,
+        author_model: author.model,
+        reviewer_provider: reviewer.provider,
+        reviewer_model: reviewer.model,
+        direction,
+        qualification: 'pinned-corpus',
+        evidence_date:
+          author.evidence_date.localeCompare(reviewer.evidence_date) > 0
+            ? author.evidence_date
+            : reviewer.evidence_date,
+        results_digest: resultsDigest,
+      });
+    }
+  });
+});
diff --git a/packages/cli/tests/review/policy.test.ts b/packages/cli/tests/review/policy.test.ts
index ac4657ccc..2f46a5039 100644
--- a/packages/cli/tests/review/policy.test.ts
+++ b/packages/cli/tests/review/policy.test.ts
@@ -4,8 +4,11 @@ import nodePath from 'node:path';
 
 import { describe, expect, it } from 'vitest';
 
-import type { ReviewAuthor } from '../../src/review/contract.js';
-import { readConfiguredReviewRoutes, reviewRoutePlan } from '../../src/review/policy.js';
+import {
+  builtInReviewRoutes,
+  readConfiguredReviewRoutes,
+  reviewRoutePlan,
+} from '../../src/review/policy.js';
 
 describe('review route policy', () => {
   function project(config: unknown): string {
@@ -36,12 +39,19 @@ describe('review route policy', () => {
     });
   });
 
-  it.each<ReviewAuthor>(['cursor', 'unknown'])(
-    'keeps unsupported author %s outside review routing',
-    author => {
-      expect(reviewRoutePlan(author)).toBeUndefined();
-    },
-  );
+  it('routes Cursor authors through independent CLI reviewers without inventing a headless Cursor reviewer', () => {
+    expect(reviewRoutePlan('cursor')).toEqual({
+      author: 'cursor',
+      preferred: 'claude',
+      independentFallback: 'codex',
+    });
+    expect(
+      builtInReviewRoutes(project({}), 'cursor').every(
+        route => route.independence === 'cross-agent',
+      ),
+    ).toBe(true);
+    expect(reviewRoutePlan('unknown')).toBeUndefined();
+  });
 
   it('uses an ordered reviewer and model list as the complete route authority', () => {
     const cwd = project({
diff --git a/packages/cli/tests/review/runtime.test.ts b/packages/cli/tests/review/runtime.test.ts
index 236b8174e..dc8a52f17 100644
--- a/packages/cli/tests/review/runtime.test.ts
+++ b/packages/cli/tests/review/runtime.test.ts
@@ -22,6 +22,7 @@ import { prepareReviewPacket } from '../../src/review/packet.js';
 import {
   inspectReviewRoute,
   parseProcessStat,
+  parseReviewerExecution,
   parseReviewerOutput,
   planReviewRubric,
   procGroupHasRunningMember,
@@ -32,6 +33,7 @@ import {
   reviewTimeoutMilliseconds,
   runBoundMs,
   runHeadlessReviewer,
+  runHeadlessReviewerWithProvenance,
   scenarioReviewRubric,
 } from '../../src/review/runtime.js';
 import { writePlanningInventories } from '../planning-fixtures.js';
@@ -306,6 +308,37 @@ describe('headless reviewer output adapters', () => {
     expect(parseReviewerOutput('claude', envelope)).toEqual(output);
   });
 
+  it('confirms the Claude assistant model without mistaking auxiliary model usage for the reviewer', () => {
+    const stdout = [
+      JSON.stringify({ type: 'system', subtype: 'init', model: 'opus' }),
+      JSON.stringify({ type: 'assistant', message: { model: 'claude-opus-5' } }),
+      JSON.stringify({
+        type: 'result',
+        subtype: 'success',
+        structured_output: output,
+        modelUsage: {
+          'claude-haiku-4-5-20251001': {
+            canonicalModel: 'claude-haiku-4-5',
+            provider: 'firstParty',
+          },
+          'claude-opus-5[1m]': { canonicalModel: 'claude-opus-5', provider: 'firstParty' },
+        },
+      }),
+    ].join('\n');
+
+    expect(parseReviewerExecution('claude', stdout, 'plan-implementation')).toEqual({
+      output,
+      confirmedModel: { provider: 'anthropic', model: 'claude-opus-5' },
+    });
+    expect(
+      parseReviewerExecution(
+        'claude',
+        stdout.replace('"model":"claude-opus-5"', '"model":"claude-sonnet-5"'),
+        'plan-implementation',
+      ).confirmedModel,
+    ).toBeUndefined();
+  });
+
   it('falls back to Claude result JSON when structured output is unusable', () => {
     const envelope = JSON.stringify({ structured_output: 0, result: JSON.stringify(output) });
 
@@ -475,6 +508,28 @@ describe('reviewer arguments', () => {
     expect(args).not.toContain('-');
   });
 
+  it('requests streamed assistant metadata for planning reviews', () => {
+    const args = reviewerArguments('claude', 'opus', undefined, {}, 'plan-implementation');
+    expect(
+      args.slice(args.indexOf('--output-format'), args.indexOf('--output-format') + 2),
+    ).toEqual(['--output-format', 'stream-json']);
+    expect(args).toContain('--verbose');
+    const productArguments = reviewerArguments(
+      'claude',
+      'opus',
+      undefined,
+      {},
+      { kind: 'quality-review', planning_phase: 'product-plan' },
+    );
+    expect(
+      productArguments.slice(
+        productArguments.indexOf('--output-format'),
+        productArguments.indexOf('--output-format') + 2,
+      ),
+    ).toEqual(['--output-format', 'stream-json']);
+    expect(productArguments).toContain('--verbose');
+  });
+
   it('appends an explicitly configured Claude effort level', () => {
     const args = reviewerArguments('claude', 'sonnet', undefined, {
       SAFEWORD_REVIEW_EFFORT_CLAUDE: 'low',
@@ -731,6 +786,171 @@ esac
     },
   );
 
+  it.skipIf(process.platform === 'win32')(
+    'carries a confirmed planning reviewer model across the process boundary',
+    async () => {
+      vi.stubEnv('NODE_ENV', 'test');
+      const bin = trustedTemporaryDirectory();
+      const project = temporaryDirectory();
+      const untrustedRoot = temporaryDirectory();
+      const executable = nodePath.join(bin, 'claude');
+      const events = [
+        { type: 'assistant', message: { model: 'claude-opus-5' } },
+        {
+          type: 'result',
+          subtype: 'success',
+          structured_output: output,
+          modelUsage: {
+            'claude-opus-5': { canonicalModel: 'claude-opus-5', provider: 'firstParty' },
+          },
+        },
+      ];
+      const serializedEvents = events.map(event => `'${JSON.stringify(event)}'`).join(' ');
+      writeFileSync(
+        executable,
+        `#!/bin/sh\nif [ "\${1:-}" = "--help" ]; then\n  echo '--output-format --json-schema --no-session-persistence --disable-slash-commands --setting-sources --strict-mcp-config --tools'\n  exit 0\nfi\ncase " $* " in *" --effort medium "*) ;; *) exit 8 ;; esac\n/bin/cat >/dev/null\nprintf '%s\\n' ${serializedEvents}\n`,
+        { mode: 0o755 },
+      );
+      vi.stubEnv('PATH', bin);
+
+      await expect(
+        runHeadlessReviewerWithProvenance(
+          'claude',
+          {
+            schema_version: 1,
+            dispatch_id: 'dispatch-1',
+            kind: 'scenario-gate',
+            logical_files: [],
+          },
+          project,
+          untrustedRoot,
+          { effort: 'medium' },
+        ),
+      ).resolves.toMatchObject({
+        output: { dispatch_id: 'dispatch-1', verdict: 'approve' },
+        confirmedModel: { provider: 'anthropic', model: 'claude-opus-5' },
+      });
+    },
+  );
+
+  it.skipIf(process.platform === 'win32')(
+    'confirms a Codex planning model only through an app-server turn',
+    async () => {
+      vi.stubEnv('NODE_ENV', 'test');
+      const bin = trustedTemporaryDirectory();
+      const project = temporaryDirectory();
+      const untrustedRoot = temporaryDirectory();
+      const executable = nodePath.join(bin, 'codex');
+      const codexOutput = { ...output, reviewer_agent: 'codex' };
+      writeFileSync(
+        executable,
+        `#!${process.execPath}\nif (process.argv.includes('--version')) { console.log('codex 1.0.0'); process.exit(0); }\nif (process.argv.includes('--help')) { console.log(process.argv.includes('app-server') ? '--stdio --config' : ${JSON.stringify(REVIEWER_CAPABILITIES.codex)}); process.exit(0); }\nif (!process.argv.includes('app-server')) process.exit(7);\nlet buffer = '';\nprocess.stdin.setEncoding('utf8');\nprocess.stdin.on('data', chunk => { buffer += chunk; let index; while ((index = buffer.indexOf('\\n')) !== -1) { const line = buffer.slice(0, index); buffer = buffer.slice(index + 1); const message = JSON.parse(line); if (message.id === 1) console.log(JSON.stringify({ id: 1, result: {} })); if (message.id === 2) console.log(JSON.stringify({ id: 2, result: { thread: { id: 'thread-1' }, model: message.params.model, modelProvider: 'openai' } })); if (message.id === 3) { if (message.params.effort !== 'medium') process.exit(8); console.log(JSON.stringify({ id: 3, result: { turn: { id: 'turn-1' } } })); console.log(JSON.stringify({ method: 'turn/completed', params: { threadId: 'thread-1', turn: { id: 'turn-1', status: 'completed', items: [{ type: 'agentMessage', phase: 'final_answer', text: JSON.stringify(${JSON.stringify(codexOutput)}) }] } } })); } } });\n`,
+        { mode: 0o755 },
+      );
+      vi.stubEnv('PATH', bin);
+
+      await expect(
+        runHeadlessReviewerWithProvenance(
+          'codex',
+          {
+            schema_version: 1,
+            dispatch_id: 'dispatch-1',
+            kind: 'scenario-gate',
+            logical_files: [],
+          },
+          project,
+          untrustedRoot,
+          { model: 'gpt-6-astra', effort: 'medium' },
+        ),
+      ).resolves.toMatchObject({
+        output: { dispatch_id: 'dispatch-1', verdict: 'approve' },
+        confirmedModel: { provider: 'openai', model: 'gpt-6-astra' },
+      });
+      await expect(
+        runHeadlessReviewerWithProvenance(
+          'codex',
+          {
+            schema_version: 1,
+            dispatch_id: 'dispatch-1',
+            kind: 'quality-review',
+            planning_phase: 'product-plan',
+            logical_files: [],
+          },
+          project,
+          untrustedRoot,
+          { model: 'gpt-6-astra', effort: 'medium' },
+        ),
+      ).resolves.toMatchObject({
+        output: { dispatch_id: 'dispatch-1', verdict: 'approve' },
+        confirmedModel: { provider: 'openai', model: 'gpt-6-astra' },
+      });
+    },
+  );
+
+  it.skipIf(process.platform === 'win32')(
+    'reports a rejected Codex turn without waiting for the review deadline',
+    async () => {
+      vi.stubEnv('NODE_ENV', 'test');
+      const bin = trustedTemporaryDirectory();
+      const project = temporaryDirectory();
+      const untrustedRoot = temporaryDirectory();
+      const executable = nodePath.join(bin, 'codex');
+      writeFileSync(
+        executable,
+        `#!${process.execPath}\nif (process.argv.includes('--version')) { console.log('codex 1.0.0'); process.exit(0); }\nif (process.argv.includes('--help')) { console.log(process.argv.includes('app-server') ? '--stdio --config' : ${JSON.stringify(REVIEWER_CAPABILITIES.codex)}); process.exit(0); }\nlet buffer = ''; process.stdin.setEncoding('utf8'); process.stdin.on('data', chunk => { buffer += chunk; let index; while ((index = buffer.indexOf('\\n')) !== -1) { const line = buffer.slice(0, index); buffer = buffer.slice(index + 1); const message = JSON.parse(line); if (message.id === 1) console.log(JSON.stringify({ id: 1, result: {} })); if (message.id === 2) console.log(JSON.stringify({ id: 2, result: { thread: { id: 'thread-1' }, model: message.params.model, modelProvider: 'openai' } })); if (message.id === 3) console.log(JSON.stringify({ id: 3, error: { code: -32000, message: 'turn rejected' } })); } });\n`,
+        { mode: 0o755 },
+      );
+      vi.stubEnv('PATH', bin);
+
+      await expect(
+        runHeadlessReviewerWithProvenance(
+          'codex',
+          {
+            schema_version: 1,
+            dispatch_id: 'dispatch-1',
+            kind: 'scenario-gate',
+            logical_files: [],
+          },
+          project,
+          untrustedRoot,
+          { model: 'gpt-6-astra', runDeadline: Date.now() + 3000 },
+        ),
+      ).rejects.toMatchObject({ failure: 'process_failed' });
+    },
+  );
+
+  it.skipIf(process.platform === 'win32')(
+    'reports a failed Codex turn without waiting for the review deadline',
+    async () => {
+      vi.stubEnv('NODE_ENV', 'test');
+      const bin = trustedTemporaryDirectory();
+      const project = temporaryDirectory();
+      const untrustedRoot = temporaryDirectory();
+      const executable = nodePath.join(bin, 'codex');
+      writeFileSync(
+        executable,
+        `#!${process.execPath}\nif (process.argv.includes('--version')) { console.log('codex 1.0.0'); process.exit(0); }\nif (process.argv.includes('--help')) { console.log(process.argv.includes('app-server') ? '--stdio --config' : ${JSON.stringify(REVIEWER_CAPABILITIES.codex)}); process.exit(0); }\nlet buffer = ''; process.stdin.setEncoding('utf8'); process.stdin.on('data', chunk => { buffer += chunk; let index; while ((index = buffer.indexOf('\\n')) !== -1) { const line = buffer.slice(0, index); buffer = buffer.slice(index + 1); const message = JSON.parse(line); if (message.id === 1) console.log(JSON.stringify({ id: 1, result: {} })); if (message.id === 2) console.log(JSON.stringify({ id: 2, result: { thread: { id: 'thread-1' }, model: message.params.model, modelProvider: 'openai' } })); if (message.id === 3) { console.log(JSON.stringify({ id: 3, result: { turn: { id: 'turn-1' } } })); console.log(JSON.stringify({ method: 'turn/completed', params: { threadId: 'thread-1', turn: { id: 'turn-1', status: 'failed', error: { message: 'invalid schema' }, items: [] } } })); } } });\n`,
+        { mode: 0o755 },
+      );
+      vi.stubEnv('PATH', bin);
+
+      await expect(
+        runHeadlessReviewerWithProvenance(
+          'codex',
+          {
+            schema_version: 1,
+            dispatch_id: 'dispatch-1',
+            kind: 'plan-execution',
+            logical_files: [],
+          },
+          project,
+          untrustedRoot,
+          { model: 'gpt-6-astra', runDeadline: Date.now() + 3000 },
+        ),
+      ).rejects.toMatchObject({ failure: 'process_failed' });
+    },
+  );
+
   it.skipIf(process.platform === 'win32').each([
     {
       name: 'unsupported capabilities',
diff --git a/packages/cli/tests/review/surface-parity.test.ts b/packages/cli/tests/review/surface-parity.test.ts
index 3bbf61733..b5a899a91 100644
--- a/packages/cli/tests/review/surface-parity.test.ts
+++ b/packages/cli/tests/review/surface-parity.test.ts
@@ -160,21 +160,20 @@ function expectTypedExhaustion(relativePath: string, call: ReviewCallSection): v
   if (relativePath.endsWith('PLAN_EXECUTION.md')) {
     expect(normalized, context).toContain('--agent-handoff --json');
     expect(normalized, context).toContain('REVIEW_PENDING');
-    expect(normalized, context).toContain('typed route exhaustion');
-    expect(normalized, context).toMatch(/approving `[^`]*finish-review` fallback/u);
-    expect(normalized, context).toContain('actual reduced independence');
+    expect(normalized, context).toContain('REVIEW_CONTINUATION_REQUIRED');
+    expect(normalized, context).toContain('continuation_required');
+    expect(normalized, context).toContain('authenticated reduced independence');
     return;
   }
+  const planning = kind === 'scenario-gate' || kind === 'plan-implementation';
   expect(normalized, context).toContain('--agent-handoff --json');
   expect(normalized, context).toContain('`REVIEW_AUTHENTICATION_REQUIRED`');
   expect(normalized, context).toMatch(/execute its exact recovery command/iu);
   expect(normalized, context).toMatch(/rerun the same coordinator command once/iu);
   expect(section, context).toContain('REVIEW_PENDING');
-  if (relativePath.endsWith('PLAN_IMPLEMENTATION.md')) {
-    expect(normalized, context).toMatch(/degraded result[^.]{0,320}REVIEW_ROUTES_EXHAUSTED/iu);
-    expect(normalized, context).toMatch(/actual reviewer was not independent/iu);
-  } else {
-    expect(normalized, context).toMatch(/independence: degraded[^.]{0,240}not independent/iu);
+  if (planning) {
+    expect(normalized, context).toContain('REVIEW_CONTINUATION_REQUIRED');
+    expect(normalized, context).toContain('continuation_required');
   }
   expect(normalized, context).toContain(
     'Never substitute another surface-private reviewer or hand-written independent evidence.',
@@ -192,21 +191,13 @@ function expectTypedExhaustion(relativePath: string, call: ReviewCallSection): v
     return;
   }
 
-  if (kind !== 'quality-review') {
-    if (relativePath.endsWith('PLAN_IMPLEMENTATION.md')) {
-      expect(normalized, context).toContain('Otherwise do not stamp or advance');
-    } else {
-      expect(normalized, context).toMatch(
-        /independence: degraded[^.]{0,240}do not stamp or advance/iu,
-      );
-    }
+  if (planning) {
+    expect(normalized, context).toContain('do not stamp or advance');
+    expect(normalized, context).toMatch(/continuation_required[^.]{0,320}finish-review/iu);
+  } else if (kind === 'quality-review') {
+    expect(section, context).toContain('REVIEW_ROUTES_EXHAUSTED');
+    expect(normalized, context).toContain('REVIEW_CONTINUATION_REQUIRED');
   }
-
-  expect(section, context).toContain('REVIEW_ROUTES_EXHAUSTED');
-  expect(normalized, context).toMatch(/Only when[^.]{0,240}REVIEW_ROUTES_EXHAUSTED/u);
-  expect(normalized, context).toMatch(
-    /REVIEW_ROUTES_EXHAUSTED[^.]{0,200}invoke[^.]{0,80}finish-review/iu,
-  );
 }
 
 function markedQualityRubric(content: string): string {
diff --git a/packages/cli/tests/smoke/planning-review-model-confirmation.live.test.ts b/packages/cli/tests/smoke/planning-review-model-confirmation.live.test.ts
new file mode 100644
index 000000000..79f789387
--- /dev/null
+++ b/packages/cli/tests/smoke/planning-review-model-confirmation.live.test.ts
@@ -0,0 +1,116 @@
+import { readFileSync, writeFileSync } from 'node:fs';
+import nodePath from 'node:path';
+import process from 'node:process';
+
+import { describe, expect, it } from 'vitest';
+
+import { PACKAGED_CAPABILITY_PAIRS } from '../../src/review/capability-catalogue.js';
+import { reviewTimeoutMilliseconds } from '../../src/review/runtime.js';
+import {
+  assertTestCliFresh,
+  createConfiguredProject,
+  createTemporaryDirectory,
+  removeTemporaryDirectory,
+  runCli,
+} from '../helpers.js';
+import { writePlanningInventories } from '../planning-fixtures.js';
+
+const CAN_RUN = process.env.SAFEWORD_RUN_PLANNING_MODEL_LIVE === '1';
+const REVIEW_TIMEOUT_MS = reviewTimeoutMilliseconds({});
+const LIVE_TIMEOUT_MS = REVIEW_TIMEOUT_MS + 90_000;
+
+describe.skipIf(!CAN_RUN)('live packaged planning reviewer model confirmation', () => {
+  it.each([
+    { author: 'claude', reviewer: 'codex', provider: 'openai' },
+    { author: 'codex', reviewer: 'claude', provider: 'anthropic' },
+  ] as const)(
+    'confirms the exact packaged $reviewer selector through the public coordinator',
+    async ({ author, reviewer, provider }) => {
+      assertTestCliFresh();
+      const pairs = PACKAGED_CAPABILITY_PAIRS.filter(
+        record =>
+          record.reviewer_provider === provider &&
+          record.author_provider === (provider === 'openai' ? 'anthropic' : 'openai') &&
+          record.qualification !== 'unqualified',
+      );
+      expect(pairs, 'The packaged reviewer must have one exact qualified selector').toHaveLength(1);
+      const pair = pairs[0];
+      if (pair === undefined) throw new Error('Packaged reviewer selector is missing');
+      const profile =
+        reviewer === 'codex'
+          ? process.env.SAFEWORD_PLANNING_MODEL_LIVE_CODEX_HOME
+          : process.env.SAFEWORD_PLANNING_MODEL_LIVE_CLAUDE_CONFIG_DIR;
+      expect(
+        profile,
+        'Live proof requires an explicitly authenticated reviewer profile',
+      ).toBeTruthy();
+      if (!profile) throw new Error('Live reviewer profile is missing');
+      const profileEnvironment: Record<string, string> = {};
+      if (reviewer === 'codex') profileEnvironment.CODEX_HOME = profile;
+      else if (profile !== 'default') profileEnvironment.CLAUDE_CONFIG_DIR = profile;
+
+      const directory = createTemporaryDirectory();
+      try {
+        await createConfiguredProject(directory);
+        writePlanningInventories(directory);
+        const configPath = nodePath.join(directory, '.safeword/config.json');
+        const config = JSON.parse(readFileSync(configPath, 'utf8'));
+        writeFileSync(
+          configPath,
+          JSON.stringify({
+            ...config,
+            crossAgentReview: 'require',
+            crossAgentReviewRoutes: {
+              [author]: [{ reviewer, model: pair.reviewer_model }],
+            },
+          }),
+        );
+        writeFileSync(
+          nodePath.join(directory, 'spec.md'),
+          '# Preserve review authority\n\nPersona: Builder (BU).\n\nWhen no authenticated review receipt exists, the builder needs advancement denied so unreviewed work cannot advance.\n\nRule: advancement requires an authenticated review receipt.\n',
+        );
+        writeFileSync(
+          nodePath.join(directory, 'behavior.feature'),
+          'Feature: Preserve review authority\n\n  Scenario: Deny an unauthenticated approval\n    Given no authenticated review receipt exists\n    When the builder requests advancement\n    Then advancement is denied\n',
+        );
+        const result = await runCli(
+          [
+            'review',
+            'run',
+            'scenario-gate',
+            'behavior.feature',
+            '--context',
+            'spec.md',
+            '--json',
+            '--no-input',
+          ],
+          {
+            cwd: directory,
+            timeout: LIVE_TIMEOUT_MS,
+            env: {
+              SAFEWORD_AGENT_RUNTIME: author,
+              SAFEWORD_NO_UPDATE_CHECK: '1',
+              SAFEWORD_REVIEW_TIMEOUT_MS: String(REVIEW_TIMEOUT_MS),
+              SAFEWORD_REVIEW_RUN_BOUND_MS: String(REVIEW_TIMEOUT_MS + 60_000),
+              ...profileEnvironment,
+            },
+            unsetEnv: reviewer === 'claude' && profile === 'default' ? ['CLAUDE_CONFIG_DIR'] : [],
+          },
+        );
+        expect(result.timedOut, result.stderr).toBe(false);
+        expect([0, 2], result.stderr).toContain(result.exitCode);
+        const output = JSON.parse(result.stdout);
+        // Model confirmation is separate from author qualification and plan approval.
+        expect(output.data, result.stdout).toMatchObject({
+          actual_reviewer: reviewer,
+          reviewer_model: pair.reviewer_model,
+          confirmed_reviewer_model: { provider, model: pair.reviewer_model },
+        });
+        expect(output.data.status, result.stdout).not.toBe('pending');
+      } finally {
+        removeTemporaryDirectory(directory);
+      }
+    },
+    LIVE_TIMEOUT_MS,
+  );
+});
diff --git a/packages/website/src/content/docs/reference/cli.mdx b/packages/website/src/content/docs/reference/cli.mdx
index 7d253a9b9..eb1dc9a48 100644
--- a/packages/website/src/content/docs/reference/cli.mdx
+++ b/packages/website/src/content/docs/reference/cli.mdx
@@ -63,6 +63,7 @@ canonical commands below.
 | `ticket record-delivery-proof`          | mutate      | Run and retain one reviewed delivery proof                                                                                                       |
 | `review run`                            | mutate      | Run an independent adversarial review; report data.excluded_targets and REVIEW_TARGET_ATTRIBUTE_UNAVAILABLE or REVIEW_NO_ELIGIBLE_TARGETS errors |
 | `review status`                         | mutate      | Collect a durable independent review                                                                                                             |
+| `review continue`                       | mutate      | Complete a sealed planning review continuation                                                                                                   |
 | `review gate executable-red`            | observe     | Check whether a scenario may claim GREEN                                                                                                         |
 | `review gate retrospective`             | observe     | Check CKWE2D retrospective receipts                                                                                                              |
 | `review attest retrospective`           | mutate      | Replay one CKWE2D proof before checking its row                                                                                                  |
diff --git a/plugin/agents/safeword-reviewer.md b/plugin/agents/safeword-reviewer.md
index bc173df1c..3ebe96e8e 100644
--- a/plugin/agents/safeword-reviewer.md
+++ b/plugin/agents/safeword-reviewer.md
@@ -1,12 +1,15 @@
 ---
 name: safeword-reviewer
-description: Performs one read-only, fresh-context degraded review after Safeword exhausts every CLI reviewer route.
+description: Reviews one sealed planning packet or an accepted non-planning target set after Safeword exhausts reviewer routes.
 tools: Read
 ---
 
 You are Safeword's fresh-context degraded reviewer. Read and follow
-`"${CLAUDE_PLUGIN_ROOT}"/skills/finish-review/REVIEWER.md` completely, then review only the
-accepted target paths provided by the main agent.
+`"${CLAUDE_PLUGIN_ROOT}"/skills/finish-review/REVIEWER.md` completely. For a planning
+continuation, review only the sealed packet and reviewer instructions; do not
+use Read to inspect live worktree content. For a legacy non-planning
+supplemental review, use Read only for the accepted target paths supplied by
+the main agent.
 
 Do not delegate, edit files, run commands, invoke another workflow, or inspect
 failed reviewer diagnostics. Return only the JSON object required by the shared
diff --git a/plugin/identity.json b/plugin/identity.json
index f633ea750..9aeb3f53a 100644
--- a/plugin/identity.json
+++ b/plugin/identity.json
@@ -2,5 +2,5 @@
   "schema_version": 1,
   "plugin_version": "1.0.0",
   "hook_manifest_sha256": "566e99f2ec53278b400dae1e54085940594048f0423787cc6863f3f543422756",
-  "inventory_sha256": "66b18def8ce5efd230759d288a85023b000d7aa676ee855cab51b0c3037d7dfc"
+  "inventory_sha256": "cbf1fbd388e49c5ba2d2046782cd0b963c46282e2834c74af33d88f81132d985"
 }
diff --git a/plugin/inventory.json b/plugin/inventory.json
index 8716724f6..713abbeb3 100644
--- a/plugin/inventory.json
+++ b/plugin/inventory.json
@@ -11,7 +11,7 @@
     },
     {
       "path": "agents/safeword-reviewer.md",
-      "sha256": "3c12133f48ccb22d77b9b7353afaa84e1cc7b3b60a0c1d0b358a6e9720860bad"
+      "sha256": "ea350b16b94f91f09d94093c140c632edd2007b2af0da326fad9d007de0c8aef"
     },
     {
       "path": "hooks/hooks.json",
@@ -95,7 +95,7 @@
     },
     {
       "path": "resources/SAFEWORD.md",
-      "sha256": "8a0e3b614c5a21579b6a45245c2c418d57b2bf54c6a146cb7dffde9d80af1ba8"
+      "sha256": "1a0cc0336cfe85947c86589dcc149e0bcb1387b6ace23f7f6b9f79b2a36ac34d"
     },
     {
       "path": "resources/scripts/bisect-test-pollution.sh",
@@ -155,11 +155,11 @@
     },
     {
       "path": "runtime/cli.js",
-      "sha256": "5c78201584b376e3eef7e5d5058fdfb11f9c2cb70c67209e450a0c4c27bbf909"
+      "sha256": "ec4f05b7191c60d3ad72293324167270c1a6a5246de1f6299661a81c44ba59b1"
     },
     {
       "path": "runtime/dispatch.js",
-      "sha256": "206a7059631b1024d6bbe721565e036b6523171761099c383521efea19ba931e"
+      "sha256": "d495947f63e0d2b4daecd22d6c0877c12e2cd320a8f6a4f7580ce138c064df24"
     },
     {
       "path": "runtime/event-groups.json",
@@ -407,11 +407,11 @@
     },
     {
       "path": "runtime/hooks/lib/review-ledger.ts",
-      "sha256": "3766ca92b78cb7ad2e9b4b99426ab545882dc2231677dcbfddc7cd5655501de8"
+      "sha256": "58e4bd7ebf6d9a3f80427b4525c2da1502563cf1061fd6cc23a0c7a16e26d3de"
     },
     {
       "path": "runtime/hooks/lib/review-receipt.ts",
-      "sha256": "d9132d0eefd660a6673ef11960766bbc27b013a285f3117aef6d4df886da319d"
+      "sha256": "4b6d872e81ad2794bf25d134ad5af29eeaec51b663a5f0c4a9a22eceb0e3f8da"
     },
     {
       "path": "runtime/hooks/lib/review-trigger.ts",
@@ -611,7 +611,7 @@
     },
     {
       "path": "runtime/hooks/stop-quality.ts",
-      "sha256": "5bdb79ce3d66b6a4eb384942d5115f2041fa9aa501f0d18af5aeaf35446742c3"
+      "sha256": "61fbb203b32580d2301e003e7476ee3b4ccca95a122397fc262e08e9b78d0284"
     },
     {
       "path": "runtime/hooks/stop-reentry.ts",
@@ -631,7 +631,7 @@
     },
     {
       "path": "runtime/hooks/write-review-stamp.ts",
-      "sha256": "fa1f2c69dc727365a8b82c6cad30253d33d336cc3047bc59f661d157da755cef"
+      "sha256": "38f47423d4a7e5db3be0df7e7dd7e5d15bfaf5ca4b4185930eaf345fda8cf567"
     },
     {
       "path": "skills/audit/SKILL.md",
@@ -647,11 +647,11 @@
     },
     {
       "path": "skills/bdd/PLAN_EXECUTION.md",
-      "sha256": "5118b9a31a9dc63a08e051d234f98fcf2d4ef7bd987d73a3246c5e74b9b91b37"
+      "sha256": "277a6029ec4017089facf0698a436fb2c642d7205316a0e716303acc661b1cd3"
     },
     {
       "path": "skills/bdd/PLAN_IMPLEMENTATION.md",
-      "sha256": "5cfa76ab6f3798449f2f667b7c4d71642f343cb03942c0e2ff39091232c44646"
+      "sha256": "71bc151079386336167dde29c3e14bd18d71920ca8056678eabe741f290c27e9"
     },
     {
       "path": "skills/bdd/SCENARIOS.md",
@@ -659,7 +659,7 @@
     },
     {
       "path": "skills/bdd/SKILL.md",
-      "sha256": "3770f019f5a83fd4ad6dcb2322528595a39545f61cf1106a2f606a8137036d9d"
+      "sha256": "898e21405b0735f13087e3c986df79b2a6428309536cb43d77f5c57777f1bd90"
     },
     {
       "path": "skills/bdd/SPLITTING.md",
@@ -667,7 +667,7 @@
     },
     {
       "path": "skills/bdd/TDD.md",
-      "sha256": "33bdf8746a08bb5b69b2625fa49a82bb2d5c9cb4901dab84780f0d6d8b803e5d"
+      "sha256": "3d00929134606e25f1051d8ab1dee37c628ae5506ad06292a3b88dff0756cd13"
     },
     {
       "path": "skills/bdd/VERIFY.md",
@@ -707,11 +707,11 @@
     },
     {
       "path": "skills/finish-review/REVIEWER.md",
-      "sha256": "7575d91eb96a1c4930c8e68da1f4bb982d052c5e89f75fb38ed6422a8df96562"
+      "sha256": "9cddbcc9233c8eb60b1a13c4f957edbc314969fde941f0e1e77e03c2555855b7"
     },
     {
       "path": "skills/finish-review/SKILL.md",
-      "sha256": "84a9d06619bda24dee6fc2e7879ec76de8bcbcaafda28e365562b3fc6bd5f281"
+      "sha256": "4554176ee2093c9bffe871c566a20b5b84c6ff95e64ce81519f82ab326d7e91b"
     },
     {
       "path": "skills/lint/SKILL.md",
@@ -723,7 +723,7 @@
     },
     {
       "path": "skills/quality-review/SKILL.md",
-      "sha256": "19557310027a2dbc0ff859378ffa3848df9843768a74f3246c30f89c5b47a5a9"
+      "sha256": "7109fb8eb3a4558d94bd24cce500bed41d7107dda0f9e78a76702de6a75afbdb"
     },
     {
       "path": "skills/refactor/SKILL.md",
@@ -739,7 +739,7 @@
     },
     {
       "path": "skills/review-spec/SKILL.md",
-      "sha256": "800fabc037ec4734e5ae206898f556f8f3b030d09da2c381f7741c89f81209ea"
+      "sha256": "b6a776f0ab4a7e83f4c362a76816bcee1dde67670457429a375f8c669b844aad"
     },
     {
       "path": "skills/self-review/SKILL.md",
@@ -779,7 +779,7 @@
     },
     {
       "path": "templates/agents/safeword-reviewer.md",
-      "sha256": "13333228aa180c0ff040ccfe4e16058147fadc596b51df0d6d73caeb01755470"
+      "sha256": "54f2b47dec3639b711b7c2557b017c452b4667aa7092296a01328c7b5668efaf"
     },
     {
       "path": "templates/child-spec-template.md",
@@ -1371,11 +1371,11 @@
     },
     {
       "path": "templates/hooks/lib/review-ledger.ts",
-      "sha256": "3766ca92b78cb7ad2e9b4b99426ab545882dc2231677dcbfddc7cd5655501de8"
+      "sha256": "58e4bd7ebf6d9a3f80427b4525c2da1502563cf1061fd6cc23a0c7a16e26d3de"
     },
     {
       "path": "templates/hooks/lib/review-receipt.ts",
-      "sha256": "d9132d0eefd660a6673ef11960766bbc27b013a285f3117aef6d4df886da319d"
+      "sha256": "4b6d872e81ad2794bf25d134ad5af29eeaec51b663a5f0c4a9a22eceb0e3f8da"
     },
     {
       "path": "templates/hooks/lib/review-trigger.ts",
@@ -1575,7 +1575,7 @@
     },
     {
       "path": "templates/hooks/stop-quality.ts",
-      "sha256": "1858b5639255295d82e17ca841df994e6a3ce876d93b3744cb515a42baae9bc6"
+      "sha256": "72cdede9a591ff0ae66b2b129af190b51f6629837962374ae2bed82aa8293c97"
     },
     {
       "path": "templates/hooks/stop-reentry.ts",
@@ -1595,7 +1595,7 @@
     },
     {
       "path": "templates/hooks/write-review-stamp.ts",
-      "sha256": "fa1f2c69dc727365a8b82c6cad30253d33d336cc3047bc59f661d157da755cef"
+      "sha256": "38f47423d4a7e5db3be0df7e7dd7e5d15bfaf5ca4b4185930eaf345fda8cf567"
     },
     {
       "path": "templates/personas-template.md",
@@ -1611,7 +1611,7 @@
     },
     {
       "path": "templates/SAFEWORD.md",
-      "sha256": "44fa498fd42413551bf4e43808d5b047ea61c8ceade40f30844a5c4c44e91025"
+      "sha256": "571e9754fe2359626a3ec1ec4a081efcf1e0a66d46eba853a2305f514b86a35f"
     },
     {
       "path": "templates/scripts/bisect-test-pollution.sh",
@@ -1643,11 +1643,11 @@
     },
     {
       "path": "templates/skills/bdd/PLAN_EXECUTION.md",
-      "sha256": "9de74f10759b2bb104e7e27e626e7f7bae97509f9503bc2bfe3b26c755e9d527"
+      "sha256": "6f031383103dfe880a9c4cd5f14b8e7cf95989bafd579a9ae8450bb1d8216b53"
     },
     {
       "path": "templates/skills/bdd/PLAN_IMPLEMENTATION.md",
-      "sha256": "4a5093d7034459c06fe23b4f2960e7244561292becef19eb52ac2908d2c4bce0"
+      "sha256": "32067faf4e8f95926142aea815b5ce7b04e66a1cd0df9f64ae3436df4ad940ba"
     },
     {
       "path": "templates/skills/bdd/SCENARIOS.md",
@@ -1655,7 +1655,7 @@
     },
     {
       "path": "templates/skills/bdd/SKILL.md",
-      "sha256": "3770f019f5a83fd4ad6dcb2322528595a39545f61cf1106a2f606a8137036d9d"
+      "sha256": "898e21405b0735f13087e3c986df79b2a6428309536cb43d77f5c57777f1bd90"
     },
     {
       "path": "templates/skills/bdd/SPLITTING.md",
@@ -1663,7 +1663,7 @@
     },
     {
       "path": "templates/skills/bdd/TDD.md",
-      "sha256": "6c9142c4a7cc63fb6054d2b5335f942a77a1322f3a7e269b6e8654f4d7435702"
+      "sha256": "5cbbca305b337c2fdf18310e4fccb20979dbc731d873b4f4cec0b036bed816b1"
     },
     {
       "path": "templates/skills/bdd/VERIFY.md",
@@ -1703,11 +1703,11 @@
     },
     {
       "path": "templates/skills/finish-review/REVIEWER.md",
-      "sha256": "7575d91eb96a1c4930c8e68da1f4bb982d052c5e89f75fb38ed6422a8df96562"
+      "sha256": "9cddbcc9233c8eb60b1a13c4f957edbc314969fde941f0e1e77e03c2555855b7"
     },
     {
       "path": "templates/skills/finish-review/SKILL.md",
-      "sha256": "fdb8800d140467f1747f7b0ee067137386026003126ff17c00758940766dd07a"
+      "sha256": "7d907162daa0e6f51111ac8173d02a2b21e632532a3d736ccc02a91fb6973fb9"
     },
     {
       "path": "templates/skills/lint/SKILL.md",
@@ -1719,7 +1719,7 @@
     },
     {
       "path": "templates/skills/quality-review/SKILL.md",
-      "sha256": "61f9053cdd8007f2ebfd17684fb18cf8dfd068fbcdfbc85ad7ff7ec565a81461"
+      "sha256": "ef63c3ca21b2c383c46d143fec48d229b4e17675015a77e858638dbefbdcfbac"
     },
     {
       "path": "templates/skills/refactor/SKILL.md",
@@ -1735,7 +1735,7 @@
     },
     {
       "path": "templates/skills/review-spec/SKILL.md",
-      "sha256": "bca4e90c57cd4868219ebe9366fbca8c126837f1289671a3e7b495bca894b052"
+      "sha256": "2d39641656e0d91d8c6788fba4fdf1981b77ef53852715c58b5df75fcc56762d"
     },
     {
       "path": "templates/skills/self-review/SKILL.md",
diff --git a/plugin/resources/SAFEWORD.md b/plugin/resources/SAFEWORD.md
index f59fb66b1..6614c47be 100644
--- a/plugin/resources/SAFEWORD.md
+++ b/plugin/resources/SAFEWORD.md
@@ -10,6 +10,12 @@ Project knowledge (tickets, learnings, principles, personas, glossary, surfaces)
 
 A safeword session runs through these phases in order. Each phase has an exit criterion — meet it before advancing.
 
+Safeword planning review and approval are enforced on local Claude Code, local
+Codex, local Cursor, OpenCode CLI and TUI, Claude Code Cloud, and Cursor Cloud
+Agents. Codex Cloud and OpenCode Desktop execution is advisory. Do not claim
+authoritative planning review or approval there; move authoritative planning to
+a supported gated surface.
+
 ### 1. Clarify (Propose-and-Converge)
 
 Understand what the user is asking before classifying or building. **Propose-and-Converge** means: lead with a perspective, then surface open questions _inside_ that proposal. Don't ask first — propose first.
diff --git a/plugin/runtime/dispatch.js b/plugin/runtime/dispatch.js
index 9aae70326..3900ff0fb 100644
--- a/plugin/runtime/dispatch.js
+++ b/plugin/runtime/dispatch.js
@@ -1759,7 +1759,7 @@ var CLAUDE_HISTORICAL_CATALOGUE = {
       '.claude/agents/safeword-retro-filer.md':
         '008fa4b5777834118ba0efd008862df52dd32d3feec2218537d7c90cbfdfd904',
       '.claude/agents/safeword-reviewer.md':
-        '13333228aa180c0ff040ccfe4e16058147fadc596b51df0d6d73caeb01755470',
+        '54f2b47dec3639b711b7c2557b017c452b4667aa7092296a01328c7b5668efaf',
       '.claude/skills/audit/SKILL.md':
         '02c6353beb320c6370788c7845ec193ec08532f05ed6f6174585aa8a68456470',
       '.claude/skills/bdd/DISCOVERY.md':
@@ -1767,17 +1767,17 @@ var CLAUDE_HISTORICAL_CATALOGUE = {
       '.claude/skills/bdd/DONE.md':
         'e9f22430341cf225eaf58ef6335720c5033cb8f6779425d5740adc0ff80a5f60',
       '.claude/skills/bdd/PLAN_EXECUTION.md':
-        '9de74f10759b2bb104e7e27e626e7f7bae97509f9503bc2bfe3b26c755e9d527',
+        '6f031383103dfe880a9c4cd5f14b8e7cf95989bafd579a9ae8450bb1d8216b53',
       '.claude/skills/bdd/PLAN_IMPLEMENTATION.md':
-        '4a5093d7034459c06fe23b4f2960e7244561292becef19eb52ac2908d2c4bce0',
+        '32067faf4e8f95926142aea815b5ce7b04e66a1cd0df9f64ae3436df4ad940ba',
       '.claude/skills/bdd/SCENARIOS.md':
         '1e89aa6a46895858cff252d642dd9f7b5853d0fd7dd314aaa75e2ee6046bcddb',
       '.claude/skills/bdd/SKILL.md':
-        '3770f019f5a83fd4ad6dcb2322528595a39545f61cf1106a2f606a8137036d9d',
+        '898e21405b0735f13087e3c986df79b2a6428309536cb43d77f5c57777f1bd90',
       '.claude/skills/bdd/SPLITTING.md':
         'e232a37a4d76f0dfc51e65965c1e1b7f1572e0dedce0fb8c031e75bd6544a708',
       '.claude/skills/bdd/TDD.md':
-        '6c9142c4a7cc63fb6054d2b5335f942a77a1322f3a7e269b6e8654f4d7435702',
+        '5cbbca305b337c2fdf18310e4fccb20979dbc731d873b4f4cec0b036bed816b1',
       '.claude/skills/bdd/VERIFY.md':
         '85abadfe756a3f391779fe500cd5c66597a33e0cab7fcef55f6b633b30818f31',
       '.claude/skills/brainstorm/SKILL.md':
@@ -1797,15 +1797,15 @@ var CLAUDE_HISTORICAL_CATALOGUE = {
       '.claude/skills/figure-it-out/SKILL.md':
         '18e2b44e9a91562079b3e1f52fcd9f952b5f57a0f0e7647b0273809848a75c0d',
       '.claude/skills/finish-review/REVIEWER.md':
-        '7575d91eb96a1c4930c8e68da1f4bb982d052c5e89f75fb38ed6422a8df96562',
+        '9cddbcc9233c8eb60b1a13c4f957edbc314969fde941f0e1e77e03c2555855b7',
       '.claude/skills/finish-review/SKILL.md':
-        'fdb8800d140467f1747f7b0ee067137386026003126ff17c00758940766dd07a',
+        '7d907162daa0e6f51111ac8173d02a2b21e632532a3d736ccc02a91fb6973fb9',
       '.claude/skills/lint/SKILL.md':
         'f8bc868fb10a06ca46a22236309b9f0c3ffbd70eecc024d3c79de8ef0e42fd14',
       '.claude/skills/pr-readiness/SKILL.md':
         '4cc987da39efb1b9b682aff67988c975e8ff56a2c3eed0cfe3a1f3e8caf0d80b',
       '.claude/skills/quality-review/SKILL.md':
-        '61f9053cdd8007f2ebfd17684fb18cf8dfd068fbcdfbc85ad7ff7ec565a81461',
+        'ef63c3ca21b2c383c46d143fec48d229b4e17675015a77e858638dbefbdcfbac',
       '.claude/skills/refactor/SKILL.md':
         'a51a858fb13b50cbc86789edbde8a39e364b5cdd7d5d3b025d555d90b221760e',
       '.claude/skills/retro-filer/SKILL.md':
@@ -1813,7 +1813,7 @@ var CLAUDE_HISTORICAL_CATALOGUE = {
       '.claude/skills/retro/SKILL.md':
         'da1244dd4e210480e3754763b982b1f9614c493b9534ea03151a9aafbdd89adb',
       '.claude/skills/review-spec/SKILL.md':
-        'bca4e90c57cd4868219ebe9366fbca8c126837f1289671a3e7b495bca894b052',
+        '2d39641656e0d91d8c6788fba4fdf1981b77ef53852715c58b5df75fcc56762d',
       '.claude/skills/self-review/SKILL.md':
         '7ecb6e4475627e703d09e67c377d70b83acc4e32fa8ad41b6dd34174381b46cc',
       '.claude/skills/spike/SKILL.md':
@@ -1885,7 +1885,7 @@ var CLAUDE_HISTORICAL_CATALOGUE = {
       '.safeword/hooks/session-version.ts':
         'c6160a3ea0ef65345c89b3c1dcf5a4177a408d94ab7efda82d86f9d455815c64',
       '.safeword/hooks/stop-quality.ts':
-        '1858b5639255295d82e17ca841df994e6a3ce876d93b3744cb515a42baae9bc6',
+        '72cdede9a591ff0ae66b2b129af190b51f6629837962374ae2bed82aa8293c97',
       '.safeword/hooks/stop-reentry.ts':
         'a84d34d0798c83177d6ccc733299e9632e8485b700ef92ec53f153d68a1cfba5',
       '.safeword/hooks/stop-retro-filing.ts':
diff --git a/plugin/runtime/hooks/lib/review-ledger.ts b/plugin/runtime/hooks/lib/review-ledger.ts
index 26fb7dd3c..f7efe79ce 100644
--- a/plugin/runtime/hooks/lib/review-ledger.ts
+++ b/plugin/runtime/hooks/lib/review-ledger.ts
@@ -22,11 +22,11 @@ export interface ReviewStamp {
   /** The reviewing model, recorded by the orchestrator that assigned it (ticket MR5M3A). Absent on pre-MR5M3A stamps. */
   model?: string;
   /** Author runtime recorded from the validated coordinator result. */
-  author?: 'claude' | 'codex' | 'opencode';
+  author?: 'claude' | 'codex' | 'cursor' | 'opencode';
   /** Actual reviewer runtime recorded from the validated coordinator result. */
-  reviewer?: 'claude' | 'codex' | 'opencode';
+  reviewer?: 'claude' | 'codex' | 'cursor' | 'opencode';
   /** Independence earned by the validated route. */
-  independence?: 'cross-agent' | 'degraded' | 'none';
+  independence?: 'cross-agent' | 'reduced' | 'degraded' | 'none';
   /**
    * The coordinator review this stamp cites (ticket PB1GMZ). Recorded so the
    * claim stays checkable after the fact: `review status <id>` still reports
@@ -55,7 +55,7 @@ export function reviewScope(ticketId: string, artifact: string, contentHash: str
 export type GateVerdict = { ok: true } | { ok: false; reason: string };
 
 /** Levels that assert a coordinator ran and returned a verdict. */
-const COORDINATOR_CLAIMS = new Set(['cross-agent', 'degraded']);
+const COORDINATOR_CLAIMS = new Set(['cross-agent', 'reduced', 'degraded']);
 
 /** A stamp satisfies a gate when it's a real review, or a skip with a non-empty reason. */
 function isSatisfyingStamp(stamp: ReviewStamp, policy: CrossAgentReviewPolicy = 'prefer'): boolean {
@@ -148,6 +148,22 @@ export function reviewGateForNextAsset(
   };
 }
 
+/** The opt-in architecture gate requires independent design review or a reasoned skip. */
+export function reviewGateForIndependentDesign(
+  scope: string,
+  stamps: readonly ReviewStamp[],
+): GateVerdict {
+  if (
+    stamps.some(
+      stamp =>
+        isSatisfyingSkipStamp(scope, stamp) ||
+        isSatisfyingCoordinatorReviewStamp(scope, stamp, 'require'),
+    )
+  )
+    return { ok: true };
+  return { ok: false, reason: `"${scope}" has no independent design review` };
+}
+
 /**
  * Phase-exit gate (TB2.AC1): advancing past a phase is allowed only when an
  * independent review stamp for that phase exists. Unlike the per-asset gate
@@ -177,7 +193,7 @@ export function gatePhaseAdvance(
 // fork review). The content-hash binding in <scope> at least defeats accidental
 // stale-after-edit passes, not deliberate spoofing.
 const REVIEW_LINE =
-  /(?:^|\s)review:(\S+)(?:\s+model:(\S+))?(?:\s+author:(claude|codex|opencode))?(?:\s+reviewer:(claude|codex|opencode))?(?:\s+independence:(cross-agent|degraded|none))?(?:\s+review-id:(\S+))?(?:\s+skip:(.+))?$/;
+  /(?:^|\s)review:(\S+)(?:\s+model:(\S+))?(?:\s+author:(claude|codex|cursor|opencode))?(?:\s+reviewer:(claude|codex|cursor|opencode))?(?:\s+independence:(cross-agent|reduced|degraded|none))?(?:\s+review-id:(\S+))?(?:\s+skip:(.+))?$/;
 
 /**
  * Tier 1 (the per-asset inline stamp) is OFF unless `.safeword/config.json` sets
diff --git a/plugin/runtime/hooks/lib/review-receipt.ts b/plugin/runtime/hooks/lib/review-receipt.ts
index 93766cb7e..4a8704881 100644
--- a/plugin/runtime/hooks/lib/review-receipt.ts
+++ b/plugin/runtime/hooks/lib/review-receipt.ts
@@ -87,7 +87,7 @@ export function reviewKindForPhase(phase: string): string {
 }
 
 /** Levels that assert a coordinator ran and returned a verdict. */
-const COORDINATOR_CLAIMS = new Set(['cross-agent', 'degraded']);
+const COORDINATOR_CLAIMS = new Set(['cross-agent', 'reduced', 'degraded']);
 
 /** Whether a stamp asserts a coordinator ran — the claims that need a witness. */
 export function claimsCoordinatorVerdict(independence?: string): boolean {
diff --git a/plugin/runtime/hooks/stop-quality.ts b/plugin/runtime/hooks/stop-quality.ts
index 87f7f46d6..db2911b39 100644
--- a/plugin/runtime/hooks/stop-quality.ts
+++ b/plugin/runtime/hooks/stop-quality.ts
@@ -30,7 +30,7 @@ import {
   modelsMatch,
   parseReviewStamps,
   readCrossAgentReviewPolicy,
-  reviewGateForNextAsset,
+  reviewGateForIndependentDesign,
   reviewScope,
 } from './lib/review-ledger.ts';
 import {
@@ -328,7 +328,7 @@ function checkArchitectureReviewGate(ticketInfo: TicketInfo): void {
   const stamps = existsSync(logPath)
     ? verifiedStamps(parseReviewStamps(readFileSync(logPath, 'utf8')), projectDir, scope)
     : [];
-  if (!reviewGateForNextAsset(scope, stamps, readCrossAgentReviewPolicy(rawConfig)).ok) {
+  if (!reviewGateForIndependentDesign(scope, stamps).ok) {
     hardBlockDone(
       'Architecture review gate: the impl-plan design has no independent design review at its current content. Run `safeword review run plan-implementation ...`, then record its author_agent, actual_reviewer, and independence with `bun "\${CLAUDE_PLUGIN_ROOT}"/runtime/hooks/write-review-stamp.ts impl-plan`; add a model only when independently verified.',
     );
diff --git a/plugin/runtime/hooks/write-review-stamp.ts b/plugin/runtime/hooks/write-review-stamp.ts
index 79dd9f4a5..6387f5e66 100644
--- a/plugin/runtime/hooks/write-review-stamp.ts
+++ b/plugin/runtime/hooks/write-review-stamp.ts
@@ -37,7 +37,11 @@ import {
 import { readSessionState } from './lib/quality-state.ts';
 import { formatReviewStamp, hashArtifact, reviewScope } from './lib/review-ledger.ts';
 import { readReviewReceipt } from './lib/read-receipt.ts';
-import { receiptGateVerdict, type StampClaim } from './lib/review-receipt.ts';
+import {
+  claimsCoordinatorVerdict,
+  receiptGateVerdict,
+  type StampClaim,
+} from './lib/review-receipt.ts';
 import { reviewClaimContext } from './lib/verify-stamp-claims.ts';
 import { resolveNamespaceRoot, resolveWorkingProjectDirectory } from './lib/namespace-root.ts';
 import { resolveRunIdentity, type RunIdentity } from './lib/run-identity.ts';
@@ -62,9 +66,9 @@ const HELP = `Usage:
 Options:
   --ticket <folder>         Select the ticket folder to stamp
   --model <id>              Record the verified reviewer model
-  --author-agent <agent>    Record claude, codex, or opencode as author
-  --reviewer-agent <agent>  Record claude, codex, or opencode as reviewer
-  --independence <level>    Record cross-agent, degraded, or none
+  --author-agent <agent>    Record claude, codex, cursor, or opencode as author
+  --reviewer-agent <agent>  Record claude, codex, cursor, or opencode as reviewer
+  --independence <level>    Record cross-agent, reduced, degraded, or none
   --review-id <id>          Verify and record a coordinator review receipt
   --skip <reason>           Record a deliberate skip instead of a review
   -h, --help                Show this help message
@@ -121,9 +125,9 @@ interface ParsedArguments {
   positional: string[];
   explicitTicket: string | undefined;
   reviewerModel: string | undefined;
-  authorAgent: 'claude' | 'codex' | 'opencode' | undefined;
-  reviewerAgent: 'claude' | 'codex' | 'opencode' | undefined;
-  independence: 'cross-agent' | 'degraded' | 'none' | undefined;
+  authorAgent: 'claude' | 'codex' | 'cursor' | 'opencode' | undefined;
+  reviewerAgent: 'claude' | 'codex' | 'cursor' | 'opencode' | undefined;
+  independence: 'cross-agent' | 'reduced' | 'degraded' | 'none' | undefined;
   reviewId: string | undefined;
   skipReason: string | undefined;
 }
@@ -153,9 +157,9 @@ function parseArguments(argv: string[]): ParsedArguments {
   const positional: string[] = [];
   let explicitTicket: string | undefined;
   let reviewerModel: string | undefined;
-  let authorAgent: 'claude' | 'codex' | 'opencode' | undefined;
-  let reviewerAgent: 'claude' | 'codex' | 'opencode' | undefined;
-  let independence: 'cross-agent' | 'degraded' | 'none' | undefined;
+  let authorAgent: 'claude' | 'codex' | 'cursor' | 'opencode' | undefined;
+  let reviewerAgent: 'claude' | 'codex' | 'cursor' | 'opencode' | undefined;
+  let independence: 'cross-agent' | 'reduced' | 'degraded' | 'none' | undefined;
   let reviewId: string | undefined;
   let skipReason: string | undefined;
   const seen = new Set<string>();
@@ -193,17 +197,17 @@ function parseArguments(argv: string[]): ParsedArguments {
       if (/\s/.test(value)) fail('--model id must not contain whitespace');
       reviewerModel = value;
     } else if (flag === '--independence') {
-      if (!['cross-agent', 'degraded', 'none'].includes(value)) {
-        fail('--independence must be cross-agent, degraded, or none');
+      if (!['cross-agent', 'reduced', 'degraded', 'none'].includes(value)) {
+        fail('--independence must be cross-agent, reduced, degraded, or none');
       }
-      independence = value as 'cross-agent' | 'degraded' | 'none';
+      independence = value as 'cross-agent' | 'reduced' | 'degraded' | 'none';
     } else if (flag === '--review-id') {
       if (!REVIEW_ID.test(value))
         fail('--review-id must be the review_id the coordinator returned');
       reviewId = value;
     } else {
-      if (value !== 'claude' && value !== 'codex' && value !== 'opencode') {
-        fail(`${flag} must be claude, codex, or opencode`);
+      if (value !== 'claude' && value !== 'codex' && value !== 'cursor' && value !== 'opencode') {
+        fail(`${flag} must be claude, codex, cursor, or opencode`);
       }
       if (flag === '--author-agent') authorAgent = value;
       else reviewerAgent = value;
@@ -248,7 +252,18 @@ const runIdentity =
   environmentIdentity.runtime === 'claude' && environmentIdentity.sessionKey !== null
     ? environmentIdentity
     : (readBridgedRunIdentity() ?? environmentIdentity);
-const sessionId = runIdentity.sessionKey ?? fail('missing run identity for review stamp');
+// OpenCode's profile hook receives the session id, but its shell tool does not
+// pass that id to this command. A verified coordinator receipt supplies a
+// narrower identity for this one stamp; receiptGateVerdict below must still
+// authenticate it before anything is written.
+const sessionId =
+  runIdentity.sessionKey ??
+  (runIdentity.runtime === 'opencode' &&
+  reviewId !== undefined &&
+  skipReason === undefined &&
+  claimsCoordinatorVerdict(independence)
+    ? `opencode-review-${reviewId}`
+    : fail('missing run identity for review stamp'));
 
 function formatTicketList(folders: string[]): string {
   const shown = folders.slice(0, 12).join(', ');
