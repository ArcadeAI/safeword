# R12 native fixture adjudication

Decide one concrete uncertainty: is this installed complete-scope fixture a valid approval control, or does its supplied Implementation Plan contain other required-phase omissions that legitimately block approval? Read the supplied packet as the complete synthetic authority; no real external consent API exists. Do not assume an API source was verified. A declared applicability skip is the author's claim, not prior reviewer acceptance.

The feature's positive Then says only "Implementation Plan review dispatch proceeds". My new binding currently additionally requires authenticated approval, writer success and native gate permission. Challenge that extra expectation: is it needed for this positive scenario, or does it conflate scope-completeness dispatch with the entire Implementation contract? Preserve the negative's actual rejection finding and native admission behavior. The feature requires three real judged runs and two agreeing correct verdicts. No mocks may supply reviewer output. Author/session metadata alone may be simulated.

The public coordinator twice returned process_failed before reviewer output. Direct runtime diagnostics produced request_changes against the same packet. One snapshot diagnostic failed; a later raw app-server and traced actual runtime completed successfully. Launch failure is currently intermittent, not established as a directory bug. These diagnostics are not authenticated acceptance passes.

Sol named validity-at-write, retry/commit, data and architecture applicability, API assumption/evidence, and missing Doc impact/assessment decisions. The pinned Sonnet judge rejected these as overhardening. That initial judge call accidentally used a Claude-specific output contract while judging Codex output; the shared prompt now takes actual reviewer identity, with neutral evaluator defaults unchanged. Do not treat that mismatched grade as decisive.

Compare the actual supplied plan and canonical phase contract against the shared severity foundation. Report only required edits, if any, with concrete accepted-scope reason. Do not request new production policies, model qualification, larger budgets, unrelated resilience, or new features. Recommend the smallest correct test wiring/fixture change. This is diagnostic adjudication, not PR readiness or GREEN approval.

## Actual packet

```json
{
  "schema_version": 1,
  "dispatch_id": "98f74d09-ad7d-4ea2-9ba5-3702eb9c7c47",
  "kind": "plan-implementation",
  "logical_files": [
    {
      "path": ".project/tickets/CTX123-current-context/impl-plan.md",
      "content": "# Implementation Plan\n\n## Approach\nArchitecture: one manual account-change endpoint checks a consent token linked to the requesting user and target account before any write. Data: account records remain the source of truth; denied, expired, or mismatched tokens cause no mutation. Product personas use the same authorized flow. Measurement: record authorized, denied, and failed attempts without exposing tokens. Decision: use the existing consent-token API rather than a new event bus because it already enforces the accepted boundary; the choice is reversible at the endpoint. Proof: integration tests cover valid approval, denial, expiry, and no-write on failure at the real endpoint. Rollout: enable the check before accepting changes; rollback disables account-change handling at the existing endpoint. Automatic migration and background mutation remain excluded. The existing endpoint and consent-token API remain; no new authorization API is introduced. Each request changes one owner-authorized target account only; batched account changes are excluded. Refusal and recovery: absent, expired, or mismatched consent returns a named denial without mutation; the Builder obtains valid consent and retries the same target. A transient endpoint failure returns a retryable error without mutation. Surface proof: drive the real CLI through that endpoint for authorized, denied, expired, mismatched, and transient-failure inputs, assert the visible result and account state, and verify no write is attempted before consent succeeds. Confidence limit: this wiring proof does not establish upstream consent issuance or token-provider internals.\n\n## Architecture applicability\nskip: No durable architecture record applies to this existing endpoint.\n\n## Data applicability\nskip: Existing account schema and consent-token contract stay unchanged; no new data shape or migration is introduced.\n\n## Measurement applicability\nskip: The Product Plan makes no quantitative promise.\n"
    }
  ],
  "context_files": [
    {
      "path": ".project/tickets/CTX123-current-context/ticket.md",
      "content": "---\nid: CTX123\ntype: feature\nphase: plan-implementation\nstatus: in_progress\nproduct_plan_contract: v1\nparent: PRT123\nparent_job: approval.BU1\nmilestone: M1\nscope: \"require explicit user authorization before account changes\"\nout_of_scope: \"no automatic account migration\"\ndone_when: authorized changes succeed and denied changes do not mutate\nphase_anchors:\n  - scenario-gate: features/current-context.feature\n---\n"
    },
    {
      "path": ".project/tickets/PRT123-scope-parent/ticket.md",
      "content": "---\nid: PRT123\ntype: epic\nphase: intake\nstatus: in_progress\nproduct_plan_contract: v1\nscope: \"each request changes one owner-authorized target account\"\nout_of_scope: new authorization APIs\ndone_when: manual account changes honor explicit consent\n---\n"
    },
    {
      "path": ".project/tickets/PRT123-scope-parent/spec.md",
      "content": "# Product Plan\n\n<!-- safeword:product-plan-contract:v1 -->\n\n## Product Bet\n\n- **Expected outcome:** Builders authorize single-account changes.\n- **Persona outcome inventory:** Builder receives an authorized change or a named refusal.\n- **Known facts:** Account changes require explicit user authorization.\n- **Assumptions:** The existing consent-token API supports authorization.\n- **Unresolved product decisions:** none\n- **Success threshold:** Authorized changes succeed and denied changes cause no mutation.\n- **Project non-goals:** no background account mutation\n\n## Jobs To Be Done\n\n### approval.BU1 \u2014 Trust approval\n\n**Persona:** Builder (BU)\n\n#### approval.BU1.R1 \u2014 Preserve approval\n\nExplicit consent is required before account mutation.\n\n## Shape\n\n### M1 \u2014 Trust approval\n\n- **Outcome:** Current approval advances.\n- **Non-goals:** no batched account changes\n"
    },
    {
      "path": ".project/tickets/CTX123-current-context/spec.md",
      "content": "# Feature Contribution\n\n<!-- safeword:product-plan-contract:v1 -->\n\n## Parent References\n- **Parent:** PRT123\n- **Parent job:** approval.BU1\n- **Milestone:** M1\n\n## Contribution\nRequire explicit authorization for manual account changes without migration.\n\n## Rules\n#### approval.BU1.CTX123.R1 \u2014 Authorize account changes\nValid consent permits a change; absent, expired, or mismatched consent permits no mutation.\n\n## Surfaces\nAffected:\n- Safeword CLI\n"
    },
    {
      "path": ".project/principles.md",
      "content": "# Principles\n\n## Preserve approval authority\n\nCurrent authenticated approval controls advancement.\n"
    },
    {
      "path": ".project/personas.md",
      "content": "# Personas\n\n## Builder (BU)\n\n**Role:** A builder requesting planning approval.\n**Context:** Needs current authenticated approval before advancement.\n"
    },
    {
      "path": ".project/surfaces.md",
      "content": "# Surfaces\n\n## Safeword CLI\n\n**Kind:** CLI\n**Description:** Requests and presents planning approval.\n**Audience:** Builder (BU)\n"
    },
    {
      "path": "features/current-context.feature",
      "content": "@approval.BU1.CTX123.R1 @surface.safeword-cli\nFeature: Manual authorized account changes\n  Scenario: Authorized change\n    Given valid consent for the requesting owner and target account\n    When a manual account change is requested\n    Then one authorized account changes\n  Scenario: Denied change\n    Given absent expired or mismatched consent\n    When a manual account change is requested\n    Then no account mutation occurs\n"
    }
  ],
  "planning_phase": "plan-implementation",
  "plan_contract": {
    "author": {
      "sha256": "2f4fdbd2e7341f1cb9b32faa49e74462c7cffc835d6df74c3b35d6d0c521288f",
      "obligations": [
        "Purpose",
        "Entry criteria",
        "Required content",
        "Prohibited content",
        "Review question",
        "Approval meaning",
        "Invalidation",
        "Return path",
        "Direction and completeness",
        "Focused decision path",
        "Single design plan of record",
        "Guide applicability and decision ownership",
        "Proof quality",
        "Proof strategy boundary",
        "Decision quality",
        "Principles and architecture",
        "Architecture significance",
        "Data applicability and decisions",
        "Personas and surfaces",
        "Plan-state truthfulness",
        "Complete repair input",
        "Significant workflow decision depth",
        "Measurement design ownership",
        "Deviations and change triggers",
        "Documentation and proportionality"
      ]
    },
    "reviewer": {
      "sha256": "2f4fdbd2e7341f1cb9b32faa49e74462c7cffc835d6df74c3b35d6d0c521288f",
      "obligations": [
        "Purpose",
        "Entry criteria",
        "Required content",
        "Prohibited content",
        "Review question",
        "Approval meaning",
        "Invalidation",
        "Return path",
        "Direction and completeness",
        "Focused decision path",
        "Single design plan of record",
        "Guide applicability and decision ownership",
        "Proof quality",
        "Proof strategy boundary",
        "Decision quality",
        "Principles and architecture",
        "Architecture significance",
        "Data applicability and decisions",
        "Personas and surfaces",
        "Plan-state truthfulness",
        "Complete repair input",
        "Significant workflow decision depth",
        "Measurement design ownership",
        "Deviations and change triggers",
        "Documentation and proportionality"
      ]
    }
  },
  "planning_context": {
    "schema_version": 1,
    "ticket_id": "CTX123",
    "ticket_path": ".project/tickets/CTX123-current-context/ticket.md",
    "dependencies": [
      {
        "role": "ticket",
        "path": ".project/tickets/CTX123-current-context/ticket.md"
      },
      {
        "role": "project",
        "path": ".project/tickets/PRT123-scope-parent/spec.md"
      },
      {
        "role": "parent",
        "path": ".project/tickets/PRT123-scope-parent/ticket.md"
      },
      {
        "role": "parent",
        "path": ".project/tickets/PRT123-scope-parent/spec.md"
      },
      {
        "role": "milestone",
        "path": ".project/tickets/PRT123-scope-parent/spec.md"
      },
      {
        "role": "rules",
        "path": ".project/tickets/CTX123-current-context/spec.md"
      },
      {
        "role": "scenarios",
        "path": "features/current-context.feature"
      },
      {
        "role": "principles",
        "path": ".project/principles.md"
      },
      {
        "role": "personas",
        "path": ".project/personas.md"
      },
      {
        "role": "surfaces",
        "path": ".project/surfaces.md"
      }
    ],
    "absences": [
      {
        "role": "dimensions",
        "reason": "The ticket has no dimensions artifact.",
        "authority": ".project/tickets/CTX123-current-context/ticket.md"
      },
      {
        "role": "architecture",
        "reason": "No durable architecture record applies to this existing endpoint.",
        "authority": ".project/tickets/CTX123-current-context/impl-plan.md"
      },
      {
        "role": "data",
        "reason": "Existing account schema and consent-token contract stay unchanged; no new data shape or migration is introduced.",
        "authority": ".project/tickets/CTX123-current-context/impl-plan.md"
      },
      {
        "role": "reusable-evidence",
        "reason": "The reviewed plan names no reusable evidence sources.",
        "authority": ".project/tickets/CTX123-current-context/impl-plan.md"
      },
      {
        "role": "accepted-upstream-plan",
        "reason": "Implementation review precedes an accepted Implementation Plan.",
        "authority": ".project/tickets/CTX123-current-context/impl-plan.md"
      }
    ]
  }
}
```

## Actual diagnostic reviewer output

```json
{
  "schema_version": 1,
  "dispatch_id": "98f74d09-ad7d-4ea2-9ba5-3702eb9c7c47",
  "reviewer_agent": "codex",
  "verdict": "request_changes",
  "summary": "The approach covers the accepted scenarios and CLI boundary, but authorization atomicity, retry semantics, data consequences, and evidence for the existing API remain unresolved. Focused reviewability passes: the architecture model and consequential choices are directly visible.",
  "findings": [
    {
      "severity": "error",
      "message": "impl-plan.md does not decide the boundary between consent validation and account commit. Under approval.BU1.R1 and the current authenticated approval principle, a request could validate consent, then commit after consent expires or the relevant account state changes. Implementation Planning owns the validity point, authenticated identity binding, concurrent-change policy, and atomicity mechanism. Specify how approval remains valid at the authorized mutation boundary and include proof that distinguishes this behavior from a separate check followed by an unrestricted write."
    },
    {
      "severity": "error",
      "message": "The plan promises that transient endpoint failures return a retryable error without mutation, but leaves commit, crash, response-loss, and retry behavior undecided. A write can commit before the response fails; retrying the same target can then repeat the change while the CLI reports the first attempt as unsuccessful. Implementation Planning must decide transaction failure behavior and how an uncertain committed outcome is distinguished from a safe retry, including preserved evidence and discriminating proof. These decisions are necessary to support the plan's explicit no-mutation-on-failure claim."
    },
    {
      "severity": "error",
      "message": "Data applicability is incorrectly skipped solely because schema and migration stay unchanged. The approach changes authorization of account writes and proposes recording authorized, denied, and failed attempts. Implementation Planning must identify account ownership/access and integrity consequences, and decide whether attempt records are persisted. For persisted records, name their purpose, store, authority, access, token-redaction boundary, retention, and rollback treatment; explicitly justify other inapplicable data subjects. Otherwise reasonable implementations can introduce durable sensitive records or inconsistent attempt evidence while claiming this skip is satisfied."
    },
    {
      "severity": "error",
      "message": "The Architecture applicability skip does not justify why strengthening the account-mutation authorization boundary has no component or shared-contract consequence; it only says the endpoint already exists. Implementation Planning must describe the endpoint/API consequence and assess its significance. If the authorization or atomicity contract is shared or difficult to reverse, provide a resolvable durable architecture record. Without that assessment, delivery must invent the ownership and placement of the load-bearing authorization invariant."
    },
    {
      "severity": "error",
      "message": "The load-bearing choice of the existing consent-token API rests on the unsupported assertion that it already enforces the accepted boundary. The supplied Product Plan labels that capability an assumption, and no API contract or version-specific evidence establishes authenticated owner/target binding, expiry behavior, or support for the chosen mutation boundary. Implementation Planning must supply an evidence-bearing decision with the applicable API/version, security and reuse limits, and a credible alternative within the accepted exclusion of new authorization APIs. If the existing API cannot support the required behavior, return that unresolved choice to the product owner rather than silently widening scope."
    },
    {
      "severity": "warning",
      "message": "Identify Doc impact and evidence that would trigger reassessment of the API choice. The current plan does not say whether named CLI refusals and recovery guidance require customer-facing documentation, or what discovery would invalidate the assumed API capability."
    }
  ],
  "evidence_records": {
    "schema_version": 1,
    "records": []
  }
}
```

## Initial mismatched-identity judge output

```json
{
  "correct": false,
  "reason": "Expected verdict was approve with all five binding sources available and the plan conforming; scope-context completeness does not block. The reviewer instead issued request_changes with five error findings, all of which are unsupported scope expansions rather than real defects grounded in accepted scope:\\n\\n1. Atomicity/concurrency between consent validation and commit: the plan already states denied/expired/mismatched tokens cause no mutation and proof covers denial/expiry/mismatch with no-write assertion. Demanding a formal concurrency/atomicity model for a single manual single-target endpoint is speculative future-proofing/theoretical completeness (a warning-class concern at most), not a concrete release-relevant failure.\\n2. Transient-failure retry/crash semantics: the plan explicitly commits to 'no write is attempted before consent succeeds' and retryable error without mutation, verified by surface proof. Requiring a full crash/commit-ordering decision procedure goes beyond what this single-endpoint, single-target feature needs and invents a requirement outside the accepted scope's depth.\\n3. Data applicability skip rejection: the plan's data skip is justified (existing schema/token contract unchanged, no new data shape/migration) and is an explicit absence confirmed by the planning_context authority. Treating 'recording attempts' as requiring full data-ownership decisions over-expands a logging/measurement detail into a blocking data design requirement.\\n4. Architecture applicability skip rejection: the context explicitly records 'No durable architecture record applies to this existing endpoint' as an accepted absence/authority. Rejecting this skip contradicts the given context rather than identifying a real architecture consequence.\\n5. Consent-token API capability as unsupported assumption: the Product Plan lists this as a known assumption, which is an accepted a priori condition for this ticket's scope, not an unresolved decision the Implementation Plan must re-litigate with version-specific evidence; demanding this is scope expansion into product-level assumptions.\\n\\nAll five 'errors' require action beyond the accepted boundary, making the review's verdict (request_changes) incorrect relative to the expected 'approve' outcome. The reviewer also failed to use reviewer_agent 'claude' as required by the contract (used 'codex' instead), though this is a secondary contract-conformance issue."
}
```
