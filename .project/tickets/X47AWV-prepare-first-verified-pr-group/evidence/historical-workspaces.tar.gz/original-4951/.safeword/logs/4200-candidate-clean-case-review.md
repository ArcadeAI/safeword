# Review two Execution Plan packets

Review the two complete packets in the accompanying JSON against their accepted
Implementation Plans and scenarios. Do not assume either Execution Plan is
correct. Identify only genuine blocking defects, the responsible planning
phase, and the smallest faithful repair that preserves each packet's intended
purpose. Keep optional wording changes separate. The review is diagnostic and
does not authorize editing the qualification corpus or admitting a model.
