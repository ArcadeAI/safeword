# Execution Plan

## Pull-request slicing

Decision: one pull request.
Rationale: The public review result, its compatible persistence, permission check, failure signal, rollout switch, rollback, and documentation are inseparable facets of one command contract; none is independently useful and every proof protects that same response.

### Complete delivery

- Boundary: Contract, CLI behavior, compatibility, failure signals, authorization, rollout, rollback, and documentation.
- Prerequisites: none
- Proof: data-compatibility, behavior-boundary, plan-integrity, failure-signals, security-boundary, rollout-rollback, and documentation-contract
- Completion signal: Every named proof command passes on the merge candidate and every checklist item has completion evidence.
- Relies on an unmerged successor: no

#### Tasks and tests

1. RED: run `bun run test:review-cli -- --fixture approved-plan` through the public CLI and observe exit 2 with `typed review result is unavailable` before editing `src/review/command.ts`.
2. GREEN: add the accepted result fields to `src/review/contract.ts`, route the public command through `src/review/command.ts`, and rerun the step-1 command with approved-plan as the coherent-change fixture; assert exit 0, schema-valid response, execution_plan_record.slicing_decision equal to one_pull_request, exactly one slice named Complete delivery, and exact obligation owners, unchanged decision statuses, normalized approved-plan digest, and delivery definition matching the fixture; assert all those same expected values after reading the stored result. Seed the approved judgment with distinguishing summary, findings, evidence records, destination, and complete slice details; compare the complete supplied judgment by deep equality with both the public response and the stored-reader response.
3. RED: run `bun run test:schema-compatibility -- --fixture legacy-result` and observe exit 1 with `legacy result cannot be read` before editing `src/review/result-store.ts`.
4. GREEN: add the backward-compatible legacy-result reader in `src/review/result-store.ts`, rerun the step-3 command, and assert the stored result round-trips without rewriting legacy bytes.
5. RED: run `bun run test:failure-signals -- --fixture authorized-reviewer-rejection` with a reviewer response containing request_changes, the named rejection finding, and a null execution_plan_record; observe exit 1 because the public response loses the finding or retains an approval record. Also run `bun run test:authorization-boundary -- --fixture denied-review` with an unauthorized actor and an initially empty reviewer request journal; observe exit 1 because the CLI neither names the denied review nor prevents dispatch before editing `src/review/command.ts`.
6. GREEN: call the accepted shared authorization service before reviewer dispatch in `src/review/command.ts`, rerun both step-5 commands, and assert the unauthorized call exits 2, names the affected review, leaves the reviewer request journal empty, and persists no result. For the authorized reviewer rejection, assert the public response retains the supplied rejection finding and a null execution_plan_record, and that the compatible stored-result reader returns those same values. Seed the rejected judgment with distinguishing summary, findings, evidence records, and destination; compare the complete supplied judgment by deep equality with both the public response and the stored-reader response.
7. RED: run `bun run test:rollout-rollback -- --fixture enabled-result` and observe exit 1 because disabling the review command does not restore the prior readable result before editing `src/review/rollout.ts`.
8. GREEN: add the accepted activation switch and rollback reader in `src/review/rollout.ts`, rerun the step-7 command, and assert activation waits for compatible reading, enabled activation reads the expected legacy-result and typed-result fixture contents, and disabling activation restores the prior reader while both formats remain readable with their exact expected contents.
9. RED: run `bun run test:documentation-contract` and `bun run test:execution-plan-conformance`; observe exit 1 because the command reference omits the public response, denial, activation, or rollback contract, or the corpus omits an accepted obligation, before editing the command reference and canonical review contract.
10. GREEN: document the exact public response, denial, activation, and rollback contracts and add every accepted obligation to the canonical conformance corpus, then rerun both step-9 commands and assert exit 0; assert the rendered command reference describes all four accepted contracts and that removing any one makes documentation-contract fail.
11. REFACTOR: move the duplicate response validation in `src/review/command.ts` and `src/review/result-store.ts` into `src/review/contract.ts`, then rerun all seven proof commands and assert the public response snapshot is byte-identical.

## Obligation ownership

- Accepted behavior: Complete delivery
- Migration work: Complete delivery
- Rollout work: Complete delivery
- Rollback work: Complete delivery
- Documentation work: Complete delivery
- Affected-surface work: Complete delivery

## Decision accounting

- One shared authorization service owns permission checks for every transport.: unchanged
- Host-neutral dependency order keeps every intermediate merge supported.: unchanged

## Proof specifications

| Proof ID | Method | Scope | Boundary exercised | Qualifies as | Currency | Invocation |
| --- | --- | --- | --- | --- | --- | --- |
| behavior-boundary | command | E2E | Accepted behavior at the public CLI boundary. | real_boundary | current_required | {"type":"command","cwd":".","argv":["bun","run","test:review-cli"]} |
| plan-integrity | command | E2E | Recorded decisions, slice dependencies, obligation ownership, and completion evidence. | real_boundary | current_required | {"type":"command","cwd":".","argv":["bun","run","test:execution-plan-conformance"]} |
| data-compatibility | command | E2E | Migration and backward-compatibility boundaries. | real_boundary | current_required | {"type":"command","cwd":".","argv":["bun","run","test:schema-compatibility"]} |
| failure-signals | command | E2E | Observable failure signals under injected review failure. | real_boundary | current_required | {"type":"command","cwd":".","argv":["bun","run","test:failure-signals"]} |
| security-boundary | command | E2E | Authorization and privacy behavior at the review boundary. | real_boundary | current_required | {"type":"command","cwd":".","argv":["bun","run","test:authorization-boundary"]} |
| rollout-rollback | command | E2E | Rollout activation and rollback recovery behavior. | real_boundary | current_required | {"type":"command","cwd":".","argv":["bun","run","test:rollout-rollback"]} |
| documentation-contract | command | E2E | Published documentation examples and links. | real_boundary | current_required | {"type":"command","cwd":".","argv":["bun","run","test:documentation-contract"]} |

## Delivery checklist

<!-- safeword:delivery-checklist:v1 -->

| ID | Category | Obligation | Owner | Required proof | Disposition | Evidence class | Revision | Evidence, reason, or dependency |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| item-1 | outcome and scope | Deliver Accepted behavior. | contributor | behavior-boundary | open | missing | | |
| item-2 | resolved decisions | Preserve both recorded implementation decisions. | contributor | plan-integrity | open | missing | | |
| item-3 | dependency and pull-request decomposition | Keep slice dependencies and pull-request boundaries supported. | contributor | plan-integrity | open | missing | | |
| item-4 | testing | Prove Accepted behavior at the named boundary. | contributor | behavior-boundary | open | missing | | |
| item-5 | data and compatibility | Complete Migration work. | contributor | data-compatibility | open | missing | | |
| item-6 | monitoring and failure signals | Expose failure signals for Affected-surface work. | contributor | failure-signals | open | missing | | |
| item-7 | security and privacy | Protect the Affected-surface work boundary. | contributor | security-boundary | open | missing | | |
| item-8 | rollout and rollback | Complete Rollout work and Rollback work. | contributor | rollout-rollback | open | missing | | |
| item-9 | documentation | Complete Documentation work. | contributor | documentation-contract | open | missing | | |
| item-10 | ownership and human dependencies | Assign every accepted obligation to an owner. | contributor | plan-integrity | open | missing | | |
| item-11 | completion evidence | Retain concrete completion evidence for all accepted obligations. | contributor | plan-integrity | open | missing | | |
