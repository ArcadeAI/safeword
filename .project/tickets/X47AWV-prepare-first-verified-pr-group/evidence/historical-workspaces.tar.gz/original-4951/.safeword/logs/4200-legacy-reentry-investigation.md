# Legacy planning reentry investigation

Decision: prevent a returned legacy ticket from reusing its earlier Implementation
approval, without migrating untouched accepted work or introducing a second
revocation registry. The user explicitly chose to fix this risk on 2026-10-07.

Investigation questions and domains:

1. Authorization currency: can an authenticated old review remain current when
   its legacy packet never captured the returned ticket context?
2. Workflow compatibility: what does accepted 82T411 R15 require at the first
   return to planning, and which earlier accepted implementation must continue?
3. Persistence and recovery: can the existing recorded discovery and current
   contract marker express refusal without a new receipt store or epoch?
4. Proof: does the actual public CLI refuse reuse, while an untouched legacy
   ticket still advances and existing modern conversion/review gates remain?

Options:

- Automatically add legacy ticket context to every review. This would expose
  discoveries, but would also change untouched legacy review identity and needs
  another semantic projection and migration policy.
- Add a revocation event or freshness epoch. This can invalidate old receipts,
  but introduces new state and another interpretation of approval authority.
- Enforce the existing current-contract requirement after recorded reentry.
  This uses the existing ticket notice and product_plan_contract marker and
  leaves current authenticated admission responsible for converted work.

Choose the third option: accepted parent R15 requires conversion, current
Implementation review, and enabled human approval before Execution Planning.
The guard refuses advancement rather than rewriting the retained plan or
declaring conversion complete. It does not bypass any review or human gate.
Premortem: a new return path forgets to record its discovery; this bounded fix
does not claim to implement every migration route or close YCFFNC's 28 scenarios.

Primary authorization reference:
https://cheatsheetseries.owasp.org/cheatsheets/Authorization_Cheat_Sheet.html
The existing current authenticated phase gate remains authority; authentication
of an older review alone does not authorize a changed planning context.

Root cause: the legacy review does not have modern role context. Recording a
discovery in ticket.md therefore need not stale the authenticated old plan
receipt. No plan repair or new review is required by the old receipt alone.
The D1 diagnostic reproduced exit 0 where exit 2 was required. A new current-root
CLI regression independently reproduced the same exit 0 after a recorded
discovery and protects the untouched legacy success path in the same journey.
The new refusal passes that current-root regression after the guard is applied.

Artifacts: /tmp/4200-legacy-reentry-red.log,
/tmp/4200-legacy-current-red.log, /tmp/4200-legacy-current-green.log.
The broader targeted run is 76 passing and 3 failing, not a clean suite.
Those three Execution-route failures remain in
/tmp/4200-legacy-and-defaults-green.log.
