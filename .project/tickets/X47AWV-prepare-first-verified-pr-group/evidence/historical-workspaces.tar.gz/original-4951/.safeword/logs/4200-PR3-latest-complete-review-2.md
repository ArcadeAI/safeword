Review the complete authored/source change for PR #5051 at exact current head 11867f743542616868fcb7ae2a59bae741c9c711, base 2f8a39d9d8047b1c5c92f5ca61995ec8a48b4620. Review semantic context identities, provenance, authentication and stale-approval refusal, meaningful tests, and tight scope. All changed files except the two compiled runtime bundles are included across the numbered parts. The excluded plugin/runtime/cli.js and packages/cli/codex-plugin/runtime/cli.js diffs exceed the packet budget; their complete source/generation changes and identities are supplied. Do not claim every compiled byte was inspected. This review supplies evidence for this exact slice only, not original full acceptance, merge or promotion authority. The user deferred OpenCode/cloud, retrieval producers, genuine weaker-model proofs and an unattempted eligible reviewer retry to named follow-on tickets; those remain unverified. PR5 owns the current installed canonical-contract currency regression and its pending correction. Do not invent that successor's completion or widen this PR through review. Existing review 9c3808bb approved the earlier source snapshot; this refresh covers the current material source change after integration. No new external dependency is introduced.

Part 2/3.

+}
+
+function capturedPacket(capture: string) {
+  expect(existsSync(capture)).toBe(true);
+  return JSON.parse(readFileSync(capture, 'utf8'));
+}
+
+describe('owned Execution review resolves Product context', () => {
+  it('preserves explicitly supplied ticket and Product Plan as a control', async () => {
+    const { result, capture } = await review(true, true);
+    expect(result.exitCode, `${result.stdout}\n${result.stderr}`).toBe(0);
+    expect(capturedPacket(capture).context_files).toEqual(
+      expect.arrayContaining([
+        expect.objectContaining({ path: ticketPath, content: metadata }),
+        expect.objectContaining({ path: specPath, content: product }),
+      ]),
+    );
+  });
+  it('automatically supplies its accepted ticket and Product Plan', async () => {
+    const { result, capture } = await review();
+    expect(result.exitCode, `${result.stdout}\n${result.stderr}`).toBe(0);
+    expect(
+      capturedPacket(capture).context_files,
+      'owned Execution review must resolve Product context',
+    ).toEqual(
+      expect.arrayContaining([
+        expect.objectContaining({ path: ticketPath, content: metadata }),
+        expect.objectContaining({ path: specPath, content: product }),
+      ]),
+    );
+  });
+  it('refuses a missing required Product Plan before reviewer execution', async () => {
+    const { result, capture } = await review(false);
+    expect(result.exitCode, 'owned Execution review must resolve Product context').not.toBe(0);
+    expect(JSON.parse(result.stdout).findings).toEqual(
+      expect.arrayContaining([
+        expect.objectContaining({
+          code: 'missing_planning_context',
+          metadata: { context_role: 'project', context_path: specPath },
+        }),
+      ]),
+    );
+    expect(
+      existsSync(capture),
+      'missing Product context must refuse before reviewer execution',
+    ).toBe(false);
+  });
+});
diff --git a/packages/cli/tests/integration/execution-upstream-planning-context.test.ts b/packages/cli/tests/integration/execution-upstream-planning-context.test.ts
new file mode 100644
index 000000000..e1d4c3626
--- /dev/null
+++ b/packages/cli/tests/integration/execution-upstream-planning-context.test.ts
@@ -0,0 +1,285 @@
+import { spawnSync } from 'node:child_process';
+import { createHash } from 'node:crypto';
+import { cpSync, existsSync, mkdirSync, readFileSync, rmSync, writeFileSync } from 'node:fs';
+import nodePath from 'node:path';
+
+import { afterEach, describe, expect, it } from 'vitest';
+
+import { EXECUTION_PLAN_CONFORMANCE_CASES } from '../../src/review/execution-plan-conformance.js';
+import { EXECUTION_PLAN_REVIEW_RUBRIC } from '../../src/review/execution-plan-rubric.generated.js';
+import { PLAN_REVIEW_RUBRIC } from '../../src/review/plan-rubric.generated.js';
+import { createConfiguredProject, createTemporaryDirectory, runCli } from '../helpers.js';
+import { writePlanningInventories } from '../planning-fixtures.js';
+import {
+  cleanupTrustedReviewerDirectories,
+  createTrustedReviewerDirectory,
+  REVIEWER_CAPABILITIES,
+} from '../review-fixtures.js';
+
+const projects: string[] = [];
+const folder = '.project/tickets/OWN123-owned-product';
+const ticketPath = `${folder}/ticket.md`;
+const specPath = `${folder}/spec.md`;
+const target = `${folder}/execution-plan.md`;
+const implementationPath = `${folder}/impl-plan.md`;
+const scenarioPath = `${folder}/behavior.feature`;
+const delivery = EXECUTION_PLAN_CONFORMANCE_CASES.find(
+  candidate => candidate.id === 'one-coherent-change',
+);
+if (delivery === undefined) throw new Error('Missing canonical Execution Plan fixture');
+const executionPlan = delivery.execution_plan;
+const implementation =
+  '# Impl Plan\n\n**Status:** planned\n\n## Approach\n\nPreserve authenticated approval.\n\n## Architecture applicability\n\nskip: No durable architecture records apply.\n\n## Data applicability\n\nskip: No product data is stored.\n';
+const metadata = `---
+id: OWN123
+type: feature
+phase: intake
+status: in_progress
+product_plan_contract: v1
+scope: preserve authenticated approval
+out_of_scope: anonymous approval
+done_when: current approval advances
+phase_anchors:
+  - scenario-gate: ${scenarioPath}
+---
+`;
+const product = `# Product Plan: Preserve approval
+
+<!-- safeword:product-plan-contract:v1 -->
+
+## Product Bet
+
+- **Expected outcome:** Builders advance with current approval.
+- **Persona outcome inventory:** Builder receives approval or a named refusal.
+- **Known facts:** Approval authenticates the current source.
+- **Assumptions:** Review latency is acceptable.
+- **Unresolved product decisions:** none
+- **Success threshold:** Current approval advances.
+- **Project non-goals:** No new approval authority.
+
+## Jobs To Be Done
+
+### approval.BU1 — Trust approval
+
+**Persona:** Builder (BU)
+
+> When I request approval, I want current evidence, so I can trust advancement.
+
+#### approval.BU1.R1 — Preserve approval
+
+Only current approval advances.
+
+## Surfaces
+
+Affected:
+- Safeword CLI
+`;
+
+afterEach(() => {
+  for (const project of projects) rmSync(project, { recursive: true, force: true });
+  projects.length = 0;
+  cleanupTrustedReviewerDirectories();
+});
+
+async function review(includeImplementation = true, explicit = false) {
+  const project = createTemporaryDirectory();
+  projects.push(project);
+  await createConfiguredProject(project);
+  writePlanningInventories(project);
+  mkdirSync(nodePath.join(project, folder), { recursive: true });
+  writeFileSync(nodePath.join(project, ticketPath), metadata);
+  writeFileSync(nodePath.join(project, specPath), product);
+  writeFileSync(nodePath.join(project, target), executionPlan);
+  if (includeImplementation)
+    writeFileSync(nodePath.join(project, implementationPath), implementation);
+  writeFileSync(
+    nodePath.join(project, scenarioPath),
+    'Feature: Trust approval\n  Scenario: Current approval\n    Given an authenticated approval\n    When the Builder requests advancement\n    Then current approval advances\n',
+  );
+  const reviewer = createTrustedReviewerDirectory('safeword-standalone-context-');
+  const capture = nodePath.join(reviewer, 'packet.json');
+  writeFileSync(
+    nodePath.join(reviewer, 'claude'),
+    String.raw`#!${process.execPath}
+const { writeFileSync } = require('node:fs');
+if (process.argv.includes('--version')) { console.log('claude 1.0.0'); process.exit(0); }
+if (process.argv.includes('--help')) { console.log(${JSON.stringify(REVIEWER_CAPABILITIES.claude)}); process.exit(0); }
+let input = ''; process.stdin.setEncoding('utf8');
+process.stdin.on('data', chunk => { input += chunk; });
+process.stdin.on('end', () => {
+  const packet = JSON.parse(input.trim().split('\n').pop());
+  writeFileSync(${JSON.stringify(capture)}, JSON.stringify(packet));
+  const output = { structured_output: { schema_version: 1, dispatch_id: packet.dispatch_id,
+    reviewer_agent: 'claude', verdict: 'approve', summary: 'Fixture approves the supplied packet.', findings: [], planning_destination: 'plan-execution',
+    execution_plan_record: { slicing_decision: 'one_pull_request', rationale: 'One coherent change.',
+      slices: [{ name: 'Complete delivery', purpose: 'Deliver the reviewed plan.', boundary: 'The accepted CLI boundary.', prerequisites: [], proof: 'The installed CLI review passes.', completion_signal: 'The review is approved.', relies_on_unmerged_successor: false }],
+      obligation_owners: [{ obligation: 'Accepted behavior', slices: ['Complete delivery'] }],
+      decision_statuses: [{ decision: 'Keep the accepted approach.', status: 'unchanged' }],
+      accepted_scenarios_covered: true, accepted_approach_preserved: true,
+      normalized_plan_digest: packet.execution_plan_normalized_digest, delivery_definition: packet.execution_plan_delivery_definition }  } };
+  if (packet.kind !== 'plan-execution') {
+    delete output.structured_output.planning_destination;
+    delete output.structured_output.execution_plan_record;
+  }
+  console.log(JSON.stringify(output));
+});
+`,
+    { mode: 0o755 },
+  );
+  const context = ['--context', scenarioPath, ...(explicit ? [implementationPath] : [])];
+  const result = await runCli(
+    [
+      'review',
+      'run',
+      'plan-execution',
+      target,
+      ...context,
+      '--cwd',
+      project,
+      '--json',
+      '--no-input',
+    ],
+    { cwd: project, env: { PATH: `${reviewer}:/usr/bin:/bin`, SAFEWORD_AGENT_RUNTIME: 'codex' } },
+  );
+  return { capture, result, project, reviewer };
+}
+
+function capturedPacket(capture: string) {
+  expect(existsSync(capture)).toBe(true);
+  return JSON.parse(readFileSync(capture, 'utf8'));
+}
+
+describe('owned Execution review resolves accepted upstream plan', () => {
+  it.each([
+    {
+      phase: 'Implementation',
+      rubric: PLAN_REVIEW_RUBRIC,
+      prefix: 'PLAN',
+      implementationStatus: 'stale',
+    },
+    {
+      phase: 'Execution',
+      rubric: EXECUTION_PLAN_REVIEW_RUBRIC,
+      prefix: 'EXECUTION_PLAN',
+      implementationStatus: 'approved',
+    },
+  ])(
+    'stales only dependent approvals after canonical $phase contract bytes change',
+    async ({ rubric, prefix, implementationStatus }) => {
+      const { result, project, reviewer } = await review();
+      expect(result.exitCode, `${result.stdout}\n${result.stderr}`).toBe(0);
+      const reviewId = JSON.parse(result.stdout).data.review_id;
+      const implementationReview = await runCli(
+        [
+          'review',
+          'run',
+          'plan-implementation',
+          implementationPath,
+          '--context',
+          specPath,
+          '--cwd',
+          project,
+          '--json',
+          '--no-input',
+        ],
+        {
+          cwd: project,
+          env: { PATH: `${reviewer}:/usr/bin:/bin`, SAFEWORD_AGENT_RUNTIME: 'codex' },
+        },
+      );
+      expect(implementationReview.exitCode, implementationReview.stdout).toBe(0);
+      const implementationReviewId = JSON.parse(implementationReview.stdout).data.review_id;
+      const distribution = createTemporaryDirectory();
+      projects.push(distribution);
+      cpSync(nodePath.resolve(import.meta.dirname, '../../../../plugin'), distribution, {
+        recursive: true,
+      });
+      const runtime = nodePath.join(distribution, 'runtime/cli.js');
+      const status = (id = reviewId) => {
+        const response = spawnSync(
+          'bun',
+          [runtime, 'review', 'status', id, '--cwd', project, '--json'],
+          {
+            cwd: project,
+            encoding: 'utf8',
+            timeout: 30_000,
+            env: { ...process.env, CLAUDE_PLUGIN_ROOT: distribution },
+          },
+        );
+        const envelope = JSON.parse(response.stdout);
+        expect(envelope.errors, `${response.stdout}\n${response.stderr}`).toEqual([]);
+        return envelope.data.status;
+      };
+      expect(status(), 'the unchanged copied runtime retains the real approval').toBe('approved');
+      expect(status(implementationReviewId)).toBe('approved');
+      const author = nodePath.join(distribution, 'templates/skills/bdd/PLAN_IMPLEMENTATION.md');
+      writeFileSync(
+        author,
+        `${readFileSync(author, 'utf8')}\n<!-- Unrelated authoring note. -->\n`,
+      );
+      expect(status(), 'outside-marker authoring notes retain Execution approval').toBe('approved');
+      expect(status(implementationReviewId)).toBe('approved');
+      const bundle = readFileSync(runtime, 'utf8');
+      const start = bundle.indexOf(`var ${prefix}_REVIEW_RUBRIC = \``);
+      const end = bundle.indexOf(`${prefix}_REVIEW_RUBRIC_SHA256`, start);
+      expect(start).toBeGreaterThanOrEqual(0);
+      expect(end).toBeGreaterThan(start);
+      const before = '- **Purpose:**';
+      const after = '- **Purpose:**   ';
+      const block = bundle.slice(start, end);
+      expect(block).toContain(before);
+      const digest = (value: string) => createHash('sha256').update(value).digest('hex');
+      const oldHash = digest(rubric);
+      const newHash = digest(rubric.replace(before, () => after));
+      expect(bundle).toContain(`${prefix}_REVIEW_RUBRIC_SHA256 = "${oldHash}"`);
+      writeFileSync(
+        runtime,
+        (bundle.slice(0, start) + block.replace(before, () => after) + bundle.slice(end)).replace(
+          `${prefix}_REVIEW_RUBRIC_SHA256 = "${oldHash}"`,
+          () => `${prefix}_REVIEW_RUBRIC_SHA256 = "${newHash}"`,
+        ),
+      );
+      expect(
+        status(),
+        'Execution approval must depend on the upstream canonical contract bytes',
+      ).toBe('stale');
+      expect(status(implementationReviewId)).toBe(implementationStatus);
+    },
+  );
+  it('preserves the explicit upstream plan as a passing control', async () => {
+    const { result, capture } = await review(true, true);
+    expect(result.exitCode, `${result.stdout}\n${result.stderr}`).toBe(0);
+    expect(capturedPacket(capture).context_files).toEqual(
+      expect.arrayContaining([
+        expect.objectContaining({ path: implementationPath, content: implementation }),
+      ]),
+    );
+  });
+  it('automatically supplies the owning Implementation Plan', async () => {
+    const { result, capture } = await review();
+    expect(result.exitCode, 'owned Execution review must resolve accepted upstream plan').toBe(0);
+    expect(capturedPacket(capture).context_files).toEqual(
+      expect.arrayContaining([
+        expect.objectContaining({ path: implementationPath, content: implementation }),
+      ]),
+    );
+  });
+  it('names a missing owning upstream plan before reviewer execution', async () => {
+    const { result, capture } = await review(false);
+    expect(result.exitCode).not.toBe(0);
+    expect(
+      JSON.parse(result.stdout).findings,
+      'owned Execution review must resolve accepted upstream plan',
+    ).toEqual(
+      expect.arrayContaining([
+        expect.objectContaining({
+          code: 'missing_planning_context',
+          metadata: { context_role: 'accepted-upstream-plan', context_path: implementationPath },
+        }),
+      ]),
+    );
+    expect(existsSync(capture), 'missing upstream plan refuses before reviewer execution').toBe(
+      false,
+    );
+  });
+});
diff --git a/packages/cli/tests/integration/implementation-product-planning-context.test.ts b/packages/cli/tests/integration/implementation-product-planning-context.test.ts
new file mode 100644
index 000000000..cc3c81c37
--- /dev/null
+++ b/packages/cli/tests/integration/implementation-product-planning-context.test.ts
@@ -0,0 +1,163 @@
+import { existsSync, mkdirSync, readFileSync, rmSync, writeFileSync } from 'node:fs';
+import nodePath from 'node:path';
+
+import { afterEach, describe, expect, it } from 'vitest';
+
+import { createConfiguredProject, createTemporaryDirectory, runCli } from '../helpers.js';
+import { writePlanningInventories } from '../planning-fixtures.js';
+import { writeImplementationRoleInputs } from '../planning-role-fixtures.js';
+import {
+  cleanupTrustedReviewerDirectories,
+  createTrustedReviewerDirectory,
+  REVIEWER_CAPABILITIES,
+} from '../review-fixtures.js';
+
+const projects: string[] = [];
+const folder = '.project/tickets/OWN123-owned-product';
+const ticketPath = `${folder}/ticket.md`;
+const specPath = `${folder}/spec.md`;
+const target = `${folder}/impl-plan.md`;
+const implementation =
+  '# Impl Plan\n\n**Status:** planned\n\n## Approach\n\nPreserve authenticated approval.\n';
+const metadata = `---
+id: OWN123
+type: feature
+phase: intake
+status: in_progress
+product_plan_contract: v1
+scope: preserve authenticated approval
+out_of_scope: anonymous approval
+done_when: current approval advances
+---
+`;
+const product = `# Product Plan: Preserve approval
+
+<!-- safeword:product-plan-contract:v1 -->
+
+## Product Bet
+
+- **Expected outcome:** Builders advance with current approval.
+- **Persona outcome inventory:** Builder receives approval or a named refusal.
+- **Known facts:** Approval authenticates the current source.
+- **Assumptions:** Review latency is acceptable.
+- **Unresolved product decisions:** none
+- **Success threshold:** Current approval advances.
+- **Project non-goals:** No new approval authority.
+
+## Jobs To Be Done
+
+### approval.BU1 — Trust approval
+
+**Persona:** Builder (BU)
+
+> When I request approval, I want current evidence, so I can trust advancement.
+
+#### approval.BU1.R1 — Preserve approval
+
+Only current approval advances.
+
+## Surfaces
+
+Affected:
+- Safeword CLI
+`;
+
+afterEach(() => {
+  for (const project of projects) rmSync(project, { recursive: true, force: true });
+  projects.length = 0;
+  cleanupTrustedReviewerDirectories();
+});
+
+async function review(includeProduct = true, explicit = false) {
+  const project = createTemporaryDirectory();
+  projects.push(project);
+  await createConfiguredProject(project);
+  writePlanningInventories(project);
+  mkdirSync(nodePath.join(project, folder), { recursive: true });
+  writeFileSync(nodePath.join(project, ticketPath), metadata);
+  if (includeProduct) writeFileSync(nodePath.join(project, specPath), product);
+  writeFileSync(nodePath.join(project, target), implementation);
+  writeImplementationRoleInputs(project, target, 'owned-product.feature');
+  const reviewer = createTrustedReviewerDirectory('safeword-standalone-context-');
+  const capture = nodePath.join(reviewer, 'packet.json');
+  writeFileSync(
+    nodePath.join(reviewer, 'claude'),
+    String.raw`#!${process.execPath}
+const { writeFileSync } = require('node:fs');
+if (process.argv.includes('--version')) { console.log('claude 1.0.0'); process.exit(0); }
+if (process.argv.includes('--help')) { console.log(${JSON.stringify(REVIEWER_CAPABILITIES.claude)}); process.exit(0); }
+let input = ''; process.stdin.setEncoding('utf8');
+process.stdin.on('data', chunk => { input += chunk; });
+process.stdin.on('end', () => {
+  const packet = JSON.parse(input.trim().split('\n').pop());
+  writeFileSync(${JSON.stringify(capture)}, JSON.stringify(packet));
+  console.log(JSON.stringify({ structured_output: { schema_version: 1, dispatch_id: packet.dispatch_id,
+    reviewer_agent: 'claude', verdict: 'approve', summary: 'Fixture approves the supplied packet.', findings: [] } }));
+});
+`,
+    { mode: 0o755 },
+  );
+  const context = explicit ? ['--context', ticketPath, specPath] : [];
+  const result = await runCli(
+    [
+      'review',
+      'run',
+      'plan-implementation',
+      target,
+      ...context,
+      '--cwd',
+      project,
+      '--json',
+      '--no-input',
+    ],
+    { cwd: project, env: { PATH: `${reviewer}:/usr/bin:/bin`, SAFEWORD_AGENT_RUNTIME: 'codex' } },
+  );
+  return { capture, result };
+}
+
+function capturedPacket(capture: string) {
+  expect(existsSync(capture)).toBe(true);
+  return JSON.parse(readFileSync(capture, 'utf8'));
+}
+
+describe('owned Implementation review resolves Product context', () => {
+  it('preserves explicitly supplied ticket and Product Plan as a control', async () => {
+    const { result, capture } = await review(true, true);
+    expect(result.exitCode, `${result.stdout}\n${result.stderr}`).toBe(0);
+    expect(capturedPacket(capture).context_files).toEqual(
+      expect.arrayContaining([
+        expect.objectContaining({ path: ticketPath, content: metadata }),
+        expect.objectContaining({ path: specPath, content: product }),
+      ]),
+    );
+  });
+  it('automatically supplies its accepted ticket and Product Plan', async () => {
+    const { result, capture } = await review();
+    expect(result.exitCode, `${result.stdout}\n${result.stderr}`).toBe(0);
+    expect(
+      capturedPacket(capture).context_files,
+      'owned Implementation review must resolve Product context',
+    ).toEqual(
+      expect.arrayContaining([
+        expect.objectContaining({ path: ticketPath, content: metadata }),
+        expect.objectContaining({ path: specPath, content: product }),
+      ]),
+    );
+  });
+  it('refuses a missing required Product Plan before reviewer execution', async () => {
+    const { result, capture } = await review(false);
+    expect(result.exitCode, 'owned Implementation review must resolve Product context').not.toBe(0);
+    expect(JSON.parse(result.stdout).findings).toEqual(
+      expect.arrayContaining([
+        expect.objectContaining({
+          code: 'missing_planning_context',
+          metadata: { context_role: 'project', context_path: specPath },
+        }),
+      ]),
+    );
+    expect(
+      existsSync(capture),
+      'missing Product context must refuse before reviewer execution',
+    ).toBe(false);
+  });
+});
diff --git a/packages/cli/tests/integration/implementation-ticket-context-currency.test.ts b/packages/cli/tests/integration/implementation-ticket-context-currency.test.ts
new file mode 100644
index 000000000..43087b38e
--- /dev/null
+++ b/packages/cli/tests/integration/implementation-ticket-context-currency.test.ts
@@ -0,0 +1,172 @@
+import { existsSync, mkdirSync, readFileSync, rmSync, writeFileSync } from 'node:fs';
+import nodePath from 'node:path';
+
+import { afterEach, describe, expect, it } from 'vitest';
+
+import { createConfiguredProject, createTemporaryDirectory, runCli } from '../helpers.js';
+import { writePlanningInventories } from '../planning-fixtures.js';
+import { writeImplementationRoleInputs } from '../planning-role-fixtures.js';
+import {
+  cleanupTrustedReviewerDirectories,
+  createTrustedReviewerDirectory,
+  REVIEWER_CAPABILITIES,
+} from '../review-fixtures.js';
+
+const projects: string[] = [];
+const folder = '.project/tickets/OWN123-owned-product';
+const ticketPath = `${folder}/ticket.md`;
+const specPath = `${folder}/spec.md`;
+const target = `${folder}/impl-plan.md`;
+const implementation =
+  '# Impl Plan\n\n**Status:** planned\n\n## Approach\n\nPreserve authenticated approval.\n';
+const metadata = `---
+id: OWN123
+type: feature
+phase: intake
+status: in_progress
+product_plan_contract: v1
+scope: preserve authenticated approval
+out_of_scope: anonymous approval
+done_when: current approval advances
+---
+`;
+const product = `# Product Plan: Preserve approval
+
+<!-- safeword:product-plan-contract:v1 -->
+
+## Product Bet
+
+- **Expected outcome:** Builders advance with current approval.
+- **Persona outcome inventory:** Builder receives approval or a named refusal.
+- **Known facts:** Approval authenticates the current source.
+- **Assumptions:** Review latency is acceptable.
+- **Unresolved product decisions:** none
+- **Success threshold:** Current approval advances.
+- **Project non-goals:** No new approval authority.
+
+## Jobs To Be Done
+
+### approval.BU1 — Trust approval
+
+**Persona:** Builder (BU)
+
+> When I request approval, I want current evidence, so I can trust advancement.
+
+#### approval.BU1.R1 — Preserve approval
+
+Only current approval advances.
+
+## Surfaces
+
+Affected:
+- Safeword CLI
+`;
+
+afterEach(() => {
+  for (const project of projects) rmSync(project, { recursive: true, force: true });
+  projects.length = 0;
+  cleanupTrustedReviewerDirectories();
+});
+
+async function review() {
+  const project = createTemporaryDirectory();
+  projects.push(project);
+  await createConfiguredProject(project);
+  writePlanningInventories(project);
+  mkdirSync(nodePath.join(project, folder), { recursive: true });
+  writeFileSync(nodePath.join(project, ticketPath), metadata);
+  writeFileSync(nodePath.join(project, specPath), product);
+  writeFileSync(nodePath.join(project, target), implementation);
+  writeImplementationRoleInputs(project, target, 'owned-product.feature');
+  const reviewer = createTrustedReviewerDirectory('safeword-standalone-context-');
+  const capture = nodePath.join(reviewer, 'packet.json');
+  writeFileSync(
+    nodePath.join(reviewer, 'claude'),
+    String.raw`#!${process.execPath}
+const { writeFileSync } = require('node:fs');
+if (process.argv.includes('--version')) { console.log('claude 1.0.0'); process.exit(0); }
+if (process.argv.includes('--help')) { console.log(${JSON.stringify(REVIEWER_CAPABILITIES.claude)}); process.exit(0); }
+let input = ''; process.stdin.setEncoding('utf8');
+process.stdin.on('data', chunk => { input += chunk; });
+process.stdin.on('end', () => {
+  const packet = JSON.parse(input.trim().split('\n').pop());
+  writeFileSync(${JSON.stringify(capture)}, JSON.stringify(packet));
+  console.log(JSON.stringify({ structured_output: { schema_version: 1, dispatch_id: packet.dispatch_id,
+    reviewer_agent: 'claude', verdict: 'approve', summary: 'Fixture approves the supplied packet.', findings: [] } }));
+});
+`,
+    { mode: 0o755 },
+  );
+  const result = await runCli(
+    ['review', 'run', 'plan-implementation', target, '--cwd', project, '--json', '--no-input'],
+    { cwd: project, env: { PATH: `${reviewer}:/usr/bin:/bin`, SAFEWORD_AGENT_RUNTIME: 'codex' } },
+  );
+  expect(result.exitCode, `${result.stdout}\n${result.stderr}`).toBe(0);
+  expect(capturedPacket(capture).kind).toBe('plan-implementation');
+  expect(capturedPacket(capture).context_files).toEqual(
+    expect.arrayContaining([expect.objectContaining({ path: ticketPath, content: metadata })]),
+  );
+  const receipt = JSON.parse(result.stdout).data;
+  expect(receipt.status).toBe('approved');
+  return {
+    edit: (transform: (text: string) => string) => {
+      const path = nodePath.join(project, ticketPath);
+      const before = readFileSync(path, 'utf8');
+      const after = transform(before);
+      expect(after, 'the intended ticket mutation must change the source').not.toBe(before);
+      writeFileSync(path, after);
+    },
+    status: async () => {
+      const status = await runCli(
+        ['review', 'status', receipt.review_id, '--cwd', project, '--json', '--no-input'],
+        {
+          cwd: project,
+          env: { PATH: `${reviewer}:/usr/bin:/bin`, SAFEWORD_AGENT_RUNTIME: 'codex' },
+        },
+      );
+      const state = JSON.parse(status.stdout).data.status as string;
+      expect(status.exitCode, `${status.stdout}\n${status.stderr}`).toBe(state === 'stale' ? 2 : 0);
+      return state;
+    },
+  };
+}
+
+function capturedPacket(capture: string) {
+  expect(existsSync(capture)).toBe(true);
+  return JSON.parse(readFileSync(capture, 'utf8'));
+}
+
+describe('Implementation ticket semantic currency through public status', () => {
+  it('retains an unchanged authenticated approval as a control', async () => {
+    const current = await review();
+    expect(await current.status()).toBe('approved');
+  });
+  it.each([
+    [
+      'ordinary phase progress',
+      (text: string) => text.replace('phase: intake', 'phase: define-behavior'),
+    ],
+    [
+      'YAML formatting',
+      (text: string) =>
+        text.replace(
+          'scope: preserve authenticated approval',
+          'scope: "preserve authenticated approval"',
+        ),
+    ],
+  ])('retains approval after %s', async (_label, transform) => {
+    const current = await review();
+    current.edit(transform);
+    expect(
+      await current.status(),
+      'Implementation ticket currency must ignore non-semantic edits',
+    ).toBe('approved');
+  });
+  it('stales approval after an accepted scope change', async () => {
+    const current = await review();
+    current.edit(text =>
+      text.replace('scope: preserve authenticated approval', 'scope: permit anonymous approval'),
+    );
+    expect(await current.status()).toBe('stale');
+  });
+});
diff --git a/packages/cli/tests/integration/native-planning-copy-dispatch.test.ts b/packages/cli/tests/integration/native-planning-copy-dispatch.test.ts
index 806cbc98e..348492cc3 100644
--- a/packages/cli/tests/integration/native-planning-copy-dispatch.test.ts
+++ b/packages/cli/tests/integration/native-planning-copy-dispatch.test.ts
@@ -7,6 +7,7 @@ import { afterEach, describe, expect, it } from 'vitest';
 
 import { PLANNING_CONTRACT_TEMPLATE_PATHS } from '../../src/schema.js';
 import { VERSION } from '../../src/version.js';
+import { writePlanningInventories } from '../planning-fixtures.js';
 import {
   cleanupTrustedReviewerDirectories,
   createTrustedReviewerDirectory,
@@ -60,6 +61,7 @@ describe('Complete native planning author-copy dispatch', () => {
       const project = nodePath.join(root, 'project');
       const ticket = nodePath.join(project, '.project/tickets/NAT123-native-copy');
       mkdirSync(ticket, { recursive: true });
+      writePlanningInventories(project);
       writeFileSync(
         nodePath.join(ticket, 'ticket.md'),
         '---\nid: NAT123\ntype: feature\nphase: plan-implementation\nstatus: in_progress\n---\n',
diff --git a/packages/cli/tests/integration/plan-design-approval.test.ts b/packages/cli/tests/integration/plan-design-approval.test.ts
index 59faf783b..1a01f3964 100644
--- a/packages/cli/tests/integration/plan-design-approval.test.ts
+++ b/packages/cli/tests/integration/plan-design-approval.test.ts
@@ -199,6 +199,17 @@ function fixture(designApprovalGate: boolean, reviewState: ReviewState = 'approv
   mkdirSync(nodePath.join(root, '.safeword', 'templates'), { recursive: true });
   mkdirSync(nodePath.join(root, 'features'), { recursive: true });
   mkdirSync(ticketDirectory, { recursive: true });
+  const inventories = {
+    principles:
+      '# Principles\n\n## Preserve approval authority\n\nCurrent authenticated approval controls advancement.\n',
+    personas:
+      '# Personas\n\n## Builder (BU)\n\n**Role:** A builder requesting planning approval.\n**Context:** Needs current authenticated approval before advancement.\n',
+    surfaces:
+      '# Surfaces\n\n## Safeword CLI\n\n**Kind:** CLI\n**Description:** Requests and presents planning approval.\n**Audience:** Builder (BU)\n',
+  };
+  for (const [role, content] of Object.entries(inventories)) {
+    writeFileSync(nodePath.join(root, '.project', `${role}.md`), content);
+  }
   writeFileSync(
     nodePath.join(root, '.safeword', 'config.json'),
     `${JSON.stringify({ designApprovalGate, reviewGate: true }, undefined, 2)}\n`,
diff --git a/packages/cli/tests/integration/plan-execution-journey.test.ts b/packages/cli/tests/integration/plan-execution-journey.test.ts
index f9c876c5c..ca5d2173a 100644
--- a/packages/cli/tests/integration/plan-execution-journey.test.ts
+++ b/packages/cli/tests/integration/plan-execution-journey.test.ts
@@ -19,6 +19,7 @@ import {
   parseDeliveryPlanContract,
 } from '../../src/execution-plan/delivery-checklist.js';
 import { assertTestCliFresh, expectHookAllow, expectHookDeny, runCli } from '../helpers.js';
+import { writePlanningInventories } from '../planning-fixtures.js';
 import {
   cleanupTrustedReviewerDirectories,
   createTrustedReviewerDirectory,
@@ -41,7 +42,7 @@ const CATEGORIES = [
 const REVIEW_CONTRACT_SIGNAL = 'Every executable step must name its exact action';
 const CONCRETE_PROOF_CONTRACT_SIGNAL =
   'A test step must name its fixture, command, edit action, expected exit or assertion, and real actor boundary.';
-const RED_COMMAND = ['node', 'tests/denied-request.cjs'] as const;
+const RED_COMMAND = ['bun', 'tests/denied-request.cjs'] as const;
 const PACKAGED_CLI = nodePath.resolve(import.meta.dirname, '../../dist/cli.js');
 const WRITE_REVIEW_STAMP = nodePath.resolve(
   import.meta.dirname,
@@ -266,13 +267,14 @@ describe('Execution Plan cold-start journey', () => {
     cleanupTrustedReviewerDirectories();
   });
 
-  it('rejects an unstartable fourth step through the installed CLI, then reaches the named RED', async () => {
+  it('rejects an unstartable fourth step through the installed CLI, then reaches the named RED and completes GREEN and REFACTOR', async () => {
     const root = mkdtempSync(nodePath.join(tmpdir(), 'safeword-plan-journey-'));
     try {
       const ticketDirectory = nodePath.join(root, '.project', 'tickets', 'START1-feature');
       const plan = executionPlan();
       mkdirSync(nodePath.join(root, '.safeword'), { recursive: true });
       mkdirSync(ticketDirectory, { recursive: true });
+      writePlanningInventories(root);
       mkdirSync(nodePath.join(root, 'features'), { recursive: true });
       mkdirSync(nodePath.join(root, 'tests'), { recursive: true });
       mkdirSync(nodePath.join(root, 'src'), { recursive: true });
@@ -358,10 +360,22 @@ describe('Execution Plan cold-start journey', () => {
         nodePath.join(root, 'features', 'feature.feature'),
         'Feature: Authorization\n\n  Scenario: denied request\n    Then the request is denied\n',
       );
-      writeFileSync(nodePath.join(root, 'src', 'auth.ts'), 'export const policy = "pending";\n');
+      const authorization =
+        'export const authorize = () => ({ status: policy === "denied" ? 403 : 200 });';
+      writeFileSync(
+        nodePath.join(root, 'src', 'auth.ts'),
+        `export const policy = "pending";\n${authorization}\n`,
+      );
       writeFileSync(
         nodePath.join(root, 'tests', 'denied-request.cjs'),
-        'process.stderr.write("denied request is not implemented\\n"); process.exit(1);\n',
+        [
+          'const { authorize } = require("../src/auth.ts");',
+          'if (authorize().status !== 403) {',
+          String.raw`  process.stderr.write("denied request is not implemented\n");`,
+          '  process.exit(1);',
+          '}',
+          'console.log("denied request returns 403");',
+        ].join('\n'),
       );
       writeFileSync(nodePath.join(root, '.project', 'skill-invocations.log'), '');
       writeFileSync(
@@ -606,6 +620,45 @@ describe('Execution Plan cold-start journey', () => {
         () => checkedRed,
       );
       writeFileSync(ledgerPath, observedLedger);
+      const redReview = await runCli(
+        [
+          '--json',
+          '--no-input',
+          'review',
+          'run',
+          'executable-red',
+          'tests/denied-request.cjs',
+          '--scenario',
+          'Scenario: denied request',
+          '--ledger',
+          '.project/tickets/START1-feature/test-definitions.md',
+          '--proof-cwd',
+          '.',
+          '--evidence-class',
+          'pure-contract',
+          '--expected-failure',
+          'denied request is not implemented',
+          '--execute',
+          JSON.stringify(RED_COMMAND),
+        ],
+        {
+          cwd: root,
+          env: {
+            PATH: `${reviewerBin}:${process.env.PATH}`,
+            SAFEWORD_AGENT_RUNTIME: 'codex',
+            SAFEWORD_NO_UPDATE_CHECK: '1',
+            SAFEWORD_REVIEW_KEY_ROOT: reviewKeyRoot,
+          },
+        },
+      );
+      expect(redReview.exitCode, `${redReview.stdout}\n${redReview.stderr}`).toBe(0);
+      expect(JSON.parse(redReview.stdout).data).toMatchObject({
+        status: 'approved',
+        execution_attestation: {
+          termination: { exit_code: 1, timed_out: false },
+          expected_failure: { matched: true },
+        },
+      });
       const productionEditAfterRed = runPreTool(
         root,
         {
@@ -620,6 +673,90 @@ describe('Execution Plan cold-start journey', () => {
         receiptPluginRoot,
       );
       expectHookAllow(productionEditAfterRed);
+      const sourcePath = nodePath.join(root, 'src', 'auth.ts');
+      writeFileSync(
+        sourcePath,
+        readFileSync(sourcePath, 'utf8').replace('policy = "pending"', 'policy = "denied"'),
+      );
+
+      function passingNamedProof(): void {
+        const proof = spawnSync(RED_COMMAND[0], RED_COMMAND.slice(1), {
+          cwd: root,
+          encoding: 'utf8',
+        });
+        expect(proof.status, `${proof.stdout}\n${proof.stderr}`).toBe(0);
+        expect(proof.stdout).toContain('denied request returns 403');
+      }
+
+      function recordStep(step: 'GREEN' | 'REFACTOR'): string {
+        const commit = spawnSync(
+          'git',
+          [
+            '-c',
+            'commit.gpgsign=false',
+            '-c',
+            'user.name=Safeword Test',
+            '-c',
+            'user.email=test@safeword.local',
+            'commit',
+            '-am',
+            `fixture ${step}`,
+          ],
+          { cwd: root, encoding: 'utf8' },
+        );
+        expect(commit.status, `${commit.stdout}\n${commit.stderr}`).toBe(0);
+        const revision = spawnSync('git', ['rev-parse', '--short', 'HEAD'], {
+          cwd: root,
+          encoding: 'utf8',
+        }).stdout.trim();
+        const before = readFileSync(ledgerPath, 'utf8');
+        const oldLine = `- [ ] ${step}`;
+        const newLine = `- [x] ${step} ${revision}`;
+        const admission = runPreTool(
+          root,
+          {
+            tool_name: 'Edit',
+            tool_input: { file_path: ledgerPath, old_string: oldLine, new_string: newLine },
+          },
+          reviewKeyRoot,
+          receiptPluginRoot,
+        );
+        expectHookAllow(admission);
+        writeFileSync(
+          ledgerPath,
+          before.replace(oldLine, () => newLine),
+        );
+        return newLine;
+      }
+
+      passingNamedProof();
+      const greenLine = recordStep('GREEN');
+      const refactored =
+        'export function authorize() { return { status: policy === "denied" ? 403 : 200 }; }';
+      expectHookAllow(
+        runPreTool(
+          root,
+          {
+            tool_name: 'Edit',
+            tool_input: {
+              file_path: sourcePath,
+              old_string: authorization,
+              new_string: refactored,
+            },
+          },
+          reviewKeyRoot,
+          receiptPluginRoot,
+        ),
+      );
+      writeFileSync(
+        sourcePath,
+        readFileSync(sourcePath, 'utf8').replace(authorization, () => refactored),
+      );
+      passingNamedProof();
+      const refactorLine = recordStep('REFACTOR');
+      expect(readFileSync(ledgerPath, 'utf8')).toContain(checkedRed);
+      expect(readFileSync(ledgerPath, 'utf8')).toContain(greenLine);
+      expect(readFileSync(ledgerPath, 'utf8')).toContain(refactorLine);
     } finally {
       rmSync(root, { recursive: true, force: true });
     }
@@ -631,6 +768,7 @@ describe('Execution Plan cold-start journey', () => {
       const ticketDirectory = nodePath.join(root, '.project', 'tickets', 'START1-feature');
       mkdirSync(nodePath.join(root, '.safeword'), { recursive: true });
       mkdirSync(ticketDirectory, { recursive: true });
+      writePlanningInventories(root);
       mkdirSync(nodePath.join(root, 'features'), { recursive: true });
       mkdirSync(nodePath.join(root, 'tests'), { recursive: true });
       writeFileSync(
diff --git a/packages/cli/tests/integration/planning-context-currency.test.ts b/packages/cli/tests/integration/planning-context-currency.test.ts
new file mode 100644
index 000000000..c5d19e827
--- /dev/null
+++ b/packages/cli/tests/integration/planning-context-currency.test.ts
@@ -0,0 +1,223 @@
+import { mkdirSync, readFileSync, rmSync, writeFileSync } from 'node:fs';
+import nodePath from 'node:path';
+
+import { afterEach, describe, expect, it } from 'vitest';
+
+import { createConfiguredProject, createTemporaryDirectory, runCli } from '../helpers.js';
+import { writePlanningInventories } from '../planning-fixtures.js';
+import {
+  cleanupTrustedReviewerDirectories,
+  createTrustedReviewerDirectory,
+  REVIEWER_CAPABILITIES,
+} from '../review-fixtures.js';
+
+const projects: string[] = [];
+const parentFolder = '.project/tickets/PRT123-parent';
+const childFolder = '.project/tickets/CHD123-child';
+const parentSpec = `${parentFolder}/spec.md`;
+const childTicket = `${childFolder}/ticket.md`;
+const parent = `# Product Plan: Trust review
+
+## Product Bet
+
+- **Expected outcome:** Builders advance with current approval.
+- **Persona outcome inventory:** Builder receives approval or a named refusal.
+- **Known facts:** Approval authenticates the current source.
+- **Assumptions:** Review latency is acceptable.
+- **Unresolved product decisions:** none
+- **Success threshold:** Current approval advances.
+- **Project non-goals:** No new approval authority.
+
+## Jobs To Be Done
+
+### trust.BU1 — Trust approval
+
+**Persona:** Builder (BU)
+
+> When I request approval, I want current evidence, so I can trust advancement.
+
+- **Outcome:** Current evidence is visible.
+- **Constraints:** Preserve authentication.
+
+### trust.RD1 — Find guidance
+
+**Persona:** Reader (RD)
+
+> When I read a guide, I want an index, so I can find instructions.
+
+## Shape
+
+### M1 — Trust review
+
+- **Outcome:** Review preserves trust.
+- **Non-goals:** No provider routing changes.
+
+### M2 — Find guidance
+
+- **Outcome:** Guidance has a readable index.
+- **Non-goals:** No approval changes.
+`;
+
+afterEach(() => {
+  for (const project of projects) rmSync(project, { recursive: true, force: true });
+  projects.length = 0;
+  cleanupTrustedReviewerDirectories();
+});
+
+async function fixture() {
+  const project = createTemporaryDirectory();
+  projects.push(project);
+  await createConfiguredProject(project);
+  writePlanningInventories(project);
+  for (const [folder, metadata] of [
+    [parentFolder, 'id: PRT123\ntype: epic'],
+    [
+      childFolder,
+      'id: CHD123\ntype: feature\nparent: PRT123\nparent_job: trust.BU1\nmilestone: M1',
+    ],
+  ] as const) {
+    mkdirSync(nodePath.join(project, folder), { recursive: true });
+    writeFileSync(
+      nodePath.join(project, folder, 'ticket.md'),
+      `---\n${metadata}\nphase: intake\nstatus: in_progress\nproduct_plan_contract: v1\nscope: preserve approval\nout_of_scope: new authority\ndone_when: current approval advances\n---\n`,
+    );
+  }
+  writeFileSync(nodePath.join(project, parentSpec), parent);
+  const target = `${childFolder}/spec.md`;
+  writeFileSync(
+    nodePath.join(project, target),
+    '# Feature Contribution: Current review\n\n<!-- safeword:product-plan-contract:v1 -->\n\n## Parent References\n\n- **Parent:** PRT123\n- **Parent job:** trust.BU1\n- **Milestone:** M1\n\n## Contribution\n\nPreserve current approval.\n\n## Rules\n\n#### trust.BU1.CHD123.R1 — Preserve approval\n\nOnly current approval advances.\n\n## Surfaces\n\nAffected:\n- Safeword CLI\n',
+  );
+  const reviewer = createTrustedReviewerDirectory('safeword-context-currency-');
+  const capture = nodePath.join(reviewer, 'packet.json');
+  writeFileSync(
+    nodePath.join(reviewer, 'claude'),
+    String.raw`#!${process.execPath}
+const { writeFileSync } = require('node:fs');
+if (process.argv.includes('--version')) { console.log('claude 1.0.0'); process.exit(0); }
+if (process.argv.includes('--help')) { console.log(${JSON.stringify(REVIEWER_CAPABILITIES.claude)}); process.exit(0); }
+let input = ''; process.stdin.setEncoding('utf8');
+process.stdin.on('data', chunk => { input += chunk; });
+process.stdin.on('end', () => {
+  const packet = JSON.parse(input.trim().split('\n').pop());
+  writeFileSync(${JSON.stringify(capture)}, JSON.stringify(packet));
+  console.log(JSON.stringify({ structured_output: { schema_version: 1, dispatch_id: packet.dispatch_id,
+    reviewer_agent: 'claude', verdict: 'approve', summary: 'Review fixture approves the supplied source.', findings: [] } }));
+});
+`,
+    { mode: 0o755 },
+  );
+  const run = (args: string[]) =>
+    runCli([...args, '--cwd', project, '--json', '--no-input'], {
+      cwd: project,
+      env: { PATH: `${reviewer}:/usr/bin:/bin`, SAFEWORD_AGENT_RUNTIME: 'codex' },
+    });
+  const reviewed = await run(['review', 'run', 'quality-review', target]);
+  expect(reviewed.exitCode, `${reviewed.stdout}\n${reviewed.stderr}`).toBe(0);
+  expect(JSON.parse(readFileSync(capture, 'utf8')).planning_phase).toBe('product-plan');
+  const receipt = JSON.parse(reviewed.stdout).data;
+  expect(receipt.status).toBe('approved');
+  expect(receipt.review_id).toEqual(expect.any(String));
+  return {
+    edit: (path: string, transform: (text: string) => string) => {
+      const absolute = nodePath.join(project, path);
+      const before = readFileSync(absolute, 'utf8');
+      const after = transform(before);
+      expect(after, 'the intended context mutation must change the source').not.toBe(before);
+      writeFileSync(absolute, after);
+    },
+    status: async () => {
+      const result = await run(['review', 'status', receipt.review_id]);
+      return JSON.parse(result.stdout).data.status as string;
+    },
+  };
+}
+
+describe('semantic planning context currency through public review status', () => {
+  it('retains an unchanged authenticated approval as a control', async () => {
+    const review = await fixture();
+    expect(await review.status()).toBe('approved');
+  });
+  it.each([
+    [
+      'administrative ticket progress',
+      childTicket,
+      (text: string) => text.replace('phase: intake', 'phase: define-behavior'),
+    ],
+    [
+      'administrative parent ticket progress',
+      `${parentFolder}/ticket.md`,
+      (text: string) => text.replace('phase: intake', 'phase: define-behavior'),
+    ],
+    [
+      'an unrelated milestone',
+      parentSpec,
+      (text: string) =>
+        text.replace('Guidance has a readable index.', 'Guidance has a searchable index.'),
+    ],
+    [
+      'parent comments and layout',
+      parentSpec,
+      (text: string) =>
+        text.replace('## Product Bet', '<!-- editorial note -->\n\n\n## Product Bet'),
+    ],
+    [
+      'an unrelated parent job',
+      parentSpec,
+      (text: string) => text.replace('I want an index', 'I want a searchable index'),
+    ],
+  ])('retains approval after %s changes', async (_label, path, transform) => {
+    const review = await fixture();
+    review.edit(path, transform);
+    expect(
+      await review.status(),
+      'planning context identity must ignore cosmetic and unrelated edits',
+    ).toBe('approved');
+  });
+  it('invalidates a cosmetic edit to the exact Product Plan target', async () => {
+    const review = await fixture();
+    review.edit(`${childFolder}/spec.md`, text => `${text}\n<!-- editorial note -->\n`);
+    expect(await review.status()).toBe('stale');
+  });
+  it.each([
+    [
+      'ticket scope',
+      childTicket,
+      (text: string) => text.replace('scope: preserve approval', 'scope: allow anonymous approval'),
+    ],
+    [
+      'parent ticket scope',
+      `${parentFolder}/ticket.md`,
+      (text: string) => text.replace('scope: preserve approval', 'scope: allow anonymous approval'),
+    ],
+    [
+      'selected milestone outcome',
+      parentSpec,
+      (text: string) => text.replace('Review preserves trust.', 'Review permits stale approval.'),
+    ],
+    [
+      'selected milestone non-goals',
+      parentSpec,
+      (text: string) =>
+        text.replace('No provider routing changes.', 'Provider routing changes are allowed.'),
+    ],
+    [
+      'global Product Bet facts',
+      parentSpec,
+      (text: string) =>
+        text.replace(
+          'authenticates the current source',
+          'does not authenticate the current source',
+        ),
+    ],
+    [
+      'selected parent constraints',
+      parentSpec,
+      (text: string) => text.replace('Preserve authentication.', 'Remove authentication.'),
+    ],
+  ])('invalidates approval after %s changes', async (_label, path, transform) => {
+    const review = await fixture();
+    review.edit(path, transform);
+    expect(await review.status()).toBe('stale');
+  });
+});
diff --git a/packages/cli/tests/integration/planning-review-disposition.test.ts b/packages/cli/tests/integration/planning-review-disposition.test.ts
new file mode 100644
index 000000000..3b7bb88da
--- /dev/null
+++ b/packages/cli/tests/integration/planning-review-disposition.test.ts
@@ -0,0 +1,246 @@
+import { spawnSync } from 'node:child_process';
+import { mkdirSync, readFileSync, rmSync, writeFileSync } from 'node:fs';
+import nodePath from 'node:path';
+
+import { afterEach, describe, expect, it } from 'vitest';
+
+import { parseFrontmatter } from '../../templates/hooks/lib/hierarchy.js';
+import { createConfiguredProject, createTemporaryDirectory, runCli } from '../helpers.js';
+import { writePlanningInventories } from '../planning-fixtures.js';
+import {
+  cleanupTrustedReviewerDirectories,
+  createTrustedReviewerDirectory,
+  REVIEWER_CAPABILITIES,
+} from '../review-fixtures.js';
+
+const roots: string[] = [];
+const ticketId = 'DIS123';
+const folder = `.project/tickets/${ticketId}-review-disposition`;
+const target = `${folder}/spec.md`;
+const suggestion = 'Consider adding an optional approval audit export.';
+const cli = nodePath.resolve(import.meta.dirname, '../../dist/cli.js');
+
+afterEach(() => {
+  for (const root of roots) rmSync(root, { recursive: true, force: true });
+  roots.length = 0;
+  cleanupTrustedReviewerDirectories();
+});
+
+async function reviewedProject() {
+  const root = createTemporaryDirectory();
+  roots.push(root);
+  await createConfiguredProject(root);
+  writePlanningInventories(root);
+  mkdirSync(nodePath.join(root, folder), { recursive: true });
+  const ticketPath = nodePath.join(root, folder, 'ticket.md');
+  writeFileSync(
+    ticketPath,
+    `---\nid: ${ticketId}\ntype: feature\nproduct_plan_contract: v1\nscope:\n  - preserve current approval\nout_of_scope:\n  - optional audit export\n---\n`,
+  );
+  writeFileSync(
+    nodePath.join(root, target),
+    `# Product Plan
+
+## Product Bet
+
+- **Expected outcome:** Builder can trust current approval.
+- **Persona outcome inventory:** Builder receives current approval.
+- **Known facts:** Approval is authenticated.
+- **Assumptions:** Review remains available.
+- **Unresolved product decisions:** none
+- **Success threshold:** Current approval advances.
+- **Project non-goals:** No optional audit export.
+
+## Jobs To Be Done
+
+### approval.BU1 — Trust approval
+
+**Persona:** Builder (BU)
+
+#### approval.BU1.R1 — Preserve approval
+
+Only current approval advances.
+
+## Shape
+
+### M1 — Current approval
+
+- **Outcome:** Review is current.
+- **Non-goals:** Optional audit export.
+
+## Surfaces
+
+Affected:
+- Safeword CLI
+`,
+  );
+  const reviewer = createTrustedReviewerDirectory('safeword-disposition-');
+  writeFileSync(
+    nodePath.join(reviewer, 'claude'),
+    String.raw`#!${process.execPath}
+if (process.argv.includes('--version')) { console.log('claude 1.0.0'); process.exit(0); }
+if (process.argv.includes('--help')) { console.log(${JSON.stringify(REVIEWER_CAPABILITIES.claude)}); process.exit(0); }
+let input = ''; process.stdin.setEncoding('utf8');
+process.stdin.on('data', chunk => { input += chunk; });
+process.stdin.on('end', () => {
+  const packet = JSON.parse(input.trim().split('\n').pop());
+  console.log(JSON.stringify({ structured_output: {
+    schema_version: 1, dispatch_id: packet.dispatch_id, reviewer_agent: 'claude',
+    verdict: 'approve',
+    summary: packet.review_disposition_context?.records[0]
+      ? 'The user decline for ' + packet.review_disposition_context.records[0].message + ' is ' + packet.review_disposition_context.records[0].boundary_status + ' in ticket context.'
+      : 'The accepted boundary remains intact.',
+    findings: [{ severity: 'warning', message: ${JSON.stringify(suggestion)} }],
+  } }));
+});
+`,
+    { mode: 0o755 },
+  );
+  const run = (args: string[]) =>
+    runCli([...args, '--cwd', root, '--json', '--no-input'], {
+      cwd: root,
+      env: { PATH: `${reviewer}:/usr/bin:/bin`, SAFEWORD_AGENT_RUNTIME: 'codex' },
+    });
+  const reviewed = await run(['review', 'run', 'quality-review', target]);
+  expect(reviewed.exitCode, `${reviewed.stdout}\n${reviewed.stderr}`).toBe(0);
+  const data = JSON.parse(reviewed.stdout).data as { status: string; review_id: string };
+  expect(data.status).toBe('approved');
+  const terminal = (answer: string, reviewId: string) =>
+    spawnSync(
+      'python3',
+      [
+        '-c',
+        String.raw`import os, pty, select, subprocess, sys
+master, slave = pty.openpty()
+child = subprocess.Popen(sys.argv[2:], stdin=slave, stdout=slave, stderr=slave)
+os.close(slave)
+os.write(master, (sys.argv[1] + '\n').encode())
+output = bytearray()
+while True:
+    ready, _, _ = select.select([master], [], [], 0.1)
+    if ready:
+        try:
+            part = os.read(master, 65536)
+        except OSError:
+            break
+        if not part:
+            break
+        output.extend(part)
+    if child.poll() is not None and not ready:
+        break
+os.close(master)
+sys.stdout.buffer.write(output)
+sys.exit(child.wait())`,
+        answer,
+        process.execPath,
+        cli,
+        'ticket',
+        'record-review-disposition',
+        ticketId,
+        reviewId,
+        '1',
+        '--reason',
+        'Outside the accepted scope.',
+        '--cwd',
+        root,
+        '--json',
+      ],
+      {
+        cwd: root,
+        input: `${answer}\n`,
+        encoding: 'utf8',
+        timeout: 30_000,
+        env: {
+          ...process.env,
+          PATH: `${reviewer}:${process.env.PATH ?? ''}`,
+          SAFEWORD_AGENT_RUNTIME: 'codex',
+        },
+      },
+    );
+  return { run, terminal, ticketPath, reviewId: data.review_id };
+}
+
+describe('user-owned planning review disposition', () => {
+  it('preserves long ticket lists for the installed hook reader after a decline', async () => {
+    const project = await reviewedProject();
+    const longScope =
+      'Preserve the authenticated approval of a planning review even when a contributor has written a detailed implementation note about the accepted behavior.';
+    writeFileSync(
+      project.ticketPath,
+      readFileSync(project.ticketPath, 'utf8').replace(
+        '  - preserve current approval',
+        () =>
+          `  - ${longScope}\n  - preserve current approval\nphase_skips:\n  - 'intake → define-behavior: approved scope already exists'\n  - 'scenario-gate → plan-implementation: accepted scenarios already exist'`,
+      ),
+    );
+    const fresh = await project.run(['review', 'run', 'quality-review', target]);
+    expect(fresh.exitCode, fresh.stdout).toBe(0);
+    const reviewId = (JSON.parse(fresh.stdout).data as { review_id: string }).review_id;
+
+    const confirmed = project.terminal('y', reviewId);
+    expect(confirmed.status, `${confirmed.stdout}\n${confirmed.stderr}`).toBe(0);
+    const frontmatter = readFileSync(project.ticketPath, 'utf8').split('---', 2)[1] ?? '';
+    const parsed = parseFrontmatter(frontmatter);
+    expect(parsed.scope).toEqual([longScope, 'preserve current approval']);
+    expect(parsed.phase_skips).toHaveLength(2);
+  });
+
+  it('leaves an authenticated optional finding pending in noninteractive mode', async () => {
+    const project = await reviewedProject();
+    const before = readFileSync(project.ticketPath, 'utf8');
+    const result = await project.run([
+      'ticket',
+      'record-review-disposition',
+      ticketId,
+      project.reviewId,
+      '1',
+      '--reason',
+      'Outside the accepted scope.',
+    ]);
+    const output = JSON.parse(result.stdout);
+    expect(output.state).toBe('action_required');
+    expect(output.data).toMatchObject({ status: 'pending', review_id: project.reviewId });
+    expect(JSON.stringify(output)).toContain(suggestion);
+    expect(readFileSync(project.ticketPath, 'utf8')).toBe(before);
+  });
+  it('records an explicit local decline and stales the matching review', async () => {
+    const project = await reviewedProject();
+    const before = readFileSync(project.ticketPath, 'utf8');
+    const refused = project.terminal('n', project.reviewId);
+    expect(refused.stdout, refused.stderr).toContain('"status":"pending"');
+    expect(readFileSync(project.ticketPath, 'utf8')).toBe(before);
+    const confirmed = project.terminal('y', project.reviewId);
+    expect(confirmed.status, `${confirmed.stdout}\n${confirmed.stderr}`).toBe(0);
+    expect(readFileSync(project.ticketPath, 'utf8')).toContain('review_dispositions:');
+    const status = await project.run(['review', 'status', project.reviewId]);
+    expect(JSON.parse(status.stdout).data.status).toBe('stale');
+    const fresh = await project.run(['review', 'run', 'quality-review', target]);
+    expect(fresh.exitCode, `${fresh.stdout}\n${fresh.stderr}`).toBe(0);
+    expect(fresh.stdout).toContain(
+      `The user decline for ${suggestion} is current in ticket context.`,
+    );
+    expect(fresh.stdout).toContain(suggestion);
+    writeFileSync(
+      project.ticketPath,
+      readFileSync(project.ticketPath, 'utf8').replace(
+        'preserve current approval',
+        'expand approval',
+      ),
+    );
+    const changedBoundary = await project.run(['review', 'run', 'quality-review', target]);
+    expect(changedBoundary.exitCode, `${changedBoundary.stdout}\n${changedBoundary.stderr}`).toBe(
+      0,
+    );
+    expect(changedBoundary.stdout).toContain(
+      `The user decline for ${suggestion} is superseded in ticket context.`,
+    );
+  });
+  it('leaves the ticket untouched when another disposition writer owns its lock', async () => {
+    const project = await reviewedProject();
+    const before = readFileSync(project.ticketPath, 'utf8');
+    writeFileSync(`${project.ticketPath}.review-disposition.lock`, String(process.pid));
+    const result = project.terminal('y', project.reviewId);
+    expect(result.stdout).toContain('REVIEW_DISPOSITION_WRITE_UNAVAILABLE');
+    expect(readFileSync(project.ticketPath, 'utf8')).toBe(before);
+  });
+});
diff --git a/packages/cli/tests/integration/planning-review-identity.test.ts b/packages/cli/tests/integration/planning-review-identity.test.ts
new file mode 100644
index 000000000..28c97c764
--- /dev/null
+++ b/packages/cli/tests/integration/planning-review-identity.test.ts
@@ -0,0 +1,250 @@
+import { spawnSync } from 'node:child_process';
+import {
+  cpSync,
+  existsSync,
+  mkdirSync,
+  mkdtempSync,
+  readFileSync,
+  rmSync,
+  symlinkSync,
+  writeFileSync,
+} from 'node:fs';
+import { tmpdir } from 'node:os';
+import nodePath from 'node:path';
+
+import { afterEach, describe, expect, it } from 'vitest';
+
+import {
+  cleanupTrustedReviewerDirectories,
+  createTrustedReviewerDirectory,
+  REVIEWER_CAPABILITIES,
+} from '../review-fixtures.js';
+
+const packageRoot = nodePath.resolve(import.meta.dirname, '../..');
+const roots: string[] = [];
+const folder = 'CTX123-current-context';
+const principle = 'PROJECT PRINCIPLE: Preserve the authenticated approval authority.';
+const plan =
+  '# Impl Plan\n\n**Status:** planned\n\n## Approach\n\nPreserve the existing approval authority.\n\n## Decisions\n\nRead the current configured principles before judging the approach.\n\n## Design alignment\n\nApply the Builder approval principle.\n\n## Architecture applicability\n\nskip: no durable architecture records are configured\n\n## Data applicability\n\nskip: this contribution stores no product data\n\n## Known deviations\n\nskip: none\n\n## Doc impact\n\nskip: fixture has no customer documentation change\n\n## Assessment triggers\n\nRevisit when approval authority changes.\n';
+const spec =
+  '# Product Plan: Preserve current approval authority\n\n<!-- safeword:product-plan-contract:v1 -->\n\n## Product Bet\n\n- **Problem / Why now:** Builders need trustworthy approval.\n- **Expected outcome:** Builders advance only with current approval.\n- **Success threshold:** Current approval advances and missing context refuses.\n- **Project non-goals:** Changing approval authority.\n- **Persona outcome inventory:** Builder succeeds with current approval; missing required context refuses with a named repair action.\n- **Known facts:** The fixture has one Builder and one CLI surface.\n- **Assumptions:** none\n- **Unresolved product decisions:** none\n\n## Jobs To Be Done\n\n### current-context.BU1 — Advance with current approval\n\n**Persona:** Builder (`BU`)\n\n> When I request approval, I want the current principles reviewed, so I can trust advancement.\n\n#### current-context.BU1.R1 — Required principles reach the reviewer\n\nReview the actual configured principles; refuse a missing configured source.\n\n## Shape\n\n### M1 — Trust approval\n\n- **Outcome:** Current required context reaches review.\n- **Non-goals:** New approval authority.\n\n## Surfaces\n\nAffected:\n- Safeword CLI\n';
+
+afterEach(() => {
+  for (const root of roots) rmSync(root, { recursive: true, force: true });
+  roots.length = 0;
+  cleanupTrustedReviewerDirectories();
+});
+
+function fixture() {
+  const root = mkdtempSync(nodePath.join(tmpdir(), 'safeword-planning-context-'));
+  roots.push(root);
+  const distribution = nodePath.join(root, 'package');
+  mkdirSync(distribution);
+  for (const part of ['dist', 'templates', 'package.json'])
+    cpSync(nodePath.join(packageRoot, part), nodePath.join(distribution, part), {
+      recursive: true,
+    });
+  symlinkSync(
+    nodePath.join(packageRoot, 'node_modules'),
+    nodePath.join(distribution, 'node_modules'),
+  );
+  const project = nodePath.join(root, 'project');
+  mkdirSync(project);
+  const reviewer = createTrustedReviewerDirectory('safeword-required-context-');
+  const capture = nodePath.join(reviewer, 'packet.json');
+  writeFileSync(
+    nodePath.join(reviewer, 'claude'),
+    String.raw`#!${process.execPath}
+const { writeFileSync } = require('node:fs');
+if (process.argv.includes('--version')) { console.log('claude 1.0.0'); process.exit(0); }
+if (process.argv.includes('--help')) { console.log(${JSON.stringify(REVIEWER_CAPABILITIES.claude)}); process.exit(0); }
+let input = ''; process.stdin.setEncoding('utf8');
+process.stdin.on('data', chunk => { input += chunk; });
+process.stdin.on('end', () => {
+  const packet = JSON.parse(input.trim().split('\n').pop());
+  writeFileSync(${JSON.stringify(capture)}, JSON.stringify(packet));
+  const complete = packet.context_files?.some(file => file.content.includes(${JSON.stringify(principle)}));
+  console.log(JSON.stringify({ structured_output: { schema_version: 1, dispatch_id: packet.dispatch_id,
+    reviewer_agent: 'claude', verdict: complete ? 'approve' : 'request_changes',
+    summary: complete ? 'The current principles reached review.' : 'Required principles were omitted.',
+    findings: complete ? [] : [{ severity: 'error', message: 'Required principles were omitted from the actual packet.' }] } }));
+});
+`,
+    { mode: 0o755 },
+  );
+  const capability = spawnSync(nodePath.join(reviewer, 'claude'), ['--help'], { encoding: 'utf8' });
+  expect(capability.status, `${capability.stdout}\n${capability.stderr}`).toBe(0);
+  expect(capability.stdout.trim()).toBe(REVIEWER_CAPABILITIES.claude);
+  symlinkSync(process.execPath, nodePath.join(reviewer, 'node'));
+  const bun = spawnSync('which', ['bun'], { encoding: 'utf8' });
+  expect(bun.status).toBe(0);
+  symlinkSync(bun.stdout.trim(), nodePath.join(reviewer, 'bun'));
+  const environment = {
+    ...process.env,
+    NODE_ENV: 'test',
+    PATH: `${reviewer}:/usr/bin:/bin`,
+    SAFEWORD_AGENT_RUNTIME: 'codex',
+    SAFEWORD_REVIEW_KEY_ROOT: nodePath.join(root, 'keys'),
+    SAFEWORD_NO_UPDATE_CHECK: '1',
+    SAFEWORD_SKIP_INSTALL: '1',
+    SAFEWORD_SKIP_SKILLS: '1',
+  };
+  const run = (args: string[]) =>
+    spawnSync(
+      'bun',
+      [
+        nodePath.join(distribution, 'dist/cli.js'),
+        ...args,
+        '--cwd',
+        project,
+        '--json',
+        '--no-input',
+      ],
+      { cwd: project, encoding: 'utf8', timeout: 30_000, env: environment },
+    );
+  const installed = run(['install', '--agents=cursor', '--no-modify', '--offline']);
+  expect(installed.status, `${installed.stdout}\n${installed.stderr}`).toBe(0);
+  const configPath = nodePath.join(project, '.safeword/config.json');
+  const config = JSON.parse(readFileSync(configPath, 'utf8'));
+  writeFileSync(
+    configPath,
+    JSON.stringify({
+      ...config,
+      paths: { ...config.paths, principles: '.project/approval-principles.md' },
+    }),
+  );
+  const ticket = nodePath.join(project, '.project/tickets', folder);
+  mkdirSync(ticket, { recursive: true });
+  writeFileSync(
+    nodePath.join(ticket, 'ticket.md'),
+    '---\nid: CTX123\ntype: feature\nphase: plan-implementation\nstatus: in_progress\nproduct_plan_contract: v1\nscope: preserve current approval authority\nout_of_scope: changing approval authority\ndone_when: current context reaches review\nphase_anchors:\n  - scenario-gate: features/current-context.feature\n---\n# Ticket\n',
+  );
+  writeFileSync(nodePath.join(ticket, 'spec.md'), spec);
+  writeFileSync(nodePath.join(ticket, 'impl-plan.md'), plan);
+  writeFileSync(
+    nodePath.join(project, '.project/approval-principles.md'),
+    `# Principles\n\n${principle}\n`,
+  );
+  writeFileSync(
+    nodePath.join(project, '.project/personas.md'),
+    '# Personas\n\n## Builder (`BU`)\n\nBuilder needs trustworthy approvals.\n',
+  );
+  writeFileSync(
+    nodePath.join(project, '.project/surfaces.md'),
+    '# Surfaces\n\n## Safeword CLI\n\nThe public CLI approves plans.\n',
+  );
+  mkdirSync(nodePath.join(project, 'features'), { recursive: true });
+  writeFileSync(
+    nodePath.join(project, 'features/current-context.feature'),
+    '@current-context.BU1.R1 @surface.safeword-cli\nFeature: Trust current approval\n  Scenario: Required principles reach review\n    Given current configured principles exist\n    When the Builder requests plan review\n    Then the current principles reach the reviewer\n',
+  );
+  const review = () =>
+    run([
+      'review',
+      'run',
+      'plan-implementation',
+      `.project/tickets/${folder}/impl-plan.md`,
+      '--context',
+      `.project/tickets/${folder}/spec.md`,
+    ]);
+  return { project, capture, review };
+}
+
+describe('required context through installed planning review', () => {
+  it(
+    'resolves current configured principles without requiring the caller to supply them',
+    { timeout: 60_000 },
+    () => {
+      const project = fixture();
+      const result = project.review();
+      expect(
+        result.status,
+        `installed review must resolve current configured principles\n${result.stdout}\n${result.stderr}`,
+      ).toBe(0);
+      expect(JSON.parse(result.stdout)).toMatchObject({
+        state: 'healthy',
+        data: { status: 'approved', actual_reviewer: 'claude' },
+      });
+      const packet = JSON.parse(readFileSync(project.capture, 'utf8'));
+      const expectedPrinciples = expect.objectContaining({
+        path: '.project/approval-principles.md',
+        content: expect.stringContaining(principle),
+      });
+      expect(packet.context_files).toEqual(expect.arrayContaining([expectedPrinciples]));
+    },
+  );
+  it(
+    'refuses a missing configured principles file before invoking the reviewer',
+    { timeout: 60_000 },
+    () => {
+      const project = fixture();
+      rmSync(nodePath.join(project.project, '.project/approval-principles.md'));
+      const result = project.review();
+      expect(
+        result.status,
+        'missing configured principles must not enter reviewer execution',
+      ).not.toBe(0);
+      const output = JSON.parse(result.stdout);
+      const expectedMissingContext = expect.objectContaining({
+        code: 'missing_planning_context',
+        metadata: expect.objectContaining({
+          context_role: 'principles',
+          context_path: '.project/approval-principles.md',
+        }),
+      });
+      expect(output.findings).toEqual(expect.arrayContaining([expectedMissingContext]));
+      const repair = output.recovery
+        .map((action: { description: string }) => action.description)
+        .join('\n');
+      expect(repair).toContain('paths.principles');
+      expect(repair).toContain('rerun the planning review');
+      expect(
+        existsSync(project.capture),
+        'missing configured context must block before reviewer execution',
+      ).toBe(false);
+      expect(output.data?.status).not.toBe('approved');
+    },
+  );
+  it.each([
+    ['personas', 'Builder needs trustworthy approvals.'],
+    ['surfaces', 'The public CLI approves plans.'],
+  ])('sends the current %s source through the installed reviewer packet', (role, marker) => {
+    const project = fixture();
+    const result = project.review();
+    expect(result.status, `${result.stdout}\n${result.stderr}`).toBe(0);
+    const packet = JSON.parse(readFileSync(project.capture, 'utf8'));
+    const expectedSource = expect.objectContaining({
+      path: `.project/${role}.md`,
+      content: expect.stringContaining(marker),
+    });
+    expect(packet.context_files, `installed review must include current ${role}`).toEqual(
+      expect.arrayContaining([expectedSource]),
+    );
+  });
+
+  it.each(['personas', 'surfaces'])(
+    'refuses missing %s before installed reviewer execution',
+    role => {
+      const project = fixture();
+      rmSync(nodePath.join(project.project, '.project', `${role}.md`));
+      const result = project.review();
+      expect(result.status, `missing ${role} must not enter reviewer execution`).not.toBe(0);
+      const output = JSON.parse(result.stdout);
+      const expectedMissingContext = expect.objectContaining({
+        code: 'missing_planning_context',
+        metadata: { context_role: role, context_path: `.project/${role}.md` },
+      });
+      expect(output.findings).toEqual(expect.arrayContaining([expectedMissingContext]));
+      const repair = output.recovery
+        .map((action: { description: string }) => action.description)
+        .join('\n');
+      expect(repair).toContain(`paths.${role}`);
+      expect(repair).toContain('rerun the planning review');
+      expect(
+        existsSync(project.capture),
+        `missing ${role} must block before reviewer execution`,
+      ).toBe(false);
+      expect(output.data?.status).not.toBe('approved');
+    },
+  );
+});
diff --git a/packages/cli/tests/integration/planning-role-review-identity.test.ts b/packages/cli/tests/integration/planning-role-review-identity.test.ts
new file mode 100644
index 000000000..9f524cc6d
--- /dev/null
+++ b/packages/cli/tests/integration/planning-role-review-identity.test.ts
@@ -0,0 +1,268 @@
+import { existsSync, mkdirSync, readFileSync, rmSync, writeFileSync } from 'node:fs';
+import nodePath from 'node:path';
+
+import { afterEach, describe, expect, it } from 'vitest';
+
+import { createConfiguredProject, createTemporaryDirectory, runCli } from '../helpers.js';
+import { writePlanningInventories } from '../planning-fixtures.js';
+import {
+  cleanupTrustedReviewerDirectories,
+  createTrustedReviewerDirectory,
+  REVIEWER_CAPABILITIES,
+} from '../review-fixtures.js';
+
+const projects: string[] = [];
+const folder = '.project/tickets/OWN123-owned-product';
+const ticketPath = `${folder}/ticket.md`;
+const specPath = `${folder}/spec.md`;
+const target = `${folder}/impl-plan.md`;
+const scenarioPath = `${folder}/behavior.feature`;
+const implementation = `# Impl Plan
+
+**Status:** planned
+
+## Approach
+
+Preserve authenticated approval.
+
+## Architecture applicability
+
+skip: No durable architecture records are configured.
+
+## Data applicability
+
+skip: No product data is stored.
+
+## Implementation Inspiration
+
+skip: No reusable evidence is referenced.
+`;
+const metadata = `---
+id: OWN123
+type: feature
+phase: intake
+status: in_progress
+product_plan_contract: v1
+scope: preserve authenticated approval
+out_of_scope: anonymous approval
+done_when: current approval advances
+phase_anchors:
+  - scenario-gate: .project/tickets/OWN123-owned-product/behavior.feature
+---
+`;
+const product = `# Product Plan: Preserve approval
+
+<!-- safeword:product-plan-contract:v1 -->
+
+## Product Bet
+
+- **Expected outcome:** Builders advance with current approval.
+- **Persona outcome inventory:** Builder receives approval or a named refusal.
+- **Known facts:** Approval authenticates the current source.
+- **Assumptions:** Review latency is acceptable.
+- **Unresolved product decisions:** none
+- **Success threshold:** Current approval advances.
+- **Project non-goals:** No new approval authority.
+
+## Jobs To Be Done
+
+### approval.BU1 — Trust approval
+
+**Persona:** Builder (BU)
+
+> When I request approval, I want current evidence, so I can trust advancement.
+
+#### approval.BU1.R1 — Preserve approval
+
+Only current approval advances.
+
+## Surfaces
+
+Affected:
+- Safeword CLI
+`;
+
+afterEach(() => {
+  for (const project of projects) rmSync(project, { recursive: true, force: true });
+  projects.length = 0;
+  cleanupTrustedReviewerDirectories();
+});
+
+async function review() {
+  const project = createTemporaryDirectory();
+  projects.push(project);
+  await createConfiguredProject(project);
+  writePlanningInventories(project);
+  mkdirSync(nodePath.join(project, folder), { recursive: true });
+  writeFileSync(nodePath.join(project, ticketPath), metadata);
+  writeFileSync(nodePath.join(project, specPath), product);
+  writeFileSync(nodePath.join(project, target), implementation);
+  writeFileSync(
+    nodePath.join(project, scenarioPath),
+    '@approval.BU1.R1 @surface.safeword-cli\nFeature: Trust approval\n  Scenario: Current approval\n    Given current evidence\n    When approval is requested\n    Then approval is current\n',
+  );
+  const reviewer = createTrustedReviewerDirectory('safeword-standalone-context-');
+  const capture = nodePath.join(reviewer, 'packet.json');
+  writeFileSync(
+    nodePath.join(reviewer, 'claude'),
+    String.raw`#!${process.execPath}
+const { writeFileSync } = require('node:fs');
+if (process.argv.includes('--version')) { console.log('claude 1.0.0'); process.exit(0); }
+if (process.argv.includes('--help')) { console.log(${JSON.stringify(REVIEWER_CAPABILITIES.claude)}); process.exit(0); }
+let input = ''; process.stdin.setEncoding('utf8');
+process.stdin.on('data', chunk => { input += chunk; });
+process.stdin.on('end', () => {
+  const packet = JSON.parse(input.trim().split('\n').pop());
+  writeFileSync(${JSON.stringify(capture)}, JSON.stringify(packet));
+  console.log(JSON.stringify({ structured_output: { schema_version: 1, dispatch_id: packet.dispatch_id,
+    reviewer_agent: 'claude', verdict: 'approve', summary: 'Fixture approves the supplied packet.', findings: [] } }));
+});
+`,
+    { mode: 0o755 },
+  );
+  const result = await runCli(
+    [
+      'review',
+      'run',
+      'plan-implementation',
+      target,
+      '--context',
+      scenarioPath,
+      '--cwd',
+      project,
+      '--json',
+      '--no-input',
+    ],
+    { cwd: project, env: { PATH: `${reviewer}:/usr/bin:/bin`, SAFEWORD_AGENT_RUNTIME: 'codex' } },
+  );
+  expect(result.exitCode, `${result.stdout}\n${result.stderr}`).toBe(0);
+  expect(capturedPacket(capture).kind).toBe('plan-implementation');
+  expect(capturedPacket(capture).context_files).toEqual(
+    expect.arrayContaining([expect.objectContaining({ path: ticketPath, content: metadata })]),
+  );
+  const receipt = JSON.parse(result.stdout).data;
+  expect(receipt.status).toBe('approved');
+  return {
+    identity: receipt.review_identity,
+    edit: (transform: (text: string) => string) => {
+      const path = nodePath.join(project, ticketPath);
+      const before = readFileSync(path, 'utf8');
+      const after = transform(before);
+      expect(after, 'the intended ticket mutation must change the source').not.toBe(before);
+      writeFileSync(path, after);
+    },
+    status: async () => {
+      const status = await runCli(
+        ['review', 'status', receipt.review_id, '--cwd', project, '--json', '--no-input'],
+        {
+          cwd: project,
+          env: { PATH: `${reviewer}:/usr/bin:/bin`, SAFEWORD_AGENT_RUNTIME: 'codex' },
+        },
+      );
+      const state = JSON.parse(status.stdout).data.status as string;
+      expect(status.exitCode, `${status.stdout}\n${status.stderr}`).toBe(state === 'stale' ? 2 : 0);
+      return JSON.parse(status.stdout).data;
+    },
+  };
+}
+
+function capturedPacket(capture: string) {
+  expect(existsSync(capture)).toBe(true);
+  return JSON.parse(readFileSync(capture, 'utf8'));
+}
+
+const roles = [
+  'ticket',
+  'project',
+  'parent',
+  'milestone',
+  'rules',
+  'scenarios',
+  'dimensions',
+  'principles',
+  'personas',
+  'surfaces',
+  'architecture',
+  'data',
+  'reusable-evidence',
+  'accepted-upstream-plan',
+];
+
+describe('complete planning role identity through authenticated public review', () => {
+  it('keeps an unchanged authenticated approval as a passing control', async () => {
+    const current = await review();
+    const status = await current.status();
+    expect(status.status).toBe('approved');
+  });
+  it('exposes every required or explicitly absent role in a versioned identity', async () => {
+    const current = await review();
+    const identity = current.identity;
+    expect(identity, 'owned planning approval must expose complete review identity').toMatchObject({
+      schema_version: 1,
+      ticket_id: 'OWN123',
+      ticket_path: ticketPath,
+      review_kind: 'plan-implementation',
+    });
+    const targetIdentity = expect.objectContaining({
+      path: target,
+      digest: expect.stringMatching(/^[a-f0-9]{64}$/u),
+    });
+    expect(identity.targets).toEqual(expect.arrayContaining([targetIdentity]));
+    expect(identity.canonical_contract_digest).toMatch(/^[a-f0-9]{64}$/u);
+    const recordedRoles = new Set([
+      ...identity.dependencies.map((entry: { role: string }) => entry.role),
+      ...identity.absences.map((entry: { role: string }) => entry.role),
+    ]);
+    expect(recordedRoles).toEqual(new Set(roles));
+    expect(identity.dependencies).toEqual(
+      expect.arrayContaining([
+        expect.objectContaining({ role: 'ticket', path: ticketPath }),
+        expect.objectContaining({ role: 'project', path: specPath }),
+        expect.objectContaining({ role: 'rules', path: specPath }),
+        expect.objectContaining({ role: 'scenarios', path: scenarioPath }),
+        expect.objectContaining({ role: 'principles', path: '.project/principles.md' }),
+        expect.objectContaining({ role: 'personas', path: '.project/personas.md' }),
+        expect.objectContaining({ role: 'surfaces', path: '.project/surfaces.md' }),
+      ]),
+    );
+    for (const entry of identity.dependencies) {
+      expect(entry.semantic_digest).toMatch(/^[a-f0-9]{64}$/u);
+    }
+    for (const entry of identity.absences) {
+      expect(entry.reason.trim()).not.toBe('');
+      expect(entry.authority.trim()).not.toBe('');
+      expect(
+        identity.dependencies.some(
+          (dependency: { role: string }) => dependency.role === entry.role,
+        ),
+      ).toBe(false);
+    }
+  });
+  it('returns the same reviewed identity from durable status after a scope edit', async () => {
+    const current = await review();
+    expect(
+      current.identity,
+      'owned planning approval must expose complete review identity',
+    ).toMatchObject({ schema_version: 1 });
+    current.edit(text =>
+      text.replace('scope: preserve authenticated approval', 'scope: permit anonymous approval'),
+    );
+    const status = await current.status();
+    expect(status.status).toBe('stale');
+    expect(status.review_identity).toEqual(current.identity);
+  });
+  it('retains approval for ordinary ticket progress as a passing control', async () => {
+    const current = await review();
+    current.edit(text => text.replace('phase: intake', 'phase: define-behavior'));
+    const status = await current.status();
+    expect(status.status).toBe('approved');
+  });
+  it('stales approval for an accepted scope change as a passing control', async () => {
+    const current = await review();
+    current.edit(text =>
+      text.replace('scope: preserve authenticated approval', 'scope: permit anonymous approval'),
+    );
+    const status = await current.status();
+    expect(status.status).toBe('stale');
+  });
+});
diff --git a/packages/cli/tests/integration/product-planning-context.test.ts b/packages/cli/tests/integration/product-planning-context.test.ts
new file mode 100644
index 000000000..b1939163f
--- /dev/null
+++ b/packages/cli/tests/integration/product-planning-context.test.ts
@@ -0,0 +1,207 @@
+import { spawnSync } from 'node:child_process';
+import {
+  cpSync,
+  existsSync,
+  mkdirSync,
+  mkdtempSync,
+  readFileSync,
+  rmSync,
+  symlinkSync,
+  writeFileSync,
+} from 'node:fs';
+import { tmpdir } from 'node:os';
+import nodePath from 'node:path';
+
+import { afterEach, describe, expect, it } from 'vitest';
+
+import {
+  cleanupTrustedReviewerDirectories,
+  createTrustedReviewerDirectory,
+  REVIEWER_CAPABILITIES,
+} from '../review-fixtures.js';
+
+const packageRoot = nodePath.resolve(import.meta.dirname, '../..');
+const roots: string[] = [];
+const folder = 'CTX123-current-context';
+const principle = 'PROJECT PRINCIPLE: Preserve the authenticated approval authority.';
+const plan =
+  '# Impl Plan\n\n**Status:** planned\n\n## Approach\n\nPreserve the existing approval authority.\n\n## Decisions\n\nRead the current configured principles before judging the approach.\n\n## Design alignment\n\nApply the Builder approval principle.\n\n## Architecture applicability\n\nskip: no durable architecture records are configured\n\n## Data applicability\n\nskip: this contribution stores no product data\n\n## Known deviations\n\nskip: none\n\n## Doc impact\n\nskip: fixture has no customer documentation change\n\n## Assessment triggers\n\nRevisit when approval authority changes.\n';
+const spec =
+  '# Product Plan: Preserve current approval authority\n\n<!-- safeword:product-plan-contract:v1 -->\n\n## Product Bet\n\n- **Problem / Why now:** Builders need trustworthy approval.\n- **Expected outcome:** Builders advance only with current approval.\n- **Success threshold:** Current approval advances and missing context refuses.\n- **Project non-goals:** Changing approval authority.\n- **Persona outcome inventory:** Builder succeeds with current approval; missing required context refuses with a named repair action.\n- **Known facts:** The fixture has one Builder and one CLI surface.\n- **Assumptions:** none\n- **Unresolved product decisions:** none\n\n## Jobs To Be Done\n\n### current-context.BU1 — Advance with current approval\n\n**Persona:** Builder (`BU`)\n\n> When I request approval, I want the current principles reviewed, so I can trust advancement.\n\n#### current-context.BU1.R1 — Required principles reach the reviewer\n\nReview the actual configured principles; refuse a missing configured source.\n\n## Shape\n\n### M1 — Trust approval\n\n- **Outcome:** Current required context reaches review.\n- **Non-goals:** New approval authority.\n\n## Surfaces\n\nAffected:\n- Safeword CLI\n';
+
+afterEach(() => {
+  for (const root of roots) rmSync(root, { recursive: true, force: true });
+  roots.length = 0;
+  cleanupTrustedReviewerDirectories();
+});
+
+function fixture() {
+  const root = mkdtempSync(nodePath.join(tmpdir(), 'safeword-planning-context-'));
+  roots.push(root);
+  const distribution = nodePath.join(root, 'package');
+  mkdirSync(distribution);
+  for (const part of ['dist', 'templates', 'package.json'])
+    cpSync(nodePath.join(packageRoot, part), nodePath.join(distribution, part), {
+      recursive: true,
+    });
+  symlinkSync(
+    nodePath.join(packageRoot, 'node_modules'),
+    nodePath.join(distribution, 'node_modules'),
+  );
+  const project = nodePath.join(root, 'project');
+  mkdirSync(project);
+  const reviewer = createTrustedReviewerDirectory('safeword-required-context-');
+  const capture = nodePath.join(reviewer, 'packet.json');
+  writeFileSync(
+    nodePath.join(reviewer, 'claude'),
+    String.raw`#!${process.execPath}
+const { writeFileSync } = require('node:fs');
+if (process.argv.includes('--version')) { console.log('claude 1.0.0'); process.exit(0); }
+if (process.argv.includes('--help')) { console.log(${JSON.stringify(REVIEWER_CAPABILITIES.claude)}); process.exit(0); }
+let input = ''; process.stdin.setEncoding('utf8');
+process.stdin.on('data', chunk => { input += chunk; });
+process.stdin.on('end', () => {
+  const packet = JSON.parse(input.trim().split('\n').pop());
+  writeFileSync(${JSON.stringify(capture)}, JSON.stringify(packet));
+  const complete = packet.context_files?.some(file => file.content.includes(${JSON.stringify(principle)}));
+  console.log(JSON.stringify({ structured_output: { schema_version: 1, dispatch_id: packet.dispatch_id,
+    reviewer_agent: 'claude', verdict: complete ? 'approve' : 'request_changes',
+    summary: complete ? 'The current principles reached review.' : 'Required principles were omitted.',
+    findings: complete ? [] : [{ severity: 'error', message: 'Required principles were omitted from the actual packet.' }] } }));
+});
+`,
+    { mode: 0o755 },
+  );
+  const capability = spawnSync(nodePath.join(reviewer, 'claude'), ['--help'], {
+    encoding: 'utf8',
+  });
+  expect(capability.status, `${capability.stdout}\n${capability.stderr}`).toBe(0);
+  expect(capability.stdout.trim()).toBe(REVIEWER_CAPABILITIES.claude);
+  symlinkSync(process.execPath, nodePath.join(reviewer, 'node'));
+  const bun = spawnSync('which', ['bun'], { encoding: 'utf8' });
+  expect(bun.status).toBe(0);
+  symlinkSync(bun.stdout.trim(), nodePath.join(reviewer, 'bun'));
+  const environment = {
+    ...process.env,
+    NODE_ENV: 'test',
+    PATH: `${reviewer}:/usr/bin:/bin`,
+    SAFEWORD_AGENT_RUNTIME: 'codex',
+    SAFEWORD_REVIEW_KEY_ROOT: nodePath.join(root, 'keys'),
+    SAFEWORD_NO_UPDATE_CHECK: '1',
+    SAFEWORD_SKIP_INSTALL: '1',
+    SAFEWORD_SKIP_SKILLS: '1',
+  };
+  const run = (args: string[]) =>
+    spawnSync(
+      'bun',
+      [
+        nodePath.join(distribution, 'dist/cli.js'),
+        ...args,
+        '--cwd',
+        project,
+        '--json',
+        '--no-input',
+      ],
+      { cwd: project, encoding: 'utf8', timeout: 30_000, env: environment },
+    );
+  const installed = run(['install', '--agents=cursor', '--no-modify', '--offline']);
+  expect(installed.status, `${installed.stdout}\n${installed.stderr}`).toBe(0);
+  const configPath = nodePath.join(project, '.safeword/config.json');
+  const config = JSON.parse(readFileSync(configPath, 'utf8'));
+  writeFileSync(
+    configPath,
+    JSON.stringify({
+      ...config,
+      paths: { ...config.paths, principles: '.project/approval-principles.md' },
+    }),
+  );
+  const ticket = nodePath.join(project, '.project/tickets', folder);
+  mkdirSync(ticket, { recursive: true });
+  writeFileSync(
+    nodePath.join(ticket, 'ticket.md'),
+    '---\nid: CTX123\ntype: feature\nphase: plan-implementation\nstatus: in_progress\nproduct_plan_contract: v1\nscope: preserve current approval authority\nout_of_scope: changing approval authority\ndone_when: current context reaches review\nphase_anchors:\n  - scenario-gate: features/current-context.feature\n---\n# Ticket\n'.replace(
+      'phase: plan-implementation',
+      'phase: intake',
+    ),
+  );
+  writeFileSync(nodePath.join(ticket, 'spec.md'), spec);
+  writeFileSync(nodePath.join(ticket, 'impl-plan.md'), plan);
+  writeFileSync(
+    nodePath.join(project, '.project/approval-principles.md'),
+    `# Principles\n\n${principle}\n`,
+  );
+  writeFileSync(
+    nodePath.join(project, '.project/personas.md'),
+    '# Personas\n\n## Builder (`BU`)\n\nBuilder needs trustworthy approvals.\n',
+  );
+  writeFileSync(
+    nodePath.join(project, '.project/surfaces.md'),
+    '# Surfaces\n\n## Safeword CLI\n\nThe public CLI approves plans.\n',
+  );
+  mkdirSync(nodePath.join(project, 'features'), { recursive: true });
+  writeFileSync(
+    nodePath.join(project, 'features/current-context.feature'),
+    '@current-context.BU1.R1 @surface.safeword-cli\nFeature: Trust current approval\n  Scenario: Required principles reach review\n    Given current configured principles exist\n    When the Builder requests plan review\n    Then the current principles reach the reviewer\n',
+  );
+  const review = () =>
+    run(['review', 'run', 'quality-review', `.project/tickets/${folder}/spec.md`]);
+  return { project, capture, review };
+}
+
+describe('required context through installed Product Plan review', () => {
+  it('supplies all current project inventories without caller context', () => {
+    const project = fixture();
+    const result = project.review();
+    expect(
+      result.status,
+      `installed Product review must resolve current principles\n${result.stdout}\n${result.stderr}`,
+    ).toBe(0);
+    const packet = JSON.parse(readFileSync(project.capture, 'utf8'));
+    expect(packet.planning_phase).toBe('product-plan');
+    const expectedPrinciples = expect.objectContaining({
+      path: '.project/approval-principles.md',
+      content: expect.stringContaining(principle),
+    });
+    const expectedPersonas = expect.objectContaining({
+      path: '.project/personas.md',
+      content: expect.stringContaining('Builder needs trustworthy approvals.'),
+    });
+    const expectedSurfaces = expect.objectContaining({
+      path: '.project/surfaces.md',
+      content: expect.stringContaining('The public CLI approves plans.'),
+    });
+    expect(packet.context_files).toEqual(
+      expect.arrayContaining([expectedPrinciples, expectedPersonas, expectedSurfaces]),
+    );
+  });
+  it.each(['principles', 'personas', 'surfaces'] as const)(
+    'refuses missing Product review %s before reviewer execution',
+    role => {
+      const project = fixture();
+      const contextPath =
+        role === 'principles' ? '.project/approval-principles.md' : `.project/${role}.md`;
+      rmSync(nodePath.join(project.project, contextPath));
+      const result = project.review();
+      expect(result.status, `missing Product ${role} must not enter reviewer execution`).not.toBe(
+        0,
+      );
+      const output = JSON.parse(result.stdout);
+      expect(output.findings).toEqual(
+        expect.arrayContaining([
+          expect.objectContaining({
+            code: 'missing_planning_context',
+            metadata: { context_role: role, context_path: contextPath },
+          }),
+        ]),
+      );
+      expect(
+        existsSync(project.capture),
+        'missing Product context must block before reviewer execution',
+      ).toBe(false);
+      expect(output.data?.status).not.toBe('approved');
+      expect(
+        output.recovery.map((action: { description: string }) => action.description).join('\n'),
+      ).toContain(`paths.${role}`);
+    },
+  );
+});
diff --git a/packages/cli/tests/integration/scenario-planning-context.test.ts b/packages/cli/tests/integration/scenario-planning-context.test.ts
new file mode 100644
index 000000000..4125c93c0
--- /dev/null
+++ b/packages/cli/tests/integration/scenario-planning-context.test.ts
@@ -0,0 +1,198 @@
+import { existsSync, mkdirSync, readFileSync, rmSync, writeFileSync } from 'node:fs';
+import nodePath from 'node:path';
+
+import { afterEach, describe, expect, it } from 'vitest';
+
+import { createConfiguredProject, createTemporaryDirectory, runCli } from '../helpers.js';
+import { writePlanningInventories } from '../planning-fixtures.js';
+import {
+  cleanupTrustedReviewerDirectories,
+  createTrustedReviewerDirectory,
+  REVIEWER_CAPABILITIES,
+} from '../review-fixtures.js';
+
+const projects: string[] = [];
+const folder = '.project/tickets/OWN123-owned-product';
+const ticketPath = `${folder}/ticket.md`;
+const specPath = `${folder}/spec.md`;
+const target = 'features/approval.feature';
+const metadata = `---
+id: OWN123
+type: feature
+phase: intake
+status: in_progress
+product_plan_contract: v1
+scope: preserve authenticated approval
+out_of_scope: anonymous approval
+done_when: current approval advances
+phase_anchors:
+  - scenario-gate: ${target}
+---
+`;
+const product = `# Product Plan: Preserve approval
+
+<!-- safeword:product-plan-contract:v1 -->
+
+## Product Bet
+
+- **Expected outcome:** Builders advance with current approval.
+- **Persona outcome inventory:** Builder receives approval or a named refusal.
+- **Known facts:** Approval authenticates the current source.
+- **Assumptions:** Review latency is acceptable.
+- **Unresolved product decisions:** none
+- **Success threshold:** Current approval advances.
+- **Project non-goals:** No new approval authority.
+
+## Jobs To Be Done
+
+### approval.BU1 — Trust approval
+
+**Persona:** Builder (BU)
+
+> When I request approval, I want current evidence, so I can trust advancement.
+
+#### approval.BU1.R1 — Preserve approval
+
+Only current approval advances.
+
+## Surfaces
+
+Affected:
+- Safeword CLI
+`;
+
+afterEach(() => {
+  for (const project of projects) rmSync(project, { recursive: true, force: true });
+  projects.length = 0;
+  cleanupTrustedReviewerDirectories();
+});
+
+async function review(missing?: 'ticket' | 'principles', explicit = false, multiple = false) {
+  const project = createTemporaryDirectory();
+  projects.push(project);
+  await createConfiguredProject(project);
+  writePlanningInventories(project);
+  mkdirSync(nodePath.join(project, folder), { recursive: true });
+  if (missing !== 'ticket') writeFileSync(nodePath.join(project, ticketPath), metadata);
+  writeFileSync(nodePath.join(project, specPath), product);
+  mkdirSync(nodePath.join(project, 'features'), { recursive: true });
+  writeFileSync(
+    nodePath.join(project, target),
+    'Feature: Trust approval\n  Scenario: Current approval\n    Given an authenticated approval\n    When the Builder requests advancement\n    Then current approval advances\n',
+  );
+  const secondTarget = 'features/rejection.feature';
+  if (multiple)
+    writeFileSync(
+      nodePath.join(project, secondTarget),
+      'Feature: Refuse stale approval\n  Scenario: Changed approval\n    Given changed approval evidence\n    When the Builder requests advancement\n    Then Safeword refuses it\n',
+    );
+  if (missing === 'principles') rmSync(nodePath.join(project, '.project/principles.md'));
+  const reviewer = createTrustedReviewerDirectory('safeword-standalone-context-');
+  const capture = nodePath.join(reviewer, 'packet.json');
+  writeFileSync(
+    nodePath.join(reviewer, 'claude'),
+    String.raw`#!${process.execPath}
+const { writeFileSync } = require('node:fs');
+if (process.argv.includes('--version')) { console.log('claude 1.0.0'); process.exit(0); }
+if (process.argv.includes('--help')) { console.log(${JSON.stringify(REVIEWER_CAPABILITIES.claude)}); process.exit(0); }
+let input = ''; process.stdin.setEncoding('utf8');
+process.stdin.on('data', chunk => { input += chunk; });
+process.stdin.on('end', () => {
+  const packet = JSON.parse(input.trim().split('\n').pop());
+  writeFileSync(${JSON.stringify(capture)}, JSON.stringify(packet));
+  console.log(JSON.stringify({ structured_output: { schema_version: 1, dispatch_id: packet.dispatch_id,
+    reviewer_agent: 'claude', verdict: 'approve', summary: 'Fixture approves the supplied packet.', findings: [] } }));
+});
+`,
+    { mode: 0o755 },
+  );
+  const context = [
+    '--context',
+    specPath,
+    ...(explicit
+      ? [ticketPath, '.project/principles.md', '.project/personas.md', '.project/surfaces.md']
+      : []),
+  ];
+  const result = await runCli(
+    [
+      'review',
+      'run',
+      'scenario-gate',
+      target,
+      ...(multiple ? [secondTarget] : []),
+      ...context,
+      '--cwd',
+      project,
+      '--json',
+      '--no-input',
+    ],
+    { cwd: project, env: { PATH: `${reviewer}:/usr/bin:/bin`, SAFEWORD_AGENT_RUNTIME: 'codex' } },
+  );
+  return { capture, result, project };
+}
+
+function capturedPacket(capture: string) {
+  expect(existsSync(capture)).toBe(true);
+  return JSON.parse(readFileSync(capture, 'utf8'));
+}
+
+describe('owned scenario review resolves required context', () => {
+  it('persists a readable current record for two reviewed feature targets', async () => {
+    const { result, capture, project } = await review(undefined, false, true);
+    expect(result.exitCode, `${result.stdout}\n${result.stderr}`).toBe(0);
+    expect(capturedPacket(capture).logical_files).toHaveLength(2);
+    const reviewId = (JSON.parse(result.stdout).data as { review_id: string }).review_id;
+    const status = await runCli(['review', 'status', reviewId, '--cwd', project, '--json'], {
+      cwd: project,
+    });
+    expect(status.exitCode, `${status.stdout}\n${status.stderr}`).toBe(0);
+    expect(JSON.parse(status.stdout).data.status).toBe('approved');
+  });
+
+  it('preserves explicitly supplied required sources as a control', async () => {
+    const { result, capture } = await review(undefined, true);
+    expect(result.exitCode, `${result.stdout}\n${result.stderr}`).toBe(0);
+    expect(capturedPacket(capture).context_files).toEqual(
+      expect.arrayContaining([
+        expect.objectContaining({ path: ticketPath, content: metadata }),
+        expect.objectContaining({ path: '.project/principles.md' }),
+        expect.objectContaining({ path: '.project/personas.md' }),
+        expect.objectContaining({ path: '.project/surfaces.md' }),
+      ]),
+    );
+  });
+  it('resolves its ticket and project inventories from the owning spec context', async () => {
+    const { result, capture } = await review();
+    expect(result.exitCode, `${result.stdout}\n${result.stderr}`).toBe(0);
+    expect(
+      capturedPacket(capture).context_files,
+      'owned scenario review must resolve required context',
+    ).toEqual(
+      expect.arrayContaining([
+        expect.objectContaining({ path: ticketPath, content: metadata }),
+        expect.objectContaining({ path: '.project/principles.md' }),
+        expect.objectContaining({ path: '.project/personas.md' }),
+        expect.objectContaining({ path: '.project/surfaces.md' }),
+      ]),
+    );
+  });
+  it.each([
+    ['ticket', ticketPath],
+    ['principles', '.project/principles.md'],
+  ] as const)('refuses missing required %s before reviewer execution', async (role, path) => {
+    const { result, capture } = await review(role);
+    expect(result.exitCode, 'owned scenario review must resolve required context').not.toBe(0);
+    expect(JSON.parse(result.stdout).findings).toEqual(
+      expect.arrayContaining([
+        expect.objectContaining({
+          code: 'missing_planning_context',
+          metadata: { context_role: role, context_path: path },
+        }),
+      ]),
+    );
+    expect(
+      existsSync(capture),
+      'missing required context must refuse before reviewer execution',
+    ).toBe(false);
+  });
+});
diff --git a/packages/cli/tests/integration/standalone-product-context-currency.test.ts b/packages/cli/tests/integration/standalone-product-context-currency.test.ts
new file mode 100644
index 000000000..34556d9ea
--- /dev/null
+++ b/packages/cli/tests/integration/standalone-product-context-currency.test.ts
@@ -0,0 +1,163 @@
+import { existsSync, mkdirSync, readFileSync, rmSync, writeFileSync } from 'node:fs';
+import nodePath from 'node:path';
+
+import { afterEach, describe, expect, it } from 'vitest';
+
+import { createConfiguredProject, createTemporaryDirectory, runCli } from '../helpers.js';
+import { writePlanningInventories } from '../planning-fixtures.js';
+import {
+  cleanupTrustedReviewerDirectories,
+  createTrustedReviewerDirectory,
+  REVIEWER_CAPABILITIES,
+} from '../review-fixtures.js';
+
+const projects: string[] = [];
+const folder = '.project/tickets/OWN123-owned-product';
+const ticketPath = `${folder}/ticket.md`;
+const target = `${folder}/spec.md`;
+const metadata = `---
+id: OWN123
+type: feature
+phase: intake
+status: in_progress
+product_plan_contract: v1
+scope: preserve authenticated approval
+out_of_scope: anonymous approval
+done_when: current approval advances
+---
+`;
+const product = `# Product Plan: Preserve approval
+
+<!-- safeword:product-plan-contract:v1 -->
+
+## Product Bet
+
+- **Expected outcome:** Builders advance with current approval.
+- **Persona outcome inventory:** Builder receives approval or a named refusal.
+- **Known facts:** Approval authenticates the current source.
+- **Assumptions:** Review latency is acceptable.
+- **Unresolved product decisions:** none
+- **Success threshold:** Current approval advances.
+- **Project non-goals:** No new approval authority.
+
+## Jobs To Be Done
+
+### approval.BU1 — Trust approval
+
+**Persona:** Builder (BU)
+
+> When I request approval, I want current evidence, so I can trust advancement.
+
+#### approval.BU1.R1 — Preserve approval
+
+Only current approval advances.
+
+## Surfaces
+
+Affected:
+- Safeword CLI
+`;
+
+afterEach(() => {
+  for (const project of projects) rmSync(project, { recursive: true, force: true });
+  projects.length = 0;
+  cleanupTrustedReviewerDirectories();
+});
+
+async function review() {
+  const project = createTemporaryDirectory();
+  projects.push(project);
+  await createConfiguredProject(project);
+  writePlanningInventories(project);
+  mkdirSync(nodePath.join(project, folder), { recursive: true });
+  writeFileSync(nodePath.join(project, ticketPath), metadata);
+  writeFileSync(nodePath.join(project, target), product);
+  const reviewer = createTrustedReviewerDirectory('safeword-standalone-context-');
+  const capture = nodePath.join(reviewer, 'packet.json');
+  writeFileSync(
+    nodePath.join(reviewer, 'claude'),
+    String.raw`#!${process.execPath}
+const { writeFileSync } = require('node:fs');
+if (process.argv.includes('--version')) { console.log('claude 1.0.0'); process.exit(0); }
+if (process.argv.includes('--help')) { console.log(${JSON.stringify(REVIEWER_CAPABILITIES.claude)}); process.exit(0); }
+let input = ''; process.stdin.setEncoding('utf8');
+process.stdin.on('data', chunk => { input += chunk; });
+process.stdin.on('end', () => {
+  const packet = JSON.parse(input.trim().split('\n').pop());
+  writeFileSync(${JSON.stringify(capture)}, JSON.stringify(packet));
+  console.log(JSON.stringify({ structured_output: { schema_version: 1, dispatch_id: packet.dispatch_id,
+    reviewer_agent: 'claude', verdict: 'approve', summary: 'Fixture approves the supplied packet.', findings: [] } }));
+});
+`,
+    { mode: 0o755 },
+  );
+  const result = await runCli(
+    ['review', 'run', 'quality-review', target, '--cwd', project, '--json', '--no-input'],
+    { cwd: project, env: { PATH: `${reviewer}:/usr/bin:/bin`, SAFEWORD_AGENT_RUNTIME: 'codex' } },
+  );
+  expect(result.exitCode, `${result.stdout}\n${result.stderr}`).toBe(0);
+  expect(capturedPacket(capture).planning_phase).toBe('product-plan');
+  const receipt = JSON.parse(result.stdout).data;
+  expect(receipt.status).toBe('approved');
+  return {
+    edit: (transform: (text: string) => string) => {
+      const path = nodePath.join(project, ticketPath);
+      const before = readFileSync(path, 'utf8');
+      const after = transform(before);
+      expect(after, 'the intended ticket mutation must change the source').not.toBe(before);
+      writeFileSync(path, after);
+    },
+    status: async () => {
+      const status = await runCli(
+        ['review', 'status', receipt.review_id, '--cwd', project, '--json', '--no-input'],
+        {
+          cwd: project,
+          env: { PATH: `${reviewer}:/usr/bin:/bin`, SAFEWORD_AGENT_RUNTIME: 'codex' },
+        },
+      );
+      const state = JSON.parse(status.stdout).data.status as string;
+      expect(status.exitCode, `${status.stdout}\n${status.stderr}`).toBe(state === 'stale' ? 2 : 0);
+      return state;
+    },
+  };
+}
+
+function capturedPacket(capture: string) {
+  expect(existsSync(capture)).toBe(true);
+  return JSON.parse(readFileSync(capture, 'utf8'));
+}
+
+describe('standalone ticket semantic currency through public status', () => {
+  it('retains an unchanged authenticated approval as a control', async () => {
+    const current = await review();
+    expect(await current.status()).toBe('approved');
+  });
+  it.each([
+    [
+      'ordinary phase progress',
+      (text: string) => text.replace('phase: intake', 'phase: define-behavior'),
+    ],
+    [
+      'YAML formatting',
+      (text: string) =>
+        text.replace(
+          'scope: preserve authenticated approval',
+          'scope: "preserve authenticated approval"',
+        ),
+    ],
+  ])('retains approval after %s', async (_label, transform) => {
+    const current = await review();
+    current.edit(transform);
+    expect(
+      await current.status(),
+      'standalone ticket currency must ignore non-semantic edits',
+    ).toBe('approved');
+  });
+  it('stales approval after an accepted scope change', async () => {
+    const current = await review();
+    current.edit(text =>
+      text.replace('scope: preserve authenticated approval', 'scope: permit anonymous approval'),
+    );
+    expect(await current.status()).toBe('stale');
+  });
+});
diff --git a/packages/cli/tests/integration/standalone-product-planning-context.test.ts b/packages/cli/tests/integration/standalone-product-planning-context.test.ts
new file mode 100644
index 000000000..21ea0d4c8
--- /dev/null
+++ b/packages/cli/tests/integration/standalone-product-planning-context.test.ts
@@ -0,0 +1,163 @@
+import { existsSync, mkdirSync, readFileSync, rmSync, writeFileSync } from 'node:fs';
+import nodePath from 'node:path';
+
+import { afterEach, describe, expect, it } from 'vitest';
+
+import { createConfiguredProject, createTemporaryDirectory, runCli } from '../helpers.js';
+import { writePlanningInventories } from '../planning-fixtures.js';
+import {
+  cleanupTrustedReviewerDirectories,
+  createTrustedReviewerDirectory,
+  REVIEWER_CAPABILITIES,
+} from '../review-fixtures.js';
+
+const projects: string[] = [];
+const folder = '.project/tickets/OWN123-owned-product';
+const ticketPath = `${folder}/ticket.md`;
+const target = `${folder}/spec.md`;
+const metadata = `---
+id: OWN123
+type: feature
+phase: intake
+status: in_progress
+product_plan_contract: v1
+scope: preserve authenticated approval
+out_of_scope: anonymous approval
+done_when: current approval advances
+---
+`;
+const product = `# Product Plan: Preserve approval
+
+<!-- safeword:product-plan-contract:v1 -->
+
+## Product Bet
+
+- **Expected outcome:** Builders advance with current approval.
+- **Persona outcome inventory:** Builder receives approval or a named refusal.
+- **Known facts:** Approval authenticates the current source.
+- **Assumptions:** Review latency is acceptable.
+- **Unresolved product decisions:** none
+- **Success threshold:** Current approval advances.
+- **Project non-goals:** No new approval authority.
+
+## Jobs To Be Done
+
+### approval.BU1 — Trust approval
+
+**Persona:** Builder (BU)
+
+> When I request approval, I want current evidence, so I can trust advancement.
+
+#### approval.BU1.R1 — Preserve approval
+
+Only current approval advances.
+
+## Surfaces
+
+Affected:
+- Safeword CLI
+`;
+
+afterEach(() => {
+  for (const project of projects) rmSync(project, { recursive: true, force: true });
+  projects.length = 0;
+  cleanupTrustedReviewerDirectories();
+});
+
+async function review(ticket: string | undefined, explicit = false) {
+  const project = createTemporaryDirectory();
+  projects.push(project);
+  await createConfiguredProject(project);
+  writePlanningInventories(project);
+  mkdirSync(nodePath.join(project, folder), { recursive: true });
+  if (ticket !== undefined) writeFileSync(nodePath.join(project, ticketPath), ticket);
+  writeFileSync(nodePath.join(project, target), product);
+  const reviewer = createTrustedReviewerDirectory('safeword-standalone-context-');
+  const capture = nodePath.join(reviewer, 'packet.json');
+  writeFileSync(
+    nodePath.join(reviewer, 'claude'),
+    String.raw`#!${process.execPath}
+const { writeFileSync } = require('node:fs');
+if (process.argv.includes('--version')) { console.log('claude 1.0.0'); process.exit(0); }
+if (process.argv.includes('--help')) { console.log(${JSON.stringify(REVIEWER_CAPABILITIES.claude)}); process.exit(0); }
+let input = ''; process.stdin.setEncoding('utf8');
+process.stdin.on('data', chunk => { input += chunk; });
+process.stdin.on('end', () => {
+  const packet = JSON.parse(input.trim().split('\n').pop());
+  writeFileSync(${JSON.stringify(capture)}, JSON.stringify(packet));
+  console.log(JSON.stringify({ structured_output: { schema_version: 1, dispatch_id: packet.dispatch_id,
+    reviewer_agent: 'claude', verdict: 'approve', summary: 'Fixture approves the supplied packet.', findings: [] } }));
+});
+`,
+    { mode: 0o755 },
+  );
+  const context = explicit ? ['--context', ticketPath] : [];
+  const result = await runCli(
+    [
+      'review',
+      'run',
+      'quality-review',
+      target,
+      ...context,
+      '--cwd',
+      project,
+      '--json',
+      '--no-input',
+    ],
+    { cwd: project, env: { PATH: `${reviewer}:/usr/bin:/bin`, SAFEWORD_AGENT_RUNTIME: 'codex' } },
+  );
+  return { capture, result };
+}
+
+function capturedPacket(capture: string) {
+  expect(existsSync(capture)).toBe(true);
+  return JSON.parse(readFileSync(capture, 'utf8'));
+}
+
+describe('owned standalone Product context through public review dispatch', () => {
+  it('preserves an explicitly supplied current ticket as a dispatch control', async () => {
+    const { result, capture } = await review(metadata, true);
+    expect(result.exitCode, `${result.stdout}\n${result.stderr}`).toBe(0);
+    const packet = capturedPacket(capture);
+    expect(packet.planning_phase).toBe('product-plan');
+    expect(packet.context_files).toEqual(
+      expect.arrayContaining([expect.objectContaining({ path: ticketPath, content: metadata })]),
+    );
+  });
+  it('automatically supplies the current standalone ticket', async () => {
+    const { result, capture } = await review(metadata);
+    expect(result.exitCode, `${result.stdout}\n${result.stderr}`).toBe(0);
+    const packet = capturedPacket(capture);
+    expect(packet.planning_phase).toBe('product-plan');
+    expect(packet.context_files, 'owned Product review must resolve its current ticket').toEqual(
+      expect.arrayContaining([expect.objectContaining({ path: ticketPath, content: metadata })]),
+    );
+  });
+  it('recognizes valid quoted YAML ownership without downgrading planning review', async () => {
+    const quoted = metadata
+      .replace('id: OWN123', 'id: "OWN123"')
+      .replace('product_plan_contract: v1', "product_plan_contract: 'v1'");
+    expect(quoted).not.toBe(metadata);
+    const { result, capture } = await review(quoted, true);
+    expect(result.exitCode, `${result.stdout}\n${result.stderr}`).toBe(0);
+    expect(
+      capturedPacket(capture).planning_phase,
+      'owned Product review must resolve its current ticket',
+    ).toBe('product-plan');
+  });
+  it('refuses a missing ticket for a marked owned Product Plan before reviewer execution', async () => {
+    const { result, capture } = await review(undefined);
+    expect(result.exitCode, 'owned Product review must resolve its current ticket').not.toBe(0);
+    expect(JSON.parse(result.stdout).findings).toEqual(
+      expect.arrayContaining([
+        expect.objectContaining({
+          code: 'missing_planning_context',
+          metadata: { context_role: 'ticket', context_path: ticketPath },
+        }),
+      ]),
+    );
+    expect(existsSync(capture), 'missing owner ticket must refuse before reviewer execution').toBe(
+      false,
+    );
+  });
+});
diff --git a/packages/cli/tests/planning-fixtures.ts b/packages/cli/tests/planning-fixtures.ts
new file mode 100644
index 000000000..4795ac14f
--- /dev/null
+++ b/packages/cli/tests/planning-fixtures.ts
@@ -0,0 +1,18 @@
+import { mkdirSync, writeFileSync } from 'node:fs';
+import nodePath from 'node:path';
+
+export function writePlanningInventories(directory: string): void {
+  const project = nodePath.join(directory, '.project');
+  mkdirSync(project, { recursive: true });
+  const inventories = {
+    principles:
+      '# Principles\n\n## Preserve approval authority\n\nCurrent authenticated approval controls advancement.\n',
+    personas:
+      '# Personas\n\n## Builder (BU)\n\n**Role:** A builder requesting planning approval.\n**Context:** Needs current authenticated approval before advancement.\n',
+    surfaces:
+      '# Surfaces\n\n## Safeword CLI\n\n**Kind:** CLI\n**Description:** Requests and presents planning approval.\n**Audience:** Builder (BU)\n',
+  };
+  for (const [role, content] of Object.entries(inventories)) {
+    writeFileSync(nodePath.join(project, `${role}.md`), content);
+  }
+}
diff --git a/packages/cli/tests/planning-role-fixtures.ts b/packages/cli/tests/planning-role-fixtures.ts
new file mode 100644
index 000000000..7863e8694
--- /dev/null
+++ b/packages/cli/tests/planning-role-fixtures.ts
@@ -0,0 +1,46 @@
+import { mkdirSync, readFileSync, writeFileSync } from 'node:fs';
+import nodePath from 'node:path';
+
+export const PLANNING_ROLE_PRODUCT = `# Product Plan
+
+## Product Bet
+
+- **Expected outcome:** Builders retain approval.
+- **Persona outcome inventory:** Builder receives approval.
+- **Known facts:** Approval is authenticated.
+- **Assumptions:** Review is available.
+- **Unresolved product decisions:** none
+- **Success threshold:** Approval advances.
+- **Project non-goals:** No anonymous approval.
+
+## Jobs To Be Done
+
+### approval.BU1 — Trust approval
+
+**Persona:** Builder (BU)
+
+#### approval.BU1.R1 — Preserve approval
+
+Current approval advances.
+
+## Shape
+
+### M1 — Trust approval
+
+- **Outcome:** Current approval advances.
+- **Non-goals:** Anonymous approval.
+`;
+
+/** Supply phase prerequisites without changing the behavior under test. */
+export function writeImplementationRoleInputs(root: string, target: string, feature: string): void {
+  mkdirSync(nodePath.join(root, 'features'), { recursive: true });
+  writeFileSync(
+    nodePath.join(root, 'features', feature),
+    'Feature: Trust approval\n  Scenario: Current approval\n    Given current evidence\n',
+  );
+  const path = nodePath.join(root, target);
+  writeFileSync(
+    path,
+    `${readFileSync(path, 'utf8')}\n## Architecture applicability\n\nskip: No durable architecture records apply.\n\n## Data applicability\n\nskip: No product data is stored.\n`,
+  );
+}
diff --git a/packages/cli/tests/review/execution-plan-contract-identity.test.ts b/packages/cli/tests/review/execution-plan-contract-identity.test.ts
index 35744c5cb..ca6f34d2f 100644
--- a/packages/cli/tests/review/execution-plan-contract-identity.test.ts
+++ b/packages/cli/tests/review/execution-plan-contract-identity.test.ts
@@ -27,6 +27,7 @@ import { assemblePlanContract } from '../../src/review/packet.js';
 import { extractPlanReviewRubric } from '../../src/review/plan-rubric.js';
 import { reviewPromptContract } from '../../src/review/review-rubric.js';
 import { reconcilePlanContract } from '../../src/review/runtime.js';
+import { writePlanningInventories } from '../planning-fixtures.js';
 import {
   cleanupTrustedReviewerDirectories,
   createTrustedReviewerDirectory,
@@ -330,6 +331,7 @@ function runInstalledReview(
   const project = temporaryDirectory('safeword-contract-project-');
   const ticket = nodePath.join(project, '.project/tickets/T1-feature');
   mkdirSync(ticket, { recursive: true });
+  writePlanningInventories(project);
   const testCase = EXECUTION_PLAN_CONFORMANCE_CASES.find(
     candidate => candidate.id === 'one-coherent-change',
   );
diff --git a/packages/cli/tests/review/execution-role-context.test.ts b/packages/cli/tests/review/execution-role-context.test.ts
new file mode 100644
index 000000000..cf5fae13d
--- /dev/null
+++ b/packages/cli/tests/review/execution-role-context.test.ts
@@ -0,0 +1,310 @@
+import { mkdirSync, mkdtempSync, readFileSync, rmSync, writeFileSync } from 'node:fs';
+import { tmpdir } from 'node:os';
+import nodePath from 'node:path';
+
+import { afterEach, describe, expect, it } from 'vitest';
+
+import { PLANNING_CONTRACTS } from '../../src/planning/contracts.generated.js';
+import { EXECUTION_PLAN_CONFORMANCE_CASES } from '../../src/review/execution-plan-conformance.js';
+import { EXECUTION_PLAN_REVIEW_RUBRIC } from '../../src/review/execution-plan-rubric.generated.js';
+import { assemblePlanContract, prepareReviewPacket } from '../../src/review/packet.js';
+import { PLANNING_CONTEXT_ROLES } from '../../src/review/planning-context-error.js';
+import { createPlanningReviewIdentity } from '../../src/review/planning-context-identity.js';
+import { isPlanningReviewIdentity } from '../../src/review/planning-role-context.js';
+import { writePlanningInventories } from '../planning-fixtures.js';
+
+const delivery = EXECUTION_PLAN_CONFORMANCE_CASES.find(value => value.id === 'one-coherent-change');
+if (delivery === undefined) throw new Error('Missing canonical Execution fixture');
+const executionPlan = delivery.execution_plan;
+const roots: string[] = [];
+const folder = '.project/tickets/OWN123-execution';
+const target = `${folder}/execution-plan.md`;
+const upstream = `${folder}/impl-plan.md`;
+const spec = `${folder}/spec.md`;
+const feature = 'features/execution.feature';
+const canonicalExecutionContract = PLANNING_CONTRACTS['plan-execution'];
+const product = `# Product Plan
+
+## Product Bet
+
+- **Expected outcome:** Builders retain current approval.
+- **Persona outcome inventory:** Builder receives current approval.
+- **Known facts:** Approval is authenticated.
+- **Assumptions:** Review remains available.
+- **Unresolved product decisions:** none
+- **Success threshold:** Current approval advances.
+- **Project non-goals:** No anonymous approval.
+
+## Jobs To Be Done
+
+### approval.BU1 — Trust approval
+
+**Persona:** Builder (BU)
+
+#### approval.BU1.R1 — Preserve approval
+
+Current approval advances.
+`;
+const implementation = `# Implementation Plan
+
+## Approach
+
+Preserve authenticated approval.
+
+## Design alignment
+
+Architecture applicability: skip: No durable architecture record applies.
+
+### Data applicability
+
+Data applicability: skip: No product data is stored.
+
+## Implementation Inspiration
+
+- [Prior source](https://example.com/evidence) informs review, without changing approval authority.
+`;
+function project() {
+  const root = mkdtempSync(nodePath.join(tmpdir(), 'safeword-execution-role-'));
+  roots.push(root);
+  writePlanningInventories(root);
+  mkdirSync(nodePath.join(root, folder), { recursive: true });
+  mkdirSync(nodePath.join(root, 'features'));
+  writeFileSync(
+    nodePath.join(root, `${folder}/ticket.md`),
+    `---\nid: OWN123\ntype: feature\nproduct_plan_contract: v1\nphase_anchors:\n  - scenario-gate: ${feature}\n---\n`,
+  );
+  writeFileSync(nodePath.join(root, spec), product);
+  writeFileSync(nodePath.join(root, upstream), implementation);
+  writeFileSync(nodePath.join(root, target), executionPlan);
+  writeFileSync(
+    nodePath.join(root, feature),
+    '@approval.BU1.R1 @surface.safeword-cli\nFeature: Trust approval\n  Scenario: Current approval\n    Given current evidence\n',
+  );
+  return root;
+}
+function identity(root: string) {
+  const prepared = prepareReviewPacket(root, 'plan-execution', [target], [upstream, feature]);
+  try {
+    return createPlanningReviewIdentity(prepared.packet);
+  } finally {
+    prepared.cleanup();
+  }
+}
+afterEach(() => {
+  const contracts = PLANNING_CONTRACTS as unknown as Record<string, unknown>;
+  contracts['plan-execution'] = canonicalExecutionContract;
+  for (const root of roots) rmSync(root, { recursive: true, force: true });
+  roots.length = 0;
+});
+
+describe('Execution planning role context', () => {
+  it.each([
+    ['plan-implementation', upstream],
+    ['plan-execution', target],
+  ] as const)('retains the owned %s context when target spellings repeat', (kind, plan) => {
+    const prepared = prepareReviewPacket(project(), kind, [plan, `./${plan}`], [feature]);
+    try {
+      expect(prepared.packet.planning_phase).toBe(kind);
+      expect(prepared.packet.planning_context?.dependencies.map(row => row.role)).toEqual(
+        expect.arrayContaining(['ticket', 'project', 'rules', 'scenarios']),
+      );
+      expect(isPlanningReviewIdentity(createPlanningReviewIdentity(prepared.packet))).toBe(true);
+    } finally {
+      prepared.cleanup();
+    }
+  });
+
+  it('derives the owned role graph including its accepted Implementation Plan', () => {
+    const prepared = prepareReviewPacket(
+      project(),
+      'plan-execution',
+      [target],
+      [upstream, feature],
+    );
+    try {
+      const context = prepared.packet.planning_context;
+      expect(context, 'owned Execution review must derive its planning role graph').toBeDefined();
+      const present = context?.dependencies.map(row => row.role) ?? [];
+      const absent = context?.absences.map(row => row.role) ?? [];
+      expect(new Set([...present, ...absent])).toEqual(new Set(PLANNING_CONTEXT_ROLES));
+      expect(present).toEqual(
+        expect.arrayContaining([
+          'ticket',
+          'project',
+          'rules',
+          'scenarios',
+          'accepted-upstream-plan',
+          'principles',
+          'personas',
+          'surfaces',
+        ]),
+      );
+      expect(absent).toEqual(expect.arrayContaining(['dimensions', 'architecture', 'data']));
+      const reviewIdentity = createPlanningReviewIdentity(prepared.packet);
+      expect(isPlanningReviewIdentity(reviewIdentity)).toBe(true);
+      expect(reviewIdentity).toMatchObject({
+        review_kind: 'plan-execution',
+        ticket_id: 'OWN123',
+        targets: [expect.objectContaining({ path: target })],
+      });
+    } finally {
+      prepared.cleanup();
+    }
+  });
+  it('inherits triggered data guidance from the accepted Implementation Plan', () => {
+    const root = project();
+    expect(readFileSync(nodePath.join(root, target), 'utf8')).not.toContain('Data applicability');
+    writeFileSync(
+      nodePath.join(root, upstream),
+      implementation.replace(
+        'Data applicability: skip: No product data is stored.',
+        'Data applicability: Approval records are durable project-local authority data.',
+      ),
+    );
+    const guide = '.safeword/guides/data-architecture-guide.md';
+    mkdirSync(nodePath.dirname(nodePath.join(root, guide)), { recursive: true });
+    writeFileSync(
+      nodePath.join(root, guide),
+      '# Data architecture\n\nPreserve approval records.\n',
+    );
+    const prepared = prepareReviewPacket(root, 'plan-execution', [target], [upstream, feature]);
+    try {
+      expect(prepared.packet.planning_context?.dependencies).toContainEqual({
+        role: 'data',
+        path: guide,
+      });
+      expect(prepared.packet.context_files).toContainEqual({
+        path: guide,
+        content: '# Data architecture\n\nPreserve approval records.\n',
+      });
+      expect(prepared.packet.planning_context?.absences.map(row => row.role)).not.toContain('data');
+    } finally {
+      prepared.cleanup();
+    }
+  });
+  it('retains ordinary checklist progress but stales a delivery definition change', () => {
+    const root = project();
+    const path = nodePath.join(root, target);
+    const before = identity(root);
+    const progressed = readFileSync(path, 'utf8').replace(
+      '| open | missing | | |',
+      '| complete | current_revision_real_boundary | 0123456789abcdef0123456789abcdef01234567 | receipt:proof-1 |',
+    );
+    writeFileSync(path, progressed);
+    expect(identity(root)).toEqual(before);
+    writeFileSync(
+      path,
+      progressed.replace(
+        'Deliver the complete typed Execution Plan review capability.',
+        'Deliver the complete typed Execution Plan review with a changed boundary.',
+      ),
+    );
+    expect(identity(root)).not.toEqual(before);
+  });
+  it('binds an additional Execution review target to its own exact bytes', () => {
+    const prepared = prepareReviewPacket(
+      project(),
+      'plan-execution',
+      [target],
+      [upstream, feature],
+    );
+    try {
+      const auxiliary = { path: 'docs/review-note.md', content: 'Current authorization note.\n' };
+      const packet = {
+        ...prepared.packet,
+        logical_files: [...prepared.packet.logical_files, auxiliary],
+      };
+      const before = createPlanningReviewIdentity(packet);
+      const after = createPlanningReviewIdentity({
+        ...packet,
+        logical_files: [
+          ...prepared.packet.logical_files,
+          { ...auxiliary, content: 'Changed authorization note.\n' },
+        ],
+      });
+      expect(after).not.toEqual(before);
+    } finally {
+      prepared.cleanup();
+    }
+  });
+  it('stales after a decision in the accepted Implementation Plan changes', () => {
+    const root = project();
+    const before = identity(root);
+    writeFileSync(
+      nodePath.join(root, upstream),
+      implementation
+        .replace('Preserve authenticated approval.', 'Require attributable approval.')
+        .replace('No product data is stored.', 'This contribution stores no product data.'),
+    );
+    expect(identity(root)).not.toEqual(before);
+  });
+  it('cannot retain Execution approval through an unsupported own-review-only direction', () => {
+    const contracts = PLANNING_CONTRACTS as unknown as Record<string, unknown>;
+    contracts['plan-execution'] = {
+      ...canonicalExecutionContract,
+      upstreamImplementationInvalidation: 'implementation_review_only',
+    };
+    const root = project();
+    const before = identity(root);
+    writeFileSync(
+      nodePath.join(root, upstream),
+      implementation
+        .replace('Preserve authenticated approval.', 'Require attributable approval.')
+        .replace('No product data is stored.', 'This contribution stores no product data.'),
+    );
+    expect(identity(root)).not.toEqual(before);
+  });
+  it('stales Execution identity when bounded canonical contract bytes change cosmetically', () => {
+    const root = project();
+    const prepared = prepareReviewPacket(root, 'plan-execution', [target], [upstream, feature]);
+    try {
+      const before = createPlanningReviewIdentity(prepared.packet);
+      const changed = EXECUTION_PLAN_REVIEW_RUBRIC.replace('\n', '\n\n');
+      const contract = assemblePlanContract(changed, changed);
+      expect(contract.reviewer.obligations).toEqual(
+        prepared.packet.plan_contract?.reviewer.obligations,
+      );
+      expect(contract.reviewer.sha256).not.toBe(prepared.packet.plan_contract?.reviewer.sha256);
+      expect(
+        createPlanningReviewIdentity({ ...prepared.packet, plan_contract: contract }),
+      ).not.toEqual(before);
+    } finally {
+      prepared.cleanup();
+    }
+  });
+  it('refuses an Execution identity without its upstream canonical contract', () => {
+    const root = project();
+    const prepared = prepareReviewPacket(root, 'plan-execution', [target], [upstream, feature]);
+    try {
+      expect(() =>
+        createPlanningReviewIdentity({
+          ...prepared.packet,
+          upstream_plan_contract: undefined,
+        }),
+      ).toThrow('accepted-upstream-plan');
+    } finally {
+      prepared.cleanup();
+    }
+  });
+  it('rejects an Execution identity that marks the upstream plan absent', () => {
+    const root = project();
+    const reviewIdentity = identity(root);
+    expect(reviewIdentity).toBeDefined();
+    if (reviewIdentity === undefined) return;
+    const missingUpstream = {
+      ...reviewIdentity,
+      dependencies: reviewIdentity.dependencies.filter(
+        row => row.role !== 'accepted-upstream-plan',
+      ),
+      absences: [
+        ...reviewIdentity.absences,
+        {
+          role: 'accepted-upstream-plan',
+          reason: 'The upstream plan was omitted.',
+          authority: reviewIdentity.ticket_path,
+        },
+      ],
+    };
+    expect(isPlanningReviewIdentity(missingUpstream)).toBe(false);
+  });
+});
diff --git a/packages/cli/tests/review/execution-upstream-context-ownership.test.ts b/packages/cli/tests/review/execution-upstream-context-ownership.test.ts
new file mode 100644
index 000000000..877ace815
--- /dev/null
+++ b/packages/cli/tests/review/execution-upstream-context-ownership.test.ts
@@ -0,0 +1,89 @@
+import { mkdirSync, mkdtempSync, rmSync, writeFileSync } from 'node:fs';
+import { tmpdir } from 'node:os';
+import nodePath from 'node:path';
+
+import { afterEach, describe, expect, it } from 'vitest';
+
+import { EXECUTION_PLAN_CONFORMANCE_CASES } from '../../src/review/execution-plan-conformance.js';
+import { prepareReviewPacket } from '../../src/review/packet.js';
+import { writePlanningInventories } from '../planning-fixtures.js';
+import { PLANNING_ROLE_PRODUCT } from '../planning-role-fixtures.js';
+
+const roots: string[] = [];
+const folder = '.project/tickets/OWN123-owned';
+const target = `${folder}/execution-plan.md`;
+const upstream = `${folder}/impl-plan.md`;
+const scenario = `${folder}/behavior.feature`;
+const delivery = EXECUTION_PLAN_CONFORMANCE_CASES.find(value => value.id === 'one-coherent-change');
+if (delivery === undefined) throw new Error('Missing canonical Execution fixture');
+const executionPlan = delivery.execution_plan;
+const other = 'another-ticket/impl-plan.md';
+
+afterEach(() => {
+  for (const root of roots) rmSync(root, { recursive: true, force: true });
+  roots.length = 0;
+});
+
+function fixture(implementation: string | undefined) {
+  const root = mkdtempSync(nodePath.join(tmpdir(), 'safeword-upstream-owner-'));
+  roots.push(root);
+  writePlanningInventories(root);
+  mkdirSync(nodePath.join(root, folder), { recursive: true });
+  mkdirSync(nodePath.join(root, 'another-ticket'));
+  writeFileSync(
+    nodePath.join(root, folder, 'ticket.md'),
+    `---\nid: OWN123\ntype: feature\nproduct_plan_contract: v1\nphase_anchors:\n  - scenario-gate: ${scenario}\n---\n`,
+  );
+  writeFileSync(nodePath.join(root, folder, 'spec.md'), PLANNING_ROLE_PRODUCT);
+  writeFileSync(nodePath.join(root, target), executionPlan);
+  writeFileSync(
+    nodePath.join(root, scenario),
+    'Feature: Trust approval\n  Scenario: Current approval\n    Given current evidence\n    When review is requested\n    Then approval is current\n',
+  );
+  writeFileSync(nodePath.join(root, other), '# Impl Plan\n\nAn unrelated plan.\n');
+  if (implementation !== undefined) writeFileSync(nodePath.join(root, upstream), implementation);
+  return root;
+}
+
+function prepare(root: string, context = [scenario]) {
+  return prepareReviewPacket(root, 'plan-execution', [target], context);
+}
+
+describe('Execution upstream context ownership', () => {
+  it.each([undefined, ' '.repeat(3)])('refuses missing or blank owning upstream %s', content => {
+    const root = fixture(content);
+    expect(() => prepare(root)).toThrow(
+      expect.objectContaining({
+        code: 'missing_planning_context',
+        contextRole: 'accepted-upstream-plan',
+        contextPath: upstream,
+      }),
+    );
+  });
+  it('refuses a non-owning supplied plan when its own plan is missing', () => {
+    const root = fixture(undefined);
+    expect(() => prepare(root, [other, scenario])).toThrow(
+      expect.objectContaining({
+        code: 'missing_planning_context',
+        contextRole: 'accepted-upstream-plan',
+        contextPath: upstream,
+      }),
+    );
+  });
+  it('captures its own plan even when another plan is explicitly supplied', () => {
+    const implementation =
+      '# Impl Plan\n\nPreserve authenticated approval.\n\n## Architecture applicability\n\nskip: No durable architecture records apply.\n\n## Data applicability\n\nskip: No product data is stored.\n';
+    const root = fixture(implementation);
+    const prepared = prepare(root, [other, scenario]);
+    try {
+      expect(prepared.packet.context_files).toEqual(
+        expect.arrayContaining([
+          expect.objectContaining({ path: upstream, content: implementation }),
+          expect.objectContaining({ path: other, content: '# Impl Plan\n\nAn unrelated plan.\n' }),
+        ]),
+      );
+    } finally {
+      prepared.cleanup();
+    }
+  });
+});
diff --git a/packages/cli/tests/review/implementation-context-ownership.test.ts b/packages/cli/tests/review/implementation-context-ownership.test.ts
new file mode 100644
index 000000000..0eff6c631
--- /dev/null
+++ b/packages/cli/tests/review/implementation-context-ownership.test.ts
@@ -0,0 +1,83 @@
+import { mkdirSync, mkdtempSync, rmSync, writeFileSync } from 'node:fs';
+import { tmpdir } from 'node:os';
+import nodePath from 'node:path';
+
+import { afterEach, describe, expect, it } from 'vitest';
+
+import { prepareReviewPacket } from '../../src/review/packet.js';
+import { writePlanningInventories } from '../planning-fixtures.js';
+import { PLANNING_ROLE_PRODUCT, writeImplementationRoleInputs } from '../planning-role-fixtures.js';
+
+const roots: string[] = [];
+const folder = '.project/tickets/OWN123-owned';
+const target = `${folder}/impl-plan.md`;
+const parentFolder = '.project/tickets/000123-parent';
+const metadata = 'id: OWN123\ntype: feature\nproduct_plan_contract: v1';
+
+afterEach(() => {
+  for (const root of roots) rmSync(root, { recursive: true, force: true });
+  roots.length = 0;
+});
+
+function fixture(ticket = metadata) {
+  const root = mkdtempSync(nodePath.join(tmpdir(), 'safeword-implementation-context-'));
+  roots.push(root);
+  writePlanningInventories(root);
+  mkdirSync(nodePath.join(root, folder), { recursive: true });
+  writeFileSync(nodePath.join(root, folder, 'ticket.md'), `---\n${ticket}\n---\n`);
+  writeFileSync(
+    nodePath.join(root, folder, 'spec.md'),
+    ticket.startsWith(metadata) ? PLANNING_ROLE_PRODUCT : '# Product Plan\n\nPreserve approval.\n',
+  );
+  writeFileSync(nodePath.join(root, target), '# Impl Plan\n\nPreserve approval.\n');
+  if (ticket.startsWith(metadata)) writeImplementationRoleInputs(root, target, 'owned.feature');
+  return root;
+}
+
+function context(root: string) {
+  const prepared = prepareReviewPacket(root, 'plan-implementation', [target]);
+  try {
+    return prepared.packet.context_files?.map(file => file.path);
+  } finally {
+    prepared.cleanup();
+  }
+}
+
+describe('Implementation Product context ownership', () => {
+  it('resolves a numeric-looking declared parent ID without changing its spelling', () => {
+    const root = fixture(`${metadata}\nparent: 000123\nparent_job: approval.BU1\nmilestone: M1`);
+    mkdirSync(nodePath.join(root, parentFolder), { recursive: true });
+    writeFileSync(
+      nodePath.join(root, parentFolder, 'ticket.md'),
+      '---\nid: 000123\ntype: epic\n---\n',
+    );
+    writeFileSync(nodePath.join(root, parentFolder, 'spec.md'), PLANNING_ROLE_PRODUCT);
+    expect(context(root)).toEqual(
+      expect.arrayContaining([
+        `${folder}/ticket.md`,
+        `${folder}/spec.md`,
+        `${parentFolder}/ticket.md`,
+        `${parentFolder}/spec.md`,
+      ]),
+    );
+  });
+  it('reports an unresolved declared parent before a missing own Product Plan', () => {
+    const root = fixture(`${metadata}\nparent: 000123\nparent_job: approval.BU1\nmilestone: M1`);
+    rmSync(nodePath.join(root, folder, 'spec.md'));
+    expect(() => context(root)).toThrow(
+      expect.objectContaining({
+        code: 'missing_planning_context',
+        contextRole: 'parent',
+        contextPath: '.project/tickets/000123/spec.md',
+      }),
+    );
+  });
+  it.each([
+    ['legacy feature', 'id: OWN123\ntype: feature'],
+    ['task', 'id: OWN123\ntype: task\nproduct_plan_contract: v1'],
+  ])('preserves generic %s reviews', (_label, ticket) => {
+    const root = fixture(ticket);
+    rmSync(nodePath.join(root, folder, 'spec.md'));
+    expect(context(root) ?? []).not.toContain(`${folder}/ticket.md`);
+  });
+});
diff --git a/packages/cli/tests/review/implementation-role-selected-parent.test.ts b/packages/cli/tests/review/implementation-role-selected-parent.test.ts
new file mode 100644
index 000000000..9394e2f0b
--- /dev/null
+++ b/packages/cli/tests/review/implementation-role-selected-parent.test.ts
@@ -0,0 +1,164 @@
+import { mkdirSync, mkdtempSync, rmSync, writeFileSync } from 'node:fs';
+import { tmpdir } from 'node:os';
+import nodePath from 'node:path';
+
+import { afterEach, describe, expect, it } from 'vitest';
+
+import { EXECUTION_PLAN_CONFORMANCE_CASES } from '../../src/review/execution-plan-conformance.js';
+import { prepareReviewPacket } from '../../src/review/packet.js';
+import {
+  createPlanningReviewIdentity,
+  productParentContextIdentity,
+} from '../../src/review/planning-context-identity.js';
+import { writePlanningInventories } from '../planning-fixtures.js';
+
+const delivery = EXECUTION_PLAN_CONFORMANCE_CASES.find(value => value.id === 'one-coherent-change');
+if (delivery === undefined) throw new Error('Missing canonical Execution fixture');
+const executionPlan = delivery.execution_plan;
+const roots: string[] = [];
+const parentPath = '.project/tickets/000123-parent/spec.md';
+const child = '.project/tickets/OWN123-child';
+const target = `${child}/impl-plan.md`;
+const feature = 'features/child.feature';
+const parent = `# Parent Product Plan
+
+## Product Bet
+
+- **Expected outcome:** Builder can trust approval.
+- **Persona outcome inventory:** Builder receives current approval.
+- **Known facts:** Approval is authenticated.
+- **Assumptions:** Review remains available.
+- **Unresolved product decisions:** none
+- **Success threshold:** Current approval advances.
+- **Project non-goals:** No anonymous approval.
+
+## Jobs To Be Done
+
+### approval.BU1 — Trust approval
+
+**Persona:** Builder (BU)
+
+#### approval.BU1.R1 — Preserve approval
+
+Only current approval advances.
+
+### approval.BU2 — Unrelated work
+
+Builder can do another task.
+
+## Shape
+
+### M1 — Current approval
+
+- **Outcome:** Review is current.
+- **Non-goals:** Anonymous approval.
+
+### M2 — Unrelated milestone
+
+An unrelated delivery remains available.
+`;
+
+function project(): string {
+  const root = mkdtempSync(nodePath.join(tmpdir(), 'safeword-implementation-parent-'));
+  roots.push(root);
+  writePlanningInventories(root);
+  for (const folder of [child, '.project/tickets/000123-parent', 'features'])
+    mkdirSync(nodePath.join(root, folder), { recursive: true });
+  writeFileSync(
+    nodePath.join(root, `${child}/ticket.md`),
+    `---\nid: OWN123\ntype: feature\nproduct_plan_contract: v1\nparent: 000123\nparent_job: approval.BU1\nmilestone: M1\nphase_anchors:\n  - scenario-gate: ${feature}\n---\n`,
+  );
+  writeFileSync(
+    nodePath.join(root, '.project/tickets/000123-parent/ticket.md'),
+    '---\nid: 000123\ntype: epic\n---\n',
+  );
+  writeFileSync(nodePath.join(root, parentPath), parent);
+  writeFileSync(
+    nodePath.join(root, `${child}/spec.md`),
+    '# Child Contribution\n\n## Jobs To Be Done\n\n### approval.BU1 — Trust approval\n\n#### approval.BU1.R1 — Preserve approval\n\nOnly current approval advances.\n',
+  );
+  writeFileSync(
+    nodePath.join(root, target),
+    '# Implementation Plan\n\n## Approach\n\nPreserve authenticated approval.\n\n## Design alignment\n\nArchitecture applicability: skip: No durable architecture record applies.\n\n### Data applicability\n\nData applicability: skip: No product data is stored.\n',
+  );
+  writeFileSync(nodePath.join(root, `${child}/execution-plan.md`), executionPlan);
+  writeFileSync(
+    nodePath.join(root, feature),
+    '@approval.BU1.R1 @surface.safeword-cli\nFeature: Trust approval\n  Scenario: Current approval\n    Given current evidence\n',
+  );
+  return root;
+}
+
+function executionIdentity(root: string) {
+  const prepared = prepareReviewPacket(
+    root,
+    'plan-execution',
+    [`${child}/execution-plan.md`],
+    [target, feature],
+  );
+  try {
+    return createPlanningReviewIdentity(prepared.packet);
+  } finally {
+    prepared.cleanup();
+  }
+}
+
+function identity(root: string) {
+  const prepared = prepareReviewPacket(root, 'plan-implementation', [target], [feature]);
+  try {
+    return createPlanningReviewIdentity(prepared.packet);
+  } finally {
+    prepared.cleanup();
+  }
+}
+
+afterEach(() => {
+  for (const root of roots) rmSync(root, { recursive: true, force: true });
+  roots.length = 0;
+});
+
+describe('Implementation child selected-parent review identity', () => {
+  it('projects the declared ticket even when the sibling Product Plan is not captured', () => {
+    const root = project();
+    const prepared = prepareReviewPacket(root, 'plan-implementation', [target], [feature]);
+    try {
+      const packet = {
+        ...prepared.packet,
+        context_files: prepared.packet.context_files?.filter(
+          file => file.path !== `${child}/spec.md`,
+        ),
+      };
+      expect(productParentContextIdentity(packet).has(`${child}/ticket.md`)).toBe(true);
+    } finally {
+      prepared.cleanup();
+    }
+  });
+  it('retains approval after an unrelated parent job changes', () => {
+    const root = project();
+    const before = identity(root);
+    writeFileSync(
+      nodePath.join(root, parentPath),
+      parent.replace('Builder can do another task.', 'Builder can do a revised unrelated task.'),
+    );
+    expect(identity(root)).toEqual(before);
+  });
+
+  it('stales approval after the selected parent outcome changes', () => {
+    const root = project();
+    const before = identity(root);
+    writeFileSync(
+      nodePath.join(root, parentPath),
+      parent.replace('Review is current.', 'Review is current and attributable.'),
+    );
+    expect(identity(root)).not.toEqual(before);
+  });
+  it('retains Execution approval after an unrelated parent job changes', () => {
+    const root = project();
+    const before = executionIdentity(root);
+    writeFileSync(
+      nodePath.join(root, parentPath),
+      parent.replace('Builder can do another task.', 'Builder can do a revised unrelated task.'),
+    );
+    expect(executionIdentity(root)).toEqual(before);
+  });
+});
diff --git a/packages/cli/tests/review/implementation-ticket-identity.test.ts b/packages/cli/tests/review/implementation-ticket-identity.test.ts
new file mode 100644
index 000000000..6d3460a89
--- /dev/null
+++ b/packages/cli/tests/review/implementation-ticket-identity.test.ts
@@ -0,0 +1,53 @@
+import { describe, expect, it } from 'vitest';
+
+import type { ReviewPacket } from '../../src/review/contract.js';
+import { productParentContextIdentity } from '../../src/review/planning-context-identity.js';
+
+const ticketPath = '.project/tickets/OWN123-owned/ticket.md';
+const ticket =
+  '---\nid: OWN123\ntype: feature\nphase: intake\nstatus: in_progress\nlast_modified: yesterday\nproduct_plan_contract: v1\nscope: preserve approval\nout_of_scope: anonymous approval\ndone_when: current approval advances\n---\n# Ticket\n\nPreserve authentication.\n';
+
+function projected(content: string) {
+  const packet: ReviewPacket = {
+    schema_version: 1,
+    dispatch_id: 'implementation-ticket-identity',
+    kind: 'plan-implementation',
+    planning_phase: 'plan-implementation',
+    planning_context: {
+      schema_version: 1,
+      ticket_id: 'OWN123',
+      ticket_path: ticketPath,
+      dependencies: [{ role: 'ticket', path: ticketPath }],
+      absences: [],
+    },
+    logical_files: [{ path: '.project/tickets/OWN123-owned/impl-plan.md', content: '# Impl Plan' }],
+    context_files: [{ path: ticketPath, content }],
+  };
+  const value = productParentContextIdentity(packet).get(ticketPath);
+  expect(value).toEqual(expect.any(String));
+  return value;
+}
+
+describe('Implementation ticket semantic projection', () => {
+  it.each([
+    ['phase: intake', 'phase: define-behavior'],
+    ['status: in_progress', 'status: done'],
+    ['last_modified: yesterday', 'last_modified: today'],
+    ['scope: preserve approval', 'scope: "preserve approval"'],
+    ['# Ticket', '<!-- editorial -->\n\n# Ticket'],
+  ])('ignores cosmetic or administrative %s', (before, after) => {
+    const changed = ticket.replace(before, () => after);
+    expect(changed).not.toBe(ticket);
+    expect(projected(changed)).toBe(projected(ticket));
+  });
+  it.each([
+    ['scope: preserve approval', 'scope: permit anonymous approval'],
+    ['out_of_scope: anonymous approval', 'out_of_scope: none'],
+    ['done_when: current approval advances', 'done_when: any approval advances'],
+    ['Preserve authentication.', 'Remove authentication.'],
+  ])('retains decision-bearing %s', (before, after) => {
+    const changed = ticket.replace(before, () => after);
+    expect(changed).not.toBe(ticket);
+    expect(projected(changed)).not.toBe(projected(ticket));
+  });
+});
diff --git a/packages/cli/tests/review/implementation-ticket-ownership.test.ts b/packages/cli/tests/review/implementation-ticket-ownership.test.ts
new file mode 100644
index 000000000..f5c722445
--- /dev/null
+++ b/packages/cli/tests/review/implementation-ticket-ownership.test.ts
@@ -0,0 +1,50 @@
+import { mkdirSync, mkdtempSync, rmSync, writeFileSync } from 'node:fs';
+import { tmpdir } from 'node:os';
+import nodePath from 'node:path';
+
+import { afterEach, describe, expect, it } from 'vitest';
+
+import { prepareReviewPacket } from '../../src/review/packet.js';
+import { productParentContextIdentity } from '../../src/review/planning-context-identity.js';
+import { writePlanningInventories } from '../planning-fixtures.js';
+import { PLANNING_ROLE_PRODUCT, writeImplementationRoleInputs } from '../planning-role-fixtures.js';
+
+const roots: string[] = [];
+afterEach(() => {
+  for (const root of roots) rmSync(root, { recursive: true, force: true });
+  roots.length = 0;
+});
+
+describe('Implementation semantic ticket ownership', () => {
+  it.each([
+    ['owned feature', '.project/tickets/OWN123-owned', 'feature', 'v1', true],
+    ['legacy feature', '.project/tickets/OWN123-owned', 'feature', 'legacy', false],
+    ['task', '.project/tickets/OWN123-owned', 'task', 'v1', false],
+    ['generic supplied ticket', 'OWN123-generic', 'feature', 'v1', false],
+  ] as const)('projects only the %s ticket', (_label, folder, type, contract, owned) => {
+    const root = mkdtempSync(nodePath.join(tmpdir(), 'safeword-implementation-owner-'));
+    roots.push(root);
+    writePlanningInventories(root);
+    mkdirSync(nodePath.join(root, folder), { recursive: true });
+    const ticket = `${folder}/ticket.md`;
+    const spec = `${folder}/spec.md`;
+    const target = `${folder}/impl-plan.md`;
+    writeFileSync(
+      nodePath.join(root, ticket),
+      `---\nid: OWN123\ntype: ${type}\nproduct_plan_contract: ${contract}\nscope: preserve approval\n---\n`,
+    );
+    writeFileSync(
+      nodePath.join(root, spec),
+      owned ? PLANNING_ROLE_PRODUCT : '# Product Plan\n\nPreserve approval.\n',
+    );
+    writeFileSync(nodePath.join(root, target), '# Impl Plan\n\nPreserve approval.\n');
+    if (owned) writeImplementationRoleInputs(root, target, 'owned.feature');
+    const prepared = prepareReviewPacket(root, 'plan-implementation', [target], [ticket, spec]);
+    try {
+      expect(prepared.packet.planning_phase).toBe(owned ? 'plan-implementation' : undefined);
+      expect(productParentContextIdentity(prepared.packet).has(ticket)).toBe(owned);
+    } finally {
+      prepared.cleanup();
+    }
+  });
+});
diff --git a/packages/cli/tests/review/job.test.ts b/packages/cli/tests/review/job.test.ts
index 70c722239..0f450aa39 100644
--- a/packages/cli/tests/review/job.test.ts
+++ b/packages/cli/tests/review/job.test.ts
@@ -32,6 +32,7 @@ import {
 } from '../../src/review/job.js';
 import { readReviewReceipt } from '../../templates/hooks/lib/read-receipt.js';
 import { receiptGateVerdict } from '../../templates/hooks/lib/review-receipt.js';
+import { writePlanningInventories } from '../planning-fixtures.js';
 import {
   cleanupTrustedReviewerDirectories,
   createTrustedReviewerDirectory,
@@ -153,6 +154,7 @@ function executionPlanWithDeliveryContract(): string {
 
 function executionPlanProject(): string {
   const cwd = project();
+  writePlanningInventories(cwd);
   mkdirSync(nodePath.join(cwd, '.safeword'), { recursive: true });
   writeFileSync(nodePath.join(cwd, '.safeword', 'config.json'), '{"designApprovalGate":false}\n');
   writeFileSync(nodePath.join(cwd, 'execution-plan.md'), executionPlanWithDeliveryContract());
diff --git a/packages/cli/tests/review/packet.test.ts b/packages/cli/tests/review/packet.test.ts
index 0454d1923..ace0732e9 100644
--- a/packages/cli/tests/review/packet.test.ts
+++ b/packages/cli/tests/review/packet.test.ts
@@ -23,6 +23,18 @@ const temporaryDirectories: string[] = [];
 
 function temporaryDirectory(): string {
   const directory = mkdtempSync(nodePath.join(tmpdir(), 'safeword-packet-test-'));
+  mkdirSync(nodePath.join(directory, '.project'));
+  const inventories = {
+    principles:
+      '# Principles\n\n## Preserve approval authority\n\nCurrent authenticated approval controls advancement.\n',
+    personas:
+      '# Personas\n\n## Builder (BU)\n\n**Role:** A builder requesting planning approval.\n**Context:** Needs current authenticated approval before advancement.\n',
+    surfaces:
+      '# Surfaces\n\n## Safeword CLI\n\n**Kind:** CLI\n**Description:** Requests and presents planning approval.\n**Audience:** Builder (BU)\n',
+  };
+  for (const [role, content] of Object.entries(inventories)) {
+    writeFileSync(nodePath.join(directory, '.project', `${role}.md`), content);
+  }
   temporaryDirectories.push(directory);
   return directory;
 }
@@ -91,6 +103,28 @@ afterEach(() => {
 });
 
 describe('review packet containment and change accounting', () => {
+  it.each([
+    ['missing ticket', undefined],
+    ['malformed ticket', '---\nid: LEG123\nid: DUP123\n---\n'],
+  ])('keeps a generic spec review available beside a %s', (_case, ticketSource) => {
+    const root = temporaryDirectory();
+    const directory = nodePath.join(root, '.project', 'tickets', 'LEG123-legacy');
+    mkdirSync(directory, { recursive: true });
+    if (ticketSource !== undefined)
+      writeFileSync(nodePath.join(directory, 'ticket.md'), ticketSource);
+    writeFileSync(nodePath.join(directory, 'spec.md'), '# Generic spec\n');
+
+    const prepared = prepareReviewPacket(root, 'quality-review', [
+      '.project/tickets/LEG123-legacy/spec.md',
+    ]);
+    try {
+      expect(prepared.packet.planning_phase).toBeUndefined();
+      expect(prepared.packet.plan_contract).toBeUndefined();
+    } finally {
+      prepared.cleanup();
+    }
+  });
+
   it('uses forward slashes for Git attribute paths on Windows', () => {
     expect(toReviewPath(String.raw`generated\nested\output.js`, nodePath.win32.sep)).toBe(
       'generated/nested/output.js',
@@ -143,7 +177,12 @@ describe('review packet containment and change accounting', () => {
     );
     try {
       expect(prepared.packet.logical_files.map(file => file.path)).toEqual(['impl-plan.md']);
-      expect(prepared.packet.context_files?.map(file => file.path)).toEqual(['spec.md']);
+      expect(prepared.packet.context_files?.map(file => file.path)).toEqual([
+        'spec.md',
+        '.project/principles.md',
+        '.project/personas.md',
+        '.project/surfaces.md',
+      ]);
       expect(prepared.packet.plan_contract?.author).toEqual(
         prepared.packet.plan_contract?.reviewer,
       );
@@ -154,6 +193,31 @@ describe('review packet containment and change accounting', () => {
     }
   });
 
+  it('does not require planning inventories for a ticket without the planning contract', () => {
+    const root = temporaryDirectory();
+    const ticket = nodePath.join(root, '.project', 'tickets', 'LEG123-legacy');
+    mkdirSync(ticket, { recursive: true });
+    writeFileSync(nodePath.join(ticket, 'ticket.md'), '---\nid: LEG123\ntype: task\n---\n');
+    writeFileSync(nodePath.join(ticket, 'impl-plan.md'), '# Implementation Plan\n');
+    writeFileSync(nodePath.join(ticket, 'spec.md'), '# Legacy spec\n');
+    unlinkSync(nodePath.join(root, '.project', 'surfaces.md'));
+
+    const prepared = prepareReviewPacket(
+      root,
+      'plan-implementation',
+      ['.project/tickets/LEG123-legacy/impl-plan.md'],
+      ['.project/tickets/LEG123-legacy/spec.md'],
+    );
+    try {
+      expect(prepared.packet.planning_context).toBeUndefined();
+      expect(prepared.packet.context_files?.map(file => file.path)).toEqual([
+        '.project/tickets/LEG123-legacy/spec.md',
+      ]);
+    } finally {
+      prepared.cleanup();
+    }
+  });
+
   it('rejects supporting evidence supplied as plan-review work', () => {
     const root = temporaryDirectory();
     writeFileSync(nodePath.join(root, 'impl-plan.md'), '# Plan\n');
@@ -182,6 +246,9 @@ describe('review packet containment and change accounting', () => {
       expect(prepared.packet.context_files?.map(file => file.path)).toEqual([
         'impl-plan.md',
         'behavior.feature',
+        '.project/principles.md',
+        '.project/personas.md',
+        '.project/surfaces.md',
       ]);
       expect(prepared.packet.plan_contract?.author).toEqual(
         prepared.packet.plan_contract?.reviewer,
diff --git a/packages/cli/tests/review/planning-accepted-boundary.test.ts b/packages/cli/tests/review/planning-accepted-boundary.test.ts
new file mode 100644
index 000000000..fe50ac721
--- /dev/null
+++ b/packages/cli/tests/review/planning-accepted-boundary.test.ts
@@ -0,0 +1,98 @@
+import { createHash } from 'node:crypto';
+
+import { describe, expect, it } from 'vitest';
+
+import {
+  acceptedBoundaryDigest,
+  reviewDispositionContext,
+} from '../../src/review/planning-accepted-boundary.js';
+import { PLANNING_ROLE_PRODUCT } from '../planning-role-fixtures.js';
+
+const ticket = `---
+id: CHILD
+type: feature
+scope:
+  - preserve current approval
+out_of_scope:
+  - anonymous approval
+parent: PARENT
+parent_job: approval.BU1
+milestone: M1
+---
+# Ticket
+`;
+
+describe('accepted boundary of a user decline', () => {
+  it('excludes dispositions while tracking scope, parent job and milestone boundaries', () => {
+    const before = acceptedBoundaryDigest(ticket, PLANNING_ROLE_PRODUCT);
+    const withDisposition = ticket.replace(
+      '---\n# Ticket',
+      'review_dispositions:\n  - review_kind: plan-implementation\n    disposition: declined\n---\n# Ticket',
+    );
+    expect(acceptedBoundaryDigest(withDisposition, PLANNING_ROLE_PRODUCT)).toBe(before);
+    expect(
+      acceptedBoundaryDigest(
+        ticket.replace('preserve current approval', 'expand approval'),
+        PLANNING_ROLE_PRODUCT,
+      ),
+    ).not.toBe(before);
+    expect(
+      acceptedBoundaryDigest(
+        ticket,
+        PLANNING_ROLE_PRODUCT.replace(
+          'Current approval advances.',
+          'Current approval is attributable.',
+        ),
+      ),
+    ).not.toBe(before);
+    expect(
+      acceptedBoundaryDigest(
+        ticket,
+        PLANNING_ROLE_PRODUCT.replace('Anonymous approval.', 'No anonymous or delegated approval.'),
+      ),
+    ).not.toBe(before);
+  });
+  it('keeps a decline current when parent boundary wording only changes Markdown emphasis', () => {
+    expect(
+      acceptedBoundaryDigest(
+        ticket,
+        PLANNING_ROLE_PRODUCT.replace('Anonymous approval.', '_Anonymous_ approval.'),
+      ),
+    ).toBe(acceptedBoundaryDigest(ticket, PLANNING_ROLE_PRODUCT));
+  });
+
+  it('preserves a recorded decline as superseded history after a boundary change', () => {
+    const digest = acceptedBoundaryDigest(ticket, PLANNING_ROLE_PRODUCT);
+    const fingerprint = createHash('sha256')
+      .update(JSON.stringify({ severity: 'warning', message: 'Optional audit export.' }))
+      .digest('hex');
+    const recorded = ticket.replace(
+      '---\n# Ticket',
+      () =>
+        `review_dispositions:\n  - version: 1\n    review_id: prior-review\n    review_kind: plan-implementation\n    finding_fingerprint: ${fingerprint}\n    finding_severity: warning\n    finding_message: Optional audit export.\n    accepted_boundary_digest: ${digest}\n    disposition: declined\n    reason: outside scope\n---\n# Ticket`,
+    );
+    expect(
+      reviewDispositionContext(recorded, PLANNING_ROLE_PRODUCT, 'plan-implementation')?.records[0]
+        ?.boundary_status,
+    ).toBe('current');
+    expect(
+      reviewDispositionContext(
+        recorded.replace('preserve current approval', 'expanded approval'),
+        PLANNING_ROLE_PRODUCT,
+        'plan-implementation',
+      )?.records[0]?.boundary_status,
+    ).toBe('superseded');
+    expect(
+      reviewDispositionContext(recorded, PLANNING_ROLE_PRODUCT, 'quality-review')?.records,
+    ).toEqual([]);
+  });
+  it('rejects a malformed recorded decline instead of silently hiding it', () => {
+    const invalid = ticket.replace(
+      '---\n# Ticket',
+      () => 'review_dispositions:\n  - malformed\n---\n# Ticket',
+    );
+    expect(() =>
+      reviewDispositionContext(invalid, PLANNING_ROLE_PRODUCT, 'quality-review'),
+    ).toThrow('review dispositions are invalid');
+  });
+});
diff --git a/packages/cli/tests/review/planning-applicability.test.ts b/packages/cli/tests/review/planning-applicability.test.ts
new file mode 100644
index 000000000..baf06f318
--- /dev/null
+++ b/packages/cli/tests/review/planning-applicability.test.ts
@@ -0,0 +1,31 @@
+import { describe, expect, it } from 'vitest';
+
+import { planningSkipReason } from '../../src/review/planning-context-identity.js';
+
+describe('Implementation applicability declarations', () => {
+  it('retains a justified depth-two skip', () => {
+    expect(
+      planningSkipReason(
+        '# Plan\n\n## Data applicability\n\nskip: No data is stored.\n',
+        'Data applicability',
+      ),
+    ).toBe('No data is stored.');
+  });
+  it('accepts the shipped template depth-three Data declaration as applicable', () => {
+    const plan =
+      '# Plan\n\n## Approach\n\n### Data applicability\n\nData applicability: review provenance changes a durable schema.\n\n- **Purpose:** authenticate the current scope.\n';
+    expect(planningSkipReason(plan, 'Data applicability')).toBeUndefined();
+  });
+  it('recognizes the shipped template inline Architecture skip', () => {
+    const plan =
+      '# Plan\n\n## Design alignment\n\nArchitecture applicability: skip: No durable architecture record applies.\n';
+    expect(planningSkipReason(plan, 'Architecture applicability')).toBe(
+      'No durable architecture record applies.',
+    );
+  });
+  it('does not interpret unrelated prose as an Architecture declaration', () => {
+    const plan =
+      '# Plan\n\n## Approach\n\nA code example says `Architecture applicability: skip: pretend`.\n\n## Design alignment\n\nThe current decisions still apply.\n';
+    expect(() => planningSkipReason(plan, 'Architecture applicability')).toThrow();
+  });
+});
diff --git a/packages/cli/tests/review/planning-context.test.ts b/packages/cli/tests/review/planning-context.test.ts
new file mode 100644
index 000000000..d3f569365
--- /dev/null
+++ b/packages/cli/tests/review/planning-context.test.ts
@@ -0,0 +1,123 @@
+import { mkdirSync, mkdtempSync, rmSync, writeFileSync } from 'node:fs';
+import { tmpdir } from 'node:os';
+import nodePath from 'node:path';
+
+import { afterEach, describe, expect, it } from 'vitest';
+
+import { prepareReviewPacket } from '../../src/review/packet.js';
+
+const projects: string[] = [];
+
+function project(): string {
+  const root = mkdtempSync(nodePath.join(tmpdir(), 'safeword-context-role-'));
+  projects.push(root);
+  mkdirSync(nodePath.join(root, '.project'));
+  writeFileSync(
+    nodePath.join(root, 'impl-plan.md'),
+    '# Impl Plan\n\nPreserve accepted behavior.\n',
+  );
+  writeFileSync(nodePath.join(root, 'spec.md'), '# Product Plan\n\nPreserve accepted behavior.\n');
+  for (const role of ['principles', 'personas', 'surfaces']) {
+    writeFileSync(nodePath.join(root, '.project', `${role}.md`), `# ${role}\n\nCURRENT ${role}\n`);
+  }
+  return root;
+}
+
+afterEach(() => {
+  for (const root of projects) rmSync(root, { recursive: true, force: true });
+  projects.length = 0;
+});
+
+describe('required planning inventory sources at packet preparation', () => {
+  it.each(['personas', 'surfaces'])(
+    'includes the current %s without caller-supplied context',
+    role => {
+      const root = project();
+      const prepared = prepareReviewPacket(
+        root,
+        'plan-implementation',
+        ['impl-plan.md'],
+        ['spec.md'],
+      );
+      try {
+        const source = prepared.packet.context_files?.find(
+          file => file.path === `.project/${role}.md`,
+        );
+        expect(source).toMatchObject({
+          path: `.project/${role}.md`,
+          content: expect.stringContaining(`CURRENT ${role}`),
+        });
+      } finally {
+        prepared.cleanup();
+      }
+    },
+  );
+
+  it.each(['personas', 'surfaces'])('refuses a missing required %s source', role => {
+    const root = project();
+    rmSync(nodePath.join(root, '.project', `${role}.md`));
+    let failure: unknown;
+    try {
+      const prepared = prepareReviewPacket(
+        root,
+        'plan-implementation',
+        ['impl-plan.md'],
+        ['spec.md'],
+      );
+      prepared.cleanup();
+    } catch (error) {
+      failure = error;
+    }
+    expect(failure).toMatchObject({
+      code: 'missing_planning_context',
+      contextRole: role,
+      contextPath: `.project/${role}.md`,
+    });
+  });
+  it('retains an explicitly supplied principles source exactly once', () => {
+    const root = project();
+    const prepared = prepareReviewPacket(
+      root,
+      'plan-implementation',
+      ['impl-plan.md'],
+      ['spec.md', '.project/principles.md'],
+    );
+    try {
+      const sources = prepared.packet.context_files?.filter(
+        file => file.path === '.project/principles.md',
+      );
+      expect(sources).toHaveLength(1);
+    } finally {
+      prepared.cleanup();
+    }
+  });
+
+  it.each(['principles', 'personas', 'surfaces'])(
+    'refuses a broken %s override despite an intact default',
+    role => {
+      const root = project();
+      mkdirSync(nodePath.join(root, '.safeword'));
+      writeFileSync(
+        nodePath.join(root, '.safeword/config.json'),
+        JSON.stringify({ paths: { [role]: '' } }),
+      );
+      let failure: unknown;
+      try {
+        const prepared = prepareReviewPacket(
+          root,
+          'plan-implementation',
+          ['impl-plan.md'],
+          ['spec.md'],
+        );
+        prepared.cleanup();
+      } catch (error) {
+        failure = error;
+      }
+      expect(failure).toMatchObject({
+        code: 'missing_planning_context',
+        contextRole: role,
+        contextPath: `.safeword/config.json:paths.${role}`,
+      });
+    },
+  );
+});
diff --git a/packages/cli/tests/review/planning-disposition-identity.test.ts b/packages/cli/tests/review/planning-disposition-identity.test.ts
new file mode 100644
index 000000000..64c883403
--- /dev/null
+++ b/packages/cli/tests/review/planning-disposition-identity.test.ts
@@ -0,0 +1,22 @@
+import { describe, expect, it } from 'vitest';
+
+import { semanticTicketIdentity } from '../../src/review/planning-context-identity.js';
+
+const before =
+  '---\nid: TEST\ntype: feature\nscope:\n  - preserve approved behavior\n---\n# Ticket\n';
+const after =
+  '---\nid: TEST\ntype: feature\nscope:\n  - preserve approved behavior\nreview_dispositions:\n  - version: 1\n    review_kind: plan-implementation\n    finding_fingerprint: abc\n    accepted_boundary_digest: def\n    disposition: declined\n    reason: outside scope\n---\n# Ticket\n';
+
+describe('planning disposition currency', () => {
+  it('stales only a review of the disposition’s own kind', () => {
+    expect(semanticTicketIdentity(after, 'plan-implementation')).not.toBe(
+      semanticTicketIdentity(before, 'plan-implementation'),
+    );
+    expect(semanticTicketIdentity(after, 'quality-review')).toBe(
+      semanticTicketIdentity(before, 'quality-review'),
+    );
+    expect(semanticTicketIdentity(after, 'plan-execution')).toBe(
+      semanticTicketIdentity(before, 'plan-execution'),
+    );
+  });
+});
diff --git a/packages/cli/tests/review/planning-markdown-semantics.test.ts b/packages/cli/tests/review/planning-markdown-semantics.test.ts
new file mode 100644
index 000000000..96e63408b
--- /dev/null
+++ b/packages/cli/tests/review/planning-markdown-semantics.test.ts
@@ -0,0 +1,163 @@
+import { describe, expect, it } from 'vitest';
+
+import type { ReviewPacket } from '../../src/review/contract.js';
+import {
+  productParentContextIdentity,
+  semanticMarkdownIdentity,
+} from '../../src/review/planning-context-identity.js';
+
+describe('meaning retained by planning context Markdown identity', () => {
+  it.each([
+    ['blank lines', '# Rule\n\nPreserve approval.\n', '# Rule\n\n\nPreserve approval.\n\n'],
+    ['prose wrapping', 'Preserve approval for Builders.', 'Preserve approval\nfor Builders.'],
+    [
+      'standalone comments',
+      '# Rule\n\nPreserve approval.',
+      '<!-- editorial -->\n\n# Rule\n\nPreserve approval.',
+    ],
+    ['inline comments', 'Preserve approval.', 'Preserve <!-- editorial -->approval.'],
+    ['heading edge comments', '## Product Bet', '## Product Bet <!-- editorial -->'],
+    ['paragraph edge comments', 'Preserve approval.', 'Preserve approval. <!-- editorial -->'],
+    [
+      'table-cell edge comments',
+      '| Rule | Value |\n| --- | --- |\n| Approval | current |',
+      '| Rule | Value |\n| --- | --- |\n| Approval | current <!-- editorial --> |',
+    ],
+    ['list spacing', '- First\n- Second\n', '- First\n\n- Second\n'],
+    ['code fence spelling', '```js\nconst value = 1;\n```', '~~~js\nconst value = 1;\n~~~'],
+  ])('ignores cosmetic %s', (_label, original, cosmetic) => {
+    expect(semanticMarkdownIdentity(cosmetic)).toBe(semanticMarkdownIdentity(original));
+  });
+  it.each([
+    ['literal identifiers', 'Rule scope_guard must pass.', 'Rule scopeguard must pass.'],
+    ['leading nonbreaking space', '\u{A0}Preserve approval.', 'Preserve approval.'],
+    ['trailing nonbreaking space', 'Preserve approval.\u{A0}', 'Preserve approval.'],
+    ['inline code whitespace', 'Use `a  b`.', 'Use `a b`.'],
+    ['code block whitespace', '```text\na  b\n```', '```text\na b\n```'],
+    ['comments inside code', '```text\n<!-- preserve -->\n```', '```text\n<!-- remove -->\n```'],
+    [
+      'link destinations',
+      '[guide](https://example.test/current)',
+      '[guide](https://example.test/obsolete)',
+    ],
+    ['meaningful order', '1. Authenticate\n2. Approve\n', '1. Approve\n2. Authenticate\n'],
+    ['hard line breaks', 'First\nSecond', 'First  \nSecond'],
+    [
+      'table values',
+      '| Rule | Value |\n| --- | --- |\n| Approval | current |',
+      '| Rule | Value |\n| --- | --- |\n| Approval | stale |',
+    ],
+    ['text between comments', '<!-- note -->approved<!-- note -->', '<!-- note --><!-- note -->'],
+  ])('retains meaningful %s', (_label, original, changed) => {
+    expect(semanticMarkdownIdentity(changed)).not.toBe(semanticMarkdownIdentity(original));
+  });
+});
+
+const childPath = '.project/tickets/CHD123-child/spec.md';
+const parentPath = '.project/tickets/PRT123-parent/spec.md';
+const productFields = [
+  'Expected outcome',
+  'Persona outcome inventory',
+  'Known facts',
+  'Assumptions',
+  'Unresolved product decisions',
+  'Success threshold',
+  'Project non-goals',
+];
+const productBet = productFields
+  .map(field => `- **${field}:** preserve current approval`)
+  .join('\n');
+const parentContext = `## Product Bet\n\n${productBet}\n\n## Jobs To Be Done\n\n### trust.BU1 — Trust approval\n\n**Persona:** Builder (BU)\n\n> When I request approval, I want current evidence, so I can trust advancement.\n\n- **Outcome:** Current evidence is visible.\n- **Constraints:** Follow [policy][current].\n\n#### trust.BU1.R1 — Keep parent evidence current\n\nCurrent parent evidence is required.\n\n### trust.RD1 — Find guidance\n\n**Persona:** Reader (RD)\n\n#### trust.RD1.R1 — Find current guidance\n\nGuidance has a readable index.\n\n## Shape\n\n### M1 — Trust review\n\n- **Outcome:** Preserve trust.\n- **Non-goals:** No provider changes.\n`;
+function parentIdentity(content: string) {
+  const packet: ReviewPacket = {
+    schema_version: 1,
+    dispatch_id: 'unit-projection',
+    kind: 'quality-review',
+    planning_phase: 'product-plan',
+    planning_context: {
+      schema_version: 1,
+      ticket_id: 'CHD123',
+      ticket_path: '.project/tickets/CHD123-child/ticket.md',
+      dependencies: [{ role: 'ticket', path: '.project/tickets/CHD123-child/ticket.md' }],
+      absences: [],
+    },
+    logical_files: [{ path: childPath, content: '# Feature Contribution' }],
+    context_files: [
+      {
+        path: '.project/tickets/CHD123-child/ticket.md',
+        content:
+          '---\nid: CHD123\nparent: PRT123\nparent_job: trust.BU1\nmilestone: M1\nscope: preserve approval\n---\n',
+      },
+      {
+        path: '.project/tickets/PRT123-parent/ticket.md',
+        content: '---\nid: PRT123\ntype: epic\nscope: preserve trust\n---\n',
+      },
+      { path: parentPath, content },
+    ],
+  };
+  return productParentContextIdentity(packet).get(parentPath);
+}
+
+describe('selected parent Markdown context meaning', () => {
+  const definition = '[current]: https://example.test/current\n';
+  it.each(['Jobs To Be Done', 'Shape'])(
+    'refuses selected content reclassified outside its owning %s section',
+    section => {
+      const original = `${parentContext}\n## Notes\n\n${definition}`;
+      const reclassified = original.replace(`## ${section}`, '## Unrelated Notes');
+      expect(reclassified).not.toBe(original);
+      expect(() => parentIdentity(reclassified)).toThrow(`one ${section} section`);
+    },
+  );
+  it('refuses ambiguous selected-job ownership', () => {
+    expect(() => parentIdentity(`${parentContext}\n${definition}\n## Jobs To Be Done\n`)).toThrow(
+      'one Jobs To Be Done section',
+    );
+  });
+  it('ignores an inline comment in a required section heading', () => {
+    const original = `${parentContext}\n## Notes\n\n${definition}`;
+    const cosmetic = original.replace('## Product Bet', '## Product<!-- editorial --> Bet');
+    expect(parentIdentity(cosmetic)).toBe(parentIdentity(original));
+  });
+  it('ignores a trailing comment in a required section heading', () => {
+    const original = `${parentContext}\n## Notes\n\n${definition}`;
+    const cosmetic = original.replace('## Product Bet', '## Product Bet <!-- editorial -->');
+    expect(parentIdentity(cosmetic)).toBe(parentIdentity(original));
+  });
+  it.each([
+    ['lineage ID', 'trust.BU1.R1', 'trust.BU1.R2'],
+    ['text', 'Current parent evidence is required.', 'Stale parent evidence is permitted.'],
+  ])('retains a selected inherited Rule %s', (_label, before, after) => {
+    const original = `${parentContext}\n## Notes\n\n${definition}`;
+    const changed = original.replace(before, () => after);
+    expect(changed).not.toBe(original);
+    expect(parentIdentity(changed)).not.toBe(parentIdentity(original));
+  });
+  it('ignores an unrelated inherited Rule change', () => {
+    const original = `${parentContext}\n## Notes\n\n${definition}`;
+    const unrelated = original.replace(
+      'Guidance has a readable index.',
+      'Guidance has a searchable index.',
+    );
+    expect(unrelated).not.toBe(original);
+    expect(parentIdentity(unrelated)).toBe(parentIdentity(original));
+  });
+  it('ignores where a referenced link definition is placed', () => {
+    expect(parentIdentity(`${parentContext}\n${definition}`)).toBe(
+      parentIdentity(`${parentContext}\n## Notes\n\n${definition}`),
+    );
+  });
+  it('retains a referenced destination outside the selected sections', () => {
+    const original = `${parentContext}\n## Notes\n\n${definition}`;
+    expect(
+      parentIdentity(
+        original.replace('https://example.test/current', 'https://example.test/obsolete'),
+      ),
+    ).not.toBe(parentIdentity(original));
+  });
+  it('refuses duplicate definitions for a selected reference', () => {
+    expect(() =>
+      parentIdentity(`${parentContext}\n## Notes\n\n${definition}${definition}`),
+    ).toThrow('missing or duplicate referenced link definitions');
+  });
+});
diff --git a/packages/cli/tests/review/planning-role-context.test.ts b/packages/cli/tests/review/planning-role-context.test.ts
new file mode 100644
index 000000000..41d189581
--- /dev/null
+++ b/packages/cli/tests/review/planning-role-context.test.ts
@@ -0,0 +1,176 @@
+import { mkdirSync, mkdtempSync, rmSync, writeFileSync } from 'node:fs';
+import { tmpdir } from 'node:os';
+import nodePath from 'node:path';
+
+import { afterEach, describe, expect, it } from 'vitest';
+
+import { prepareReviewPacket } from '../../src/review/packet.js';
+import { writePlanningInventories } from '../planning-fixtures.js';
+
+const roots: string[] = [];
+const folder = '.project/tickets/OWN123-owned';
+const target = `${folder}/impl-plan.md`;
+const ticketPath = `${folder}/ticket.md`;
+const scenario = `${folder}/behavior.feature`;
+const metadata = `---\nid: OWN123\ntype: feature\nproduct_plan_contract: v1\nphase_anchors:\n  - scenario-gate: ${scenario}\n---\n`;
+const spec = `# Product Plan
+
+## Product Bet
+
+- **Expected outcome:** Builders retain approval.
+- **Persona outcome inventory:** Builder receives approval.
+- **Known facts:** Approval is authenticated.
+- **Assumptions:** Review is available.
+- **Unresolved product decisions:** none
+- **Success threshold:** Approval advances.
+- **Project non-goals:** No anonymous approval.
+
+## Jobs To Be Done
+
+### approval.BU1 — Trust approval
+
+**Persona:** Builder (BU)
+
+#### approval.BU1.R1 — Preserve approval
+
+Current approval advances.
+`;
+const implementation = `# Impl Plan
+
+## Architecture applicability
+
+skip: No durable architecture records apply.
+
+## Data applicability
+
+skip: No product data is stored.
+`;
+function project() {
+  const root = mkdtempSync(nodePath.join(tmpdir(), 'safeword-role-context-'));
+  roots.push(root);
+  writePlanningInventories(root);
+  mkdirSync(nodePath.join(root, folder), { recursive: true });
+  for (const [path, content] of [
+    [ticketPath, metadata],
+    [`${folder}/spec.md`, spec],
+    [target, implementation],
+    [scenario, 'Feature: Trust approval\n  Scenario: Approval\n    Given current evidence\n'],
+  ] as const)
+    writeFileSync(nodePath.join(root, path), content);
+  return root;
+}
+function context(root: string) {
+  const prepared = prepareReviewPacket(root, 'plan-implementation', [target]);
+  try {
+    return prepared.packet.planning_context;
+  } finally {
+    prepared.cleanup();
+  }
+}
+afterEach(() => {
+  for (const root of roots) rmSync(root, { recursive: true, force: true });
+  roots.length = 0;
+});
+
+describe('owned Implementation role resolution', () => {
+  it('derives required scenarios and authorized optional absences', () => {
+    const result = context(project());
+    expect(result?.dependencies).toContainEqual({ role: 'scenarios', path: scenario });
+    expect(result?.absences).toEqual(
+      expect.arrayContaining([
+        expect.objectContaining({ role: 'dimensions', authority: ticketPath }),
+        expect.objectContaining({ role: 'architecture', authority: target }),
+        expect.objectContaining({ role: 'data', authority: target }),
+      ]),
+    );
+  });
+  it('uses the latest scenario anchor when a phase is repeated', () => {
+    const root = project();
+    writeFileSync(
+      nodePath.join(root, ticketPath),
+      metadata.replace('phase_anchors:\n', 'phase_anchors:\n  - scenario-gate: missing.feature\n'),
+    );
+    expect(context(root)?.dependencies).toContainEqual({ role: 'scenarios', path: scenario });
+  });
+  it.each(['missing', 'blank'])('refuses a %s scenario source', state => {
+    const root = project();
+    const path = nodePath.join(root, scenario);
+    if (state === 'missing') rmSync(path);
+    else writeFileSync(path, ' \n');
+    expect(() => context(root)).toThrow(
+      expect.objectContaining({ contextRole: 'scenarios', contextPath: scenario }),
+    );
+  });
+  it('captures present dimensions instead of claiming absence', () => {
+    const root = project();
+    const path = `${folder}/dimensions.md`;
+    writeFileSync(nodePath.join(root, path), '# Dimensions\n\nRequired versus optional.\n');
+    const result = context(root);
+    expect(result?.dependencies).toContainEqual({ role: 'dimensions', path });
+    expect(result?.absences.some(row => row.role === 'dimensions')).toBe(false);
+  });
+  it('captures existing architecture records despite a plan skip', () => {
+    const root = project();
+    writeFileSync(
+      nodePath.join(root, '.project/architecture.md'),
+      '# Decision\n\nPreserve authenticated authority.\n',
+    );
+    expect(context(root)?.dependencies).toContainEqual({
+      role: 'architecture',
+      path: '.project/architecture.md',
+    });
+  });
+  it('refuses an unjustified architecture absence', () => {
+    const root = project();
+    writeFileSync(
+      nodePath.join(root, target),
+      implementation.replace(
+        'skip: No durable architecture records apply.',
+        'Apply current architecture.',
+      ),
+    );
+    expect(() => context(root)).toThrow(expect.objectContaining({ contextRole: 'architecture' }));
+  });
+  it('names the first required inventory when config is malformed', () => {
+    const root = project();
+    mkdirSync(nodePath.join(root, '.safeword'), { recursive: true });
+    writeFileSync(nodePath.join(root, '.safeword/config.json'), '{"paths":');
+    expect(() => context(root)).toThrow(expect.objectContaining({ contextRole: 'principles' }));
+  });
+  it('names the missing plan declaration instead of the data guide', () => {
+    const root = project();
+    writeFileSync(
+      nodePath.join(root, target),
+      implementation.replace(
+        '## Data applicability\n\nskip: No product data is stored.',
+        '## Data decisions\n\nNo data declaration is present.',
+      ),
+    );
+    expect(() => context(root)).toThrow(
+      expect.objectContaining({
+        contextRole: 'data',
+        message: expect.stringContaining('Data applicability declaration'),
+      }),
+    );
+  });
+  it('refuses a missing triggered data guide', () => {
+    const root = project();
+    writeFileSync(
+      nodePath.join(root, target),
+      implementation.replace('skip: No product data is stored.', 'Persist product data.'),
+    );
+    expect(() => context(root)).toThrow(expect.objectContaining({ contextRole: 'data' }));
+  });
+  it.each(['blank', 'duplicate'])('refuses %s required Product framing', state => {
+    const root = project();
+    const changed =
+      state === 'blank'
+        ? spec.replace('Builders retain approval.', '')
+        : spec.replace(
+            '## Jobs To Be Done',
+            '- **Expected outcome:** Duplicate outcome.\n\n## Jobs To Be Done',
+          );
+    writeFileSync(nodePath.join(root, folder, 'spec.md'), changed);
+    expect(() => context(root)).toThrow(expect.objectContaining({ contextRole: 'project' }));
+  });
+});
diff --git a/packages/cli/tests/review/planning-role-record.test.ts b/packages/cli/tests/review/planning-role-record.test.ts
new file mode 100644
index 000000000..275e789e3
--- /dev/null
+++ b/packages/cli/tests/review/planning-role-record.test.ts
@@ -0,0 +1,172 @@
+import { describe, expect, it } from 'vitest';
+
+import { PLANNING_CONTEXT_ROLES } from '../../src/review/planning-context-error.js';
+import { isPlanningReviewIdentity } from '../../src/review/planning-role-context.js';
+
+const digest = 'a'.repeat(64);
+const requiredRoles = new Set([
+  'ticket',
+  'project',
+  'rules',
+  'scenarios',
+  'principles',
+  'personas',
+  'surfaces',
+]);
+function identity() {
+  return {
+    schema_version: 1,
+    ticket_id: 'OWN123',
+    ticket_path: '.project/tickets/OWN123-owned/ticket.md',
+    review_kind: 'plan-implementation',
+    targets: [{ path: '.project/tickets/OWN123-owned/impl-plan.md', digest }],
+    canonical_contract_digest: digest,
+    dependencies: [...requiredRoles].map(role => ({
+      role,
+      path: `.project/tickets/OWN123-owned/${role}.md`,
+      semantic_digest: digest,
+    })),
+    absences: PLANNING_CONTEXT_ROLES.filter(role => !requiredRoles.has(role)).map(role => ({
+      role,
+      reason: 'Not applicable to this reviewed artifact.',
+      authority: '.project/tickets/OWN123-owned/impl-plan.md',
+    })),
+  };
+}
+
+describe('stored planning identity admission', () => {
+  it('accepts distinct scenario-gate targets in one protected review record', () => {
+    const first = identity();
+    const scenario = {
+      ...first,
+      review_kind: 'scenario-gate',
+      targets: [
+        { path: 'features/approval.feature', digest },
+        { path: 'features/rejection.feature', digest },
+      ],
+    };
+    expect(isPlanningReviewIdentity(scenario)).toBe(true);
+    expect(isPlanningReviewIdentity({ ...scenario, targets: [scenario.targets[0]] })).toBe(true);
+    expect(
+      isPlanningReviewIdentity({
+        ...scenario,
+        targets: [scenario.targets[0], scenario.targets[0]],
+      }),
+    ).toBe(false);
+    expect(isPlanningReviewIdentity({ ...scenario, review_kind: 'plan-implementation' })).toBe(
+      false,
+    );
+  });
+
+  it('accepts a complete known record and multiple distinct records for one role', () => {
+    const value = identity();
+    expect(isPlanningReviewIdentity(value)).toBe(true);
+    value.dependencies.push({
+      role: 'ticket',
+      path: '.project/tickets/OWN123-owned/other.md',
+      semantic_digest: digest,
+    });
+    expect(isPlanningReviewIdentity(value)).toBe(true);
+  });
+
+  it('accepts Product identity only with phase-inapplicable roles absent', () => {
+    const value = identity();
+    const scenarios = value.dependencies.find(row => row.role === 'scenarios');
+    if (scenarios === undefined) throw new Error('Fixture needs a scenario dependency.');
+    const [target] = value.targets;
+    if (target === undefined) throw new Error('Fixture needs a target.');
+    const product = {
+      ...value,
+      review_kind: 'quality-review',
+      dependencies: value.dependencies.filter(row => row.role !== 'scenarios'),
+      absences: [
+        ...value.absences,
+        {
+          role: 'scenarios',
+          reason: 'Product review precedes scenario gate.',
+          authority: target.path,
+        },
+      ],
+    };
+    expect(isPlanningReviewIdentity(product)).toBe(true);
+    expect(
+      isPlanningReviewIdentity({
+        ...product,
+        dependencies: [...product.dependencies, scenarios],
+        absences: product.absences.filter(row => row.role !== 'scenarios'),
+      }),
+    ).toBe(false);
+  });
+
+  it.each([
+    ['unknown version', (value: ReturnType<typeof identity>) => ({ ...value, schema_version: 2 })],
+    [
+      'unknown field',
+      (value: ReturnType<typeof identity>) => ({ ...value, caller_complete: true }),
+    ],
+    [
+      'missing role',
+      (value: ReturnType<typeof identity>) => ({ ...value, absences: value.absences.slice(1) }),
+    ],
+    [
+      'unknown role',
+      (value: ReturnType<typeof identity>) => ({
+        ...value,
+        absences: [
+          ...value.absences,
+          { role: 'caller-context', reason: 'supplied', authority: 'caller' },
+        ],
+      }),
+    ],
+    [
+      'duplicate absence',
+      (value: ReturnType<typeof identity>) => ({
+        ...value,
+        absences: [...value.absences, value.absences[0]],
+      }),
+    ],
+    [
+      'duplicate dependency',
+      (value: ReturnType<typeof identity>) => ({
+        ...value,
+        dependencies: [...value.dependencies, value.dependencies[0]],
+      }),
+    ],
+    [
+      'conflicting role',
+      (value: ReturnType<typeof identity>) => ({
+        ...value,
+        absences: [...value.absences, { role: 'ticket', reason: 'absent', authority: 'caller' }],
+      }),
+    ],
+    [
+      'blank absence authority',
+      (value: ReturnType<typeof identity>) => ({
+        ...value,
+        absences: value.absences.map(row => ({ ...row, authority: ' ' })),
+      }),
+    ],
+    [
+      'malformed dependency digest',
+      (value: ReturnType<typeof identity>) => ({
+        ...value,
+        dependencies: value.dependencies.map(row => ({ ...row, semantic_digest: 'unknown' })),
+      }),
+    ],
+    ['missing exact target', (value: ReturnType<typeof identity>) => ({ ...value, targets: [] })],
+    [
+      'malformed target digest',
+      (value: ReturnType<typeof identity>) => ({
+        ...value,
+        targets: [{ ...value.targets[0], digest: 'unknown' }],
+      }),
+    ],
+    [
+      'malformed canonical contract digest',
+      (value: ReturnType<typeof identity>) => ({ ...value, canonical_contract_digest: 'unknown' }),
+    ],
+  ])('refuses %s before the record can supply approval authority', (_name, change) => {
+    const candidate = change(identity());
+    expect(isPlanningReviewIdentity(candidate)).toBe(false);
+  });
+});
diff --git a/packages/cli/tests/review/product-role-context.test.ts b/packages/cli/tests/review/product-role-context.test.ts
new file mode 100644
index 000000000..acb500e47
--- /dev/null
+++ b/packages/cli/tests/review/product-role-context.test.ts
@@ -0,0 +1,102 @@
+import { mkdirSync, mkdtempSync, rmSync, writeFileSync } from 'node:fs';
+import { tmpdir } from 'node:os';
+import nodePath from 'node:path';
+
+import { afterEach, describe, expect, it } from 'vitest';
+
+import { prepareReviewPacket } from '../../src/review/packet.js';
+import { PLANNING_CONTEXT_ROLES } from '../../src/review/planning-context-error.js';
+import { createPlanningReviewIdentity } from '../../src/review/planning-context-identity.js';
+import { writePlanningInventories } from '../planning-fixtures.js';
+
+const roots: string[] = [];
+const folder = '.project/tickets/OWN123-product';
+const target = `${folder}/spec.md`;
+const product = `# Product Plan
+
+## Product Bet
+
+- **Expected outcome:** Builders retain current approval.
+- **Persona outcome inventory:** Builder receives a current approval.
+- **Known facts:** Approval is authenticated.
+- **Assumptions:** Review is available.
+- **Unresolved product decisions:** none
+- **Success threshold:** Current approval advances.
+- **Project non-goals:** No anonymous approval.
+
+## Jobs To Be Done
+
+### approval.BU1 — Trust approval
+
+**Persona:** Builder (BU)
+
+#### approval.BU1.R1 — Preserve approval
+
+Current approval advances.
+`;
+function project(contract = 'v1') {
+  const root = mkdtempSync(nodePath.join(tmpdir(), 'safeword-product-role-'));
+  roots.push(root);
+  writePlanningInventories(root);
+  mkdirSync(nodePath.join(root, folder), { recursive: true });
+  writeFileSync(
+    nodePath.join(root, `${folder}/ticket.md`),
+    `---\nid: OWN123\ntype: feature\nproduct_plan_contract: ${contract}\n---\n`,
+  );
+  writeFileSync(nodePath.join(root, target), product);
+  return root;
+}
+afterEach(() => {
+  for (const root of roots) rmSync(root, { recursive: true, force: true });
+  roots.length = 0;
+});
+
+describe('Product review role context', () => {
+  it('derives a complete role set and durable identity for an owned Product target', () => {
+    const root = project();
+    const prepared = prepareReviewPacket(root, 'quality-review', [target]);
+    try {
+      expect(prepared.packet.planning_phase).toBe('product-plan');
+      const context = prepared.packet.planning_context;
+      expect(context, 'owned Product review must derive its planning role graph').toBeDefined();
+      const present = context?.dependencies.map(row => row.role) ?? [];
+      const absent = context?.absences.map(row => row.role) ?? [];
+      expect(new Set([...present, ...absent])).toEqual(new Set(PLANNING_CONTEXT_ROLES));
+      expect(present).toEqual(
+        expect.arrayContaining([
+          'ticket',
+          'project',
+          'rules',
+          'principles',
+          'personas',
+          'surfaces',
+        ]),
+      );
+      expect(absent).toEqual(
+        expect.arrayContaining([
+          'scenarios',
+          'dimensions',
+          'architecture',
+          'data',
+          'reusable-evidence',
+          'accepted-upstream-plan',
+        ]),
+      );
+      expect(createPlanningReviewIdentity(prepared.packet)).toMatchObject({
+        review_kind: 'quality-review',
+        ticket_id: 'OWN123',
+        targets: [expect.objectContaining({ path: target })],
+      });
+    } finally {
+      prepared.cleanup();
+    }
+  });
+  it('leaves a legacy generic Product review on the old route', () => {
+    const prepared = prepareReviewPacket(project('legacy'), 'quality-review', [target]);
+    try {
+      expect(prepared.packet.planning_context).toBeUndefined();
+    } finally {
+      prepared.cleanup();
+    }
+  });
+});
diff --git a/packages/cli/tests/review/product-role-selected-parent.test.ts b/packages/cli/tests/review/product-role-selected-parent.test.ts
new file mode 100644
index 000000000..040da675f
--- /dev/null
+++ b/packages/cli/tests/review/product-role-selected-parent.test.ts
@@ -0,0 +1,120 @@
+import { mkdirSync, mkdtempSync, rmSync, writeFileSync } from 'node:fs';
+import { tmpdir } from 'node:os';
+import nodePath from 'node:path';
+
+import { afterEach, describe, expect, it } from 'vitest';
+
+import { prepareReviewPacket } from '../../src/review/packet.js';
+import { createPlanningReviewIdentity } from '../../src/review/planning-context-identity.js';
+import { writePlanningInventories } from '../planning-fixtures.js';
+
+const roots: string[] = [];
+const parentPath = '.project/tickets/000123-parent/spec.md';
+const target = '.project/tickets/OWN123-child/spec.md';
+const parent = `# Parent Product Plan
+
+## Product Bet
+
+- **Expected outcome:** Builder can trust approval.
+- **Persona outcome inventory:** Builder receives current approval.
+- **Known facts:** Approval is authenticated.
+- **Assumptions:** Review remains available.
+- **Unresolved product decisions:** none
+- **Success threshold:** Current approval advances.
+- **Project non-goals:** No anonymous approval.
+
+## Jobs To Be Done
+
+### approval.BU1 — Trust approval
+
+**Persona:** Builder (BU)
+
+#### approval.BU1.R1 — Preserve approval
+
+Only current approval advances.
+
+### approval.BU2 — Unrelated work
+
+Builder can do another task.
+
+## Shape
+
+### M1 — Current approval
+
+- **Outcome:** Review is current.
+- **Non-goals:** Anonymous approval.
+
+### M2 — Unrelated milestone
+
+An unrelated delivery remains available.
+`;
+function project() {
+  const root = mkdtempSync(nodePath.join(tmpdir(), 'safeword-product-parent-'));
+  roots.push(root);
+  writePlanningInventories(root);
+  for (const folder of ['.project/tickets/OWN123-child', '.project/tickets/000123-parent'])
+    mkdirSync(nodePath.join(root, folder), { recursive: true });
+  writeFileSync(
+    nodePath.join(root, '.project/tickets/OWN123-child/ticket.md'),
+    '---\nid: OWN123\ntype: feature\nproduct_plan_contract: v1\nparent: 000123\nparent_job: approval.BU1\nmilestone: M1\n---\n',
+  );
+  writeFileSync(
+    nodePath.join(root, '.project/tickets/000123-parent/ticket.md'),
+    '---\nid: 000123\ntype: epic\n---\n',
+  );
+  writeFileSync(
+    nodePath.join(root, target),
+    '# Child Contribution\n\nFollow the selected parent job.\n',
+  );
+  writeFileSync(nodePath.join(root, parentPath), parent);
+  return root;
+}
+function identity(root: string) {
+  const prepared = prepareReviewPacket(root, 'quality-review', [target]);
+  try {
+    return createPlanningReviewIdentity(prepared.packet);
+  } finally {
+    prepared.cleanup();
+  }
+}
+afterEach(() => {
+  for (const root of roots) rmSync(root, { recursive: true, force: true });
+  roots.length = 0;
+});
+
+describe('Product child selected-parent review identity', () => {
+  it('reports a malformed inherited Product Plan as parent context', () => {
+    const root = project();
+    writeFileSync(nodePath.join(root, parentPath), parent.replace('## Shape', '## Delivery'));
+    expect(() => identity(root)).toThrow(/parent.*spec\.md/u);
+  });
+  it('retains approval after an unrelated parent job and milestone edit', () => {
+    const root = project();
+    const before = identity(root);
+    writeFileSync(
+      nodePath.join(root, parentPath),
+      parent
+        .replace('An unrelated delivery remains available.', 'An unrelated delivery can change.')
+        .replace('Builder can do another task.', 'Builder can do a revised unrelated task.'),
+    );
+    expect(identity(root)).toEqual(before);
+  });
+  it('changes after a selected milestone outcome edit', () => {
+    const root = project();
+    const before = identity(root);
+    writeFileSync(
+      nodePath.join(root, parentPath),
+      parent.replace('Review is current.', 'Review is current and attributable.'),
+    );
+    expect(identity(root)).not.toEqual(before);
+  });
+  it('changes after the inherited Product Bet changes', () => {
+    const root = project();
+    const before = identity(root);
+    writeFileSync(
+      nodePath.join(root, parentPath),
+      parent.replace('Approval is authenticated.', 'Approval is authenticated and scoped.'),
+    );
+    expect(identity(root)).not.toEqual(before);
+  });
+});
diff --git a/packages/cli/tests/review/product-ticket-ownership.test.ts b/packages/cli/tests/review/product-ticket-ownership.test.ts
new file mode 100644
index 000000000..2876b19d3
--- /dev/null
+++ b/packages/cli/tests/review/product-ticket-ownership.test.ts
@@ -0,0 +1,76 @@
+import { mkdirSync, rmSync, writeFileSync } from 'node:fs';
+import nodePath from 'node:path';
+
+import { afterEach, describe, expect, it } from 'vitest';
+
+import { prepareReviewPacket } from '../../src/review/packet.js';
+import { createConfiguredProject, createTemporaryDirectory } from '../helpers.js';
+import { writePlanningInventories } from '../planning-fixtures.js';
+import { PLANNING_ROLE_PRODUCT } from '../planning-role-fixtures.js';
+
+const projects: string[] = [];
+afterEach(() => {
+  for (const project of projects) rmSync(project, { recursive: true, force: true });
+  projects.length = 0;
+});
+
+describe('opaque ticket IDs at actual Product review classification', () => {
+  it.each(['000123', '1E0003', '123456'])('preserves generated numeric-looking ID %s', async id => {
+    const project = createTemporaryDirectory();
+    projects.push(project);
+    await createConfiguredProject(project);
+    writePlanningInventories(project);
+    const folder = `.project/tickets/${id}-ownership`;
+    mkdirSync(nodePath.join(project, folder), { recursive: true });
+    const ticket = `---\nid: ${id}\ntype: feature\nphase: intake\nstatus: in_progress\nproduct_plan_contract: v1\nscope: preserve opaque IDs\n---\n`;
+    writeFileSync(nodePath.join(project, folder, 'ticket.md'), ticket);
+    writeFileSync(nodePath.join(project, folder, 'spec.md'), PLANNING_ROLE_PRODUCT);
+    const prepared = prepareReviewPacket(
+      project,
+      'quality-review',
+      [`${folder}/spec.md`],
+      [`${folder}/ticket.md`],
+    );
+    try {
+      expect(prepared.packet.planning_phase).toBe('product-plan');
+      expect(prepared.packet.context_files).toEqual(
+        expect.arrayContaining([
+          expect.objectContaining({ path: `${folder}/ticket.md`, content: ticket }),
+        ]),
+      );
+    } finally {
+      prepared.cleanup();
+    }
+  });
+  it.each([
+    ['wrong identity', 'OWN456', 'OWN123-ownership'],
+    ['missing identity', undefined, 'OWN123-ownership'],
+    ['non-scalar identity', ['OWN123'], 'OWN123-ownership'],
+    ['blank identity', '', '-ownership'],
+  ] as const)('refuses owned Product metadata with %s', async (_label, id, directory) => {
+    const project = createTemporaryDirectory();
+    projects.push(project);
+    await createConfiguredProject(project);
+    writePlanningInventories(project);
+    const folder = `.project/tickets/${directory}`;
+    mkdirSync(nodePath.join(project, folder), { recursive: true });
+    const identifier = id === undefined ? '' : `id: ${JSON.stringify(id)}\n`;
+    writeFileSync(
+      nodePath.join(project, folder, 'ticket.md'),
+      `---\n${identifier}type: feature\nphase: intake\nproduct_plan_contract: v1\n---\n`,
+    );
+    writeFileSync(nodePath.join(project, folder, 'spec.md'), '# Product Plan\n\nPreserve IDs.\n');
+    let failure: unknown;
+    try {
+      const prepared = prepareReviewPacket(project, 'quality-review', [`${folder}/spec.md`]);
+      prepared.cleanup();
+    } catch (error) {
+      failure = error;
+    }
+    expect(failure).toMatchObject({
+      code: 'missing_planning_context',
+      contextRole: 'ticket',
+      contextPath: `${folder}/ticket.md`,
+    });
+  });
+});
diff --git a/packages/cli/tests/review/runtime.test.ts b/packages/cli/tests/review/runtime.test.ts
index 5ddc5710f..236b8174e 100644
--- a/packages/cli/tests/review/runtime.test.ts
+++ b/packages/cli/tests/review/runtime.test.ts
@@ -34,6 +34,7 @@ import {
   runHeadlessReviewer,
   scenarioReviewRubric,
 } from '../../src/review/runtime.js';
+import { writePlanningInventories } from '../planning-fixtures.js';
 import {
   cleanupTrustedReviewerDirectories,
   createTrustedReviewerDirectory,
@@ -626,6 +627,7 @@ printf '%s' '${JSON.stringify({ structured_output: output })}'
       chmodSync(executable, 0o755);
       vi.stubEnv('PATH', bin);
       writeFileSync(nodePath.join(project, 'impl-plan.md'), '# Plan\n');
+      writePlanningInventories(project);
 
       const baseline = prepareReviewPacket(project, 'plan-implementation', ['impl-plan.md']);
       const authorContract = baseline.packet.plan_contract?.author;
diff --git a/packages/cli/tests/review/scenario-context-ownership.test.ts b/packages/cli/tests/review/scenario-context-ownership.test.ts
new file mode 100644
index 000000000..424b7d19c
--- /dev/null
+++ b/packages/cli/tests/review/scenario-context-ownership.test.ts
@@ -0,0 +1,91 @@
+import { mkdirSync, mkdtempSync, rmSync, writeFileSync } from 'node:fs';
+import { tmpdir } from 'node:os';
+import nodePath from 'node:path';
+
+import { afterEach, describe, expect, it } from 'vitest';
+
+import { prepareReviewPacket } from '../../src/review/packet.js';
+import { writePlanningInventories } from '../planning-fixtures.js';
+
+const roots: string[] = [];
+const folder = '.project/tickets/OWN123-owned';
+const spec = `${folder}/spec.md`;
+const target = 'features/approval.feature';
+const metadata = `id: OWN123\ntype: feature\nproduct_plan_contract: v1\nphase_anchors:\n  - scenario-gate: ${target}`;
+const parentFolder = '.project/tickets/000123-parent';
+const product =
+  '# Product Plan\n\n## Product Bet\n\n- **Expected outcome:** Preserve approval.\n- **Persona outcome inventory:** Builder receives current approval.\n- **Known facts:** Approval authenticates source.\n- **Assumptions:** none\n- **Unresolved product decisions:** none\n- **Success threshold:** Current approval advances.\n- **Project non-goals:** No anonymous approval.\n\n## Jobs To Be Done\n\n### approval.BU1 — Trust approval\n\n**Persona:** Builder (BU)\n\n> When I request approval, I want current evidence, so I can trust advancement.\n\n#### approval.BU1.R1 — Preserve approval\n\nCurrent approval advances.\n\n## Shape\n\n### M1 — Trust approval\n\n- **Outcome:** Current approval advances.\n- **Non-goals:** No anonymous approval.\n\n## Surfaces\n\nAffected:\n- Safeword CLI\n';
+
+afterEach(() => {
+  for (const root of roots) rmSync(root, { recursive: true, force: true });
+  roots.length = 0;
+});
+
+function fixture(ticket = metadata) {
+  const root = mkdtempSync(nodePath.join(tmpdir(), 'safeword-scenario-context-'));
+  roots.push(root);
+  writePlanningInventories(root);
+  mkdirSync(nodePath.join(root, folder), { recursive: true });
+  mkdirSync(nodePath.join(root, 'features'));
+  writeFileSync(nodePath.join(root, folder, 'ticket.md'), `---\n${ticket}\n---\n`);
+  writeFileSync(nodePath.join(root, spec), product);
+  writeFileSync(
+    nodePath.join(root, target),
+    'Feature: Trust approval\n  Scenario: Current approval\n    Given current evidence\n    When approval is requested\n    Then current approval advances\n',
+  );
+  return root;
+}
+
+function context(root: string) {
+  const prepared = prepareReviewPacket(root, 'scenario-gate', [target], [spec]);
+  try {
+    return prepared.packet.context_files?.map(file => file.path);
+  } finally {
+    prepared.cleanup();
+  }
+}
+
+describe('scenario context ownership and required roles', () => {
+  it.each(['personas', 'surfaces'] as const)('refuses a missing installed %s inventory', role => {
+    const root = fixture();
+    rmSync(nodePath.join(root, '.project', `${role}.md`));
+    expect(() => context(root)).toThrow(
+      expect.objectContaining({
+        code: 'missing_planning_context',
+        contextRole: role,
+        contextPath: `.project/${role}.md`,
+      }),
+    );
+  });
+  it('resolves the declared parent before project inventories', () => {
+    const root = fixture(`${metadata}\nparent: 000123\nparent_job: approval.BU1\nmilestone: M1`);
+    rmSync(nodePath.join(root, '.project/principles.md'));
+    expect(() => context(root)).toThrow(
+      expect.objectContaining({ code: 'missing_planning_context', contextRole: 'parent' }),
+    );
+  });
+  it('captures declared parent ticket and Product Plan with the owning ticket', () => {
+    const root = fixture(`${metadata}\nparent: 000123\nparent_job: approval.BU1\nmilestone: M1`);
+    mkdirSync(nodePath.join(root, parentFolder), { recursive: true });
+    writeFileSync(
+      nodePath.join(root, parentFolder, 'ticket.md'),
+      '---\nid: 000123\ntype: epic\n---\n',
+    );
+    writeFileSync(nodePath.join(root, parentFolder, 'spec.md'), product);
+    expect(context(root)).toEqual(
+      expect.arrayContaining([
+        `${folder}/ticket.md`,
+        `${parentFolder}/ticket.md`,
+        `${parentFolder}/spec.md`,
+      ]),
+    );
+  });
+  it.each([
+    ['legacy feature', 'id: OWN123\ntype: feature'],
+    ['task', 'id: OWN123\ntype: task\nproduct_plan_contract: v1'],
+  ])('preserves generic %s context', (_label, ticket) => {
+    const root = fixture(ticket);
+    rmSync(nodePath.join(root, '.project/principles.md'));
+    expect(context(root)).toEqual([spec]);
+  });
+});
diff --git a/packages/cli/tests/review/scenario-role-context.test.ts b/packages/cli/tests/review/scenario-role-context.test.ts
new file mode 100644
index 000000000..06afdb30a
--- /dev/null
+++ b/packages/cli/tests/review/scenario-role-context.test.ts
@@ -0,0 +1,109 @@
+import { mkdirSync, mkdtempSync, rmSync, writeFileSync } from 'node:fs';
+import { tmpdir } from 'node:os';
+import nodePath from 'node:path';
+
+import { afterEach, describe, expect, it } from 'vitest';
+
+import { prepareReviewPacket } from '../../src/review/packet.js';
+import { PLANNING_CONTEXT_ROLES } from '../../src/review/planning-context-error.js';
+import { createPlanningReviewIdentity } from '../../src/review/planning-context-identity.js';
+import { writePlanningInventories } from '../planning-fixtures.js';
+
+const roots: string[] = [];
+const folder = '.project/tickets/OWN123-scenario';
+const spec = `${folder}/spec.md`;
+const feature = 'features/scenario.feature';
+const product = `# Product Plan
+
+## Product Bet
+
+- **Expected outcome:** Builders retain current approval.
+- **Persona outcome inventory:** Builder receives current approval.
+- **Known facts:** Approval is authenticated.
+- **Assumptions:** Review remains available.
+- **Unresolved product decisions:** none
+- **Success threshold:** Current approval advances.
+- **Project non-goals:** No anonymous approval.
+
+## Jobs To Be Done
+
+### approval.BU1 — Trust approval
+
+**Persona:** Builder (BU)
+
+#### approval.BU1.R1 — Preserve approval
+
+Current approval advances.
+`;
+function project(contract = 'v1') {
+  const root = mkdtempSync(nodePath.join(tmpdir(), 'safeword-scenario-role-'));
+  roots.push(root);
+  writePlanningInventories(root);
+  mkdirSync(nodePath.join(root, folder), { recursive: true });
+  mkdirSync(nodePath.join(root, 'features'));
+  writeFileSync(
+    nodePath.join(root, `${folder}/ticket.md`),
+    `---\nid: OWN123\ntype: feature\nproduct_plan_contract: ${contract}\nphase_anchors:\n  - scenario-gate: ${feature}\n---\n`,
+  );
+  writeFileSync(nodePath.join(root, spec), product);
+  writeFileSync(
+    nodePath.join(root, feature),
+    '@approval.BU1.R1 @surface.safeword-cli\nFeature: Trust approval\n  Scenario: Current approval\n    Given current evidence\n    When approval is requested\n    Then approval is current\n',
+  );
+  return root;
+}
+afterEach(() => {
+  for (const root of roots) rmSync(root, { recursive: true, force: true });
+  roots.length = 0;
+});
+
+describe('Scenario-gate role context', () => {
+  it('derives one complete role identity with the exact executable source', () => {
+    const prepared = prepareReviewPacket(project(), 'scenario-gate', [feature], [spec]);
+    try {
+      const context = prepared.packet.planning_context;
+      expect(
+        context,
+        'owned scenario-gate review must derive its planning role graph',
+      ).toBeDefined();
+      const present = context?.dependencies.map(row => row.role) ?? [];
+      const absent = context?.absences.map(row => row.role) ?? [];
+      expect(new Set([...present, ...absent])).toEqual(new Set(PLANNING_CONTEXT_ROLES));
+      expect(present).toEqual(
+        expect.arrayContaining([
+          'ticket',
+          'project',
+          'rules',
+          'scenarios',
+          'principles',
+          'personas',
+          'surfaces',
+        ]),
+      );
+      expect(absent).toEqual(
+        expect.arrayContaining([
+          'dimensions',
+          'architecture',
+          'data',
+          'reusable-evidence',
+          'accepted-upstream-plan',
+        ]),
+      );
+      expect(createPlanningReviewIdentity(prepared.packet)).toMatchObject({
+        review_kind: 'scenario-gate',
+        ticket_id: 'OWN123',
+        targets: [expect.objectContaining({ path: feature })],
+      });
+    } finally {
+      prepared.cleanup();
+    }
+  });
+  it('retains a generic legacy scenario route', () => {
+    const prepared = prepareReviewPacket(project('legacy'), 'scenario-gate', [feature], [spec]);
+    try {
+      expect(prepared.packet.planning_context).toBeUndefined();
+    } finally {
+      prepared.cleanup();
+    }
+  });
+});
diff --git a/packages/cli/tests/review/scenario-role-selected-parent.test.ts b/packages/cli/tests/review/scenario-role-selected-parent.test.ts
new file mode 100644
index 000000000..2145cbe9d
--- /dev/null
+++ b/packages/cli/tests/review/scenario-role-selected-parent.test.ts
@@ -0,0 +1,255 @@
+import { mkdirSync, mkdtempSync, readdirSync, readFileSync, rmSync, writeFileSync } from 'node:fs';
+import { tmpdir } from 'node:os';
+import nodePath from 'node:path';
+
+import { afterEach, describe, expect, it, vi } from 'vitest';
+
+import { startReviewJob } from '../../src/review/job.js';
+import { prepareReviewPacket } from '../../src/review/packet.js';
+import { createPlanningReviewIdentity } from '../../src/review/planning-context-identity.js';
+import { writePlanningInventories } from '../planning-fixtures.js';
+
+const roots: string[] = [];
+const child = '.project/tickets/OWN123-child';
+const parentPath = '.project/tickets/000123-parent/spec.md';
+const feature = 'features/child.feature';
+const parent = `# Parent Product Plan
+
+## Product Bet
+
+- **Expected outcome:** Builder can trust approval.
+- **Persona outcome inventory:** Builder receives current approval.
+- **Known facts:** Approval is authenticated.
+- **Assumptions:** Review remains available.
+- **Unresolved product decisions:** none
+- **Success threshold:** Current approval advances.
+- **Project non-goals:** No anonymous approval.
+
+## Jobs To Be Done
+
+### approval.BU1 — Trust approval
+
+**Persona:** Builder (BU)
+
+#### approval.BU1.R1 — Preserve approval
+
+Only current approval advances.
+
+### approval.BU2 — Unrelated work
+
+Builder can do another task.
+
+## Shape
+
+### M1 — Current approval
+
+- **Outcome:** Review is current.
+- **Non-goals:** Anonymous approval.
+
+### M2 — Unrelated milestone
+
+An unrelated delivery remains available.
+`;
+function project() {
+  const root = mkdtempSync(nodePath.join(tmpdir(), 'safeword-scenario-parent-'));
+  roots.push(root);
+  writePlanningInventories(root);
+  for (const folder of [child, '.project/tickets/000123-parent', 'features'])
