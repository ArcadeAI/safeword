Decision: explain receipt mismatch without expanding the public recovery-code contract.
Domains/questions: public compatibility (is a new code necessary?), recovery semantics (does the existing code remain truthful?), proof discrimination (can the regression distinguish a generic or false explanation?).
Evidence: delivery-checklist-recovery.test.ts binds six published repair codes; accepted R9 requires mismatched review kind/ticket and re-review to be named, not a new code; the public-CLI regression separately requires refusal, both kind names and the review command.
Options: add seventh code and change the public contract snapshot, or retain missing_admitted_delivery_checklist and attach the precise authenticated mismatch explanation. Both refuse; retaining the existing code is smaller and avoids an unnecessary public contract extension.
Recommend retaining the existing code: no valid admitted checklist exists for this receipt. The internal diagnostic stays structured.
Premortem: a consumer hides the message and only displays a generic code; the actual CLI displays the finding message and retains the existing repair command.
No existing recovery-code test was changed or skipped. The approved new regression preserves all originally approved assertions; an additional machine-code check binds the existing published contract.
