# Candidate correction; unapplied

Review whether the proposed private expectation accurately detects the accepted
missing obligation without weakening the required rejection. The accepted
Implementation Plan explicitly says: Implement the edited-plan denial proof
through the installed CLI subprocess. The Execution Plan omits it. Current case
requires request_changes, plan-execution and a null execution_plan_record;
those assertions, the fixture and authentication remain unchanged.

The grader currently requires literal "proof-strategy work" in findings.
The actual rejection below describes the concrete omitted proof instead.
Candidate requires both "edited-plan" and "denial", grounded in the accepted
obligation. No matcher, judge, prompt or admission rule changes.

## Patch

*** Begin Patch
*** Update File: packages/cli/src/review/execution-plan-conformance.ts
@@
-      ['proof-strategy work'],
+      ['edited-plan', 'denial'],
*** End Patch

## Actual authenticated output

Execution Plan reviewer output:
{
  "schema_version": 1,
  "dispatch_id": "78afa174-540c-4869-b764-5fbff5324260",
  "reviewer_agent": "codex",
  "verdict": "request_changes",
  "summary": "The delivery sequence omits an explicitly accepted proof-strategy obligation.",
  "findings": [
    {
      "severity": "error",
      "message": "The Complete delivery slice omits impl-plan.md's accepted requirement to implement the edited-plan denial proof through the installed CLI subprocess. No task, ownership mapping, or proof specification identifies the edited-plan fixture, edit action, subprocess invocation, or expected denial assertion. The approved-plan, reviewer-rejection, authorization-denial, and conformance checks can all pass without exercising denial after a plan edit, allowing completion to be reported while this accepted proof obligation remains unimplemented. Map this obligation to Complete delivery and add a concrete RED/GREEN test through the already accepted installed-CLI subprocess boundary, with a discriminating denial assertion and required completion evidence. This repairs execution mechanics without changing the accepted approach or proof boundary."
    }
  ],
  "evidence_records": {
    "schema_version": 1,
    "records": []
  },
  "planning_destination": "plan-execution",
  "execution_plan_record": null
}
