Current PR5 complete unique-source review 14/19. Base 854a376861bc034d65cc81ddfa6a85d0ae55821e; head b722f9a27a1815abcfb08e6f6ca09dc7317efa46. Review actual correctness, authenticated approval, rejection findings and test discrimination. Every unique production source, template, test, step and generator changed in PR5 is supplied across these packets. Byte-identical installed mirrors and compiled bundles are omitted; all five generated surfaces passed at this head. Prior historical acceptance failures remain visible; full current run is in progress. Exactly 33 cases are user-deferred and unverified. This is source review, not native-host or merge approval. Flag only concrete in-scope defects; optional hardening does not block.

diff --git a/steps/keep-plan-reviews-context.steps.ts b/steps/keep-plan-reviews-context.steps.ts
new file mode 100644
index 000000000..7ea4c5c05
--- /dev/null
+++ b/steps/keep-plan-reviews-context.steps.ts
@@ -0,0 +1,633 @@
+import { strict as assert } from 'node:assert';
+import { spawnSync } from 'node:child_process';
+import {
+  cpSync,
+  existsSync,
+  mkdirSync,
+  mkdtempSync,
+  readFileSync,
+  rmSync,
+  writeFileSync,
+} from 'node:fs';
+import { tmpdir } from 'node:os';
+import path from 'node:path';
+
+import { After, Given, Then, When } from '@cucumber/cucumber';
+
+import { EXECUTION_PLAN_CONFORMANCE_CASES } from '../packages/cli/src/review/execution-plan-conformance.js';
+import { prepareReviewPacket } from '../packages/cli/src/review/packet.js';
+import { SAFEWORD_SCHEMA } from '../packages/cli/src/schema.js';
+import { writePlanningInventories } from '../packages/cli/tests/planning-fixtures.js';
+import {
+  cleanupTrustedReviewerDirectories,
+  createTrustedReviewerDirectory,
+  REVIEWER_CAPABILITIES,
+} from '../packages/cli/tests/review-fixtures.js';
+import type { SafewordWorld } from './world.js';
+
+type Phase = 'Product Plan' | 'Implementation Plan' | 'Execution Plan';
+interface ContextState {
+  phase: Phase;
+  packetState: string;
+  root?: string;
+  packet?: ReturnType<typeof prepareReviewPacket>['packet'];
+  failure?: unknown;
+  roleFailures?: { role: string; failure: unknown }[];
+  installed?: { result: ReturnType<typeof spawnSync>; capture: string };
+}
+
+const states = new WeakMap<SafewordWorld, ContextState>();
+const ticketDirectory = '.project/tickets/CTX123-current-context';
+const packageRoot = path.resolve(import.meta.dirname, '../packages/cli');
+const executionCase = EXECUTION_PLAN_CONFORMANCE_CASES.find(
+  value => value.id === 'one-coherent-change',
+);
+assert.ok(executionCase, 'The canonical Execution Plan fixture must exist.');
+
+function createProject(): string {
+  const root = mkdtempSync(path.join(tmpdir(), 'safeword-4200-context-'));
+  writePlanningInventories(root);
+  const ticket = path.join(root, ticketDirectory);
+  mkdirSync(ticket, { recursive: true });
+  mkdirSync(path.join(root, 'features'));
+  writeFileSync(
+    path.join(ticket, 'ticket.md'),
+    `---\nid: CTX123\ntype: feature\nphase: intake\nstatus: in_progress\nproduct_plan_contract: v1\nscope: preserve authenticated approval\nout_of_scope: new approval authority\ndone_when: current context reaches review\nphase_anchors:\n  - scenario-gate: features/current-context.feature\n---\n# Ticket\n`,
+  );
+  writeFileSync(
+    path.join(ticket, 'spec.md'),
+    `# Product Plan: Preserve approval\n\n<!-- safeword:product-plan-contract:v1 -->\n\n## Product Bet\n\n- **Expected outcome:** Builders advance with current approval.\n- **Persona outcome inventory:** Builder receives approval or a named refusal.\n- **Known facts:** Approval authenticates the current source.\n- **Assumptions:** Review latency is acceptable.\n- **Unresolved product decisions:** none\n- **Success threshold:** Current approval advances.\n- **Project non-goals:** No new approval authority.\n\n## Jobs To Be Done\n\n### approval.BU1 — Trust approval\n\n**Persona:** Builder (BU)\n\n> When I request approval, I want current evidence, so I can trust advancement.\n\n#### approval.BU1.R1 — Preserve approval\n\nOnly current approval advances.\n\n## Surfaces\n\nAffected:\n- Safeword CLI\n`,
+  );
+  writeFileSync(
+    path.join(ticket, 'impl-plan.md'),
+    '# Implementation Plan\n\n## Approach\n\nPreserve authenticated approval.\n\n## Architecture applicability\n\nskip: No durable architecture records apply.\n\n## Data applicability\n\nskip: No product data is stored.\n',
+  );
+  writeFileSync(path.join(ticket, 'execution-plan.md'), executionCase.execution_plan);
+  writeFileSync(
+    path.join(root, 'features/current-context.feature'),
+    '@approval.BU1.R1 @surface.safeword-cli\nFeature: Trust current approval\n  Scenario: Approval\n    Given a current review\n    When the Builder requests approval\n    Then the current context reaches review\n',
+  );
+  return root;
+}
+
+function target(phase: Phase): {
+  kind: 'quality-review' | 'plan-implementation' | 'plan-execution';
+  path: string;
+} {
+  if (phase === 'Product Plan')
+    return { kind: 'quality-review', path: `${ticketDirectory}/spec.md` };
+  if (phase === 'Implementation Plan')
+    return { kind: 'plan-implementation', path: `${ticketDirectory}/impl-plan.md` };
+  return { kind: 'plan-execution', path: `${ticketDirectory}/execution-plan.md` };
+}
+
+function current(world: SafewordWorld): ContextState {
+  const state = states.get(world);
+  assert.ok(state, 'The scenario must select a planning phase and packet state.');
+  return state;
+}
+
+function assertDeliveredContext(
+  packet: ReturnType<typeof prepareReviewPacket>['packet'],
+  state: ContextState,
+): void {
+  assert.ok(state.root);
+  assert.ok(packet.planning_context);
+  const required = ['ticket', 'project', 'rules', 'personas', 'principles', 'surfaces'];
+  if (state.phase !== 'Product Plan') required.push('scenarios');
+  if (state.phase === 'Execution Plan') required.push('accepted-upstream-plan');
+  for (const role of required) {
+    const dependency = packet.planning_context.dependencies.find(value => value.role === role);
+    assert.ok(dependency, `${role} must be resolved.`);
+    const delivered = [...packet.logical_files, ...(packet.context_files ?? [])].find(
+      file => file.path === dependency.path,
+    );
+    assert.ok(delivered, `${role} must reach the reviewer.`);
+    assert.equal(
+      delivered.content,
+      readFileSync(path.join(state.root, dependency.path), 'utf8'),
+      `${role} must contain the current source.`,
+    );
+  }
+}
+
+function replaceFile(root: string, file: string, before: string, after: string): void {
+  const source = path.join(root, file);
+  const content = readFileSync(source, 'utf8');
+  assert.ok(content.includes(before), `${file} must contain the fixture text being changed.`);
+  writeFileSync(source, content.replace(before, after));
+}
+
+function missingEntryCases(phase: Phase): { role: string; remove: (root: string) => void }[] {
+  const shared = [
+    {
+      role: 'ticket',
+      remove: (root: string) => rmSync(path.join(root, ticketDirectory, 'ticket.md')),
+    },
+    {
+      role: 'project',
+      remove: (root: string) =>
+        replaceFile(root, `${ticketDirectory}/spec.md`, '**Expected outcome:**', '**Other:**'),
+    },
+    {
+      role: 'rules',
+      remove: (root: string) => {
+        const source = `${ticketDirectory}/spec.md`;
+        const content = readFileSync(path.join(root, source), 'utf8');
+        writeFileSync(
+          path.join(root, source),
+          content.replace(/## Jobs To Be Done[\s\S]*?(?=## Surfaces)/u, ''),
+        );
+      },
+    },
+    {
+      role: 'parent',
+      remove: (root: string) =>
+        replaceFile(
+          root,
+          `${ticketDirectory}/ticket.md`,
+          'id: CTX123',
+          'id: CTX123\nparent: PAR123',
+        ),
+    },
+    {
+      role: 'milestone',
+      remove: (root: string) => {
+        const parent = path.join(root, '.project/tickets/PAR123-parent-context');
+        mkdirSync(parent, { recursive: true });
+        writeFileSync(path.join(parent, 'ticket.md'), '---\nid: PAR123\ntype: epic\n---\n');
+        writeFileSync(
+          path.join(parent, 'spec.md'),
+          readFileSync(path.join(root, ticketDirectory, 'spec.md')),
+        );
+        replaceFile(
+          root,
+          `${ticketDirectory}/ticket.md`,
+          'id: CTX123',
+          'id: CTX123\nparent: PAR123\nparent_job: approval.BU1',
+        );
+      },
+    },
+    ...(['principles', 'personas', 'surfaces'] as const).map(role => ({
+      role,
+      remove: (root: string) => rmSync(path.join(root, `.project/${role}.md`)),
+    })),
+  ];
+  if (phase === 'Product Plan')
+    return [
+      ...shared,
+      {
+        role: 'project',
+        remove: (root: string) =>
+          replaceFile(
+            root,
+            `${ticketDirectory}/spec.md`,
+            '**Assumptions:**',
+            '**Other assumptions:**',
+          ),
+      },
+    ];
+  const downstream = [
+    {
+      role: 'scenarios',
+      remove: (root: string) => rmSync(path.join(root, 'features/current-context.feature')),
+    },
+    {
+      role: 'dimensions',
+      remove: (root: string) =>
+        writeFileSync(path.join(root, ticketDirectory, 'dimensions.md'), ''),
+    },
+    {
+      role: 'architecture',
+      remove: (root: string) =>
+        replaceFile(
+          root,
+          `${ticketDirectory}/impl-plan.md`,
+          'skip: No durable architecture records apply.',
+          'An architecture record applies.',
+        ),
+    },
+    {
+      role: 'data',
+      remove: (root: string) =>
+        replaceFile(
+          root,
+          `${ticketDirectory}/impl-plan.md`,
+          'skip: No product data is stored.',
+          'Product data is stored.',
+        ),
+    },
+  ];
+  if (phase === 'Execution Plan')
+    downstream.push({
+      role: 'accepted-upstream-plan',
+      remove: (root: string) => rmSync(path.join(root, ticketDirectory, 'impl-plan.md')),
+    });
+  return [...shared, ...downstream];
+}
+
+After(function (this: SafewordWorld) {
+  const state = states.get(this);
+  if (state?.root) rmSync(state.root, { recursive: true, force: true });
+  states.delete(this);
+  cleanupTrustedReviewerDirectories();
+});
+
+Given(
+  /^a (Product Plan|Implementation Plan|Execution Plan) review packet (.+)$/,
+  function (this: SafewordWorld, phase: Phase, packetState: string) {
+    states.set(this, { phase, packetState });
+  },
+);
+
+Given(
+  /^the canonical (Product Plan|Implementation Plan|Execution Plan) contract requires (.+) as review entry context$/,
+  function (this: SafewordWorld, phase: Phase, inventory: string) {
+    assert.ok(inventory.includes('ticket') && inventory.includes('principles'));
+    states.set(this, { phase, packetState: 'missing each required entry role' });
+  },
+);
+
+When(
+  'review dispatch receives a packet missing any listed required role',
+  function (this: SafewordWorld) {
+    const state = current(this);
+    state.roleFailures = missingEntryCases(state.phase).map(({ role, remove }) => {
+      const root = createProject();
+      try {
+        remove(root);
+        const selected = target(state.phase);
+        const context =
+          state.phase === 'Execution Plan' && role !== 'scenarios'
+            ? ['features/current-context.feature']
+            : [];
+        try {
+          const prepared = prepareReviewPacket(root, selected.kind, [selected.path], context);
+          prepared.cleanup();
+          return { role, failure: undefined };
+        } catch (failure) {
+          return { role, failure };
+        }
+      } finally {
+        rmSync(root, { recursive: true, force: true });
+      }
+    });
+  },
+);
+
+Then('dispatch is blocked with the missing role named', function (this: SafewordWorld) {
+  const failures = current(this).roleFailures;
+  assert.ok(failures);
+  for (const { role, failure } of failures) {
+    if (role === 'scenarios' && current(this).phase === 'Execution Plan') {
+      assert.match(String(failure), /approved \.feature scenarios as context/u);
+      continue;
+    }
+    assert.equal(
+      (failure as { code?: string } | undefined)?.code,
+      'missing_planning_context',
+      `${role}: ${String(failure)}`,
+    );
+    assert.equal((failure as { contextRole?: string }).contextRole, role);
+  }
+});
+
+When('review dispatch is prepared', function (this: SafewordWorld) {
+  const state = current(this);
+  const root = createProject();
+  state.root = root;
+  if (state.packetState === 'omits one required current input')
+    rmSync(path.join(root, '.project/personas.md'));
+  if (state.packetState === 'omits the accepted Implementation Plan')
+    rmSync(path.join(root, ticketDirectory, 'impl-plan.md'));
+  if (state.packetState === 'omits a conditionally required input whose trigger applies') {
+    const planPath = path.join(root, ticketDirectory, 'impl-plan.md');
+    writeFileSync(
+      planPath,
+      readFileSync(planPath, 'utf8').replace(
+        'skip: No product data is stored.',
+        'Product data is stored; review the data guide.',
+      ),
+    );
+  }
+  const selected = target(state.phase);
+  const context =
+    state.phase === 'Execution Plan'
+      ? [
+          ...(state.packetState === 'omits the accepted Implementation Plan'
+            ? []
+            : [`${ticketDirectory}/impl-plan.md`]),
+          'features/current-context.feature',
+        ]
+      : [];
+  try {
+    const prepared = prepareReviewPacket(root, selected.kind, [selected.path], context);
+    state.packet = prepared.packet;
+    prepared.cleanup();
+  } catch (error) {
+    state.failure = error;
+  }
+});
+
+When(
+  'the native plugin review hook dispatches from an installed local project with real configuration and collaborators, mocking only the reviewer process boundary',
+  function (this: SafewordWorld) {
+    const state = current(this);
+    const root = createProject();
+    state.root = root;
+    writeFileSync(
+      path.join(root, 'package.json'),
+      '{"name":"review-context-fixture","private":true}\n',
+    );
+    const installed = spawnSync(
+      'bun',
+      [
+        path.join(packageRoot, 'src/cli.ts'),
+        'install',
+        '--agents=claude',
+        '--no-input',
+        '--no-modify',
+        '--json',
+        '--cwd',
+        root,
+      ],
+      {
+        cwd: root,
+        encoding: 'utf8',
+        timeout: 60_000,
+        env: {
+          ...process.env,
+          CLAUDE_CONFIG_DIR: path.join(root, 'claude'),
+          SAFEWORD_SKIP_INSTALL: '1',
+          SAFEWORD_SKIP_SKILLS: '1',
+        },
+      },
+    );
+    const installOutput = JSON.parse(installed.stdout) as { errors: unknown[] };
+    assert.deepEqual(installOutput.errors, [], `${installed.stdout}\n${installed.stderr}`);
+    const pluginRoot = path.join(root, '.native-claude-plugin');
+    cpSync(path.resolve(import.meta.dirname, '../plugin'), pluginRoot, { recursive: true });
+    const hook = path.join(pluginRoot, 'runtime/hooks/run-review.ts');
+    assert.ok(existsSync(hook), 'The review must launch through the native plugin hook.');
+    const configPath = path.join(root, '.safeword/config.json');
+    const config = JSON.parse(readFileSync(configPath, 'utf8')) as Record<string, unknown>;
+    writeFileSync(
+      configPath,
+      JSON.stringify({
+        ...config,
+        crossAgentReview: 'prefer',
+        crossAgentReviewRoutes: { claude: [{ reviewer: 'codex', model: 'gpt-6.1-sol' }] },
+      }),
+    );
+    if (state.packetState === 'omits the current personas inventory')
+      rmSync(path.join(root, '.project/personas.md'));
+    if (state.packetState === 'omits the accepted Implementation Plan')
+      rmSync(path.join(root, ticketDirectory, 'impl-plan.md'));
+    const reviewer = createTrustedReviewerDirectory('safeword-r2-installed-');
+    const capture = path.join(reviewer, 'packet.json');
+    writeFileSync(
+      path.join(reviewer, 'codex'),
+      String.raw`#!${process.execPath}
+const { writeFileSync } = require('node:fs');
+if (process.argv.includes('--version')) { console.log('codex 1.0.0'); process.exit(0); }
+if (process.argv.includes('--help')) {
+  console.log(process.argv.includes('app-server') ? '--stdio --config' : ${JSON.stringify(REVIEWER_CAPABILITIES.codex)});
+  process.exit(0);
+}
+if (!process.argv.includes('app-server')) process.exit(7);
+const lines = require('node:readline').createInterface({ input: process.stdin });
+lines.on('line', line => {
+  const message = JSON.parse(line);
+  if (message.id === 1) console.log(JSON.stringify({ id: 1, result: {} }));
+  if (message.id === 2) console.log(JSON.stringify({ id: 2, result: {
+    thread: { id: 'thread-1' }, model: message.params.model, modelProvider: 'openai'
+  } }));
+  if (message.id !== 3) return;
+  const prompt = message.params.input[0].text;
+  const packet = JSON.parse(prompt.slice(prompt.lastIndexOf('\n') + 1));
+  writeFileSync(${JSON.stringify(capture)}, JSON.stringify(packet));
+  const output = { schema_version: 1, dispatch_id: packet.dispatch_id,
+    reviewer_agent: 'codex', verdict: 'request_changes', summary: 'Fixture observed the actual packet.',
+    findings: [{ severity: 'error', message: 'Fixture stops at the reviewer process boundary.' }],
+    evidence_records: { schema_version: 1, records: [] },
+    ...(packet.kind === 'plan-execution' ? { planning_destination: 'plan-execution', execution_plan_record: null } : {}) };
+  console.log(JSON.stringify({ id: 3, result: { turn: { id: 'turn-1' } } }));
+  console.log(JSON.stringify({ method: 'turn/completed', params: { threadId: 'thread-1',
+    turn: { id: 'turn-1', status: 'completed', items: [
+      { type: 'agentMessage', phase: 'final_answer', text: JSON.stringify(output) }
+    ] }
+  } }));
+});
+`,
+      { mode: 0o755 },
+    );
+    const bun = spawnSync('which', ['bun'], { encoding: 'utf8' });
+    assert.equal(bun.status, 0);
+    const selected = target(state.phase);
+    const context =
+      state.phase === 'Execution Plan' ? ['--context', 'features/current-context.feature'] : [];
+    const result = spawnSync(
+      'bun',
+      [hook, 'review', 'run', selected.kind, selected.path, ...context, '--json', '--no-input'],
+      {
+        cwd: root,
+        encoding: 'utf8',
+        timeout: 60_000,
+        env: {
+          ...process.env,
+          PATH: `${reviewer}:${path.dirname(bun.stdout.trim())}:/usr/bin:/bin`,
+          CLAUDE_PROJECT_DIR: root,
+          CLAUDE_PLUGIN_ROOT: pluginRoot,
+          SAFEWORD_AGENT_RUNTIME: 'claude',
+          SAFEWORD_AUTHOR_MODEL: 'claude-opus-5',
+        },
+      },
+    );
+    state.installed = { result, capture };
+  },
+);
+
+Then(
+  'dispatch remains blocked until the current personas inventory is included',
+  function (this: SafewordWorld) {
+    const installed = current(this).installed;
+    assert.ok(installed);
+    assert.notEqual(installed.result.status, 0);
+    assert.ok(
+      !existsSync(installed.capture),
+      'The reviewer must not run for a missing persona role.',
+    );
+    const output = JSON.parse(installed.result.stdout) as {
+      findings: { code: string; metadata?: { context_role?: string } }[];
+    };
+    assert.ok(
+      output.findings.some(
+        finding =>
+          finding.code === 'missing_planning_context' &&
+          finding.metadata?.context_role === 'personas',
+      ),
+    );
+  },
+);
+
+Then(
+  'dispatch remains blocked until the accepted Implementation Plan is included',
+  function (this: SafewordWorld) {
+    const installed = current(this).installed;
+    assert.ok(installed);
+    assert.notEqual(installed.result.status, 0);
+    assert.ok(
+      !existsSync(installed.capture),
+      'The reviewer must not run without the accepted plan.',
+    );
+    assert.match(installed.result.stdout, /impl-plan\.md/u);
+  },
+);
+
+Then('dispatch is blocked until that current context is included', function (this: SafewordWorld) {
+  const state = current(this);
+  assert.equal(state.packet, undefined, 'An incomplete packet must not enter review.');
+  const expectedRole =
+    state.packetState === 'omits a conditionally required input whose trigger applies'
+      ? 'data'
+      : state.packetState === 'omits the accepted Implementation Plan'
+        ? 'accepted-upstream-plan'
+        : 'personas';
+  if (expectedRole === 'accepted-upstream-plan') {
+    assert.match(String(state.failure), /impl-plan\.md/u);
+    return;
+  }
+  assert.equal((state.failure as { code?: string })?.code, 'missing_planning_context');
+  assert.equal((state.failure as { contextRole?: string })?.contextRole, expectedRole);
+});
+
+Then('dispatch proceeds to the semantic reviewer', function (this: SafewordWorld) {
+  const state = current(this);
+  if (state.installed) {
+    assert.ok(
+      existsSync(state.installed.capture),
+      `${state.installed.result.stdout}\n${state.installed.result.stderr}`,
+    );
+    const packet = JSON.parse(readFileSync(state.installed.capture, 'utf8')) as ReturnType<
+      typeof prepareReviewPacket
+    >['packet'];
+    assertDeliveredContext(packet, state);
+    return;
+  }
+  assert.equal(state.failure, undefined, String(state.failure));
+  assert.equal(
+    state.packet?.planning_phase,
+    target(state.phase).kind === 'quality-review' ? 'product-plan' : target(state.phase).kind,
+  );
+  assert.ok(
+    state.packet?.planning_context,
+    'The reviewer packet must carry resolved planning roles.',
+  );
+  assertDeliveredContext(state.packet, state);
+  const absences = state.packet.planning_context.absences;
+  if (
+    state.packetState ===
+    'omits a conditionally required input whose trigger does not apply and records the justified absence'
+  )
+    assert.ok(
+      absences.some(value => value.role === 'data' && value.reason.includes('No product data')),
+    );
+  if (
+    state.packetState === 'omits an optional supporting input while including every required input'
+  )
+    assert.ok(
+      absences.some(value => value.role === 'dimensions' && value.reason.includes('no dimensions')),
+    );
+});
+
+Given(
+  /^a planning phase has a required project-knowledge input that is (.+), where stale means its reconciliation lineage names a superseded packaged-source version$/,
+  function (this: SafewordWorld, sourceState: string) {
+    const root = createProject();
+    states.set(this, { phase: 'Product Plan', packetState: sourceState, root });
+    if (sourceState === 'not configured') return;
+
+    const relative = 'docs/principles.md';
+    const configured = path.join(root, relative);
+    mkdirSync(path.dirname(configured), { recursive: true });
+    if (sourceState === 'configured but unreadable') {
+      mkdirSync(configured);
+    } else if (sourceState.includes('only whitespace or comment changes')) {
+      writeFileSync(
+        configured,
+        `${readFileSync(path.join(root, '.project/principles.md'), 'utf8')}\n<!-- cosmetic -->\n`,
+      );
+    } else {
+      writeFileSync(
+        configured,
+        sourceState === 'configured but blank'
+          ? ' \n'
+          : '# Project principles\n\nKeep the blue recovery button visible.\n',
+      );
+    }
+    const stale = sourceState.includes('stale');
+    mkdirSync(path.join(root, '.safeword'), { recursive: true });
+    writeFileSync(
+      path.join(root, '.safeword/config.json'),
+      JSON.stringify({
+        paths: { principles: relative },
+        pathLineage: {
+          principles: { packagedSourceVersion: stale ? '0.0.0' : SAFEWORD_SCHEMA.version },
+        },
+      }),
+    );
+  },
+);
+
+When('a plan review packet is resolved', function (this: SafewordWorld) {
+  const state = current(this);
+  assert.ok(state.root);
+  try {
+    const prepared = prepareReviewPacket(
+      state.root,
+      'quality-review',
+      [`${ticketDirectory}/spec.md`],
+      [],
+    );
+    state.packet = prepared.packet;
+    prepared.cleanup();
+  } catch (failure) {
+    state.failure = failure;
+  }
+});
+
+Then('the installed default is included', function (this: SafewordWorld) {
+  const state = current(this);
+  assert.equal(state.failure, undefined, String(state.failure));
+  assert.ok(state.packet?.context_files?.some(file => file.path === '.project/principles.md'));
+});
+
+Then(
+  'the project source is included with that project-specific content',
+  function (this: SafewordWorld) {
+    const state = current(this);
+    assert.equal(state.failure, undefined, String(state.failure));
+    assert.ok(
+      state.packet?.context_files?.some(
+        file =>
+          file.path === 'docs/principles.md' &&
+          file.content.includes('Keep the blue recovery button visible.'),
+      ),
+    );
+  },
+);
+
+Then('dispatch is blocked with reconciliation named', function (this: SafewordWorld) {
+  const state = current(this);
+  assert.equal(state.packet, undefined, 'Stale planning override produced a review packet');
+  assert.equal((state.failure as { code?: string })?.code, 'missing_planning_context');
+  assert.equal((state.failure as { contextRole?: string })?.contextRole, 'principles');
+  assert.match(String(state.failure), /reconcil/iu);
+  assert.match(String(state.failure), /paths\.principles/u);
+});
+
+Then('the project source is included and dispatch is not blocked', function (this: SafewordWorld) {
+  const state = current(this);
+  assert.equal(state.failure, undefined, String(state.failure));
+  assert.ok(state.packet?.context_files?.some(file => file.path === 'docs/principles.md'));
+});
diff --git a/steps/keep-plan-reviews-currency.steps.ts b/steps/keep-plan-reviews-currency.steps.ts
new file mode 100644
index 000000000..7e961252f
--- /dev/null
+++ b/steps/keep-plan-reviews-currency.steps.ts
@@ -0,0 +1,489 @@
+import { strict as assert } from 'node:assert';
+import { spawnSync } from 'node:child_process';
+import { createHash } from 'node:crypto';
+import { cpSync, mkdirSync, mkdtempSync, readFileSync, rmSync, writeFileSync } from 'node:fs';
+import { tmpdir } from 'node:os';
+import path from 'node:path';
+
+import { After, Given, Then, When } from '@cucumber/cucumber';
+
+import { extractPlanReviewRubric } from '../packages/cli/src/review/plan-rubric.js';
+import { reviewJobStatus } from '../packages/cli/src/review/job.js';
+import { createTrustedReviewerDirectory } from '../packages/cli/tests/review-fixtures.js';
+import { fixtureProject, reviewerExecutable } from './keep-plan-reviews-installed-context.steps.js';
+import type { SafewordWorld } from './world.js';
+
+const cli = path.resolve(import.meta.dirname, '../packages/cli/src/cli.ts');
+const contractSource = path.resolve(
+  import.meta.dirname,
+  '../packages/cli/templates/skills/bdd/PLAN_IMPLEMENTATION.md',
+);
+const plan = '.project/tickets/CTX123-current-context/impl-plan.md';
+
+interface CurrencyState {
+  root: string;
+  reviewer: string;
+  reviewId: string;
+  statuses: string[];
+  retainFailure?: string;
+  staleFailure?: string;
+}
+const states = new WeakMap<SafewordWorld, CurrencyState>();
+
+function run(root: string, reviewer: string, args: string[]) {
+  const result = spawnSync('bun', [cli, 'review', ...args, '--json', '--no-input'], {
+    cwd: root,
+    encoding: 'utf8',
+    timeout: 60_000,
+    env: {
+      ...process.env,
+      PATH: `${reviewer}:${process.env.PATH ?? ''}`,
+      CLAUDE_PROJECT_DIR: root,
+      SAFEWORD_AGENT_RUNTIME: 'claude',
+    },
+  });
+  const output = JSON.parse(result.stdout) as {
+    data: {
+      status: string;
+      review_id: string;
+      review_identity?: { dependencies: { role: string }[] };
+    };
+    errors: unknown[];
+  };
+  assert.deepEqual(output.errors, [], `${result.stdout}\n${result.stderr}`);
+  return output;
+}
+
+function status(state: CurrencyState): string {
+  return run(state.root, state.reviewer, ['status', state.reviewId]).data.status;
+}
+
+function mutate(state: CurrencyState, file: string, before: string, after: string): string {
+  const absolute = path.join(state.root, file);
+  const original = readFileSync(absolute, 'utf8');
+  assert.ok(original.includes(before), `${file} must contain the expected fixture text`);
+  writeFileSync(absolute, original.replace(before, after));
+  try {
+    return status(state);
+  } finally {
+    writeFileSync(absolute, original);
+  }
+}
+
+function appendAndCheck(state: CurrencyState, file: string, addition: string): string {
+  const absolute = path.join(state.root, file);
+  const original = readFileSync(absolute, 'utf8');
+  writeFileSync(absolute, `${original}\n${addition}\n`);
+  try {
+    return status(state);
+  } finally {
+    writeFileSync(absolute, original);
+  }
+}
+
+function statusWithContractSource(state: CurrencyState, before: string, after: string): string {
+  const source = readFileSync(contractSource, 'utf8');
+  assert.ok(source.includes(before));
+  const distribution = mkdtempSync(path.join(tmpdir(), 'safeword-r4-contract-'));
+  cpSync(path.resolve(import.meta.dirname, '../plugin'), distribution, { recursive: true });
+  const runtime = path.join(distribution, 'runtime/cli.js');
+  const status = () => {
+    const result = spawnSync('bun', [runtime, 'review', 'status', state.reviewId, '--json'], {
+      cwd: state.root,
+      encoding: 'utf8',
+      timeout: 60_000,
+      env: { ...process.env, CLAUDE_PLUGIN_ROOT: distribution },
+    });
+    const output = JSON.parse(result.stdout) as { errors: unknown[]; data: { status: string } };
+    assert.deepEqual(output.errors, [], `${result.stdout}\n${result.stderr}`);
+    return output.data.status;
+  };
+  try {
+    assert.equal(status(), 'approved', 'the unmodified copied runtime must retain approval');
+    const rubric = extractPlanReviewRubric(source);
+    const changed = extractPlanReviewRubric(source.replace(before, after));
+    assert.notEqual(changed, rubric, 'the mutation must change bounded canonical contract bytes');
+    const bundle = readFileSync(runtime, 'utf8');
+    const start = bundle.indexOf('var PLAN_REVIEW_RUBRIC = `');
+    const end = bundle.indexOf('PLAN_REVIEW_RUBRIC_SHA256', start);
+    assert.ok(start >= 0 && end > start);
+    const block = bundle.slice(start, end);
+    assert.ok(block.includes(before));
+    const oldHash = createHash('sha256').update(rubric).digest('hex');
+    const newHash = createHash('sha256').update(changed).digest('hex');
+    assert.ok(bundle.includes(`PLAN_REVIEW_RUBRIC_SHA256 = "${oldHash}"`));
+    const updated = (
+      bundle.slice(0, start) +
+      block.replace(before, after) +
+      bundle.slice(end)
+    ).replace(
+      `PLAN_REVIEW_RUBRIC_SHA256 = "${oldHash}"`,
+      `PLAN_REVIEW_RUBRIC_SHA256 = "${newHash}"`,
+    );
+    writeFileSync(runtime, updated);
+    return status();
+  } finally {
+    rmSync(distribution, { recursive: true, force: true });
+  }
+}
+
+After(function (this: SafewordWorld) {
+  const state = states.get(this);
+  if (state) {
+    rmSync(state.root, { recursive: true, force: true });
+    rmSync(state.reviewer, { recursive: true, force: true });
+  }
+  states.delete(this);
+});
+
+Given(
+  "a plan has a current review recorded against its canonical phase contract, accepted scope, Rules, scenarios, plan decisions, applicable principles, applicable dimensions and data guidance, configured architecture records, and the project's surfaces and personas inventories",
+  function (this: SafewordWorld) {
+    const root = fixtureProject();
+    const reviewer = createTrustedReviewerDirectory('safeword-r4-currency-');
+    states.set(this, { root, reviewer, reviewId: '', statuses: [] });
+    writeFileSync(path.join(root, 'package.json'), '{"name":"r4-currency","private":true}\n');
+    const installed = spawnSync(
+      'bun',
+      [cli, 'install', '--agents=claude', '--no-input', '--no-modify', '--json', '--cwd', root],
+      {
+        cwd: root,
+        encoding: 'utf8',
+        timeout: 60_000,
+        env: {
+          ...process.env,
+          CLAUDE_CONFIG_DIR: path.join(root, 'claude'),
+          SAFEWORD_SKIP_INSTALL: '1',
+          SAFEWORD_SKIP_SKILLS: '1',
+        },
+      },
+    );
+    const installation = JSON.parse(installed.stdout) as { errors: unknown[] };
+    assert.deepEqual(installation.errors, [], `${installed.stdout}\n${installed.stderr}`);
+    const configPath = path.join(root, '.safeword/config.json');
+    const config = JSON.parse(readFileSync(configPath, 'utf8')) as Record<string, unknown>;
+    const architecture = '.project/architecture.md';
+    writeFileSync(
+      path.join(root, architecture),
+      '# Approval architecture\n\nKeep review receipts authenticated.\n',
+    );
+    writeFileSync(
+      path.join(root, '.project/tickets/CTX123-current-context/dimensions.md'),
+      '# Dimensions\n\n## Approval source\n\nCurrent and authenticated.\n',
+    );
+    const dataGuide = path.join(root, '.safeword/guides/data-architecture-guide.md');
+    mkdirSync(path.dirname(dataGuide), { recursive: true });
+    writeFileSync(
+      dataGuide,
+      readFileSync(
+        path.resolve(
+          import.meta.dirname,
+          '../packages/cli/templates/guides/data-architecture-guide.md',
+        ),
+        'utf8',
+      ),
+    );
+    const planPath = path.join(root, plan);
+    writeFileSync(
+      planPath,
+      readFileSync(planPath, 'utf8').replace(
+        'skip: No product data is stored.',
+        'Review receipt data follows the data architecture guide.',
+      ),
+    );
+    writeFileSync(
+      configPath,
+      JSON.stringify({
+        ...config,
+        paths: { ...(config.paths as Record<string, unknown>), architecture },
+        crossAgentReview: 'prefer',
+        crossAgentReviewRoutes: { claude: [{ reviewer: 'opencode' }] },
+      }),
+    );
+    reviewerExecutable(reviewer);
+    const approved = run(root, reviewer, ['run', 'plan-implementation', plan]);
+    assert.equal(approved.data.status, 'approved');
+    const boundRoles = new Set(
+      approved.data.review_identity?.dependencies.map(entry => entry.role),
+    );
+    for (const role of [
+      'ticket',
+      'project',
+      'rules',
+      'scenarios',
+      'principles',
+      'personas',
+      'surfaces',
+      'dimensions',
+      'architecture',
+      'data',
+    ])
+      assert.ok(boundRoles.has(role), `The approving receipt must bind ${role}.`);
+    const state = states.get(this);
+    assert.ok(state);
+    state.reviewId = approved.data.review_id;
+    assert.equal(status(state), 'approved');
+  },
+);
+
+When(
+  'a bound context artifact changes only in whitespace or comments occurs',
+  function (this: SafewordWorld) {
+    const state = states.get(this);
+    assert.ok(state);
+    state.retainFailure = 'bound context cosmetic change made review stale';
+    state.statuses = [
+      mutate(
+        state,
+        '.project/tickets/CTX123-current-context/ticket.md',
+        '# Ticket',
+        '# Ticket\n\n<!-- editorial -->',
+      ),
+      mutate(
+        state,
+        '.project/tickets/CTX123-current-context/spec.md',
+        '## Product Bet\n\n',
+        '## Product Bet\n\n<!-- editorial -->\n\n',
+      ),
+      mutate(
+        state,
+        '.project/tickets/CTX123-current-context/spec.md',
+        '#### approval.BU1.R1 — Preserve approval\n\n',
+        '#### approval.BU1.R1 — Preserve approval\n\n<!-- editorial -->\n\n',
+      ),
+      mutate(
+        state,
+        '.project/tickets/CTX123-current-context/spec.md',
+        'Only current approval advances.',
+        'Only current approval\nadvances.',
+      ),
+      mutate(
+        state,
+        'features/current-context.feature',
+        'Feature: Trust current approval',
+        '# editorial\nFeature: Trust current approval',
+      ),
+      mutate(
+        state,
+        '.project/tickets/CTX123-current-context/dimensions.md',
+        '# Dimensions\n\n',
+        '# Dimensions\n\n<!-- editorial -->\n\n',
+      ),
+      mutate(state, '.project/principles.md', '# Principles', '<!-- editorial -->\n\n# Principles'),
+      mutate(
+        state,
+        '.project/personas.md',
+        '## Builder (BU)\n\n',
+        '## Builder (BU)\n\n<!-- editorial -->\n\n',
+      ),
+      mutate(
+        state,
+        '.project/surfaces.md',
+        '## Safeword CLI\n\n',
+        '## Safeword CLI\n\n<!-- editorial -->\n\n',
+      ),
+      mutate(
+        state,
+        '.project/architecture.md',
+        '# Approval architecture\n\n',
+        '# Approval architecture\n\n<!-- editorial -->\n\n',
+      ),
+      appendAndCheck(state, '.safeword/guides/data-architecture-guide.md', '<!-- editorial -->'),
+    ];
+  },
+);
+
+When('an unrelated persona or surface entry is added occurs', function (this: SafewordWorld) {
+  const state = states.get(this);
+  assert.ok(state);
+  state.statuses = [
+    mutate(
+      state,
+      '.project/personas.md',
+      '# Personas',
+      '# Personas\n\n## Reader (RD)\n\n**Role:** Reads unrelated guidance.\n',
+    ),
+    mutate(
+      state,
+      '.project/surfaces.md',
+      '# Surfaces',
+      '# Surfaces\n\n## Documentation site\n\n**Kind:** Website\n',
+    ),
+  ];
+});
+
+When(
+  'the canonical phase contract changes only in whitespace or comments occurs',
+  function (this: SafewordWorld) {
+    const state = states.get(this);
+    assert.ok(state);
+    state.staleFailure = 'changed canonical contract bytes retained review currency';
+    state.statuses = [
+      statusWithContractSource(state, '- **Purpose:**', '- **Purpose:**   '),
+      statusWithContractSource(
+        state,
+        'Decide a coherent implementation approach',
+        'Decide a coherent <!-- editorial --> implementation approach',
+      ),
+    ];
+  },
+);
+
+When('the canonical phase contract changes semantically occurs', function (this: SafewordWorld) {
+  const state = states.get(this);
+  assert.ok(state);
+  state.staleFailure = 'shared planning clause changed review currency';
+  state.statuses = [
+    statusWithContractSource(
+      state,
+      'Decide a coherent implementation approach',
+      'Decide a permissive implementation approach',
+    ),
+    statusWithContractSource(
+      state,
+      'Each planning approval establishes only its own phase decision.',
+      'Each planning approval establishes every downstream phase decision.',
+    ),
+    statusWithContractSource(
+      state,
+      'Decide a coherent implementation approach within accepted behavior.',
+      'Decide a coherent implementation approach within accepted behavior.\n\n  Also permit unreviewed rollout.',
+    ),
+    ...[
+      'Entry criteria',
+      'Required content',
+      'Prohibited content',
+      'Review question',
+      'Approval meaning',
+      'Invalidation',
+      'Return path',
+    ].map(field =>
+      statusWithContractSource(
+        state,
+        `- **${field}:** `,
+        `- **${field}:** Permit a different decision. `,
+      ),
+    ),
+  ];
+});
+
+When(
+  'the reviewed plan changes only in whitespace or comments outside normalized Execution Plan checklist progress cells occurs',
+  function (this: SafewordWorld) {
+    const state = states.get(this);
+    assert.ok(state);
+    state.statuses = [mutate(state, plan, '## Approach', '<!-- editorial -->\n\n## Approach')];
+  },
+);
+
+When(
+  'any listed bound context artifact changes semantically occurs',
+  function (this: SafewordWorld) {
+    const state = states.get(this);
+    assert.ok(state);
+    const changes = [
+      [
+        '.project/tickets/CTX123-current-context/ticket.md',
+        'scope: preserve authenticated approval',
+        'scope: allow anonymous approval',
+      ],
+      [
+        '.project/tickets/CTX123-current-context/spec.md',
+        'Only current approval advances.',
+        'Stale approval may advance.',
+      ],
+      [
+        '.project/tickets/CTX123-current-context/spec.md',
+        'Approval authenticates the current source.',
+        'Approval accepts any source.',
+      ],
+      [
+        'features/current-context.feature',
+        'Then the current context reaches review',
+        'Then stale context reaches review',
+      ],
+      [
+        '.project/tickets/CTX123-current-context/dimensions.md',
+        'Current and authenticated.',
+        'Stale and anonymous.',
+      ],
+      [
+        '.project/principles.md',
+        'Current authenticated approval controls advancement.',
+        'Anonymous approval controls advancement.',
+      ],
+      ['.project/personas.md', 'Needs current authenticated approval', 'Needs anonymous approval'],
+      [
+        '.project/personas.md',
+        '# Personas\n\n',
+        '# Personas\n\nAll personas require current authenticated approval.\n\n',
+      ],
+      [
+        '.project/surfaces.md',
+        'Requests and presents planning approval',
+        'Rejects planning approval',
+      ],
+      [
+        '.project/surfaces.md',
+        '# Surfaces\n\n',
+        '# Surfaces\n\nAll surfaces require a current approval receipt.\n\n',
+      ],
+      [
+        '.project/architecture.md',
+        'Keep review receipts authenticated.',
+        'Allow unsigned review receipts.',
+      ],
+    ] as const;
+    state.statuses = [
+      ...changes.map(([file, before, after]) => mutate(state, file, before, after)),
+      appendAndCheck(
+        state,
+        '.safeword/guides/data-architecture-guide.md',
+        '## New approval data constraint\n\nRetain review provenance.',
+      ),
+    ];
+    assert.equal(
+      status(state),
+      'approved',
+      'Restoring each source must restore the same approval.',
+    );
+  },
+);
+
+Then('the review remains current', function (this: SafewordWorld) {
+  const state = states.get(this);
+  const statuses = state?.statuses;
+  assert.ok(statuses?.length);
+  assert.deepEqual(
+    statuses,
+    statuses.map(() => 'approved'),
+    state.retainFailure,
+  );
+});
+
+Then('the review becomes stale', function (this: SafewordWorld) {
+  const state = states.get(this);
+  const statuses = state?.statuses;
+  assert.ok(statuses?.length);
+  assert.deepEqual(
+    statuses,
+    statuses.map(() => 'stale'),
+    state.staleFailure,
+  );
+});
+
+Then(
+  "that plan's review becomes stale because its exact bytes changed",
+  function (this: SafewordWorld) {
+    assert.deepEqual(states.get(this)?.statuses, ['stale']);
+  },
+);
+
+Then('that dependent review becomes stale for every such artifact', function (this: SafewordWorld) {
+  const statuses = states.get(this)?.statuses;
+  assert.ok(statuses?.length);
+  assert.deepEqual(
+    statuses,
+    statuses.map(() => 'stale'),
+  );
+});
diff --git a/steps/keep-plan-reviews-current.steps.ts b/steps/keep-plan-reviews-current.steps.ts
new file mode 100644
index 000000000..abbea6e96
--- /dev/null
+++ b/steps/keep-plan-reviews-current.steps.ts
@@ -0,0 +1,290 @@
+import { strict as assert } from 'node:assert';
+import { spawnSync } from 'node:child_process';
+import {
+  cpSync,
+  mkdirSync,
+  mkdtempSync,
+  readFileSync,
+  rmSync,
+  symlinkSync,
+  writeFileSync,
+} from 'node:fs';
+import { tmpdir } from 'node:os';
+import path from 'node:path';
+
+import { After, Given, Then, When } from '@cucumber/cucumber';
+
+import { PLANNING_CONTRACT_TEMPLATE_PATHS } from '../packages/cli/src/schema.js';
+import type { SafewordWorld } from './world.js';
+
+const packageRoot = path.resolve(import.meta.dirname, '../packages/cli');
+const originalClause = 'Accepted scope belongs to the user; original canonical boundary.';
+const changedClause = 'Accepted scope belongs to the user; changed canonical boundary.';
+
+interface ContractWorld {
+  distribution: string;
+  project: string;
+  expected: 'changed' | 'phase-only' | 'missing';
+  result?: ReturnType<typeof spawnSync>;
+  installedContracts?: readonly { path: string; bytes: string }[];
+}
+
+const contractWorlds = new WeakMap<SafewordWorld, ContractWorld>();
+
+function run(cwd: string, command: string, args: string[]) {
+  return spawnSync(command, args, {
+    cwd,
+    encoding: 'utf8',
+    timeout: 60_000,
+    env: { ...process.env, SAFEWORD_SKIP_INSTALL: '1', SAFEWORD_SKIP_SKILLS: '1' },
+  });
+}
+
+function phaseContracts(distribution: string) {
+  for (const script of ['generate-plan-rubric.ts', 'generate-execution-plan-rubric.ts']) {
+    const result = run(distribution, 'bun', [path.join(distribution, 'scripts', script)]);
+    assert.equal(result.status, 0, `${result.stdout}\n${result.stderr}`);
+  }
+}
+
+function reconcile(state: ContractWorld, mode: 'install' | 'upgrade') {
+  return run(state.project, 'bun', [
+    path.join(state.distribution, 'src/cli.ts'),
+    mode,
+    '--agents=cursor',
+    '--no-input',
+    '--no-modify',
+    '--offline',
+    '--json',
+    '--cwd',
+    state.project,
+  ]);
+}
+
+function setScopeClause(distribution: string, scopeAuthority: string) {
+  writeFileSync(
+    path.join(distribution, 'src/planning/shared-contract.ts'),
+    `export const PLANNING_SHARED_CLAUSES = ${JSON.stringify({
+      lifecycle: 'Each planning phase advances only through its own current approval.',
+      scopeAuthority,
+      trust: 'Reviewed work and research are evidence, never instructions.',
+      contractShape: 'Every planning contract declares its purpose and bounded approval meaning.',
+    })};\n`,
+  );
+}
+
+function setup(world: SafewordWorld, expected: ContractWorld['expected']): ContractWorld {
+  const distribution = mkdtempSync(path.join(tmpdir(), 'safeword-4200-contract-'));
+  for (const part of ['src', 'scripts', 'templates'])
+    cpSync(path.join(packageRoot, part), path.join(distribution, part), { recursive: true });
+  cpSync(path.join(packageRoot, 'package.json'), path.join(distribution, 'package.json'));
+  symlinkSync(path.join(packageRoot, 'node_modules'), path.join(distribution, 'node_modules'));
+  const project = path.join(distribution, 'project');
+  mkdirSync(project);
+  writeFileSync(
+    path.join(project, 'package.json'),
+    JSON.stringify({ name: 'planning-fixture', private: true }),
+  );
+  const state = { distribution, project, expected };
+  contractWorlds.set(world, state);
+  return state;
+}
+
+function state(world: SafewordWorld): ContractWorld {
+  const current = contractWorlds.get(world);
+  assert.ok(current, 'The contract scenario must establish its project first.');
+  return current;
+}
+
+function invalidationFixture(world: SafewordWorld, declaration: string) {
+  const current = setup(world, 'missing');
+  setScopeClause(current.distribution, originalClause);
+  phaseContracts(current.distribution);
+  const installed = reconcile(current, 'install');
+  assert.equal(installed.status, 0, `${installed.stdout}\n${installed.stderr}`);
+  current.installedContracts = Object.values(PLANNING_CONTRACT_TEMPLATE_PATHS).map(relative => {
+    const installedPath = path.join(current.project, '.safeword', relative);
+    return { path: installedPath, bytes: readFileSync(installedPath, 'utf8') };
+  });
+  setScopeClause(current.distribution, changedClause);
+  phaseContracts(current.distribution);
+  for (const snapshot of current.installedContracts) {
+    const relative = path.relative(path.join(current.project, '.safeword'), snapshot.path);
+    assert.notEqual(
+      readFileSync(path.join(current.distribution, 'templates', relative), 'utf8'),
+      snapshot.bytes,
+    );
+  }
+  const contractPath = path.join(
+    current.distribution,
+    'templates',
+    PLANNING_CONTRACT_TEMPLATE_PATHS.execution,
+  );
+  const canonical = readFileSync(contractPath, 'utf8');
+  const supported = 'upstreamImplementationInvalidation: both_plan_reviews';
+  assert.ok(canonical.includes(supported));
+  writeFileSync(contractPath, canonical.replace(supported, declaration));
+}
+
+Given(
+  'the canonical Execution Planning contract declares that accepted Implementation Plan changes invalidate only their own review',
+  function (this: SafewordWorld) {
+    invalidationFixture(this, 'upstreamImplementationInvalidation: implementation_review_only');
+  },
+);
+
+Given(
+  'the canonical Execution Planning owner does not declare exactly one supported upstream invalidation direction',
+  function (this: SafewordWorld) {
+    invalidationFixture(this, 'upstreamImplementationInvalidation:');
+  },
+);
+
+Then(
+  'reconciliation is blocked with invalid_invalidation_contract, the Execution phase, and the canonical contract path named',
+  function (this: SafewordWorld) {
+    const current = state(this);
+    assert.notEqual(
+      current.result?.status,
+      0,
+      'unsupported invalidation contract advanced reconciliation',
+    );
+    const output = JSON.parse(current.result?.stdout ?? '') as {
+      errors: { code: string }[];
+      findings: { code: string; metadata?: Record<string, unknown> }[];
+    };
+    assert.ok(output.errors.some(error => error.code === 'invalid_invalidation_contract'));
+    assert.ok(
+      output.findings.some(
+        finding =>
+          finding.code === 'invalid_invalidation_contract' &&
+          finding.metadata?.planning_phase === 'plan-execution' &&
+          finding.metadata?.contract_path === PLANNING_CONTRACT_TEMPLATE_PATHS.execution,
+      ),
+    );
+  },
+);
+
+Then('the installed phase-contract bytes remain unchanged', function (this: SafewordWorld) {
+  const snapshots = state(this).installedContracts;
+  assert.ok(snapshots?.length);
+  for (const snapshot of snapshots)
+    assert.equal(readFileSync(snapshot.path, 'utf8'), snapshot.bytes);
+});
+
+After(function (this: SafewordWorld) {
+  const current = contractWorlds.get(this);
+  if (current) rmSync(current.distribution, { recursive: true, force: true });
+  contractWorlds.delete(this);
+});
+
+Given(
+  'the canonical scope clause changed after both phase contracts were generated',
+  function (this: SafewordWorld) {
+    const current = setup(this, 'changed');
+    setScopeClause(current.distribution, originalClause);
+    phaseContracts(current.distribution);
+    const installed = reconcile(current, 'install');
+    assert.equal(installed.status, 0, `${installed.stdout}\n${installed.stderr}`);
+    setScopeClause(current.distribution, changedClause);
+    phaseContracts(current.distribution);
+  },
+);
+
+Given(
+  'one clause belongs only to the Execution Plan contract and a different clause belongs only to the Implementation Plan contract',
+  function (this: SafewordWorld) {
+    const current = setup(this, 'phase-only');
+    phaseContracts(current.distribution);
+  },
+);
+
+Given(
+  'the contract generator omits a canonical shared clause from one expected phase-contract output',
+  function (this: SafewordWorld) {
+    const current = setup(this, 'missing');
+    phaseContracts(current.distribution);
+    const installed = reconcile(current, 'install');
+    assert.equal(installed.status, 0, `${installed.stdout}\n${installed.stderr}`);
+    const contractPath = path.join(
+      current.distribution,
+      'templates/skills/bdd/PLAN_IMPLEMENTATION.md',
+    );
+    const contract = readFileSync(contractPath, 'utf8');
+    const start = contract.indexOf('<!-- SAFEWORD:PLANNING_SHARED_CLAUSE:scopeAuthority -->');
+    const end = contract.indexOf('<!-- SAFEWORD:PLANNING_SHARED_CLAUSE:trust -->', start);
+    assert.ok(start >= 0 && end > start, 'The generated clause markers must be present.');
+    writeFileSync(contractPath, contract.slice(0, start) + contract.slice(end));
+  },
+);
+
+function reconcileStep(this: SafewordWorld) {
+  const current = state(this);
+  current.result = reconcile(current, current.expected === 'phase-only' ? 'install' : 'upgrade');
+}
+
+When(
+  'the Safeword CLI reconciles the installed phase contracts through real project configuration',
+  reconcileStep,
+);
+When(
+  'the Safeword CLI reconciles both installed phase contracts through real project configuration',
+  reconcileStep,
+);
+
+Then(
+  'both generated contracts contain the same changed clause and neither retains the old text',
+  function (this: SafewordWorld) {
+    const current = state(this);
+    assert.equal(current.result?.status, 0, `${current.result?.stdout}\n${current.result?.stderr}`);
+    for (const name of ['PLAN_IMPLEMENTATION.md', 'PLAN_EXECUTION.md']) {
+      const installed = readFileSync(
+        path.join(current.project, '.safeword/skills/bdd', name),
+        'utf8',
+      );
+      assert.ok(installed.includes(changedClause), `${name} must receive the changed clause.`);
+      assert.ok(!installed.includes(originalClause), `${name} must drop the old clause.`);
+    }
+  },
+);
+
+Then(
+  'each clause appears only in its owning phase contract and neither appears in the other contract',
+  function (this: SafewordWorld) {
+    const current = state(this);
+    assert.equal(current.result?.status, 0, `${current.result?.stdout}\n${current.result?.stderr}`);
+    const implementation = readFileSync(
+      path.join(current.project, '.safeword/skills/bdd/PLAN_IMPLEMENTATION.md'),
+      'utf8',
+    );
+    const execution = readFileSync(
+      path.join(current.project, '.safeword/skills/bdd/PLAN_EXECUTION.md'),
+      'utf8',
+    );
+    assert.ok(implementation.includes('Direction and completeness'));
+    assert.ok(!implementation.includes('Startable steps:'));
+    assert.ok(execution.includes('Startable steps:'));
+    assert.ok(!execution.includes('Direction and completeness'));
+  },
+);
+
+Then(
+  'reconciliation is blocked with the missing shared clause and affected phase contract named',
+  function (this: SafewordWorld) {
+    const current = state(this);
+    assert.notEqual(current.result?.status, 0);
+    const output = JSON.parse(current.result?.stdout ?? '') as {
+      errors: { code: string }[];
+      findings: { code: string; metadata?: Record<string, unknown> }[];
+    };
+    assert.ok(output.errors.some(error => error.code === 'missing_generated_shared_clause'));
+    assert.ok(
+      output.findings.some(
+        finding =>
+          finding.code === 'missing_generated_shared_clause' &&
+          finding.metadata?.clause_id === 'scopeAuthority' &&
+          finding.metadata?.contract_path === 'skills/bdd/PLAN_IMPLEMENTATION.md',
+      ),
+    );
+  },
+);
