# R9 receipt provenance regression control

The same three native phase-gate assertions run against the full plugin tree from committed pre-fix source 95c264f1282884bc803f0ba0db7537380c66bcff. The control was extracted without edits using `git archive 95c264f1282884bc803f0ba0db7537380c66bcff plugin | tar -x -C /tmp/4200-r9-native-baseline`.

The optional test-only SAFEWORD_RECEIPT_PROOF_PLUGIN_ROOT selects that installed plugin boundary. It does not change assertions, receipts, the tested project's configuration, or production source. The public fixture CLI remains current and creates genuine signed reviews; only the external reviewer process is simulated. With the old plugin, the matching approval passes and both mismatches fail at their Then assertions: the gate refuses execution but returns only “An admitted Delivery Checklist is required before execution.” instead of naming the mismatched review kind or sibling ticket and re-review. The repaired plugin passes the identical assertions without the baseline override.

This is regression proof for an existing repaired behavior, not a claim that a new production repair remains to implement. The earlier undefined-step attestation fd631781-29f3-4af0-b49b-e894f05be5a6 was rejected and is not authorization for GREEN. The first partial baseline extraction omitted plugin metadata and failed at setup; its log is retained and is not the intended RED evidence.

Root Cucumber's background and hooks account for the additional steps. The JSON formatter records exactly three scenario elements for the selected outline; each includes its Background steps. The current result is three passes; the baseline result is one pass and two assertion failures.

Evidence: /tmp/4200-r9-receipt-bdd-baseline.json and .log; current /tmp/4200-r9-receipt-bdd-bound.json and .log. Evidence class is simulated-host: actual native hook, authentic local CLI receipts, fake external reviewer, no claim of actual cloud execution.
