Review the complete exact PR #4991 diff. Base: 42c6d2ea88c88f2ffc029c321ea4f0c97e489dae. Head: 1b79d7763a04d5df73022ebe4610c166366b0cb2. Every changed file is included below. Judge correctness, authenticated approval preservation, truthful rejection reporting, the concurrency repair, test strength, and scope. Generated carrier changes are derived from canonical guidance/source and pass all five generated checks. Both Node CI jobs pass 10944 CLI tests with 10 existing skips. The uncommitted legacy diagnostic is excluded from this committed diff and remains a known out-of-scope migration gap; do not invent a passing legacy repair or whole-epic acceptance. Historical verification documents are explicitly historical, not current-head proof. No PR merge or promotion is authorized. Review the supplied committed diff rather than unrelated current checkout source.

diff --git a/.claude/skills/bdd/PLAN_IMPLEMENTATION.md b/.claude/skills/bdd/PLAN_IMPLEMENTATION.md
index a9a785214..6619f60ce 100644
--- a/.claude/skills/bdd/PLAN_IMPLEMENTATION.md
+++ b/.claude/skills/bdd/PLAN_IMPLEMENTATION.md
@@ -330,6 +330,10 @@ receipt controls eligibility for approval and phase advancement.
    safeword ticket approve-plan <ticket-id>
    ```
 
+   Use the authenticated phase stamp from step 1; no additional artifact self-stamp
+   is required. Admission still authenticates reviewer provenance and rechecks
+   the exact reviewed plan bytes. Approved warnings are not rejection findings.
+
    Never replace this command with conversational approval or a manual phase
    edit. It rechecks the exact reviewed plan bytes and the current project
    configuration. When `designApprovalGate` is absent or off, it records `not
diff --git a/.project/tickets/D1BKYA-let-approved-planning-reviews-advance-honestly/test-definitions.md b/.project/tickets/D1BKYA-let-approved-planning-reviews-advance-honestly/test-definitions.md
new file mode 100644
index 000000000..911aabcf8
--- /dev/null
+++ b/.project/tickets/D1BKYA-let-approved-planning-reviews-advance-honestly/test-definitions.md
@@ -0,0 +1,25 @@
+# D1BKYA regression proof
+
+## Scenario: Approved warnings advance on authenticated phase authority
+
+Given a current coordinator approval with a warning and only its phase stamp
+When the installed CLI approves the Implementation Plan
+Then it enters Execution Planning without another artifact stamp
+
+- [x] RED d17892b68
+- [x] GREEN 14878b34a
+- [x] REFACTOR skip: removed the duplicate check and its unused imports; authentication stays in its existing owner
+
+## Scenario: Refusals report actual evidence failures and rejection findings
+
+Given rejected, missing, or stale planning evidence
+When the installed CLI approves the Implementation Plan
+Then only a current rejection reports reviewer findings and other refusals name the evidence failure
+
+- [x] RED d17892b68
+- [x] GREEN 5622a89
+- [x] REFACTOR skip: the existing authenticated status query owns freshness; rendering filters only actual rejection findings
+
+## Feature-level cross-scenario refactor
+
+- [x] cross-scenario skip: both loops share the existing phase-admission service; no new authority or abstraction is needed
diff --git a/.project/tickets/D1BKYA-let-approved-planning-reviews-advance-honestly/ticket.md b/.project/tickets/D1BKYA-let-approved-planning-reviews-advance-honestly/ticket.md
new file mode 100644
index 000000000..712cd3115
--- /dev/null
+++ b/.project/tickets/D1BKYA-let-approved-planning-reviews-advance-honestly/ticket.md
@@ -0,0 +1,97 @@
+---
+id: D1BKYA
+slug: let-approved-planning-reviews-advance-honestly
+type: task
+phase: implement
+status: in_progress
+subtype: bug-investigated
+scope: Repair the redundant planning-approval prerequisite and misleading rejection rendering diagnosed in 5F5ZZA PR 1.
+out_of_scope: Contract generation, semantic context identity, fallback routing, reviewer rubrics, migration, and new approval authority.
+done_when: Real CLI tests distinguish approved warnings, rejection findings, missing receipts, and stale receipts; relevant verification and independent review pass.
+created: 2026-09-26T02:55:10.402Z
+last_modified: 2026-09-26T02:55:10.402Z
+---
+
+# Let approved planning reviews advance honestly
+
+**Goal:** Honor one authenticated current planning approval and report only real review rejection findings.
+
+**Why:** 5F5ZZA PR 1 diagnoses a redundant stamp prerequisite and approved warnings rendered as rejection reasons.
+
+## Work Log
+
+- 2026-09-26T02:55:10.402Z Started: Created ticket D1BKYA
+
+## Approved scope
+
+This implements only PR 1 of [5F5ZZA's Execution Plan](../5F5ZZA-keep-plan-reviews-current-and-trustworthy/execution-plan.md) under epic #4200. The existing phase-admission service remains the single authenticated review authority. Structural Implementation Plan validation stays in its existing gate.
+
+## Root cause
+
+`currentReview` in `packages/cli/src/commands/plan-approval.ts` requires both an artifact self-stamp and authenticated phase admission. A current phase approval can therefore be rejected solely for lacking the redundant artifact stamp. `latestReviewRejection` renders any matching review's findings without checking `status === 'changes_requested'`, turning approved warnings into apparent rejection reasons.
+
+The approved plan records the exact reproduction: a coordinator approval with warnings and a phase stamp failed; adding the weaker artifact stamp let it advance. Current source confirms both mechanisms. Missing authentication and stale plan bytes are distinct valid refusals, not reasons to preserve the duplicate authority path.
+
+## Verification plan
+
+First reproduce the failure through `ticket approve-plan` with the real CLI and coordinator, mocking only the reviewer process. Prove a current approved review with warnings advances without the extra artifact stamp, an actual rejection reports its findings, and missing or stale evidence reports its admission failure rather than approved findings. Then remove the duplicate check, keep current authentication/digest enforcement, and update the canonical review/stamp/approve guidance without adding another receipt path.
+
+Targeted checks: `plan-design-approval.test.ts`, `plan-transition-gate.test.ts`, and `review-receipt-wiring.test.ts`. Before delivery: relevant lint/typecheck, full package verification, generated-host parity if guidance changes, and independent review. No completion or Ready claim is made before those results are collected.
+
+- Resume: Confirmed the approved PR 1 scope and existing real CLI harness. Begin RED for a warning-bearing approval with only the authenticated phase stamp.
+
+- Implementation: RED d17892b68; authenticated phase approval GREEN 14878b34a;
+  truthful rejection GREEN 5622a89b8. Both executable RED proofs earned independent
+  coordinator approval. The five-file focused verification passed all 123 tests.
+- Final review: current-source Claude review 8ef57710-b37d-4576-882b-730003b2085f
+  approved with no error findings. Warnings and remaining verification are recorded
+  in verify.md; completion is not yet claimed.
+- User-requested toolchain repair: repository launcher and Git hook now resolve
+  pinned Bun/Node for child processes. The personal shell-profile workaround was
+  reverted. This explicit additional scope does not change planning authority.
+
+- Scoped delivery continuation: this checkout contains only D1BKYA and its
+  required generated guidance, lifecycle fingerprints and acceptance counts,
+  stacked on the separately scoped repository-toolchain branch. Review IDs and
+  RED/GREEN commit IDs above describe the original continuation checkout; no
+  authenticated receipt or review key was copied here. Fresh local verification
+  and independent review are required before any delivery completion claim.
+
+- Current-main integration, 2026-10-07: merged the repository-toolchain slice
+  `42c6d2ea88c88f2ffc029c321ea4f0c97e489dae`, which carries main `485d8ac`.
+  Frozen installation, typecheck, and all five regenerated surfaces passed.
+  Four complete targeted files report **139 passed, one failed** (140 total).
+  The failure is the preserved legacy execution-discovery regression: a second
+  `approve-plan` reuses the old Implementation approval without repair (expected
+  exit 2, actual exit 0). No test was filtered or weakened. Logs:
+  `/tmp/4200-D1-main-targeted.log`, `/tmp/4200-D1-main-typecheck.log`, and
+  `/tmp/4200-D1-main-generated.log`. The pending diagnostic test and its existing
+  `verify.md` investigation remain unstaged and byte-identical to their saved
+  pre-merge snapshots. The merge does not claim this defect fixed, acceptance
+  complete, a Ready promotion, or human merge approval.
+
+- Fresh bounded Claude review `33c980be-06fa-4835-848a-18f44dc1f089`
+  approved the D1 material diff with no error findings. This does not overturn
+  the actual failing diagnostic. Its suggested specific-denial assertion and
+  formatting apply to that unstaged RED investigation, not a passing delivery
+  test; they remain pending scoped repair rather than silently modifying tests.
+  The mirrored guidance is regenerated and its complete document-contract file
+  passed in the 139-test result. A rejection from earlier plan bytes can still
+  be rendered as the reason for refusing unreviewed current bytes; admission
+  remains closed, and no claim that this informational limitation is fixed is
+  made. Log: `/tmp/4200-D1-main-quality.json`.
+
+- Concurrent approval scaffold repair: Node 22 CI on acceptance head
+  `65f7963af` reported one failed CLI invocation. A deterministic installed-CLI
+  regression reproduced exits `[1, 0]` when both approvals observed the absent
+  Execution Plan before exclusive creation. The repair handles only `EEXIST`
+  from the losing create; all other errors still throw. The new regression
+  passes with the repair, and both concurrency cases pass in D1 (2 passed,
+  35 filtered by the explicit targeted selector). Logs:
+  `/tmp/4200-scaffold-permanent-red.log`,
+  `/tmp/4200-scaffold-permanent-green.log`, and
+  `/tmp/4200-scaffold-D1-permanent-green.log`. Source review
+  `441e7626-977b-424b-9970-3794e263b2c0` approved the narrow repair; the new
+  regression addresses its warning about chance-based scheduling. The separate
+  legacy approval-reuse RED and its verification investigation remain unstaged
+  and unresolved. This repair does not reclassify earlier failed CI as passing.
diff --git a/.project/tickets/D1BKYA-let-approved-planning-reviews-advance-honestly/verify.md b/.project/tickets/D1BKYA-let-approved-planning-reviews-advance-honestly/verify.md
new file mode 100644
index 000000000..61acc9cb6
--- /dev/null
+++ b/.project/tickets/D1BKYA-let-approved-planning-reviews-advance-honestly/verify.md
@@ -0,0 +1,162 @@
+# D1BKYA verification — in progress
+
+## Implemented behavior
+
+One authenticated current phase receipt admits Implementation Planning approval.
+The redundant artifact self-stamp is removed. A current rejected review reports
+only `REVIEWER_FINDING` messages; approved warnings and coordinator assurance
+sentences are never rejection findings. Existing provenance and exact plan-byte
+checks remain in `phaseReviewAdmission`.
+
+## Evidence collected
+
+- Focused current-source suite: 5 files, 123 tests passed (planning/design approval,
+  planning guidance, degraded explanation, review surface parity, Bun pin contract).
+- Both RED loops earned current independent executable RED approval before GREEN.
+  Scenario 1: `20bf6afd-3cf3-4685-96d2-e5e8c8b05431`; scenario 2:
+  `9048b493-0dd9-4224-82c9-f738419e189f`.
+- Independent final Claude review `8ef57710-b37d-4576-882b-730003b2085f`:
+  approved, cross-agent, no error findings. Source packet remains current.
+- Changed TypeScript ESLint, formatting, Markdown lint, generated four-surface
+  checks, and commit hooks passed. Full verification is still pending.
+- User-requested repository toolchain repair is separate: `scripts/dev` resolves
+  Bun and Node with mise and prepends their executable directories for children.
+  The commit hook uses that same PATH. A smoke run under Homebrew-first PATH
+  proved Bun 1.3.14, Node 24.18.1, preserved arguments/cwd/exit status, and explicit
+  missing-mise recovery. The earlier personal `.zprofile` edit was reverted.
+
+## Final-review warning dispositions
+
+- Concurrent execution-plan scaffolding, receipt ordering after scaffold failures,
+  plan changes during a human prompt, and mid-flight phase returns: existing
+  behavior outside this narrow duplicate-stamp/rendering repair. Retained as
+  limitations; no fix is claimed.
+- Degraded-route authority versus guidance: existing behavior owned by 5F5ZZA PR 4.
+  This PR preserves current authenticated admission and does not add authority.
+- Structural failure accompanied by a current rejection: only authenticated actual
+  rejection findings are rendered. Structural validation still blocks admission;
+  changing precedence between two valid failures is deferred, not silently fixed.
+- Generated guidance copies were outside the reviewer packet: the real guidance
+  contract tests and generated/parity checks verify those copies independently.
+- POSIX PTY and tight existing timing assertions: evidence limitations retained.
+
+## Epic and sibling acceptance remain incomplete
+
+PR #4989's current-source Claude review was refreshed:
+`a0a1fed2-bb5c-4a39-8f60-24b6740e37ce`, approved with no error findings.
+Its existing assertion warnings are retained; the PR remains Draft and Node 24
+acceptance CI remains failed. No merge or promotion occurred.
+
+Full configured sibling acceptance: 2,372 scenarios — 1,778 passed, 3 skipped,
+585 undefined, 6 failed. A pinned-toolchain rerun using six line selectors
+actually selected 2,181 scenarios — 1,593 passed, 3 skipped, 585 undefined,
+zero failed. It is not represented as a complete full-lane rerun. No undefined
+steps, skip tags, or failure assertions were hidden or weakened.
+
+## Outstanding
+
+Pre-launcher full suite collected: 642 files — 640 passed, 2 failed; 10,562 tests
+passed, 10 failed, 13 skipped. Seven failures explicitly report Bun 1.4.0 in
+child generation commands, and three are intentional Cursor tree-byte changes.
+Do not call that run green. Then run final
+verification through the repository launcher, including the new launcher tests,
+and collect the independent launcher review before any completion claim.
+
+The pre-launcher full suite also exposed three Cursor lifecycle tree-fixture
+mismatches. The canonical planning guidance intentionally changed installed
+Cursor bytes; inspect and regenerate only those expected tree hashes with the
+existing local update workflow, then rerun without update mode. No behavioral
+assertion may be weakened.
+
+## Toolchain review follow-up
+
+Initial toolchain review `00cf209f-8887-4554-9f1f-e62c40b35942` approved.
+The repository already has the requested Bun-pin synchronization assertion in
+`dogfood-source-worktree.test.ts`; reuse that evidence instead of adding a duplicate.
+The existing Bun-version contract test also proves the generator invokes the guard
+before `Bun.build`. The hook PATH-output proof and missing-pinned-tool recovery
+are now added and awaiting current-source test/review collection. Stable exact
+Bun pins are intentional; support for prerelease or Corepack hash formats is
+outside this repair. Other pinned languages and duplicate historical boundary
+hooks are not changed.
+
+The fixture update changed only the three Cursor tree hashes and their manifest
+hashes. Lifecycle result hashes, Codex/Claude fixtures, and uninstall fixtures
+were unchanged. The update-mode run passed all 13 checks; its required independent
+verification without update mode is included in the next targeted run.
+
+Current-source targeted verification through `scripts/dev`: 11 files, 229 tests
+passed. This includes the three launcher tests, seven previously failing Bun
+cases, lifecycle checks without update mode, the existing tool-pin sync assertion,
+and the planning approval/admission/guidance/provenance regressions. No filtering
+or update-mode environment was used for this run.
+
+## Isolated delivery checkout
+
+Historical review IDs and original-suite observations above belong to the
+original continuation checkout. They are not authenticated receipts for this
+worktree; none was copied.
+
+**PR Scope:** ✅ The isolated branch above `codex/4200-repo-toolchain` contains
+D1's approval/rendering repair, its real CLI regressions, canonical guidance and
+required generated surfaces, matching lifecycle fingerprints, and only the two
+acceptance counts affected by the added admission tests. The toolchain repair
+is a separate parent PR, and broader 5F5ZZA planning/proof changes are absent.
+
+Fresh targeted verification passed 150 tests in six actual files. The first
+command also named two nonexistent paths, which Vitest did not select; these
+are not counted. The intended degraded-explanation and lifecycle suites were
+then selected by their correct paths and passed all 15 tests. All four generated
+surfaces passed their check.
+
+The first complete CLI run in this fresh worktree failed: 643 files, 622 passed
+and 21 failed; 10,554 tests passed, 21 failed, 13 skipped. Each of those 21
+failures reports the missing `packages/retro-relay/dist/index.js` during
+Cucumber support-code loading. The monorepo build had not been run after the
+fresh dependency install (which builds only the CLI). A complete monorepo build
+now succeeds; a fresh complete CLI rerun is required before calling that check
+green. The original failed result remains retained at
+`/tmp/4200-planning-approval-full-cli.log`.
+
+The parent PR's historical six acceptance failures and 585 undefined scenarios
+remain visible. The continuation's later zero-failure / 586-undefined result is
+not verification of this isolated head. Full acceptance here remains pending.
+
+### Full CLI retry after monorepo build
+
+The retry completed with **10,574 passed, 1 failed, 13 skipped** in 643 files (642 passed, 1 failed). The failure was `hierarchy-navigation.test.ts > allows stop when parent directory is missing`: the fixture fell through to published `bunx safeword`, which failed to load `eslint-visitor-keys` from its temporary cache. The unchanged isolated file subsequently passed all six tests; this does not erase the failed full result or establish a stable full pass. The toolchain branch is binding that fixture to its existing local built-CLI override, followed by fresh targeted verification. Current isolated full acceptance remains pending; the parent’s six acceptance failures and 585 undefined scenarios remain preserved.
+
+### Full CLI with the hierarchy fixture binding
+
+This complete run retained **10,573 passed, 2 failed, 13 skipped** in 643 files. The failures were `stop-hook-transcript-format.test.ts > shows done-phase hard block when active ticket at done phase` and `codex-stop-retro.test.ts > codex-done-gate.SWM1.R1.returns_filing_after_success_without_an_advisory`. Both invoked published `bunx safeword` and reported dependency-link `EEXIST` errors in the shared temporary cache. The hierarchy binding passed its cases. The toolchain branch is centralizing that existing local CLI override for source-hook fixtures, followed by new scoped/full verification. This failed result remains recorded; no full-pass or isolated-acceptance claim is made.
+
+### Full CLI with shared source-hook fixture environment
+
+The complete CLI retry passed: **643/643 files; 10,575 tests passed, 13 existing skips**, 663.63 seconds. The run used the repository launcher and the rebuilt checkout CLI, with no test-name filtering or snapshot update mode. The source-hook fixtures share their existing explicit local CLI override; consumer hook behavior remains unchanged. The previous 21-, 1-, and 2-failure runs above remain historical evidence. This passing CLI run does not establish a full acceptance pass: the separate complete acceptance lane is running, with its full result still pending. Log: `/tmp/4200-D1-full-cli-shared-source-fixtures.log`.
+
+### Complete isolated acceptance and lint
+
+The unfiltered configured acceptance lane completed with **2,372 scenarios: 1,784 passed, 3 existing skips, 585 undefined, zero failed**; **110,463 steps: 108,700 passed, 4 skipped, 1,759 undefined**. It exited 1 because undefined scenarios remain. This is not a passing acceptance lane. The parent's historical six failures remain recorded above; they did not recur in this complete isolated stacked-checkout run. No undefined steps were supplied, skipped, filtered, or weakened by this patch. Log: `/tmp/4200-D1-full-acceptance.log`.
+
+Root lint passed ESLint, Gherkin validation and CLI TypeScript. Log: `/tmp/4200-D1-final-lint.log`. Current native final review `89c8e5dd-a98e-4102-85e6-7a2ba6d81a99` remains approved after the final supporting-evidence commit.
+
+## Verify Checklist
+
+**Test Suite:** ✓ 10575/10575 executed tests pass; 13 existing skips
+**Gherkin:** ❌ Failed — 585 undefined scenarios; zero failed scenarios in the current complete lane
+**Build:** ✅ Success — complete monorepo build
+**Lint:** ✅ Clean
+**Typecheck:** ✅ Clean
+**Scenarios:** All 2 D1 scenarios marked complete in their TDD ledger; epic scenarios remain unfinished
+**Refactor:** ✅ No change warranted — duplicate authority and unused imports removed; existing phase-admission owner reused
+**PR Scope:** ✅ Diff matches D1 scope above its separate repository-toolchain parent
+**Dep Drift:** ✅ Clean — no runtime dependency changes
+**Parent Epic:** #4200 — incomplete; no sibling-completion claim
+**Reconcile:** ✅ No pattern deviation
+**Experience:** ✅ No new friction — walked Tool Builder through native review and CLI rejection; worst step = waiting for the independent reviewer; new steps versus before = 0. This walk covers rejection, not native approving warnings.
+**Surface Evidence:** ✅ Real CLI regressions and generated guidance checks pass; no live-host UI claim
+**Evidence limits:** ⚠️ Acceptance retains 585 undefined scenarios and 3 existing skips; native manual walkthrough covers rejection; approval-with-warning proof mocks only the external reviewer process
+
+### Native manual rejection walkthrough
+
+At unchanged production head `e2c661f38`, a first attempted installation under `/tmp/4200-D1-manual-walk` was correctly refused as a nested project because `/tmp` was already configured. This is a setup failure, not a successful walk. A fresh system-temporary project then installed the real built CLI with Cursor, offline and without application-tool modifications. A native Claude Implementation review (`1bc97291-4d2f-4151-9d07-c7b9e446344d`) actually requested changes to the example plan. Ordinary `ticket approve-plan WALK01 --no-input --json` returned action-required, left `phase: plan-implementation`, and emitted exactly the current review's `REVIEWER_FINDING` messages. The independent-assurance sentence was absent. No fake reviewer, copied authenticated receipt, or hand-written review stamp was used. Approval without the extra stamp remains separately proven by the automated real-coordinator regression; no native approval claim is made here. Logs: `/tmp/4200-D1-native-walk-install.json`, `/tmp/4200-D1-native-walk-review-status.json`, `/tmp/4200-D1-native-walk-approval.json`.
diff --git a/.safeword/skills/bdd/PLAN_IMPLEMENTATION.md b/.safeword/skills/bdd/PLAN_IMPLEMENTATION.md
index a9a785214..6619f60ce 100644
--- a/.safeword/skills/bdd/PLAN_IMPLEMENTATION.md
+++ b/.safeword/skills/bdd/PLAN_IMPLEMENTATION.md
@@ -330,6 +330,10 @@ receipt controls eligibility for approval and phase advancement.
    safeword ticket approve-plan <ticket-id>
    ```
 
+   Use the authenticated phase stamp from step 1; no additional artifact self-stamp
+   is required. Admission still authenticates reviewer provenance and rechecks
+   the exact reviewed plan bytes. Approved warnings are not rejection findings.
+
    Never replace this command with conversational approval or a manual phase
    edit. It rechecks the exact reviewed plan bytes and the current project
    configuration. When `designApprovalGate` is absent or off, it records `not
diff --git a/packages/cli/codex-plugin/runtime/cli.js b/packages/cli/codex-plugin/runtime/cli.js
index ff749de4c..3751d92e2 100755
--- a/packages/cli/codex-plugin/runtime/cli.js
+++ b/packages/cli/codex-plugin/runtime/cli.js
@@ -3605,7 +3605,7 @@ var init_historical_catalogue_generated = __esm(() => {
         ".claude/skills/bdd/DISCOVERY.md": "1dd29f815c358ab6e215fa5d0e2db1fe6ab26d93df0b151a53908370331b09ed",
         ".claude/skills/bdd/DONE.md": "e9f22430341cf225eaf58ef6335720c5033cb8f6779425d5740adc0ff80a5f60",
         ".claude/skills/bdd/PLAN_EXECUTION.md": "4cf9fd3c73c7f0489d49c4f56af0251ea7ed8effa1415182e970f16fe764f47c",
-        ".claude/skills/bdd/PLAN_IMPLEMENTATION.md": "e24265aef799112db05a778ae42e182bd2886f883ceea4b2382949c8ccc7392c",
+        ".claude/skills/bdd/PLAN_IMPLEMENTATION.md": "248b11fd40cd23d7a6ac6f9bb8a6be7cc5d762f882ac3006b3f30ed0603858b8",
         ".claude/skills/bdd/SCENARIOS.md": "1e89aa6a46895858cff252d642dd9f7b5853d0fd7dd314aaa75e2ee6046bcddb",
         ".claude/skills/bdd/SKILL.md": "3770f019f5a83fd4ad6dcb2322528595a39545f61cf1106a2f606a8137036d9d",
         ".claude/skills/bdd/SPLITTING.md": "e232a37a4d76f0dfc51e65965c1e1b7f1572e0dedce0fb8c031e75bd6544a708",
@@ -38762,40 +38762,6 @@ var init_retrospective_close = __esm(() => {
 });
 
 // templates/hooks/lib/review-ledger.ts
-import { createHash as createHash25 } from "crypto";
-function hashArtifact(content) {
-  return createHash25("sha1").update(content).digest("hex").slice(0, 12);
-}
-function reviewScope2(ticketId, artifact, contentHash) {
-  return `${ticketId}:${artifact}@${contentHash}`;
-}
-function isSatisfyingStamp(stamp, policy = "prefer") {
-  const ordinarilySatisfying = stamp.skipReason === undefined || isValidSkipReason(stamp.skipReason);
-  if (!ordinarilySatisfying)
-    return false;
-  if (stamp.skipReason === undefined && stamp.independence !== undefined && COORDINATOR_CLAIMS.has(stamp.independence) && stamp.reviewId === undefined)
-    return false;
-  if (policy !== "require")
-    return true;
-  return stamp.skipReason === undefined && stamp.independence === "cross-agent" && stamp.author !== undefined && stamp.reviewer !== undefined && stamp.author !== stamp.reviewer;
-}
-function isSatisfyingCoordinatorReviewStamp(id, stamp, policy) {
-  return stamp.scope === id && stamp.skipReason === undefined && stamp.reviewId !== undefined && stamp.independence !== undefined && COORDINATOR_CLAIMS.has(stamp.independence) && isSatisfyingStamp(stamp, policy);
-}
-function isSatisfyingSkipStamp(id, stamp) {
-  return stamp.scope === id && stamp.skipReason !== undefined && isValidSkipReason(stamp.skipReason);
-}
-function hasSatisfyingPhaseStamp(id, stamps, policy) {
-  return stamps.some((stamp) => isSatisfyingSkipStamp(id, stamp) || isSatisfyingCoordinatorReviewStamp(id, stamp, policy));
-}
-function gatePhaseAdvance(phase, stamps, policy = "prefer") {
-  if (hasSatisfyingPhaseStamp(phase, stamps, policy))
-    return { ok: true };
-  return {
-    ok: false,
-    reason: `phase "${phase}" has no independent review stamp \u2014 run the phase-exit review (or log a skip with a reason) before advancing`
-  };
-}
 function readCrossAgentReviewPolicy(rawConfig) {
   if (rawConfig === undefined)
     return "prefer";
@@ -38962,7 +38928,7 @@ __export(exports_red_execution, {
   executeNoShellCommand: () => executeNoShellCommand
 });
 import { spawn as spawn3, spawnSync as spawnSync11 } from "child_process";
-import { createHash as createHash26 } from "crypto";
+import { createHash as createHash25 } from "crypto";
 import { realpathSync as realpathSync13 } from "fs";
 import nodePath53 from "path";
 function terminateProofTree(child) {
@@ -38996,7 +38962,7 @@ function proofEnvironment2() {
 }
 function environmentIdentity(environment) {
   const entries = Object.entries(environment).toSorted(([left], [right]) => left.localeCompare(right));
-  const sha2566 = createHash26("sha256").update(JSON.stringify(entries)).digest("hex");
+  const sha2566 = createHash25("sha256").update(JSON.stringify(entries)).digest("hex");
   return {
     sha256: sha2566,
     variable_count: entries.length,
@@ -39009,7 +38975,7 @@ function environmentIdentity(environment) {
 
 class StreamEvidence {
   expected;
-  #hash = createHash26("sha256");
+  #hash = createHash25("sha256");
   #chunks = [];
   #retained = 0;
   #bytes = 0;
@@ -39239,7 +39205,7 @@ var init_execution_plan_admission_generated = __esm(() => {
 });
 
 // src/review/execution-plan-conformance.ts
-import { createHash as createHash27 } from "crypto";
+import { createHash as createHash26 } from "crypto";
 function stagedOwners(prerequisite, activation) {
   return { "Accepted behavior": activation, "Migration work": prerequisite };
 }
@@ -39415,7 +39381,7 @@ function missingObligationCase(id, obligation) {
   }), [obligation]);
 }
 function sha2566(value) {
-  return createHash27("sha256").update(value).digest("hex");
+  return createHash26("sha256").update(value).digest("hex");
 }
 function executionPlanConformanceDigests() {
   return {
@@ -44779,7 +44745,7 @@ var CROCKFORD_ALPHABET = "0123456789ABCDEFGHJKMNPQRSTVWXYZ", ID_LENGTH = 6;
 var init_id_minter = () => {};
 
 // src/utils/product-plan-contract.ts
-import { createHash as createHash28 } from "crypto";
+import { createHash as createHash27 } from "crypto";
 import { existsSync as existsSync30, readdirSync as readdirSync14, readFileSync as readFileSync50 } from "fs";
 import nodePath65 from "path";
 function sectionAfterHeading(content, level, id) {
@@ -44845,7 +44811,7 @@ function canonicalizeContractValue(value) {
 }
 function digestParentContract(values) {
   const canonical = CONTRACT_KEYS.map((key) => [key, canonicalizeContractValue(values[key])]);
-  return createHash28("sha256").update(JSON.stringify(canonical)).digest("hex");
+  return createHash27("sha256").update(JSON.stringify(canonical)).digest("hex");
 }
 function resolveTicketDirectory(cwd, ticketId) {
   const root = resolveTicketsDirectory(cwd);
@@ -46867,7 +46833,7 @@ var init_project_root = __esm(() => {
 });
 
 // src/claude-plugin/plugin-data.ts
-import { createHash as createHash29 } from "crypto";
+import { createHash as createHash28 } from "crypto";
 import { homedir as homedir7 } from "os";
 import nodePath71 from "path";
 function claudeConfigDirectory(environment = process.env) {
@@ -46884,7 +46850,7 @@ function claudePluginDataDirectory(environment = process.env) {
   return nodePath71.join(claudeConfigDirectory(environment), CLAUDE_MIGRATION_SCHEMA.data.pluginsRoot, claudePluginDataId());
 }
 function claudeProjectDigest(canonicalProjectRoot) {
-  return createHash29("sha256").update(canonicalProjectRoot).digest("hex");
+  return createHash28("sha256").update(canonicalProjectRoot).digest("hex");
 }
 function claudeProofDirectory(environment = process.env) {
   return nodePath71.join(claudePluginDataDirectory(environment), CLAUDE_MIGRATION_SCHEMA.data.proofs);
@@ -46899,7 +46865,7 @@ var init_plugin_data = __esm(() => {
 });
 
 // src/claude-plugin/migration-state.ts
-import { createHash as createHash30, randomUUID as randomUUID12 } from "crypto";
+import { createHash as createHash29, randomUUID as randomUUID12 } from "crypto";
 import { cpSync, existsSync as existsSync34, mkdirSync as mkdirSync18, readFileSync as readFileSync54, renameSync as renameSync12, rmSync as rmSync11 } from "fs";
 import nodePath72 from "path";
 function createClaudePluginMode(marker) {
@@ -46910,7 +46876,7 @@ function createClaudePluginMode(marker) {
   };
 }
 function digest3(value) {
-  return createHash30("sha256").update(value).digest("hex");
+  return createHash29("sha256").update(value).digest("hex");
 }
 function relocateLegacyState(from, to, rename2 = renameSync12, copy = (source, destination) => {
   cpSync(source, destination, { recursive: true, errorOnExist: true, force: false });
@@ -46997,7 +46963,7 @@ function claudeWatchedSettingsDigest(cwd) {
     nodePath72.join(cwd, ".claude/settings.json"),
     nodePath72.join(configDirectory, "settings.json")
   ];
-  const hash = createHash30("sha256");
+  const hash = createHash29("sha256");
   for (const path7 of paths) {
     hash.update(path7);
     hash.update("\x00");
@@ -48878,9 +48844,9 @@ var init_detect = __esm(() => {
 });
 
 // src/utils/cucumber-template-revisions.ts
-import { createHash as createHash31 } from "crypto";
+import { createHash as createHash30 } from "crypto";
 function isShippedCucumberTemplateRevision(content) {
-  const hash = createHash31("sha256").update(content).digest("hex");
+  const hash = createHash30("sha256").update(content).digest("hex");
   return CUCUMBER_TEMPLATE_REVISION_HASHES.has(hash);
 }
 var CUCUMBER_TEMPLATE_REVISION_HASHES;
@@ -59836,7 +59802,7 @@ __export(exports_profile, {
   claudeInstallRequiresMutation: () => claudeInstallRequiresMutation
 });
 import { spawnSync as spawnSync13 } from "child_process";
-import { createHash as createHash32 } from "crypto";
+import { createHash as createHash31 } from "crypto";
 import {
   closeSync as closeSync9,
   cpSync as cpSync2,
@@ -60379,7 +60345,7 @@ function convergePlugin(cwd, scope, effects) {
   }
 }
 function fileSha256(path8) {
-  return createHash32("sha256").update(readFileSync58(path8)).digest("hex");
+  return createHash31("sha256").update(readFileSync58(path8)).digest("hex");
 }
 function assertInstalledAsset(installPath, asset) {
   if (typeof asset.path !== "string" || nodePath88.isAbsolute(asset.path) || asset.path.split(/[\\/]/u).includes("..") || typeof asset.sha256 !== "string") {
@@ -60391,7 +60357,7 @@ function assertInstalledAsset(installPath, asset) {
   }
 }
 function assertInstalledIdentity(identity, inventory, inventoryContent) {
-  if (identity.schema_version !== 1 || identity.plugin_version !== VERSION || identity.inventory_sha256 !== createHash32("sha256").update(inventoryContent).digest("hex") || inventory.schema_version !== 1 || !Array.isArray(inventory.assets)) {
+  if (identity.schema_version !== 1 || identity.plugin_version !== VERSION || identity.inventory_sha256 !== createHash31("sha256").update(inventoryContent).digest("hex") || inventory.schema_version !== 1 || !Array.isArray(inventory.assets)) {
     throw new TypeError("installed identity or inventory is inconsistent");
   }
 }
@@ -60690,7 +60656,7 @@ var init_profile = __esm(() => {
 });
 
 // src/claude-plugin/hook-manifest.ts
-import { createHash as createHash33 } from "crypto";
+import { createHash as createHash32 } from "crypto";
 function adaptHookValue(value) {
   if (typeof value === "string") {
     return value.replaceAll(PROJECT_HOOK_ROOT, () => PLUGIN_HOOK_ROOT);
@@ -60740,7 +60706,7 @@ function pluginHookManifest() {
 `;
 }
 function currentClaudePluginHookManifestSha256() {
-  return createHash33("sha256").update(pluginHookManifest()).digest("hex");
+  return createHash32("sha256").update(pluginHookManifest()).digest("hex");
 }
 var PROJECT_HOOK_ROOT = '"$CLAUDE_PROJECT_DIR"/.safeword/hooks', PLUGIN_HOOK_ROOT = '"${CLAUDE_PLUGIN_ROOT}"/runtime/hooks', PLUGIN_DISPATCH = 'bun --no-env-file --cwd "${CLAUDE_PLUGIN_ROOT}" "${CLAUDE_PLUGIN_ROOT}"/runtime/dispatch.js', EVENT_GROUP_EVENTS;
 var init_hook_manifest = __esm(() => {
@@ -61940,7 +61906,7 @@ __export(exports_profile2, {
   installOpenCodeProfile: () => installOpenCodeProfile,
   generateOpenCodeProfilePlugin: () => generateOpenCodeProfilePlugin
 });
-import { createHash as createHash34 } from "crypto";
+import { createHash as createHash33 } from "crypto";
 import {
   existsSync as existsSync45,
   lstatSync as lstatSync19,
@@ -61998,7 +61964,7 @@ function observeFile2(path8) {
   }
 }
 function sha2567(value) {
-  return createHash34("sha256").update(value).digest("hex");
+  return createHash33("sha256").update(value).digest("hex");
 }
 function packagedDispatcherPath() {
   const moduleDirectory = import.meta.dirname;
@@ -62922,7 +62888,7 @@ __export(exports_conformance, {
   observeOpenCodeVersion: () => observeOpenCodeVersion
 });
 import { spawnSync as spawnSync15 } from "child_process";
-import { createHash as createHash35 } from "crypto";
+import { createHash as createHash34 } from "crypto";
 import { accessSync as accessSync4, constants as constants6, lstatSync as lstatSync20, readFileSync as readFileSync63, realpathSync as realpathSync18, statSync as statSync7 } from "fs";
 import nodePath96 from "path";
 function resolveExecutable(environment) {
@@ -62977,7 +62943,7 @@ function profileRemediation() {
   });
 }
 function sha2568(value) {
-  return createHash35("sha256").update(value).digest("hex");
+  return createHash34("sha256").update(value).digest("hex");
 }
 function installedProfile(environment) {
   const root = resolveOpenCodeConfigRoot({
@@ -63911,7 +63877,7 @@ var init_doctor = __esm(() => {
 });
 
 // src/cli-protocol/reconciliation.ts
-import { createHash as createHash36 } from "crypto";
+import { createHash as createHash35 } from "crypto";
 import { lstatSync as lstatSync21, readdirSync as readdirSync29, readFileSync as readFileSync64, readlinkSync as readlinkSync3 } from "fs";
 import nodePath97 from "path";
 function actionTargets(action) {
@@ -63962,7 +63928,7 @@ function hashPath(hash, absolutePath, relativePath, readFile3) {
   }
 }
 function preconditionDigestForPaths(cwd, paths, readFile3 = readFileForDigest) {
-  const hash = createHash36("sha256");
+  const hash = createHash35("sha256");
   const targets = [...new Set(paths)].toSorted((left, right) => left.localeCompare(right));
   for (const target of targets) {
     hashField(hash, "target", target);
@@ -64692,7 +64658,7 @@ To wire the warn-only boundary gate, add under repos:
 
 // src/utils/namespace-migration.ts
 import { execSync } from "child_process";
-import { createHash as createHash37 } from "crypto";
+import { createHash as createHash36 } from "crypto";
 import {
   closeSync as closeSync10,
   constants as fsConstants3,
@@ -64741,7 +64707,7 @@ function validateDirectoryRoot(path8, label) {
 }
 function conflictArchivePath(source, relative) {
   const metadata = lstatSync22(source);
-  const digest4 = createHash37("sha256").update(`${metadata.mode.toString(8)}\x00`).update(readFileSync67(source)).digest("hex");
+  const digest4 = createHash36("sha256").update(`${metadata.mode.toString(8)}\x00`).update(readFileSync67(source)).digest("hex");
   return nodePath104.join(".safeword", "namespace-migration-conflicts-v1", digest4, relative);
 }
 function plannedNamespaceMigrationFiles(cwd) {
@@ -65453,7 +65419,7 @@ var init_vendored_ignores_nudge = __esm(() => {
 });
 
 // src/lifecycle/project-install.ts
-import { createHash as createHash38 } from "crypto";
+import { createHash as createHash37 } from "crypto";
 import {
   closeSync as closeSync11,
   constants as fsConstants4,
@@ -65754,7 +65720,7 @@ function setupPreconditionDigest(cwd, reconciliationDigest, effects, context, op
     ...effects.files.map((effect) => effect.target),
     ...effects.destructive.map((effect) => effect.target)
   ].filter((target) => !target.includes(" \u2192 "));
-  return createHash38("sha256").update(JSON.stringify([
+  return createHash37("sha256").update(JSON.stringify([
     reconciliationDigest,
     effects,
     JSON.stringify(context, (_key, value) => typeof value === "string" ? value.replaceAll(cwd, "<project>") : value),
@@ -66758,7 +66724,7 @@ __export(exports_commands, {
   planLifecycle: () => planLifecycle,
   installLifecycle: () => installLifecycle
 });
-import { createHash as createHash39 } from "crypto";
+import { createHash as createHash38 } from "crypto";
 function activationActionsFor(surface) {
   if (surface.name === "claude" && surface.result.changed)
     return ["run /reload-plugins"];
@@ -66954,7 +66920,7 @@ async function prepareLifecycle(cwd, operation, agents, options = {}) {
   };
   const integrationSurfaces = observedSurfaces.filter((surface) => selected.has(surface.name));
   const surfaces = [{ name: "project", effects: project.plan.effects }, ...integrationSurfaces];
-  const preconditionDigest2 = createHash39("sha256").update(JSON.stringify([
+  const preconditionDigest2 = createHash38("sha256").update(JSON.stringify([
     project.plan.preconditionDigest,
     agents,
     scope,
@@ -67254,7 +67220,7 @@ __export(exports_cleanup, {
   claudeLegacyMutations: () => claudeLegacyMutations,
   claudeCleanupPreconditionDigest: () => claudeCleanupPreconditionDigest
 });
-import { createHash as createHash40, randomUUID as randomUUID14 } from "crypto";
+import { createHash as createHash39, randomUUID as randomUUID14 } from "crypto";
 import {
   closeSync as closeSync12,
   constants as fsConstants5,
@@ -67274,7 +67240,7 @@ import {
 } from "fs";
 import nodePath111 from "path";
 function sha2569(content) {
-  return createHash40("sha256").update(content).digest("hex");
+  return createHash39("sha256").update(content).digest("hex");
 }
 function containsJsonComments(content) {
   let found = false;
@@ -68311,7 +68277,7 @@ function resolveExecutionMode(input) {
 }
 
 // src/test-execution/remote-workflow-contract.ts
-import { createHash as createHash41 } from "crypto";
+import { createHash as createHash40 } from "crypto";
 function mapping(value) {
   return typeof value === "object" && value !== null && !Array.isArray(value) ? value : undefined;
 }
@@ -68455,7 +68421,7 @@ function hasFixedUpload(steps) {
 }
 function resultViolations(steps) {
   const reportRun = stepById(steps, "report")?.run;
-  const reportValid = typeof reportRun === "string" && createHash41("sha256").update(reportRun).digest("hex") === REPORT_COMMAND_SHA256;
+  const reportValid = typeof reportRun === "string" && createHash40("sha256").update(reportRun).digest("hex") === REPORT_COMMAND_SHA256;
   return reportValid && hasFixedUpload(steps) ? [] : ["fixed_result_protocol"];
 }
 function hasSecretsKey(value) {
@@ -68713,7 +68679,7 @@ var init_remote_workflow_fs = __esm(() => {
 });
 
 // src/test-execution/remote-workflow-state.ts
-import { createHash as createHash42 } from "crypto";
+import { createHash as createHash41 } from "crypto";
 import nodePath114 from "path";
 function observationError(error2, path8) {
   const code = filesystemErrorCode(error2);
@@ -68728,7 +68694,7 @@ function normalizeLineEndings2(content) {
 `);
 }
 function workflowDigest(content) {
-  return createHash42("sha256").update(normalizeLineEndings2(content)).digest("hex");
+  return createHash41("sha256").update(normalizeLineEndings2(content)).digest("hex");
 }
 function readOpenedWorkflow(descriptor, filesystem) {
   const metadata = filesystem.fstat(descriptor);
@@ -71332,7 +71298,7 @@ var init_plan_gate = __esm(() => {
 });
 
 // src/review/approval-ledger.ts
-import { createHash as createHash43, randomUUID as randomUUID16 } from "crypto";
+import { createHash as createHash42, randomUUID as randomUUID16 } from "crypto";
 import {
   closeSync as closeSync15,
   constants as constants9,
@@ -71451,7 +71417,7 @@ function positionedEvents(ledger) {
   ];
 }
 function decisionIdempotencyKey(identity, supersedesPosition) {
-  return createHash43("sha256").update(JSON.stringify([
+  return createHash42("sha256").update(JSON.stringify([
     identity.ticket,
     identity.planDigest,
     identity.decision,
@@ -71460,7 +71426,7 @@ function decisionIdempotencyKey(identity, supersedesPosition) {
   ])).digest("hex");
 }
 function deliveryIdempotencyKey(identity) {
-  return createHash43("sha256").update(JSON.stringify([
+  return createHash42("sha256").update(JSON.stringify([
     identity.ticket,
     identity.itemId,
     identity.proofId,
@@ -71469,7 +71435,7 @@ function deliveryIdempotencyKey(identity) {
   ])).digest("hex");
 }
 function deliveryCompatibilityIdempotencyKey(identity) {
-  return createHash43("sha256").update(JSON.stringify([
+  return createHash42("sha256").update(JSON.stringify([
     identity.ticket,
     identity.itemId,
     identity.proofId,
@@ -71905,7 +71871,7 @@ var exports_plan_approval = {};
 __export(exports_plan_approval, {
   approvePlanResult: () => approvePlanResult
 });
-import { createHash as createHash44, randomUUID as randomUUID17 } from "crypto";
+import { createHash as createHash43, randomUUID as randomUUID17 } from "crypto";
 import {
   appendFileSync as appendFileSync3,
   existsSync as existsSync60,
@@ -71923,7 +71889,7 @@ function interruptApprovalForTest(boundary) {
   }
 }
 function planDigest(content) {
-  return createHash44("sha256").update(content).digest("hex");
+  return createHash43("sha256").update(content).digest("hex");
 }
 function readContext2(cwd, ticketId) {
   const ticketDirectory = resolveTicketDirectory(cwd, ticketId);
@@ -71968,11 +71934,6 @@ function currentReview(context) {
   if (!gate.ok)
     return { ok: false, reason: latestReviewRejection(context) ?? gate.reason };
   const ledger = existsSync60(context.ledgerPath) ? readFileSync84(context.ledgerPath, "utf8") : "";
-  const scope = reviewScope2(nodePath129.basename(context.ticketDirectory), "impl-plan", hashArtifact(context.plan));
-  const artifactReview = gatePhaseAdvance(scope, parseReviewStamps(ledger));
-  if (!artifactReview.ok) {
-    return { ok: false, reason: latestReviewRejection(context) ?? artifactReview.reason };
-  }
   const admission = phaseReviewAdmission({
     cwd: context.cwd,
     ticketDirectory: context.ticketDirectory,
@@ -71989,7 +71950,7 @@ function currentReview(context) {
   }
   return {
     ok: false,
-    reason: "The current Implementation Plan has no current authenticated Implementation Plan review receipt."
+    reason: latestReviewRejection(context) ?? "The current Implementation Plan has no current authenticated Implementation Plan review receipt."
   };
 }
 function reviewsPlan(data, context) {
@@ -72078,10 +72039,10 @@ function latestReviewRejection(context) {
     return;
   }
   const data = review.data;
-  if (data.review_kind !== "plan-implementation" || !reviewsPlan(data, context)) {
+  if (data.status !== "changes_requested" || data.review_kind !== "plan-implementation" || !reviewsPlan(data, context)) {
     return;
   }
-  const messages3 = review.findings.map((finding2) => finding2.message).filter(Boolean);
+  const messages3 = review.findings.filter((finding2) => finding2.code === "REVIEWER_FINDING").map((finding2) => finding2.message).filter(Boolean);
   return messages3.length > 0 ? `Implementation Plan review is blocked: ${messages3.join(" ")}` : "The Implementation Plan review requested changes.";
 }
 function appendReceipt(context, status) {
@@ -72123,7 +72084,13 @@ function scaffoldExecutionPlan(context) {
   if (!existsSync60(templatePath)) {
     throw new Error("The installed Execution Plan template is missing. Repair the Safeword installation before approving the plan.");
   }
-  writeFileSync32(planPath, readFileSync84(templatePath, "utf8"), { flag: "wx" });
+  try {
+    writeFileSync32(planPath, readFileSync84(templatePath, "utf8"), { flag: "wx" });
+  } catch (error2) {
+    if (error2.code === "EEXIST")
+      return;
+    throw error2;
+  }
   return nodePath129.relative(context.cwd, planPath);
 }
 function advanceToExecutionPlanning(context) {
@@ -72285,7 +72252,6 @@ async function approvePlanResult(cwd, ticketId, options) {
 }
 var init_plan_approval = __esm(() => {
   init_plan_gate();
-  init_review_ledger();
   init_result();
   init_approval_ledger();
   init_job();
@@ -72411,11 +72377,11 @@ var init_delivery_admission = __esm(() => {
 
 // src/execution-plan/delivery-compatibility.ts
 import { spawnSync as spawnSync20 } from "child_process";
-import { createHash as createHash45 } from "crypto";
+import { createHash as createHash44 } from "crypto";
 import { mkdirSync as mkdirSync26, writeFileSync as writeFileSync33 } from "fs";
 import nodePath131 from "path";
 function sha25610(value) {
-  return createHash45("sha256").update(value).digest("hex");
+  return createHash44("sha256").update(value).digest("hex");
 }
 function relativePathspec(projectRoot, path8) {
   const relative = nodePath131.relative(projectRoot, nodePath131.resolve(path8));
@@ -72666,7 +72632,7 @@ __export(exports_delivery_checklist, {
   observeDeliveryChecklist: () => observeDeliveryChecklist,
   hasAdmittedDeliveryChecklist: () => hasAdmittedDeliveryChecklist
 });
-import { createHash as createHash46 } from "crypto";
+import { createHash as createHash45 } from "crypto";
 import { existsSync as existsSync61, readFileSync as readFileSync85 } from "fs";
 import nodePath133 from "path";
 function findingResult(command, code, message, recovery) {
@@ -72678,7 +72644,7 @@ function findingResult(command, code, message, recovery) {
   });
 }
 function sha25611(value) {
-  return createHash46("sha256").update(value).digest("hex");
+  return createHash45("sha256").update(value).digest("hex");
 }
 function designApprovalEnabled2(cwd) {
   const path8 = nodePath133.join(cwd, ".safeword", "config.json");
@@ -73427,7 +73393,7 @@ var init_delivery_checklist2 = __esm(() => {
 });
 
 // src/execution-plan/execution-prerequisite.ts
-import { createHash as createHash47 } from "crypto";
+import { createHash as createHash46 } from "crypto";
 import { existsSync as existsSync62, readFileSync as readFileSync86 } from "fs";
 import nodePath134 from "path";
 function successful(status, achievedIndependence2, inputIdentity, executionPlanArtifact) {
@@ -73490,7 +73456,7 @@ function designDecisionAccepted(input) {
     return true;
   if (!existsSync62(input.implementationPath))
     return false;
-  const planDigest2 = createHash47("sha256").update(readFileSync86(input.implementationPath, "utf8")).digest("hex");
+  const planDigest2 = createHash46("sha256").update(readFileSync86(input.implementationPath, "utf8")).digest("hex");
   return currentDesignDecision(input.ledgerPath, input.ticketId, planDigest2) === "approved";
 }
 function contractedFeature(ticketDirectory, phase) {
@@ -73678,7 +73644,7 @@ function checklistPrerequisite(context, inspection) {
   };
 }
 function digest4(content) {
-  return createHash47("sha256").update(content).digest("hex");
+  return createHash46("sha256").update(content).digest("hex");
 }
 function fileDigest2(path8) {
   return path8 !== undefined && existsSync62(path8) ? digest4(readFileSync86(path8, "utf8")) : "missing";
diff --git a/packages/cli/codex-plugin/skills/bdd/references/PLAN_IMPLEMENTATION.md b/packages/cli/codex-plugin/skills/bdd/references/PLAN_IMPLEMENTATION.md
index d74d5dd75..49274a408 100644
--- a/packages/cli/codex-plugin/skills/bdd/references/PLAN_IMPLEMENTATION.md
+++ b/packages/cli/codex-plugin/skills/bdd/references/PLAN_IMPLEMENTATION.md
@@ -330,6 +330,10 @@ receipt controls eligibility for approval and phase advancement.
    safeword ticket approve-plan <ticket-id>
    ```
 
+   Use the authenticated phase stamp from step 1; no additional artifact self-stamp
+   is required. Admission still authenticates reviewer provenance and rechecks
+   the exact reviewed plan bytes. Approved warnings are not rejection findings.
+
    Never replace this command with conversational approval or a manual phase
    edit. It rechecks the exact reviewed plan bytes and the current project
    configuration. When `designApprovalGate` is absent or off, it records `not
diff --git a/packages/cli/codex-plugin/templates/skills/bdd/PLAN_IMPLEMENTATION.md b/packages/cli/codex-plugin/templates/skills/bdd/PLAN_IMPLEMENTATION.md
index a9a785214..6619f60ce 100644
--- a/packages/cli/codex-plugin/templates/skills/bdd/PLAN_IMPLEMENTATION.md
+++ b/packages/cli/codex-plugin/templates/skills/bdd/PLAN_IMPLEMENTATION.md
@@ -330,6 +330,10 @@ receipt controls eligibility for approval and phase advancement.
    safeword ticket approve-plan <ticket-id>
    ```
 
+   Use the authenticated phase stamp from step 1; no additional artifact self-stamp
+   is required. Admission still authenticates reviewer provenance and rechecks
+   the exact reviewed plan bytes. Approved warnings are not rejection findings.
+
    Never replace this command with conversational approval or a manual phase
    edit. It rechecks the exact reviewed plan bytes and the current project
    configuration. When `designApprovalGate` is absent or off, it records `not
diff --git a/packages/cli/src/claude-plugin/historical-catalogue.generated.ts b/packages/cli/src/claude-plugin/historical-catalogue.generated.ts
index 6ad3f3e33..663342d83 100644
--- a/packages/cli/src/claude-plugin/historical-catalogue.generated.ts
+++ b/packages/cli/src/claude-plugin/historical-catalogue.generated.ts
@@ -16,7 +16,7 @@ export const CLAUDE_HISTORICAL_CATALOGUE = {
       '.claude/skills/bdd/PLAN_EXECUTION.md':
         '4cf9fd3c73c7f0489d49c4f56af0251ea7ed8effa1415182e970f16fe764f47c',
       '.claude/skills/bdd/PLAN_IMPLEMENTATION.md':
-        'e24265aef799112db05a778ae42e182bd2886f883ceea4b2382949c8ccc7392c',
+        '248b11fd40cd23d7a6ac6f9bb8a6be7cc5d762f882ac3006b3f30ed0603858b8',
       '.claude/skills/bdd/SCENARIOS.md':
         '1e89aa6a46895858cff252d642dd9f7b5853d0fd7dd314aaa75e2ee6046bcddb',
       '.claude/skills/bdd/SKILL.md':
diff --git a/packages/cli/src/commands/plan-approval.ts b/packages/cli/src/commands/plan-approval.ts
index 0e917fca0..41fa0f00f 100644
--- a/packages/cli/src/commands/plan-approval.ts
+++ b/packages/cli/src/commands/plan-approval.ts
@@ -12,12 +12,6 @@ import process from 'node:process';
 import { createInterface } from 'node:readline/promises';
 
 import { evaluateExecutionPlanningEntry } from '../../templates/hooks/lib/plan-gate.js';
-import {
-  gatePhaseAdvance,
-  hashArtifact,
-  parseReviewStamps,
-  reviewScope,
-} from '../../templates/hooks/lib/review-ledger.js';
 import { type CliResult, createResult } from '../cli-protocol/result.js';
 import { appendDesignDecision, currentDesignDecision } from '../review/approval-ledger.js';
 import { reviewJobStatus } from '../review/job.js';
@@ -100,15 +94,6 @@ function currentReview(
   });
   if (!gate.ok) return { ok: false, reason: latestReviewRejection(context) ?? gate.reason };
   const ledger = existsSync(context.ledgerPath) ? readFileSync(context.ledgerPath, 'utf8') : '';
-  const scope = reviewScope(
-    nodePath.basename(context.ticketDirectory),
-    'impl-plan',
-    hashArtifact(context.plan),
-  );
-  const artifactReview = gatePhaseAdvance(scope, parseReviewStamps(ledger));
-  if (!artifactReview.ok) {
-    return { ok: false, reason: latestReviewRejection(context) ?? artifactReview.reason };
-  }
   const admission = phaseReviewAdmission({
     cwd: context.cwd,
     ticketDirectory: context.ticketDirectory,
@@ -126,6 +111,7 @@ function currentReview(
   return {
     ok: false,
     reason:
+      latestReviewRejection(context) ??
       'The current Implementation Plan has no current authenticated Implementation Plan review receipt.',
   };
 }
@@ -249,10 +235,17 @@ function latestReviewRejection(context: ApprovalContext): string | undefined {
     return undefined;
   }
   const data = review.data as Record<string, unknown>;
-  if (data.review_kind !== 'plan-implementation' || !reviewsPlan(data, context)) {
+  if (
+    data.status !== 'changes_requested' ||
+    data.review_kind !== 'plan-implementation' ||
+    !reviewsPlan(data, context)
+  ) {
     return undefined;
   }
-  const messages = review.findings.map(finding => finding.message).filter(Boolean);
+  const messages = review.findings
+    .filter(finding => finding.code === 'REVIEWER_FINDING')
+    .map(finding => finding.message)
+    .filter(Boolean);
   return messages.length > 0
     ? `Implementation Plan review is blocked: ${messages.join(' ')}`
     : 'The Implementation Plan review requested changes.';
@@ -310,7 +303,12 @@ function scaffoldExecutionPlan(context: ApprovalContext): string | undefined {
       'The installed Execution Plan template is missing. Repair the Safeword installation before approving the plan.',
     );
   }
-  writeFileSync(planPath, readFileSync(templatePath, 'utf8'), { flag: 'wx' });
+  try {
+    writeFileSync(planPath, readFileSync(templatePath, 'utf8'), { flag: 'wx' });
+  } catch (error) {
+    if ((error as NodeJS.ErrnoException).code === 'EEXIST') return undefined;
+    throw error;
+  }
   return nodePath.relative(context.cwd, planPath);
 }
 
diff --git a/packages/cli/templates/skills/bdd/PLAN_IMPLEMENTATION.md b/packages/cli/templates/skills/bdd/PLAN_IMPLEMENTATION.md
index a9a785214..6619f60ce 100644
--- a/packages/cli/templates/skills/bdd/PLAN_IMPLEMENTATION.md
+++ b/packages/cli/templates/skills/bdd/PLAN_IMPLEMENTATION.md
@@ -330,6 +330,10 @@ receipt controls eligibility for approval and phase advancement.
    safeword ticket approve-plan <ticket-id>
    ```
 
+   Use the authenticated phase stamp from step 1; no additional artifact self-stamp
+   is required. Admission still authenticates reviewer provenance and rechecks
+   the exact reviewed plan bytes. Approved warnings are not rejection findings.
+
    Never replace this command with conversational approval or a manual phase
    edit. It rechecks the exact reviewed plan bytes and the current project
    configuration. When `designApprovalGate` is absent or off, it records `not
diff --git a/packages/cli/tests/fixtures/lifecycle-origin-main/cursor-check.json b/packages/cli/tests/fixtures/lifecycle-origin-main/cursor-check.json
index c711d938d..5d2e277cd 100644
--- a/packages/cli/tests/fixtures/lifecycle-origin-main/cursor-check.json
+++ b/packages/cli/tests/fixtures/lifecycle-origin-main/cursor-check.json
@@ -2,5 +2,5 @@
   "integration": "cursor",
   "operation": "check",
   "result_sha256": "11354dd25a42d64ded227faac8c2ea42556c108325e2865fbcdae1c31eb91267",
-  "tree_sha256": "fe846ab3587226bd5910a8db92a5464cd1982aabe4e152668a257f80d0f7d7db"
+  "tree_sha256": "d225b4a839f1823ea4b1b1531d507e0a096f2cf2bda48d0404949c9db78115f6"
 }
diff --git a/packages/cli/tests/fixtures/lifecycle-origin-main/cursor-install.json b/packages/cli/tests/fixtures/lifecycle-origin-main/cursor-install.json
index b37531161..832b0b0cb 100644
--- a/packages/cli/tests/fixtures/lifecycle-origin-main/cursor-install.json
+++ b/packages/cli/tests/fixtures/lifecycle-origin-main/cursor-install.json
@@ -2,5 +2,5 @@
   "integration": "cursor",
   "operation": "install",
   "result_sha256": "1f3c3174135d276fe41de6b44e23ff96f100c35f8d97264f483a1fd663a9ccb8",
-  "tree_sha256": "fe846ab3587226bd5910a8db92a5464cd1982aabe4e152668a257f80d0f7d7db"
+  "tree_sha256": "d225b4a839f1823ea4b1b1531d507e0a096f2cf2bda48d0404949c9db78115f6"
 }
diff --git a/packages/cli/tests/fixtures/lifecycle-origin-main/cursor-upgrade.json b/packages/cli/tests/fixtures/lifecycle-origin-main/cursor-upgrade.json
index 0855b3a56..d570099e1 100644
--- a/packages/cli/tests/fixtures/lifecycle-origin-main/cursor-upgrade.json
+++ b/packages/cli/tests/fixtures/lifecycle-origin-main/cursor-upgrade.json
@@ -2,5 +2,5 @@
   "integration": "cursor",
   "operation": "upgrade",
   "result_sha256": "e9206dcd5541c42df9ef4548dea36082a34cd33603b53da6fb2b7e6961f8b229",
-  "tree_sha256": "fe846ab3587226bd5910a8db92a5464cd1982aabe4e152668a257f80d0f7d7db"
+  "tree_sha256": "d225b4a839f1823ea4b1b1531d507e0a096f2cf2bda48d0404949c9db78115f6"
 }
diff --git a/packages/cli/tests/fixtures/lifecycle-origin-main/manifest.json b/packages/cli/tests/fixtures/lifecycle-origin-main/manifest.json
index 1b8d7818f..a151ce1f1 100644
--- a/packages/cli/tests/fixtures/lifecycle-origin-main/manifest.json
+++ b/packages/cli/tests/fixtures/lifecycle-origin-main/manifest.json
@@ -1,6 +1,6 @@
 {
   "originMainCommit": "f22e2997ba8ef68d3d198ca2d937bfbf35fdab87",
-  "templatesSha256": "cfc3ca0a5cf55fca2897ee64561ae7e358cc7139e11c5daa0ef3c060dab8b9ac",
+  "templatesSha256": "fbeaab28da9106c304bfd6bd35b7911b2809896d3572487c4234d6341cc11073",
   "fixtures": {
     "claude-install": "19c150ddc4d9bc9d6f153b70b3f819ccaba10bb51fa516fbb74d2253b88f831f",
     "claude-check": "b52aef17fd1cf6e40bb2cb480527bb93724e679c50457f48d7bf9432d34ad805",
@@ -10,9 +10,9 @@
     "codex-check": "a0eed18c0714e90ec8bdad8d6c6e7f04b4ce1026b73a24e38cf779f018ac8861",
     "codex-upgrade": "1d009c751b57159674a50d17ebf9c67c39bf620ae333d76dad05b4f4dcd4c6e1",
     "codex-uninstall": "324e6790338fc0633848d8e6c5dc6e55d0d7c38cbf3fbe9cafaf18a154aa734b",
-    "cursor-install": "1b0ec1c6b5f2690a2008b0a8bc1acd46ef06feb4d0d5e5f1008d8c067e9ec437",
-    "cursor-check": "a5cae5bba77d5898bada37cd30566b742c8af06692609997ff7010426a2b78d6",
-    "cursor-upgrade": "5f4502c51c3c0d89d2a0d79fe8e076671d393a2fbf32417beeb8f1b0cbd1bf83",
+    "cursor-install": "f150cf936f53e1c3e8497b069865edfd979ad8fa57c09521afca87ccd9982158",
+    "cursor-check": "1f0967dc25d8943653117158dc061be014730306b7c81b3240c0948dd222a783",
+    "cursor-upgrade": "c5803a1fa910294a853072bcdf402cc8be6b02421bdb2bf4b1af12c9ec6a6499",
     "cursor-uninstall": "911fd61d7a8471f9ae03ad44ff6e70b8096777eccee6f79414a86883e8244290"
   }
 }
diff --git a/packages/cli/tests/hooks/plan-implementation-document.test.ts b/packages/cli/tests/hooks/plan-implementation-document.test.ts
index 31429d04f..eac42a89a 100644
--- a/packages/cli/tests/hooks/plan-implementation-document.test.ts
+++ b/packages/cli/tests/hooks/plan-implementation-document.test.ts
@@ -35,6 +35,15 @@ describe('PLAN_IMPLEMENTATION.md contract (TXRHMD)', () => {
     return { path, text: readFileSync(path, 'utf8') };
   });
 
+  it('documents the single authenticated phase-stamp approval path (D1BKYA)', () => {
+    for (const { path, text } of planCopies) {
+      const approval = text.slice(text.indexOf('2. **Use the canonical approval boundary.**'));
+      expect(approval, path).toMatch(/authenticated phase stamp/iu);
+      expect(approval, path).toMatch(/no additional artifact self-stamp/iu);
+      expect(approval, path).toMatch(/approved warnings.*not.*rejection/iu);
+    }
+  });
+
   it('owns the impl-plan authoring steps with all six design sections (TB1.R3)', () => {
     for (const { path, text } of planCopies) {
       expect(text, path).toContain('impl-plan.md');
diff --git a/packages/cli/tests/integration/plan-design-approval.test.ts b/packages/cli/tests/integration/plan-design-approval.test.ts
index cd942b3cd..59faf783b 100644
--- a/packages/cli/tests/integration/plan-design-approval.test.ts
+++ b/packages/cli/tests/integration/plan-design-approval.test.ts
@@ -178,7 +178,7 @@ interface Fixture {
   readonly reviewId?: string;
 }
 
-type ReviewState = 'approved' | 'missing' | 'rejected';
+type ReviewState = 'approved' | 'approved-warning' | 'missing' | 'rejected';
 
 const fixtures: string[] = [];
 
@@ -264,6 +264,7 @@ function fixture(designApprovalGate: boolean, reviewState: ReviewState = 'approv
         SAFEWORD_REVIEW_FOREGROUND_MS: '5000',
         SAFEWORD_REVIEW_KEY_ROOT: nodePath.join(root, '.review-keys'),
         SAFEWORD_REVIEW_FAKE_VERDICT: reviewState === 'rejected' ? 'request_changes' : 'approve',
+        SAFEWORD_REVIEW_FAKE_FINDING: reviewState === 'approved-warning' ? '1' : '',
       },
     },
   );
@@ -534,6 +535,8 @@ if printf '%s' "$payload" | /usr/bin/grep -Fq '"kind":"plan-execution"'; then
 fi
 if [ "${'$'}{SAFEWORD_REVIEW_FAKE_VERDICT:-approve}" = "request_changes" ]; then
   printf '{"schema_version":1,"dispatch_id":"%s","reviewer_agent":"claude","verdict":"request_changes","summary":"plan is blocked","findings":[{"severity":"error","message":"Authorization boundary is missing."}]}\n' "$dispatch_id"
+elif [ "${'$'}{SAFEWORD_REVIEW_FAKE_FINDING:-}" = "1" ]; then
+  printf '{"schema_version":1,"dispatch_id":"%s","reviewer_agent":"claude","verdict":"approve","summary":"plan is approved with advice","findings":[{"severity":"warning","message":"Consider documenting the optional recovery example."}]}\n' "$dispatch_id"
 else
   printf '{"schema_version":1,"dispatch_id":"%s","reviewer_agent":"claude","verdict":"approve","summary":"plan is approved","findings":[]}\n' "$dispatch_id"
 fi
@@ -808,6 +811,93 @@ describe('an accepted design enters Execution Planning', () => {
 });
 
 describe('Implementation Plan review admission controls Execution Planning', () => {
+  it('advances an approved warning with only its authenticated phase stamp', async () => {
+    const project = fixture(false, 'approved-warning');
+    writeFileSync(
+      project.ledgerPath,
+      readFileSync(project.ledgerPath, 'utf8')
+        .split('\n')
+        .filter(line => !line.includes('review:') || line.includes(':phase@plan-implementation'))
+        .join('\n'),
+    );
+
+    const result = await runCli(['--json', '--no-input', 'ticket', 'approve-plan', TICKET_ID], {
+      cwd: project.root,
+      env: reviewEnvironment(project),
+    });
+
+    const reviewed = await runCli(['--json', 'review', 'status', project.reviewId ?? ''], {
+      cwd: project.root,
+      env: reviewEnvironment(project),
+    });
+    expect(JSON.parse(reviewed.stdout)).toMatchObject({
+      data: { status: 'approved', reviewer_output: { findings: [{ severity: 'warning' }] } },
+    });
+    expect(result.exitCode, result.stdout).toBe(0);
+    expect(phase(project.ticketPath)).toBe('plan-execution');
+    expect(JSON.parse(result.stdout)).toMatchObject({
+      data: { approval_status: 'not-required', achieved_independence: 'cross-agent' },
+    });
+    expect(result.stdout).not.toContain('Implementation Plan review is blocked');
+  });
+
+  it.each(['missing-phase-stamp', 'stale-plan', 'invalid-plan'] as const)(
+    'reports %s without rendering approved warnings as rejection findings',
+    async evidence => {
+      const project = fixture(false, 'approved-warning');
+      if (evidence === 'missing-phase-stamp') {
+        writeFileSync(
+          project.ledgerPath,
+          readFileSync(project.ledgerPath, 'utf8')
+            .split('\n')
+            .filter(line => !line.includes(':phase@plan-implementation'))
+            .join('\n'),
+        );
+      } else {
+        const plan =
+          evidence === 'stale-plan'
+            ? `${PLAN}\nA later unreviewed decision.\n`
+            : PLAN.replace('## Approach', '## Missing approach');
+        writeFileSync(nodePath.join(project.ticketDirectory, 'impl-plan.md'), plan);
+      }
+
+      const result = await runCli(['--json', '--no-input', 'ticket', 'approve-plan', TICKET_ID], {
+        cwd: project.root,
+        env: reviewEnvironment(project),
+      });
+
+      expect(result.exitCode, result.stdout).toBe(2);
+      expect(phase(project.ticketPath)).toBe('plan-implementation');
+      expect(result.stdout).not.toContain('Consider documenting the optional recovery example.');
+      expect(result.stdout).not.toContain('Implementation Plan review is blocked');
+      expect(result.stdout).toContain(
+        evidence === 'invalid-plan'
+          ? 'Approach'
+          : 'has no current authenticated Implementation Plan review receipt',
+      );
+    },
+  );
+
+  it('reports only actual rejection findings without a phase stamp', async () => {
+    const project = fixture(false, 'rejected');
+    writeFileSync(project.ledgerPath, '');
+
+    const result = await runCli(['--json', '--no-input', 'ticket', 'approve-plan', TICKET_ID], {
+      cwd: project.root,
+      env: reviewEnvironment(project),
+    });
+
+    expect(result.exitCode, result.stdout).toBe(2);
+    expect(phase(project.ticketPath)).toBe('plan-implementation');
+    expect(JSON.parse(result.stdout)).toMatchObject({
+      findings: [
+        { message: 'Implementation Plan review is blocked: Authorization boundary is missing.' },
+      ],
+    });
+    expect(result.stdout).not.toContain('A different agent');
+    expect(result.stdout).not.toContain('plan is blocked');
+  });
+
   it('blocks when the project-local Implementation Plan is absent', async () => {
     const project = fixture(false);
     rmSync(nodePath.join(project.ticketDirectory, 'impl-plan.md'));
@@ -1130,6 +1220,50 @@ describe('retrying the same design approval does not duplicate authority', () =>
     });
   });
 
+  it('converges when both approvals observe an absent Execution Plan before creating it', async () => {
+    const project = fixture(true);
+    const schedule = nodePath.join(project.root, 'schedule-scaffold.mjs');
+    writeFileSync(
+      schedule,
+      String.raw`import fs from 'node:fs';
+import { syncBuiltinESMExports } from 'node:module';
+const exists = fs.existsSync;
+fs.existsSync = function(path) {
+  const found = exists(path);
+  if (!found && String(path).endsWith('/execution-plan.md')) {
+    const barrier = String(path) + '.two-writers';
+    fs.appendFileSync(barrier, 'ready\n');
+    const deadline = Date.now() + 5000;
+    while (fs.readFileSync(barrier, 'utf8').trim().split('\n').length < 2) {
+      if (Date.now() >= deadline) throw new Error('The second scaffold writer did not arrive');
+      Atomics.wait(new Int32Array(new SharedArrayBuffer(4)), 0, 0, 10);
+    }
+  }
+  return found;
+};
+syncBuiltinESMExports();
+`,
+    );
+    const environment = {
+      NODE_OPTIONS: `${process.env.NODE_OPTIONS ?? ''} --import ${JSON.stringify(schedule)}`,
+    };
+
+    const statuses = await Promise.all([
+      runApprovalInPtyAsync(project, TICKET_ID, environment),
+      runApprovalInPtyAsync(project, TICKET_ID, environment),
+    ]);
+
+    expect(statuses).toEqual([0, 0]);
+    expect(decisionPayloads(project.ledgerPath)).toHaveLength(1);
+    expect(phase(project.ticketPath)).toBe('plan-execution');
+    expect(readFileSync(nodePath.join(project.ticketDirectory, 'execution-plan.md'), 'utf8')).toBe(
+      readFileSync(
+        nodePath.join(project.root, '.safeword/templates/execution-plan-template.md'),
+        'utf8',
+      ),
+    );
+  });
+
   it('records a fresh approval after an earlier approval was superseded', () => {
     const project = fixture(true);
     const digest = createHash('sha256').update(PLAN).digest('hex');
diff --git a/plugin/identity.json b/plugin/identity.json
index ce21cf538..e4e5dcd9c 100644
--- a/plugin/identity.json
+++ b/plugin/identity.json
@@ -2,5 +2,5 @@
   "schema_version": 1,
   "plugin_version": "1.0.0",
   "hook_manifest_sha256": "566e99f2ec53278b400dae1e54085940594048f0423787cc6863f3f543422756",
-  "inventory_sha256": "c2cd4c7d241c534749277e5c017ba5f08cbccdb4c3ed443a26d1c5f6be63515d"
+  "inventory_sha256": "f1c164ee9d085485ac3da76d6ea1ca7634ac7a1139a6991fe0e45ea0de65f5e0"
 }
diff --git a/plugin/inventory.json b/plugin/inventory.json
index 95d81e7d6..3367e7791 100644
--- a/plugin/inventory.json
+++ b/plugin/inventory.json
@@ -155,11 +155,11 @@
     },
     {
       "path": "runtime/cli.js",
-      "sha256": "95f92b1bd4f5c81f339f42675ef53d2987e6ba7a1311a2c87f7ac3116a0d5131"
+      "sha256": "e37dd08053869bd91ee8195463fae5dbe131e0982fafcd61ff9d441ffd0e76ba"
     },
     {
       "path": "runtime/dispatch.js",
-      "sha256": "9a5413d6877d60db3d1b17eb10d3dd14a68d6c502e425357d67c8ca5f6b59c69"
+      "sha256": "cd49e22853180b9d9da7cf019cf1bed58ad089c52bf373beffe16177f9995a84"
     },
     {
       "path": "runtime/event-groups.json",
@@ -651,7 +651,7 @@
     },
     {
       "path": "skills/bdd/PLAN_IMPLEMENTATION.md",
-      "sha256": "b7cf417a40d59887f88adad3a51531afb40b98c29ff3cee095d0c62b691dfbaa"
+      "sha256": "a08270c39f9f922e65fb9931ce7ac74aa51a0e9ae711010614315819ce9e9aa9"
     },
     {
       "path": "skills/bdd/SCENARIOS.md",
@@ -1647,7 +1647,7 @@
     },
     {
       "path": "templates/skills/bdd/PLAN_IMPLEMENTATION.md",
-      "sha256": "e24265aef799112db05a778ae42e182bd2886f883ceea4b2382949c8ccc7392c"
+      "sha256": "248b11fd40cd23d7a6ac6f9bb8a6be7cc5d762f882ac3006b3f30ed0603858b8"
     },
     {
       "path": "templates/skills/bdd/SCENARIOS.md",
diff --git a/plugin/runtime/cli.js b/plugin/runtime/cli.js
index ff749de4c..3751d92e2 100644
--- a/plugin/runtime/cli.js
+++ b/plugin/runtime/cli.js
@@ -3605,7 +3605,7 @@ var init_historical_catalogue_generated = __esm(() => {
         ".claude/skills/bdd/DISCOVERY.md": "1dd29f815c358ab6e215fa5d0e2db1fe6ab26d93df0b151a53908370331b09ed",
         ".claude/skills/bdd/DONE.md": "e9f22430341cf225eaf58ef6335720c5033cb8f6779425d5740adc0ff80a5f60",
         ".claude/skills/bdd/PLAN_EXECUTION.md": "4cf9fd3c73c7f0489d49c4f56af0251ea7ed8effa1415182e970f16fe764f47c",
-        ".claude/skills/bdd/PLAN_IMPLEMENTATION.md": "e24265aef799112db05a778ae42e182bd2886f883ceea4b2382949c8ccc7392c",
+        ".claude/skills/bdd/PLAN_IMPLEMENTATION.md": "248b11fd40cd23d7a6ac6f9bb8a6be7cc5d762f882ac3006b3f30ed0603858b8",
         ".claude/skills/bdd/SCENARIOS.md": "1e89aa6a46895858cff252d642dd9f7b5853d0fd7dd314aaa75e2ee6046bcddb",
         ".claude/skills/bdd/SKILL.md": "3770f019f5a83fd4ad6dcb2322528595a39545f61cf1106a2f606a8137036d9d",
         ".claude/skills/bdd/SPLITTING.md": "e232a37a4d76f0dfc51e65965c1e1b7f1572e0dedce0fb8c031e75bd6544a708",
@@ -38762,40 +38762,6 @@ var init_retrospective_close = __esm(() => {
 });
 
 // templates/hooks/lib/review-ledger.ts
-import { createHash as createHash25 } from "crypto";
-function hashArtifact(content) {
-  return createHash25("sha1").update(content).digest("hex").slice(0, 12);
-}
-function reviewScope2(ticketId, artifact, contentHash) {
-  return `${ticketId}:${artifact}@${contentHash}`;
-}
-function isSatisfyingStamp(stamp, policy = "prefer") {
-  const ordinarilySatisfying = stamp.skipReason === undefined || isValidSkipReason(stamp.skipReason);
-  if (!ordinarilySatisfying)
-    return false;
-  if (stamp.skipReason === undefined && stamp.independence !== undefined && COORDINATOR_CLAIMS.has(stamp.independence) && stamp.reviewId === undefined)
-    return false;
-  if (policy !== "require")
-    return true;
-  return stamp.skipReason === undefined && stamp.independence === "cross-agent" && stamp.author !== undefined && stamp.reviewer !== undefined && stamp.author !== stamp.reviewer;
-}
-function isSatisfyingCoordinatorReviewStamp(id, stamp, policy) {
-  return stamp.scope === id && stamp.skipReason === undefined && stamp.reviewId !== undefined && stamp.independence !== undefined && COORDINATOR_CLAIMS.has(stamp.independence) && isSatisfyingStamp(stamp, policy);
-}
-function isSatisfyingSkipStamp(id, stamp) {
-  return stamp.scope === id && stamp.skipReason !== undefined && isValidSkipReason(stamp.skipReason);
-}
-function hasSatisfyingPhaseStamp(id, stamps, policy) {
-  return stamps.some((stamp) => isSatisfyingSkipStamp(id, stamp) || isSatisfyingCoordinatorReviewStamp(id, stamp, policy));
-}
-function gatePhaseAdvance(phase, stamps, policy = "prefer") {
-  if (hasSatisfyingPhaseStamp(phase, stamps, policy))
-    return { ok: true };
-  return {
-    ok: false,
-    reason: `phase "${phase}" has no independent review stamp \u2014 run the phase-exit review (or log a skip with a reason) before advancing`
-  };
-}
 function readCrossAgentReviewPolicy(rawConfig) {
   if (rawConfig === undefined)
     return "prefer";
@@ -38962,7 +38928,7 @@ __export(exports_red_execution, {
   executeNoShellCommand: () => executeNoShellCommand
 });
 import { spawn as spawn3, spawnSync as spawnSync11 } from "child_process";
-import { createHash as createHash26 } from "crypto";
+import { createHash as createHash25 } from "crypto";
 import { realpathSync as realpathSync13 } from "fs";
 import nodePath53 from "path";
 function terminateProofTree(child) {
@@ -38996,7 +38962,7 @@ function proofEnvironment2() {
 }
 function environmentIdentity(environment) {
   const entries = Object.entries(environment).toSorted(([left], [right]) => left.localeCompare(right));
-  const sha2566 = createHash26("sha256").update(JSON.stringify(entries)).digest("hex");
+  const sha2566 = createHash25("sha256").update(JSON.stringify(entries)).digest("hex");
   return {
     sha256: sha2566,
     variable_count: entries.length,
@@ -39009,7 +38975,7 @@ function environmentIdentity(environment) {
 
 class StreamEvidence {
   expected;
-  #hash = createHash26("sha256");
+  #hash = createHash25("sha256");
   #chunks = [];
   #retained = 0;
   #bytes = 0;
@@ -39239,7 +39205,7 @@ var init_execution_plan_admission_generated = __esm(() => {
 });
 
 // src/review/execution-plan-conformance.ts
-import { createHash as createHash27 } from "crypto";
+import { createHash as createHash26 } from "crypto";
 function stagedOwners(prerequisite, activation) {
   return { "Accepted behavior": activation, "Migration work": prerequisite };
 }
@@ -39415,7 +39381,7 @@ function missingObligationCase(id, obligation) {
   }), [obligation]);
 }
 function sha2566(value) {
-  return createHash27("sha256").update(value).digest("hex");
+  return createHash26("sha256").update(value).digest("hex");
 }
 function executionPlanConformanceDigests() {
   return {
@@ -44779,7 +44745,7 @@ var CROCKFORD_ALPHABET = "0123456789ABCDEFGHJKMNPQRSTVWXYZ", ID_LENGTH = 6;
 var init_id_minter = () => {};
 
 // src/utils/product-plan-contract.ts
-import { createHash as createHash28 } from "crypto";
+import { createHash as createHash27 } from "crypto";
 import { existsSync as existsSync30, readdirSync as readdirSync14, readFileSync as readFileSync50 } from "fs";
 import nodePath65 from "path";
 function sectionAfterHeading(content, level, id) {
@@ -44845,7 +44811,7 @@ function canonicalizeContractValue(value) {
 }
 function digestParentContract(values) {
   const canonical = CONTRACT_KEYS.map((key) => [key, canonicalizeContractValue(values[key])]);
-  return createHash28("sha256").update(JSON.stringify(canonical)).digest("hex");
+  return createHash27("sha256").update(JSON.stringify(canonical)).digest("hex");
 }
 function resolveTicketDirectory(cwd, ticketId) {
   const root = resolveTicketsDirectory(cwd);
@@ -46867,7 +46833,7 @@ var init_project_root = __esm(() => {
 });
 
 // src/claude-plugin/plugin-data.ts
-import { createHash as createHash29 } from "crypto";
+import { createHash as createHash28 } from "crypto";
 import { homedir as homedir7 } from "os";
 import nodePath71 from "path";
 function claudeConfigDirectory(environment = process.env) {
@@ -46884,7 +46850,7 @@ function claudePluginDataDirectory(environment = process.env) {
   return nodePath71.join(claudeConfigDirectory(environment), CLAUDE_MIGRATION_SCHEMA.data.pluginsRoot, claudePluginDataId());
 }
 function claudeProjectDigest(canonicalProjectRoot) {
-  return createHash29("sha256").update(canonicalProjectRoot).digest("hex");
+  return createHash28("sha256").update(canonicalProjectRoot).digest("hex");
 }
 function claudeProofDirectory(environment = process.env) {
   return nodePath71.join(claudePluginDataDirectory(environment), CLAUDE_MIGRATION_SCHEMA.data.proofs);
@@ -46899,7 +46865,7 @@ var init_plugin_data = __esm(() => {
 });
 
 // src/claude-plugin/migration-state.ts
-import { createHash as createHash30, randomUUID as randomUUID12 } from "crypto";
+import { createHash as createHash29, randomUUID as randomUUID12 } from "crypto";
 import { cpSync, existsSync as existsSync34, mkdirSync as mkdirSync18, readFileSync as readFileSync54, renameSync as renameSync12, rmSync as rmSync11 } from "fs";
 import nodePath72 from "path";
 function createClaudePluginMode(marker) {
@@ -46910,7 +46876,7 @@ function createClaudePluginMode(marker) {
   };
 }
 function digest3(value) {
-  return createHash30("sha256").update(value).digest("hex");
+  return createHash29("sha256").update(value).digest("hex");
 }
 function relocateLegacyState(from, to, rename2 = renameSync12, copy = (source, destination) => {
   cpSync(source, destination, { recursive: true, errorOnExist: true, force: false });
@@ -46997,7 +46963,7 @@ function claudeWatchedSettingsDigest(cwd) {
     nodePath72.join(cwd, ".claude/settings.json"),
     nodePath72.join(configDirectory, "settings.json")
   ];
-  const hash = createHash30("sha256");
+  const hash = createHash29("sha256");
   for (const path7 of paths) {
     hash.update(path7);
     hash.update("\x00");
@@ -48878,9 +48844,9 @@ var init_detect = __esm(() => {
 });
 
 // src/utils/cucumber-template-revisions.ts
-import { createHash as createHash31 } from "crypto";
+import { createHash as createHash30 } from "crypto";
 function isShippedCucumberTemplateRevision(content) {
-  const hash = createHash31("sha256").update(content).digest("hex");
+  const hash = createHash30("sha256").update(content).digest("hex");
   return CUCUMBER_TEMPLATE_REVISION_HASHES.has(hash);
 }
 var CUCUMBER_TEMPLATE_REVISION_HASHES;
@@ -59836,7 +59802,7 @@ __export(exports_profile, {
   claudeInstallRequiresMutation: () => claudeInstallRequiresMutation
 });
 import { spawnSync as spawnSync13 } from "child_process";
-import { createHash as createHash32 } from "crypto";
+import { createHash as createHash31 } from "crypto";
 import {
   closeSync as closeSync9,
   cpSync as cpSync2,
@@ -60379,7 +60345,7 @@ function convergePlugin(cwd, scope, effects) {
   }
 }
 function fileSha256(path8) {
-  return createHash32("sha256").update(readFileSync58(path8)).digest("hex");
+  return createHash31("sha256").update(readFileSync58(path8)).digest("hex");
 }
 function assertInstalledAsset(installPath, asset) {
   if (typeof asset.path !== "string" || nodePath88.isAbsolute(asset.path) || asset.path.split(/[\\/]/u).includes("..") || typeof asset.sha256 !== "string") {
@@ -60391,7 +60357,7 @@ function assertInstalledAsset(installPath, asset) {
   }
 }
 function assertInstalledIdentity(identity, inventory, inventoryContent) {
-  if (identity.schema_version !== 1 || identity.plugin_version !== VERSION || identity.inventory_sha256 !== createHash32("sha256").update(inventoryContent).digest("hex") || inventory.schema_version !== 1 || !Array.isArray(inventory.assets)) {
+  if (identity.schema_version !== 1 || identity.plugin_version !== VERSION || identity.inventory_sha256 !== createHash31("sha256").update(inventoryContent).digest("hex") || inventory.schema_version !== 1 || !Array.isArray(inventory.assets)) {
     throw new TypeError("installed identity or inventory is inconsistent");
   }
 }
@@ -60690,7 +60656,7 @@ var init_profile = __esm(() => {
 });
 
 // src/claude-plugin/hook-manifest.ts
-import { createHash as createHash33 } from "crypto";
+import { createHash as createHash32 } from "crypto";
 function adaptHookValue(value) {
   if (typeof value === "string") {
     return value.replaceAll(PROJECT_HOOK_ROOT, () => PLUGIN_HOOK_ROOT);
@@ -60740,7 +60706,7 @@ function pluginHookManifest() {
 `;
 }
 function currentClaudePluginHookManifestSha256() {
-  return createHash33("sha256").update(pluginHookManifest()).digest("hex");
+  return createHash32("sha256").update(pluginHookManifest()).digest("hex");
 }
 var PROJECT_HOOK_ROOT = '"$CLAUDE_PROJECT_DIR"/.safeword/hooks', PLUGIN_HOOK_ROOT = '"${CLAUDE_PLUGIN_ROOT}"/runtime/hooks', PLUGIN_DISPATCH = 'bun --no-env-file --cwd "${CLAUDE_PLUGIN_ROOT}" "${CLAUDE_PLUGIN_ROOT}"/runtime/dispatch.js', EVENT_GROUP_EVENTS;
 var init_hook_manifest = __esm(() => {
@@ -61940,7 +61906,7 @@ __export(exports_profile2, {
   installOpenCodeProfile: () => installOpenCodeProfile,
   generateOpenCodeProfilePlugin: () => generateOpenCodeProfilePlugin
 });
-import { createHash as createHash34 } from "crypto";
+import { createHash as createHash33 } from "crypto";
 import {
   existsSync as existsSync45,
   lstatSync as lstatSync19,
@@ -61998,7 +61964,7 @@ function observeFile2(path8) {
   }
 }
 function sha2567(value) {
-  return createHash34("sha256").update(value).digest("hex");
+  return createHash33("sha256").update(value).digest("hex");
 }
 function packagedDispatcherPath() {
   const moduleDirectory = import.meta.dirname;
@@ -62922,7 +62888,7 @@ __export(exports_conformance, {
   observeOpenCodeVersion: () => observeOpenCodeVersion
 });
 import { spawnSync as spawnSync15 } from "child_process";
-import { createHash as createHash35 } from "crypto";
+import { createHash as createHash34 } from "crypto";
 import { accessSync as accessSync4, constants as constants6, lstatSync as lstatSync20, readFileSync as readFileSync63, realpathSync as realpathSync18, statSync as statSync7 } from "fs";
 import nodePath96 from "path";
 function resolveExecutable(environment) {
@@ -62977,7 +62943,7 @@ function profileRemediation() {
   });
 }
 function sha2568(value) {
-  return createHash35("sha256").update(value).digest("hex");
+  return createHash34("sha256").update(value).digest("hex");
 }
 function installedProfile(environment) {
   const root = resolveOpenCodeConfigRoot({
@@ -63911,7 +63877,7 @@ var init_doctor = __esm(() => {
 });
 
 // src/cli-protocol/reconciliation.ts
-import { createHash as createHash36 } from "crypto";
+import { createHash as createHash35 } from "crypto";
 import { lstatSync as lstatSync21, readdirSync as readdirSync29, readFileSync as readFileSync64, readlinkSync as readlinkSync3 } from "fs";
 import nodePath97 from "path";
 function actionTargets(action) {
@@ -63962,7 +63928,7 @@ function hashPath(hash, absolutePath, relativePath, readFile3) {
   }
 }
 function preconditionDigestForPaths(cwd, paths, readFile3 = readFileForDigest) {
-  const hash = createHash36("sha256");
+  const hash = createHash35("sha256");
   const targets = [...new Set(paths)].toSorted((left, right) => left.localeCompare(right));
   for (const target of targets) {
     hashField(hash, "target", target);
@@ -64692,7 +64658,7 @@ To wire the warn-only boundary gate, add under repos:
 
 // src/utils/namespace-migration.ts
 import { execSync } from "child_process";
-import { createHash as createHash37 } from "crypto";
+import { createHash as createHash36 } from "crypto";
 import {
   closeSync as closeSync10,
   constants as fsConstants3,
@@ -64741,7 +64707,7 @@ function validateDirectoryRoot(path8, label) {
 }
 function conflictArchivePath(source, relative) {
   const metadata = lstatSync22(source);
-  const digest4 = createHash37("sha256").update(`${metadata.mode.toString(8)}\x00`).update(readFileSync67(source)).digest("hex");
+  const digest4 = createHash36("sha256").update(`${metadata.mode.toString(8)}\x00`).update(readFileSync67(source)).digest("hex");
   return nodePath104.join(".safeword", "namespace-migration-conflicts-v1", digest4, relative);
 }
 function plannedNamespaceMigrationFiles(cwd) {
@@ -65453,7 +65419,7 @@ var init_vendored_ignores_nudge = __esm(() => {
 });
 
 // src/lifecycle/project-install.ts
-import { createHash as createHash38 } from "crypto";
+import { createHash as createHash37 } from "crypto";
 import {
   closeSync as closeSync11,
   constants as fsConstants4,
@@ -65754,7 +65720,7 @@ function setupPreconditionDigest(cwd, reconciliationDigest, effects, context, op
     ...effects.files.map((effect) => effect.target),
     ...effects.destructive.map((effect) => effect.target)
   ].filter((target) => !target.includes(" \u2192 "));
-  return createHash38("sha256").update(JSON.stringify([
+  return createHash37("sha256").update(JSON.stringify([
     reconciliationDigest,
     effects,
     JSON.stringify(context, (_key, value) => typeof value === "string" ? value.replaceAll(cwd, "<project>") : value),
@@ -66758,7 +66724,7 @@ __export(exports_commands, {
   planLifecycle: () => planLifecycle,
   installLifecycle: () => installLifecycle
 });
-import { createHash as createHash39 } from "crypto";
+import { createHash as createHash38 } from "crypto";
 function activationActionsFor(surface) {
   if (surface.name === "claude" && surface.result.changed)
     return ["run /reload-plugins"];
@@ -66954,7 +66920,7 @@ async function prepareLifecycle(cwd, operation, agents, options = {}) {
   };
   const integrationSurfaces = observedSurfaces.filter((surface) => selected.has(surface.name));
   const surfaces = [{ name: "project", effects: project.plan.effects }, ...integrationSurfaces];
-  const preconditionDigest2 = createHash39("sha256").update(JSON.stringify([
+  const preconditionDigest2 = createHash38("sha256").update(JSON.stringify([
     project.plan.preconditionDigest,
     agents,
     scope,
@@ -67254,7 +67220,7 @@ __export(exports_cleanup, {
   claudeLegacyMutations: () => claudeLegacyMutations,
   claudeCleanupPreconditionDigest: () => claudeCleanupPreconditionDigest
 });
-import { createHash as createHash40, randomUUID as randomUUID14 } from "crypto";
+import { createHash as createHash39, randomUUID as randomUUID14 } from "crypto";
 import {
   closeSync as closeSync12,
   constants as fsConstants5,
@@ -67274,7 +67240,7 @@ import {
 } from "fs";
 import nodePath111 from "path";
 function sha2569(content) {
-  return createHash40("sha256").update(content).digest("hex");
+  return createHash39("sha256").update(content).digest("hex");
 }
 function containsJsonComments(content) {
   let found = false;
@@ -68311,7 +68277,7 @@ function resolveExecutionMode(input) {
 }
 
 // src/test-execution/remote-workflow-contract.ts
-import { createHash as createHash41 } from "crypto";
+import { createHash as createHash40 } from "crypto";
 function mapping(value) {
   return typeof value === "object" && value !== null && !Array.isArray(value) ? value : undefined;
 }
@@ -68455,7 +68421,7 @@ function hasFixedUpload(steps) {
 }
 function resultViolations(steps) {
   const reportRun = stepById(steps, "report")?.run;
-  const reportValid = typeof reportRun === "string" && createHash41("sha256").update(reportRun).digest("hex") === REPORT_COMMAND_SHA256;
+  const reportValid = typeof reportRun === "string" && createHash40("sha256").update(reportRun).digest("hex") === REPORT_COMMAND_SHA256;
   return reportValid && hasFixedUpload(steps) ? [] : ["fixed_result_protocol"];
 }
 function hasSecretsKey(value) {
@@ -68713,7 +68679,7 @@ var init_remote_workflow_fs = __esm(() => {
 });
 
 // src/test-execution/remote-workflow-state.ts
-import { createHash as createHash42 } from "crypto";
+import { createHash as createHash41 } from "crypto";
 import nodePath114 from "path";
 function observationError(error2, path8) {
   const code = filesystemErrorCode(error2);
@@ -68728,7 +68694,7 @@ function normalizeLineEndings2(content) {
 `);
 }
 function workflowDigest(content) {
-  return createHash42("sha256").update(normalizeLineEndings2(content)).digest("hex");
+  return createHash41("sha256").update(normalizeLineEndings2(content)).digest("hex");
 }
 function readOpenedWorkflow(descriptor, filesystem) {
   const metadata = filesystem.fstat(descriptor);
@@ -71332,7 +71298,7 @@ var init_plan_gate = __esm(() => {
 });
 
 // src/review/approval-ledger.ts
-import { createHash as createHash43, randomUUID as randomUUID16 } from "crypto";
+import { createHash as createHash42, randomUUID as randomUUID16 } from "crypto";
 import {
   closeSync as closeSync15,
   constants as constants9,
@@ -71451,7 +71417,7 @@ function positionedEvents(ledger) {
   ];
 }
 function decisionIdempotencyKey(identity, supersedesPosition) {
-  return createHash43("sha256").update(JSON.stringify([
+  return createHash42("sha256").update(JSON.stringify([
     identity.ticket,
     identity.planDigest,
     identity.decision,
@@ -71460,7 +71426,7 @@ function decisionIdempotencyKey(identity, supersedesPosition) {
   ])).digest("hex");
 }
 function deliveryIdempotencyKey(identity) {
-  return createHash43("sha256").update(JSON.stringify([
+  return createHash42("sha256").update(JSON.stringify([
     identity.ticket,
     identity.itemId,
     identity.proofId,
@@ -71469,7 +71435,7 @@ function deliveryIdempotencyKey(identity) {
   ])).digest("hex");
 }
 function deliveryCompatibilityIdempotencyKey(identity) {
-  return createHash43("sha256").update(JSON.stringify([
+  return createHash42("sha256").update(JSON.stringify([
     identity.ticket,
     identity.itemId,
     identity.proofId,
@@ -71905,7 +71871,7 @@ var exports_plan_approval = {};
 __export(exports_plan_approval, {
   approvePlanResult: () => approvePlanResult
 });
-import { createHash as createHash44, randomUUID as randomUUID17 } from "crypto";
+import { createHash as createHash43, randomUUID as randomUUID17 } from "crypto";
 import {
   appendFileSync as appendFileSync3,
   existsSync as existsSync60,
@@ -71923,7 +71889,7 @@ function interruptApprovalForTest(boundary) {
   }
 }
 function planDigest(content) {
-  return createHash44("sha256").update(content).digest("hex");
+  return createHash43("sha256").update(content).digest("hex");
 }
 function readContext2(cwd, ticketId) {
   const ticketDirectory = resolveTicketDirectory(cwd, ticketId);
@@ -71968,11 +71934,6 @@ function currentReview(context) {
   if (!gate.ok)
     return { ok: false, reason: latestReviewRejection(context) ?? gate.reason };
   const ledger = existsSync60(context.ledgerPath) ? readFileSync84(context.ledgerPath, "utf8") : "";
-  const scope = reviewScope2(nodePath129.basename(context.ticketDirectory), "impl-plan", hashArtifact(context.plan));
-  const artifactReview = gatePhaseAdvance(scope, parseReviewStamps(ledger));
-  if (!artifactReview.ok) {
-    return { ok: false, reason: latestReviewRejection(context) ?? artifactReview.reason };
-  }
   const admission = phaseReviewAdmission({
     cwd: context.cwd,
     ticketDirectory: context.ticketDirectory,
@@ -71989,7 +71950,7 @@ function currentReview(context) {
   }
   return {
     ok: false,
-    reason: "The current Implementation Plan has no current authenticated Implementation Plan review receipt."
+    reason: latestReviewRejection(context) ?? "The current Implementation Plan has no current authenticated Implementation Plan review receipt."
   };
 }
 function reviewsPlan(data, context) {
@@ -72078,10 +72039,10 @@ function latestReviewRejection(context) {
     return;
   }
   const data = review.data;
-  if (data.review_kind !== "plan-implementation" || !reviewsPlan(data, context)) {
+  if (data.status !== "changes_requested" || data.review_kind !== "plan-implementation" || !reviewsPlan(data, context)) {
     return;
   }
-  const messages3 = review.findings.map((finding2) => finding2.message).filter(Boolean);
+  const messages3 = review.findings.filter((finding2) => finding2.code === "REVIEWER_FINDING").map((finding2) => finding2.message).filter(Boolean);
   return messages3.length > 0 ? `Implementation Plan review is blocked: ${messages3.join(" ")}` : "The Implementation Plan review requested changes.";
 }
 function appendReceipt(context, status) {
@@ -72123,7 +72084,13 @@ function scaffoldExecutionPlan(context) {
   if (!existsSync60(templatePath)) {
     throw new Error("The installed Execution Plan template is missing. Repair the Safeword installation before approving the plan.");
   }
-  writeFileSync32(planPath, readFileSync84(templatePath, "utf8"), { flag: "wx" });
+  try {
+    writeFileSync32(planPath, readFileSync84(templatePath, "utf8"), { flag: "wx" });
+  } catch (error2) {
+    if (error2.code === "EEXIST")
+      return;
+    throw error2;
+  }
   return nodePath129.relative(context.cwd, planPath);
 }
 function advanceToExecutionPlanning(context) {
@@ -72285,7 +72252,6 @@ async function approvePlanResult(cwd, ticketId, options) {
 }
 var init_plan_approval = __esm(() => {
   init_plan_gate();
-  init_review_ledger();
   init_result();
   init_approval_ledger();
   init_job();
@@ -72411,11 +72377,11 @@ var init_delivery_admission = __esm(() => {
 
 // src/execution-plan/delivery-compatibility.ts
 import { spawnSync as spawnSync20 } from "child_process";
-import { createHash as createHash45 } from "crypto";
+import { createHash as createHash44 } from "crypto";
 import { mkdirSync as mkdirSync26, writeFileSync as writeFileSync33 } from "fs";
 import nodePath131 from "path";
 function sha25610(value) {
-  return createHash45("sha256").update(value).digest("hex");
+  return createHash44("sha256").update(value).digest("hex");
 }
 function relativePathspec(projectRoot, path8) {
   const relative = nodePath131.relative(projectRoot, nodePath131.resolve(path8));
@@ -72666,7 +72632,7 @@ __export(exports_delivery_checklist, {
   observeDeliveryChecklist: () => observeDeliveryChecklist,
   hasAdmittedDeliveryChecklist: () => hasAdmittedDeliveryChecklist
 });
-import { createHash as createHash46 } from "crypto";
+import { createHash as createHash45 } from "crypto";
 import { existsSync as existsSync61, readFileSync as readFileSync85 } from "fs";
 import nodePath133 from "path";
 function findingResult(command, code, message, recovery) {
@@ -72678,7 +72644,7 @@ function findingResult(command, code, message, recovery) {
   });
 }
 function sha25611(value) {
-  return createHash46("sha256").update(value).digest("hex");
+  return createHash45("sha256").update(value).digest("hex");
 }
 function designApprovalEnabled2(cwd) {
   const path8 = nodePath133.join(cwd, ".safeword", "config.json");
@@ -73427,7 +73393,7 @@ var init_delivery_checklist2 = __esm(() => {
 });
 
 // src/execution-plan/execution-prerequisite.ts
-import { createHash as createHash47 } from "crypto";
+import { createHash as createHash46 } from "crypto";
 import { existsSync as existsSync62, readFileSync as readFileSync86 } from "fs";
 import nodePath134 from "path";
 function successful(status, achievedIndependence2, inputIdentity, executionPlanArtifact) {
@@ -73490,7 +73456,7 @@ function designDecisionAccepted(input) {
     return true;
   if (!existsSync62(input.implementationPath))
     return false;
-  const planDigest2 = createHash47("sha256").update(readFileSync86(input.implementationPath, "utf8")).digest("hex");
+  const planDigest2 = createHash46("sha256").update(readFileSync86(input.implementationPath, "utf8")).digest("hex");
   return currentDesignDecision(input.ledgerPath, input.ticketId, planDigest2) === "approved";
 }
 function contractedFeature(ticketDirectory, phase) {
@@ -73678,7 +73644,7 @@ function checklistPrerequisite(context, inspection) {
   };
 }
 function digest4(content) {
-  return createHash47("sha256").update(content).digest("hex");
+  return createHash46("sha256").update(content).digest("hex");
 }
 function fileDigest2(path8) {
   return path8 !== undefined && existsSync62(path8) ? digest4(readFileSync86(path8, "utf8")) : "missing";
diff --git a/plugin/runtime/dispatch.js b/plugin/runtime/dispatch.js
index e0335ca1e..51c1ae95b 100644
--- a/plugin/runtime/dispatch.js
+++ b/plugin/runtime/dispatch.js
@@ -1769,7 +1769,7 @@ var CLAUDE_HISTORICAL_CATALOGUE = {
       '.claude/skills/bdd/PLAN_EXECUTION.md':
         '4cf9fd3c73c7f0489d49c4f56af0251ea7ed8effa1415182e970f16fe764f47c',
       '.claude/skills/bdd/PLAN_IMPLEMENTATION.md':
-        'e24265aef799112db05a778ae42e182bd2886f883ceea4b2382949c8ccc7392c',
+        '248b11fd40cd23d7a6ac6f9bb8a6be7cc5d762f882ac3006b3f30ed0603858b8',
       '.claude/skills/bdd/SCENARIOS.md':
         '1e89aa6a46895858cff252d642dd9f7b5853d0fd7dd314aaa75e2ee6046bcddb',
       '.claude/skills/bdd/SKILL.md':
diff --git a/plugin/skills/bdd/PLAN_IMPLEMENTATION.md b/plugin/skills/bdd/PLAN_IMPLEMENTATION.md
index 93ad13d0e..951e7c9a9 100644
--- a/plugin/skills/bdd/PLAN_IMPLEMENTATION.md
+++ b/plugin/skills/bdd/PLAN_IMPLEMENTATION.md
@@ -330,6 +330,10 @@ receipt controls eligibility for approval and phase advancement.
    safeword ticket approve-plan <ticket-id>
    ```
 
+   Use the authenticated phase stamp from step 1; no additional artifact self-stamp
+   is required. Admission still authenticates reviewer provenance and rechecks
+   the exact reviewed plan bytes. Approved warnings are not rejection findings.
+
    Never replace this command with conversational approval or a manual phase
    edit. It rechecks the exact reviewed plan bytes and the current project
    configuration. When `designApprovalGate` is absent or off, it records `not
diff --git a/plugin/templates/skills/bdd/PLAN_IMPLEMENTATION.md b/plugin/templates/skills/bdd/PLAN_IMPLEMENTATION.md
index a9a785214..6619f60ce 100644
--- a/plugin/templates/skills/bdd/PLAN_IMPLEMENTATION.md
+++ b/plugin/templates/skills/bdd/PLAN_IMPLEMENTATION.md
@@ -330,6 +330,10 @@ receipt controls eligibility for approval and phase advancement.
    safeword ticket approve-plan <ticket-id>
    ```
 
+   Use the authenticated phase stamp from step 1; no additional artifact self-stamp
+   is required. Admission still authenticates reviewer provenance and rechecks
+   the exact reviewed plan bytes. Approved warnings are not rejection findings.
+
    Never replace this command with conversational approval or a manual phase
    edit. It rechecks the exact reviewed plan bytes and the current project
    configuration. When `designApprovalGate` is absent or off, it records `not
diff --git a/steps/turn-decisions-into-startable-work.steps.ts b/steps/turn-decisions-into-startable-work.steps.ts
index 9a69f9993..2ad85cdfa 100644
--- a/steps/turn-decisions-into-startable-work.steps.ts
+++ b/steps/turn-decisions-into-startable-work.steps.ts
@@ -35,12 +35,12 @@ interface Proof {
 
 const proofs: Record<string, Proof> = {
   'Implementation Plan review state controls Execution Planning': {
-    expectedTests: 8,
+    expectedTests: 13,
     selector: 'Implementation Plan review admission controls Execution Planning',
     testFile: 'tests/integration/plan-design-approval.test.ts',
   },
   'Review routes preserve their actual provenance': {
-    expectedTests: 8,
+    expectedTests: 13,
     selector: 'Implementation Plan review admission controls Execution Planning',
     testFile: 'tests/integration/plan-design-approval.test.ts',
   },
