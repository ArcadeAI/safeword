# Qualification timeout investigation

Decision: whether the full semantic matrix should use the existing production
background-worker budget after an otherwise matching Claude run times out once.

Options:

1. Retain the 210-second proof limit; Claude stays unqualified. Check whether
   Astra alone permits the promised default routing without bypassing the
   independent-attempt requirement.
2. Run a fresh complete matrix using the actual background-worker budget,
   retaining the failed foreground-budget matrix and every verdict check.
   This is valid only if it matches the production review mode and no accepted
   qualification rule requires the shorter limit.

Research domains and questions:

- Operational latency: did the process hit a native review deadline, a test
  deadline, sleep, cleanup failure, or competing installed-client budgets?
- Deployment behavior: what budget does the real public CLI worker use, and
  can the same native adapter and confirmed-model guard exercise it?
- Evaluation validity: does qualification measure semantic capability or a
  specified response-time promise, and would changing the execution budget
  conceal any failed outcome?
- Authority and recovery: can the default Codex route advance with only Astra
  admitted while the independent Claude route remains unavailable?

Initial evidence: complete Claude run has 62 passes, one native timed_out
failure, zero unfinished cases; Vitest has 63 passes and one failure including
its guard, exit 1, 4809.67 seconds. The failed case is many-mechanical-edits,
210372 ms. Only one distinct Claude executable is present on the pinned
launcher PATH, so splitting the deadline among duplicate clients is not the
cause. Raw log, results and census retain the failure. No admission is generated.
