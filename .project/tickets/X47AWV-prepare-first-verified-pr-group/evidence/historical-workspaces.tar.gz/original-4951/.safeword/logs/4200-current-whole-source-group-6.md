Current PR5 complete unique-source review 15/19. Base 854a376861bc034d65cc81ddfa6a85d0ae55821e; head b722f9a27a1815abcfb08e6f6ca09dc7317efa46. Review actual correctness, authenticated approval, rejection findings and test discrimination. Every unique production source, template, test, step and generator changed in PR5 is supplied across these packets. Byte-identical installed mirrors and compiled bundles are omitted; all five generated surfaces passed at this head. Prior historical acceptance failures remain visible; full current run is in progress. Exactly 33 cases are user-deferred and unverified. This is source review, not native-host or merge approval. Flag only concrete in-scope defects; optional hardening does not block.

diff --git a/steps/keep-plan-reviews-dependencies.steps.ts b/steps/keep-plan-reviews-dependencies.steps.ts
new file mode 100644
index 000000000..e4d3797bf
--- /dev/null
+++ b/steps/keep-plan-reviews-dependencies.steps.ts
@@ -0,0 +1,313 @@
+import { strict as assert } from 'node:assert';
+import { spawnSync } from 'node:child_process';
+import { cpSync, mkdtempSync, readFileSync, rmSync, writeFileSync } from 'node:fs';
+import { tmpdir } from 'node:os';
+import path from 'node:path';
+
+import { After, Given, Then, When } from '@cucumber/cucumber';
+
+import { parsePlanningContract } from '../packages/cli/src/planning/phase-contract.js';
+import { parseDeliveryPlanContract } from '../packages/cli/src/execution-plan/delivery-checklist.js';
+import { extractExecutionPlanReviewRubric } from '../packages/cli/src/review/execution-plan-rubric.js';
+import { extractPlanReviewRubric } from '../packages/cli/src/review/plan-rubric.js';
+import {
+  admitThroughInstalledCli,
+  featureFixture,
+} from '../packages/cli/tests/fixtures/execution-review.js';
+import { cleanupTrustedReviewerDirectories } from '../packages/cli/tests/review-fixtures.js';
+import type { SafewordWorld } from './world.js';
+import { fixtureProject } from './keep-plan-reviews-installed-context.steps.js';
+
+const ticketDirectory = '.project/tickets/ABC123-feature';
+const states = new WeakMap<SafewordWorld, DependencyState>();
+
+interface DependencyState {
+  root: string;
+  runtime: string;
+  implementation: string;
+  execution: string;
+  observed?: readonly string[];
+  canonicalChanged?: boolean;
+}
+
+function executionAdmission(state: DependencyState): string {
+  const result = spawnSync('bun', [path.join(state.runtime, 'runtime/hooks/pre-tool-quality.ts')], {
+    cwd: state.root,
+    encoding: 'utf8',
+    timeout: 30_000,
+    input: JSON.stringify({
+      session_id: 'r9-dependency',
+      tool_name: 'Edit',
+      tool_input: {
+        file_path: path.join(state.root, ticketDirectory, 'ticket.md'),
+        old_string: 'phase: plan-execution',
+        new_string: 'phase: implement',
+      },
+    }),
+    env: {
+      ...process.env,
+      XDG_STATE_HOME: path.join(state.root, '.review-keys'),
+      CLAUDE_PROJECT_DIR: state.root,
+      CLAUDE_PLUGIN_ROOT: state.runtime,
+    },
+  });
+  assert.equal(result.error, undefined, result.error?.message);
+  assert.equal(result.status, 0, `${result.stdout}\n${result.stderr}`);
+  return result.stdout.trim();
+}
+
+function reviewStatuses(state: DependencyState): readonly string[] {
+  return [state.implementation, state.execution].map(id => {
+    const result = spawnSync(
+      'bun',
+      [path.join(state.runtime, 'runtime/cli.js'), 'review', 'status', id, '--json'],
+      {
+        cwd: state.root,
+        encoding: 'utf8',
+        timeout: 30_000,
+        env: {
+          ...process.env,
+          XDG_STATE_HOME: path.join(state.root, '.review-keys'),
+          CLAUDE_PLUGIN_ROOT: state.runtime,
+        },
+      },
+    );
+    assert.equal(result.error, undefined, result.error?.message);
+    const output = JSON.parse(result.stdout);
+    assert.deepEqual(output.errors, [], `${result.stdout}\n${result.stderr}`);
+    assert.ok(output.data.review_identity, 'the receipts must carry owned planning identities');
+    assert.ok(['approved', 'stale'].includes(output.data.status), result.stdout);
+    return output.data.status;
+  });
+}
+
+async function currentReceipts(world: SafewordWorld): Promise<void> {
+  const root = featureFixture();
+  const runtime = mkdtempSync(path.join(tmpdir(), 'safeword-r9-dependency-'));
+  const state = { root, runtime, implementation: '', execution: '' };
+  states.set(world, state);
+  // Semantic dependencies belong to an owned v1 planning ticket, not a legacy plan.
+  const owned = fixtureProject();
+  try {
+    for (const file of ['ticket.md', 'spec.md', 'impl-plan.md']) {
+      const content = readFileSync(
+        path.join(owned, '.project/tickets/CTX123-current-context', file),
+        'utf8',
+      )
+        .replaceAll('CTX123', 'ABC123')
+        .replaceAll('features/current-context.feature', 'features/feature.feature')
+        .replace('phase: plan-implementation', 'phase: plan-execution');
+      writeFileSync(path.join(root, ticketDirectory, file), content);
+    }
+    writeFileSync(
+      path.join(root, 'features/feature.feature'),
+      readFileSync(path.join(owned, 'features/current-context.feature'), 'utf8'),
+    );
+  } finally {
+    rmSync(owned, { recursive: true, force: true });
+  }
+  cpSync(path.resolve(import.meta.dirname, '../plugin'), runtime, { recursive: true });
+  // Dispatch and currency reconstruction use the same installed distribution.
+  await admitThroughInstalledCli(async (args, options) => {
+    const reviewed = spawnSync('bun', [path.join(runtime, 'runtime/cli.js'), ...args], {
+      cwd: options.cwd,
+      encoding: 'utf8',
+      timeout: 60_000,
+      env: {
+        ...process.env,
+        ...options.env,
+        PATH: `${options.env.PATH}:${process.env.PATH ?? ''}`,
+        XDG_STATE_HOME: path.join(root, '.review-keys'),
+        CLAUDE_PLUGIN_ROOT: runtime,
+      },
+    });
+    assert.equal(reviewed.error, undefined, reviewed.error?.message);
+    return {
+      exitCode: reviewed.status ?? 1,
+      stdout: reviewed.stdout,
+      stderr: reviewed.stderr,
+    };
+  }, root);
+  const ledger = readFileSync(path.join(root, '.project/skill-invocations.log'), 'utf8');
+  for (const [field, kind] of [
+    ['implementation', 'plan-implementation'],
+    ['execution', 'plan-execution'],
+  ] as const) {
+    const row = ledger.split('\n').find(line => line.includes(`:phase@${kind} `));
+    assert.ok(row);
+    const id = /review-id:(\S+)/u.exec(row)?.[1];
+    assert.ok(id);
+    state[field] = id;
+  }
+  assert.deepEqual(
+    reviewStatuses(state),
+    ['approved', 'approved'],
+    'both authentic receipts must start current',
+  );
+  assert.equal(
+    executionAdmission(state),
+    '',
+    'the current authenticated receipts must admit coding',
+  );
+}
+
+Given(
+  'both plans have current review receipts',
+  { timeout: 60_000 },
+  async function (this: SafewordWorld) {
+    await currentReceipts(this);
+  },
+);
+
+Given(
+  'current plan-review receipts and a canonical Execution Planning contract that declares accepted Implementation Plan changes invalidate both plan reviews',
+  { timeout: 60_000 },
+  async function (this: SafewordWorld) {
+    await currentReceipts(this);
+    const state = states.get(this);
+    assert.ok(state);
+    const contract = readFileSync(
+      path.join(state.runtime, 'templates/skills/bdd/PLAN_EXECUTION.md'),
+      'utf8',
+    );
+    const parsed = parsePlanningContract('plan-execution', contract);
+    assert.equal(parsed.phase, 'plan-execution');
+    assert.ok('upstreamImplementationInvalidation' in parsed);
+    assert.equal(parsed.upstreamImplementationInvalidation, 'both_plan_reviews');
+  },
+);
+
+function changeCanonicalContract(state: DependencyState, implementation: boolean): void {
+  const file = implementation ? 'PLAN_IMPLEMENTATION.md' : 'PLAN_EXECUTION.md';
+  const before = '- **Purpose:**';
+  const after = '- **Purpose:**   ';
+  const extract = implementation ? extractPlanReviewRubric : extractExecutionPlanReviewRubric;
+  // Change the actual canonical and installed authoring files, leaving the
+  // previously approved runtime and reviewer copy untouched.
+  for (const directory of ['templates/skills/bdd', 'skills/bdd']) {
+    const contract = path.join(state.runtime, directory, file);
+    const content = readFileSync(contract, 'utf8');
+    assert.ok(content.includes(before), `the ${file} contract must declare its purpose`);
+    const changed = content.replace(before, () => after);
+    assert.notEqual(extract(changed), extract(content), 'the exact bounded contract must change');
+    writeFileSync(contract, changed);
+  }
+  state.canonicalChanged = true;
+}
+
+function changeFile(
+  state: DependencyState,
+  file: string,
+  change: (content: string) => string,
+): void {
+  const absolute = path.join(state.root, file);
+  const before = readFileSync(absolute, 'utf8');
+  const after = change(before);
+  assert.notEqual(after, before, `the ${file} mutation must actually change bytes`);
+  writeFileSync(absolute, after);
+}
+
+const mutations: Record<string, (state: DependencyState) => void> = {
+  'accepted behavior': state =>
+    changeFile(state, 'features/feature.feature', content =>
+      content.replace(
+        'Then the current context reaches review',
+        'Then changed acceptance reaches review',
+      ),
+    ),
+  'accepted scope': state =>
+    changeFile(state, `${ticketDirectory}/ticket.md`, content =>
+      content.replace(
+        'scope: preserve authenticated approval',
+        'scope: change accepted approval boundary',
+      ),
+    ),
+  'canonical Implementation Planning contract bytes change': state =>
+    changeCanonicalContract(state, true),
+  'only canonical Execution Planning contract bytes change': state =>
+    changeCanonicalContract(state, false),
+  "only the accepted Implementation Plan's formatting bytes": state =>
+    changeFile(state, `${ticketDirectory}/impl-plan.md`, content => `${content}\n`),
+  'only the Execution Plan bytes, including formatting-only bytes outside normalized checklist progress cells':
+    state => changeFile(state, `${ticketDirectory}/execution-plan.md`, content => `${content}\n`),
+  "only whitespace inside a reviewed Execution Plan checklist row's normalized progress cells":
+    state =>
+      changeFile(state, `${ticketDirectory}/execution-plan.md`, content =>
+        content.replace('| open | missing |  |  |', '|   open   |   missing   |   |   |'),
+      ),
+  "only ordinary progress in a reviewed Execution Plan checklist row's Disposition, Evidence class, Revision, or final evidence cell":
+    state =>
+      changeFile(state, `${ticketDirectory}/execution-plan.md`, content =>
+        content.replace(
+          '| open | missing |  |  |',
+          '| complete | current_revision_real_boundary | fixture-revision | receipt:fixture-progress |',
+        ),
+      ),
+};
+
+for (const [description, mutate] of Object.entries(mutations)) {
+  When(`${description} occurs`, function (this: SafewordWorld) {
+    const state = states.get(this);
+    assert.ok(state);
+    mutate(state);
+    // A progress locator is fixture input, not a claim of authenticated delivery proof.
+    const parsed = parseDeliveryPlanContract(
+      readFileSync(path.join(state.root, ticketDirectory, 'execution-plan.md'), 'utf8'),
+    );
+    assert.ok(parsed.ok, 'each mutation must preserve a structurally valid Delivery Checklist');
+    state.observed = reviewStatuses(state);
+  });
+}
+
+When('the accepted Implementation Plan changes semantically', function (this: SafewordWorld) {
+  const state = states.get(this);
+  assert.ok(state);
+  changeFile(state, `${ticketDirectory}/impl-plan.md`, content =>
+    content.replace(
+      'Use the current review receipt to guard the transition.',
+      'Use a different authenticated review receipt to guard the transition.',
+    ),
+  );
+  state.observed = reviewStatuses(state);
+});
+
+const expectedStatuses: Record<string, readonly string[]> = {
+  'both plan reviews are invalidated': ['stale', 'stale'],
+  'only the Execution Plan review is invalidated': ['approved', 'stale'],
+  'only the Implementation Plan review is invalidated and the Execution Plan review remains current':
+    ['stale', 'approved'],
+  'neither plan review is invalidated': ['approved', 'approved'],
+};
+
+Then(
+  /^(both plan reviews are invalidated|only the Execution Plan review is invalidated|only the Implementation Plan review is invalidated and the Execution Plan review remains current|neither plan review is invalidated)$/,
+  function (this: SafewordWorld, result: string) {
+    const state = states.get(this);
+    assert.ok(state?.observed);
+    assert.deepEqual(state.observed, expectedStatuses[result], result);
+    if (state.canonicalChanged) {
+      const output = executionAdmission(state);
+      assert.notEqual(output, '', 'a changed canonical contract must not admit coding');
+      const denied = JSON.parse(output);
+      assert.equal(denied.hookSpecificOutput?.permissionDecision, 'deny', output);
+      const requiredApproval =
+        state.observed[0] === 'stale'
+          ? 'An accepted implementation approach is required before execution.'
+          : 'An admitted Delivery Checklist is required before execution.';
+      assert.ok(
+        denied.hookSpecificOutput?.permissionDecisionReason?.startsWith(requiredApproval),
+        output,
+      );
+    }
+  },
+);
+
+After(function (this: SafewordWorld) {
+  const state = states.get(this);
+  if (state) {
+    rmSync(state.root, { recursive: true, force: true });
+    rmSync(state.runtime, { recursive: true, force: true });
+    cleanupTrustedReviewerDirectories();
+  }
+  states.delete(this);
+});
diff --git a/steps/keep-plan-reviews-disposition.steps.ts b/steps/keep-plan-reviews-disposition.steps.ts
new file mode 100644
index 000000000..c65f9a9e7
--- /dev/null
+++ b/steps/keep-plan-reviews-disposition.steps.ts
@@ -0,0 +1,270 @@
+import { strict as assert } from 'node:assert';
+import { mkdirSync, readFileSync, rmSync, writeFileSync } from 'node:fs';
+import path from 'node:path';
+
+import { After, Given, Status, Then, When } from '@cucumber/cucumber';
+
+import { prepareReviewPacket } from '../packages/cli/src/review/packet.js';
+import { acceptedBoundaryDigest } from '../packages/cli/src/review/planning-accepted-boundary.js';
+import { planningContractCases } from '../packages/cli/tests/fixtures/planning-contracts-eval.js';
+import {
+  createReviewedDispositionProject,
+  target,
+} from '../packages/cli/tests/fixtures/planning-disposition.js';
+import {
+  assertPlanningEval,
+  runPlanningEval,
+  selectPlanningEval,
+} from './support/planning-eval.js';
+import type { SafewordWorld } from './world.js';
+
+const suggestion = 'Consider adding optional multi-region failover.';
+const planTarget = target.replace('spec.md', 'impl-plan.md');
+interface DispositionState {
+  project: Awaited<ReturnType<typeof createReviewedDispositionProject>>;
+  plan: string;
+  reviewId: string;
+  acceptance?: { ticket: string; boundaryDigest: string };
+}
+const states = new WeakMap<SafewordWorld, DispositionState>();
+const roots = new WeakMap<SafewordWorld, string[]>();
+
+export async function prepareRecordedSuggestion(world: SafewordWorld): Promise<void> {
+  const owned: string[] = [];
+  roots.set(world, owned);
+  const project = await createReviewedDispositionProject(owned, suggestion);
+  const complete = planningContractCases.find(item => item.id === 'r12-complete-scope-context');
+  assert.ok(complete);
+  writeFileSync(
+    project.ticketPath,
+    `---
+id: DIS123
+type: feature
+phase: plan-implementation
+status: in_progress
+product_plan_contract: v1
+scope:
+- require explicit user authorization before account changes
+out_of_scope:
+- automatic account migration
+- multi-region failover
+done_when: authorized changes succeed and denied changes do not mutate
+phase_anchors:
+- scenario-gate: features/manual-change.feature
+---
+`,
+  );
+  writeFileSync(
+    path.join(project.root, target),
+    `# Product Plan
+
+<!-- safeword:product-plan-contract:v1 -->
+
+## Product Bet
+- **Expected outcome:** Builders authorize one manual account change.
+- **Persona outcome inventory:** Builder sees success as an authorized change; refusal as no mutation; failure as a named error with no mutation; approval as explicit consent; trust as an owner-named receipt; recovery as obtaining fresh consent and retrying the same target.
+- **Known facts:** Account changes require explicit user authorization.
+- **Assumptions:** The existing consent-token API can enforce it.
+- **Unresolved product decisions:** none
+- **Success threshold:** Authorized changes succeed; denied changes leave the account intact.
+- **Project non-goals:** No background account mutation or multi-region failover.
+
+## Jobs To Be Done
+### approval.BU1 — Authorize a manual change
+**Persona:** Builder (BU)
+#### approval.BU1.R1 — Preserve consent
+An owner-authorized token permits one target account change. Absent, expired or mismatched consent permits no mutation. A transient failure permits retry without mutation.
+
+## Shape
+### M1 — Safe manual approval
+- **Outcome:** One owner-authorized target account changes.
+- **Non-goals:** Batched account changes and multi-region failover.
+
+## Surfaces
+Affected:
+- Safeword CLI
+`,
+  );
+  mkdirSync(path.join(project.root, 'features'), { recursive: true });
+  writeFileSync(
+    path.join(project.root, 'features/manual-change.feature'),
+    `@approval.BU1.R1 @surface.safeword-cli
+Feature: Manual authorized account changes
+Scenario: Authorized change
+  Given valid consent for the requesting owner and target account
+  When a manual account change is requested
+  Then one authorized account changes
+Scenario: Denied change
+  Given absent expired or mismatched consent
+  When a manual account change is requested
+  Then no account mutation occurs
+Scenario: Retry a transient failure
+  Given a transient endpoint failure
+  When the same manual change is retried with valid consent
+  Then the retry succeeds without an earlier mutation
+`,
+  );
+  const plan = `# Implementation Plan
+
+## Approach
+${complete.reviewed_plan}
+
+## Architecture applicability
+skip: No durable architecture record applies to this existing endpoint.
+
+## Data applicability
+skip: Existing account schema and consent-token contract stay unchanged; no new data shape or migration is introduced.
+
+## Measurement applicability
+skip: The Product Plan makes no quantitative promise.
+`;
+  writeFileSync(path.join(project.root, planTarget), plan);
+  const reviewed = await project.run(['review', 'run', 'plan-implementation', planTarget]);
+  assert.equal(reviewed.exitCode, 0, `${reviewed.stdout}\n${reviewed.stderr}`);
+  const data = JSON.parse(reviewed.stdout).data;
+  assert.equal(data.status, 'approved');
+  assert.deepEqual(data.reviewer_output.findings, [{ severity: 'warning', message: suggestion }]);
+  states.set(world, { project, plan, reviewId: data.review_id });
+}
+
+export function recordedSuggestion(world: SafewordWorld): DispositionState {
+  const state = states.get(world);
+  assert.ok(state);
+  return state;
+}
+
+Given(
+  'a nonblocking reviewer suggestion for a useful capability outside the accepted boundary is recorded',
+  { timeout: 60_000 },
+  async function (this: SafewordWorld) {
+    await prepareRecordedSuggestion(this);
+  },
+);
+
+When('the user declines it', function (this: SafewordWorld) {
+  const state = states.get(this);
+  assert.ok(state);
+  const result = state.project.terminal('y', state.reviewId);
+  assert.equal(result.status, 0, `${result.stdout}\n${result.stderr}`);
+  assert.match(result.stdout, /"status":"recorded"/u);
+});
+
+When('the user accepts it', function (this: SafewordWorld) {
+  const state = recordedSuggestion(this);
+  const { project } = state;
+  const specPath = path.join(project.root, target);
+  const before = acceptedBoundaryDigest(
+    readFileSync(project.ticketPath, 'utf8'),
+    readFileSync(specPath, 'utf8'),
+  );
+  // Synthetic explicit user direction, recorded through the existing authoring
+  // workflow. This is not an identity-authenticated scope-writing command.
+  const ticket =
+    readFileSync(project.ticketPath, 'utf8')
+      .replace(
+        '- require explicit user authorization before account changes\n',
+        '- require explicit user authorization before account changes\n- allow owner-requested manual multi-region failover using the existing consent guard\n',
+      )
+      .replace('- multi-region failover\n', '') +
+    `\n## User-accepted expansion\n\nThe user explicitly accepts the optional manual multi-region failover suggested in authenticated review ${state.reviewId}, finding 1: ${suggestion} Automatic failover and background mutation remain excluded. Record this boundary before correcting the Implementation Plan.\n`;
+  writeFileSync(project.ticketPath, ticket);
+  const spec =
+    readFileSync(specPath, 'utf8')
+      .replace(
+        'No background account mutation or multi-region failover.',
+        'No background account mutation or automatic failover.',
+      )
+      .replace(
+        'Batched account changes and multi-region failover.',
+        'Batched account changes and automatic failover.',
+      ) +
+    `\n## Accepted manual recovery boundary\n\nThe user may explicitly retry a pre-commit failure against a secondary region using the same owner/target consent guard. A successful retry produces one mutation and an owner-named receipt. Denial or another pre-commit failure produces no mutation. An uncertain post-commit result permits no automatic retry. This is user-requested manual multi-region failover; automatic failover stays excluded.\n`;
+  writeFileSync(specPath, spec);
+  const boundaryDigest = acceptedBoundaryDigest(ticket, spec);
+  assert.notEqual(boundaryDigest, before);
+  assert.equal(
+    readFileSync(path.join(project.root, planTarget), 'utf8'),
+    state.plan,
+    'Record acceptance and change the boundary before plan bytes.',
+  );
+  state.acceptance = { ticket, boundaryDigest };
+});
+
+Then(
+  'the expansion is recorded as user-accepted before the plan is corrected and re-reviewed',
+  { timeout: 240_000 },
+  async function (this: SafewordWorld) {
+    const state = recordedSuggestion(this);
+    assert.ok(state.acceptance);
+    const previous = await state.project.run(['review', 'status', state.reviewId]);
+    assert.equal(
+      JSON.parse(previous.stdout).data.status,
+      'stale',
+      'The boundary edit invalidates the previous approval before plan correction.',
+    );
+    const plan = `${state.plan}\n## User-accepted manual regional recovery\n\nUse the existing manual endpoint and authoritative account/consent store for both regions; regional routing does not create an independent consent authority or a second account copy. The caller explicitly selects primary or secondary through the CLI region option. Both routes enforce the same owner/target/expiry guard before the single atomic account mutation. The trusted session owner label supplies the receipt; no credential or caller-supplied owner label is printed.\n\nA pre-commit failure leaves the account and consent unconsumed so the owner can explicitly retry the same target through the secondary region. A successful retry consumes consent and changes one account once. An uncertain post-commit outcome must not claim no mutation or confirmed success, and permits no automatic retry or failover.\n\nProof invokes the real CLI against primary pre-commit failure, verifies unchanged authoritative state, explicitly retries the same target in secondary with valid consent, and verifies one mutation plus the owner-named receipt. Both region routes also prove denied, expired and mismatched consent leaves state unchanged and returns a nonzero CLI exit. Rollout keeps regional routing off until those proofs pass; rollback disables the new region option while retaining the consent guard. Automatic failover, background mutation and account migration remain excluded.\n`;
+    writeFileSync(path.join(state.project.root, planTarget), plan);
+    const packet = prepareReviewPacket(state.project.root, 'plan-implementation', [
+      planTarget,
+    ]).packet;
+    assert.equal(
+      packet.review_disposition_context,
+      undefined,
+      'Acceptance is the authoritative scope edit, not a fabricated disposition.',
+    );
+    selectPlanningEval(this, 'r14-user-accepted-expansion', {
+      context: JSON.stringify(packet),
+      reviewed_plan: plan,
+    });
+    runPlanningEval(this);
+    assertPlanningEval(this, 'approve');
+    assert.equal(readFileSync(state.project.ticketPath, 'utf8'), state.acceptance.ticket);
+    assert.equal(readFileSync(path.join(state.project.root, planTarget), 'utf8'), plan);
+    assert.equal(
+      acceptedBoundaryDigest(
+        state.acceptance.ticket,
+        readFileSync(path.join(state.project.root, target), 'utf8'),
+      ),
+      state.acceptance.boundaryDigest,
+    );
+  },
+);
+
+Then(
+  'the unchanged plan is re-reviewed against the accepted boundary and the decline remains recorded',
+  { timeout: 240_000 },
+  async function (this: SafewordWorld) {
+    const state = states.get(this);
+    assert.ok(state);
+    const { project, plan, reviewId } = state;
+    const ticket = readFileSync(project.ticketPath, 'utf8');
+    const status = await project.run(['review', 'status', reviewId]);
+    assert.equal(JSON.parse(status.stdout).data.status, 'stale');
+    const packet = prepareReviewPacket(project.root, 'plan-implementation', [planTarget]).packet;
+    const record = packet.review_disposition_context?.records[0];
+    assert.ok(record);
+    assert.equal(record.review_id, reviewId);
+    assert.equal(record.message, suggestion);
+    assert.equal(record.disposition, 'declined');
+    assert.equal(record.boundary_status, 'current');
+    assert.equal(readFileSync(path.join(project.root, planTarget), 'utf8'), plan);
+    selectPlanningEval(this, 'r14-declined-strengthening', {
+      context: JSON.stringify(packet),
+      reviewed_plan: plan,
+    });
+    runPlanningEval(this);
+    assertPlanningEval(this, 'approve', undefined, /declin|failover/iu);
+    assert.equal(readFileSync(path.join(project.root, planTarget), 'utf8'), plan);
+    assert.equal(readFileSync(project.ticketPath, 'utf8'), ticket);
+  },
+);
+
+After(function (this: SafewordWorld, scenario) {
+  if (scenario.result?.status === Status.FAILED) {
+    console.error(`Retained disposition fixture: ${(roots.get(this) ?? []).join(', ')}`);
+    return;
+  }
+  for (const root of roots.get(this) ?? []) rmSync(root, { recursive: true, force: true });
+  roots.delete(this);
+  states.delete(this);
+});
diff --git a/steps/keep-plan-reviews-fallback-order.steps.ts b/steps/keep-plan-reviews-fallback-order.steps.ts
new file mode 100644
index 000000000..61194b519
--- /dev/null
+++ b/steps/keep-plan-reviews-fallback-order.steps.ts
@@ -0,0 +1,233 @@
+import { strict as assert } from 'node:assert';
+import { readFileSync, writeFileSync } from 'node:fs';
+import path from 'node:path';
+
+import { Given, Then, When } from '@cucumber/cucumber';
+
+import { installedReviewCli } from '../packages/cli/tests/fixtures/execution-review.js';
+import { reviewerScript } from '../packages/cli/tests/fixtures/planning-reviewers.js';
+import { coordinate, prepare } from './keep-plan-reviews-independence.steps.js';
+import type { SafewordWorld } from './world.js';
+
+type Tier =
+  'same-agent headless review' | 'host-reported fresh-context review' | 'bounded self-review';
+type OrderState = Awaited<ReturnType<typeof prepare>> & {
+  nextTier: Tier;
+  launchLog: string;
+  reviewId?: string;
+  dispatchId?: string;
+};
+const states = new WeakMap<SafewordWorld, OrderState>();
+
+Given(
+  /^every route before (same-agent headless review|host-reported fresh-context review|bounded self-review) is configured to return a typed failure when attempted$/,
+  { timeout: 120_000 },
+  async function (this: SafewordWorld, nextTier: Tier) {
+    const state = await prepare(this, true);
+    const directory = path.dirname(state.marker);
+    const launchLog = path.join(directory, 'launch-order');
+    states.set(this, Object.assign(state, { nextTier, launchLog }));
+    const configPath = path.join(state.root, '.safeword/config.json');
+    const config = JSON.parse(readFileSync(configPath, 'utf8'));
+    writeFileSync(
+      configPath,
+      JSON.stringify({
+        ...config,
+        crossAgentReviewRoutes: {
+          claude: [{ reviewer: 'codex', model: 'gpt-6.1-sol' }, { reviewer: 'claude' }],
+        },
+      }),
+    );
+    for (const agent of ['codex', 'claude'] as const) {
+      const marker = agent === 'codex' ? state.marker : path.join(directory, 'headless-invoked');
+      const script = reviewerScript(
+        agent,
+        marker,
+        path.join(directory, `${agent}-packet.json`),
+        agent === 'codex',
+        true,
+      );
+      const launch = `writeFileSync(${JSON.stringify(marker)}, 'yes');`;
+      const observed = script.replace(
+        launch,
+        `${launch}\nrequire('node:fs').appendFileSync(${JSON.stringify(launchLog)}, '${agent}\\n');`,
+      );
+      assert.notEqual(observed, script);
+      const producer =
+        agent === 'claude' && nextTier !== 'same-agent headless review'
+          ? observed.replace(
+              'function reviewOutput(packet)',
+              'process.exit(7);\nfunction reviewOutput(packet)',
+            )
+          : observed;
+      writeFileSync(path.join(directory, agent), producer, { mode: 0o755 });
+    }
+  },
+);
+
+async function continueHost(
+  state: OrderState,
+  tier: 'fresh-context' | 'self-review',
+  failure: boolean,
+) {
+  assert.ok(state.result?.data.continuation);
+  const reviewId = state.result.data.review_id;
+  const dispatchId = state.result.data.continuation.packet.dispatch_id;
+  assert.equal(state.result.data.continuation.tier, tier);
+  if (!failure)
+    writeFileSync(
+      path.join(state.root, 'host-review.json'),
+      JSON.stringify({
+        schema_version: 1,
+        dispatch_id: dispatchId,
+        reviewer_agent: 'claude',
+        verdict: 'approve',
+        summary: `Approved by host-reported ${tier}.`,
+        findings: [],
+        evidence_records: { schema_version: 1, records: [] },
+      }),
+    );
+  const result = await installedReviewCli(state.root)(
+    [
+      'review',
+      'continue',
+      reviewId,
+      '--tier',
+      tier,
+      ...(failure ? ['--failure', 'process_failed'] : ['--output', 'host-review.json']),
+      '--offline',
+      '--json',
+      '--cwd',
+      state.root,
+    ],
+    { cwd: state.root, env: state.env },
+  );
+  assert.equal(result.exitCode, failure ? 2 : 0, result.stdout);
+  state.result = JSON.parse(result.stdout);
+  assert.ok(state.result?.data.continuation);
+  assert.equal(state.result.data.review_id, reviewId);
+  assert.equal(state.result.data.continuation.packet.dispatch_id, dispatchId);
+  state.reviewId = reviewId;
+  state.dispatchId = dispatchId;
+}
+
+async function refusePrematureSelfReview(state: OrderState) {
+  assert.ok(state.result?.data.continuation);
+  const reviewId = state.result.data.review_id;
+  const dispatchId = state.result.data.continuation.packet.dispatch_id;
+  writeFileSync(
+    path.join(state.root, 'premature-review.json'),
+    JSON.stringify({
+      schema_version: 1,
+      dispatch_id: dispatchId,
+      reviewer_agent: 'claude',
+      verdict: 'approve',
+      summary: 'A valid output cannot bypass the pending fresh-context tier.',
+      findings: [],
+      evidence_records: { schema_version: 1, records: [] },
+    }),
+  );
+  const cli = installedReviewCli(state.root);
+  const refused = await cli(
+    [
+      'review',
+      'continue',
+      reviewId,
+      '--tier',
+      'self-review',
+      '--output',
+      'premature-review.json',
+      '--offline',
+      '--json',
+      '--cwd',
+      state.root,
+    ],
+    { cwd: state.root, env: state.env },
+  );
+  assert.equal(refused.exitCode, 1, refused.stdout);
+  const result = JSON.parse(refused.stdout);
+  assert.ok(
+    result.errors.some(
+      (error: { code: string }) => error.code === 'REVIEW_CONTINUATION_TIER_INVALID',
+    ),
+  );
+  const current = await cli(['review', 'status', reviewId, '--json', '--cwd', state.root], {
+    cwd: state.root,
+    env: state.env,
+  });
+  const data = JSON.parse(current.stdout).data;
+  assert.equal(data.status, 'continuation_required');
+  assert.equal(data.continuation.tier, 'fresh-context');
+  assert.equal(data.continuation.packet.dispatch_id, dispatchId);
+  assert.deepEqual(data.continuation_attempts ?? [], []);
+}
+
+When(
+  'review recovery selects the next permitted route',
+  { timeout: 120_000 },
+  async function (this: SafewordWorld) {
+    const state = states.get(this);
+    assert.ok(state);
+    const headless = state.nextTier === 'same-agent headless review';
+    await coordinate(state, 'claude', headless ? 'approved' : 'continuation_required');
+    if (headless) return;
+    await refusePrematureSelfReview(state);
+    if (state.nextTier === 'bounded self-review') await continueHost(state, 'fresh-context', true);
+    await continueHost(
+      state,
+      state.nextTier === 'bounded self-review' ? 'self-review' : 'fresh-context',
+      false,
+    );
+  },
+);
+
+Then(
+  /^review recovery selects and attempts (same-agent headless review|host-reported fresh-context review|bounded self-review), and no later tier is attempted first$/,
+  async function (this: SafewordWorld, nextTier: Tier) {
+    const state = states.get(this);
+    assert.ok(state?.result);
+    assert.equal(state.nextTier, nextTier);
+    const self = nextTier === 'bounded self-review';
+    const headless = nextTier === 'same-agent headless review';
+    const launches = readFileSync(state.launchLog, 'utf8').trim().split('\n');
+    // Trusted candidate retries belong to the same tier; interleaving tiers still fails.
+    const tiers = launches.filter((launch, index) => launch !== launches[index - 1]);
+    assert.deepEqual(tiers, ['codex', 'claude']);
+    assert.deepEqual(state.result.data.review_routes, [
+      {
+        reviewer: 'codex',
+        model: 'gpt-6.1-sol',
+        independence: 'cross-agent',
+        status: 'attempted',
+        failure: 'process_failed',
+      },
+      {
+        reviewer: 'claude',
+        independence: 'degraded',
+        status: 'attempted',
+        ...(headless ? {} : { failure: 'process_failed' }),
+      },
+    ]);
+    assert.equal(state.result.data.status, 'approved');
+    assert.equal(state.result.data.actual_reviewer, 'claude');
+    assert.equal(state.result.data.independence, 'reduced');
+    assert.deepEqual(
+      state.result.data.continuation_attempts ?? [],
+      self ? [{ tier: 'fresh-context', failure: 'process_failed' }] : [],
+    );
+    if (headless) assert.equal(state.result.data.continuation, undefined);
+    else {
+      assert.equal(state.result.data.continuation?.tier, self ? 'self-review' : 'fresh-context');
+      assert.equal(state.result.data.continuation?.packet.dispatch_id, state.dispatchId);
+    }
+    const receipt = await installedReviewCli(state.root)(
+      ['review', 'status', state.result.data.review_id, '--json', '--cwd', state.root],
+      { cwd: state.root, env: state.env },
+    );
+    assert.equal(receipt.exitCode, 0, receipt.stdout);
+    const current = JSON.parse(receipt.stdout).data;
+    assert.equal(current.status, 'approved');
+    assert.equal(current.review_id, state.result.data.review_id);
+    assert.deepEqual(current.review_routes, state.result.data.review_routes);
+  },
+);
diff --git a/steps/keep-plan-reviews-finding-authority.steps.ts b/steps/keep-plan-reviews-finding-authority.steps.ts
new file mode 100644
index 000000000..166f5d678
--- /dev/null
+++ b/steps/keep-plan-reviews-finding-authority.steps.ts
@@ -0,0 +1,93 @@
+import { strict as assert } from 'node:assert';
+
+import { Given, Then, When } from '@cucumber/cucumber';
+
+import {
+  assertPlanningEval,
+  runPlanningEval,
+  selectPlanningEval,
+} from './support/planning-eval.js';
+import type { SafewordWorld } from './world.js';
+
+const cases = {
+  'a requirement accepted upstream is unmet': 'r11-unmet-accepted-requirement',
+  'an optional resilience improvement outside accepted scope': 'r11-optional-architecture',
+  'a replacement architecture selected only by the reviewer': 'r11-optional-architecture',
+  'a uniquely determined correction under an accepted decision':
+    'r11-uniquely-determined-correction',
+} as const;
+
+Given(
+  /^a recorded planning-review finding of (.+)$/,
+  function (this: SafewordWorld, finding: keyof typeof cases) {
+    const caseId = cases[finding];
+    assert.ok(caseId, `Unknown finding authority case: ${finding}`);
+    const evaluationCase = selectPlanningEval(this, caseId);
+    if (caseId !== 'r11-optional-architecture') {
+      assert.match(evaluationCase.accepted_boundary, /manual\.BU1\.R1/u);
+      assert.equal(evaluationCase.expected_verdict, 'request_changes');
+      assert.match(
+        evaluationCase.reviewed_plan,
+        caseId === 'r11-unmet-accepted-requirement'
+          ? /without checking consent/u
+          : /after the account write/u,
+      );
+      assert.doesNotMatch(
+        evaluationCase.reviewed_plan,
+        /checks a consent token linked to the requesting user and target account before any write/u,
+      );
+      return;
+    }
+    assert.match(
+      evaluationCase.context,
+      /Reviewer preference: replace the consent-token API with a new event bus for resilience/u,
+    );
+    assert.match(evaluationCase.reviewed_plan, /consent-token API/u);
+    assert.match(evaluationCase.accepted_boundary, /explicit user authorization/u);
+    assert.equal(evaluationCase.expected_verdict, 'approve');
+  },
+);
+
+When(
+  'a judged semantic reviewer evaluation applies the canonical finding-authority rubric against the accepted contract and scope',
+  { timeout: 240_000 },
+  function (this: SafewordWorld) {
+    runPlanningEval(this);
+  },
+);
+
+Then(
+  'the suggestion remains nonblocking until the user accepts it',
+  function (this: SafewordWorld) {
+    assertPlanningEval(this, 'approve', undefined, /event[ -]?bus/iu);
+  },
+);
+
+Then(
+  'the review blocks with the violated Rule, defect, unresolved choice, and constraints named',
+  function (this: SafewordWorld) {
+    assertPlanningEval(
+      this,
+      'request_changes',
+      /(?=.*manual\.BU1\.R1)(?=.*(?:authoriz|consent|token))(?=.*(?:before|unchecked|without))(?=.*(?:user|owner))(?=.*account)(?=.*(?:unresolved|undecided|binding|bound|tie|link))(?=.*(?:migration|background|existing.{0,20}(?:token|API)))/isu,
+    );
+  },
+);
+
+Then(
+  'the review blocks with the uniquely determined correction named',
+  function (this: SafewordWorld) {
+    assertPlanningEval(
+      this,
+      'request_changes',
+      /(?=.*(?:consent|token|authoriz))(?=.*after)(?=.*before)(?=.*(?:write|mutation))/isu,
+    );
+  },
+);
+
+Then(
+  'the reviewer-authored decision is recorded as a nonblocking suggestion and the review does not block on it',
+  function (this: SafewordWorld) {
+    assertPlanningEval(this, 'approve', undefined, /event[ -]?bus/iu);
+  },
+);
diff --git a/steps/keep-plan-reviews-guidance.steps.ts b/steps/keep-plan-reviews-guidance.steps.ts
new file mode 100644
index 000000000..57e848e21
--- /dev/null
+++ b/steps/keep-plan-reviews-guidance.steps.ts
@@ -0,0 +1,103 @@
+import { strict as assert } from 'node:assert';
+
+import { Given, Then, When } from '@cucumber/cucumber';
+
+import {
+  assertPlanningEval,
+  runPlanningEval,
+  selectPlanningEval,
+} from './support/planning-eval.js';
+import type { SafewordWorld } from './world.js';
+
+Given(
+  'a recorded architecture, data, testing, domain, or research suggestion proposes a decision required by accepted behavior',
+  function (this: SafewordWorld) {
+    const selected = selectPlanningEval(this, 'r15-required-proof-decision');
+    assert.equal(selected.kind, 'plan-execution');
+    assert.match(selected.accepted_boundary, /CLI denial must return a nonzero exit code/u);
+    assert.match(selected.reviewed_plan, /Execution-owned proof decision/u);
+    assert.match(selected.reviewed_plan, /invoke the actual CLI against the real endpoint/u);
+  },
+);
+
+Given(
+  'a recorded architecture, data, testing, domain, or research suggestion proposes a capability outside accepted behavior whose exclusion would change the accepted outcome',
+  function (this: SafewordWorld) {
+    const selected = selectPlanningEval(this, 'r15-consequential-scope-choice');
+    assert.equal(selected.kind, 'plan-implementation');
+    assert.match(
+      selected.accepted_boundary,
+      /excluded a new target-owner authorization capability/u,
+    );
+    assert.match(selected.context, /never the target owner/u);
+    assert.match(selected.reviewed_plan, /User-owned scope choice remains pending/u);
+    assert.match(selected.reviewed_plan, /not selected as architecture, a delivery task/u);
+  },
+);
+
+Given(
+  'a recorded architecture, data, testing, domain, or research suggestion proposes an unrelated capability whose exclusion does not change the accepted outcome',
+  function (this: SafewordWorld) {
+    const selected = selectPlanningEval(this, 'r15-guidance-candidate');
+    assert.match(selected.context, /Architecture guide suggests automatic migration/u);
+    assert.match(
+      selected.context,
+      /Excluding it does not change the accepted manual-authorization outcome/u,
+    );
+    assert.match(
+      selected.accepted_boundary,
+      /require explicit user authorization before account changes/u,
+    );
+    assert.doesNotMatch(selected.reviewed_plan, /automatic migration/u);
+  },
+);
+
+When(
+  'a judged semantic reviewer evaluation applies the canonical accepted-boundary guidance rubric to the suggestion',
+  { timeout: 240_000 },
+  function (this: SafewordWorld) {
+    runPlanningEval(this);
+  },
+);
+
+Then('the capability is dropped', function (this: SafewordWorld) {
+  assertPlanningEval(this, 'approve', undefined, /migration/iu);
+});
+
+Then(
+  'the decision is surfaced and resolved in its owning plan',
+  { timeout: 240_000 },
+  function (this: SafewordWorld) {
+    assertPlanningEval(this, 'approve');
+    selectPlanningEval(this, 'r15-missing-required-proof-decision');
+    runPlanningEval(this);
+    const runs = assertPlanningEval(this, 'request_changes');
+    assert.ok(
+      runs.filter(run =>
+        run.reviewer.findings.some(
+          finding => /CLI/iu.test(finding) && /denial|refusal|exit.code/iu.test(finding),
+        ),
+      ).length >= 2,
+      'Two correct judged findings must reject endpoint-only proof for the accepted CLI denial.',
+    );
+  },
+);
+
+Then(
+  'the capability is surfaced as a user-owned scope choice and does not enter the plan',
+  function (this: SafewordWorld) {
+    const runs = assertPlanningEval(this, 'request_changes');
+    assert.ok(
+      runs.filter(run =>
+        run.reviewer.findings.some(
+          finding =>
+            /target.owner|owner consent/iu.test(finding) &&
+            /user.owned|user (?:must )?(?:decide|choose|authorize)|scope choice|decision owner:\s*(?:the )?user/iu.test(
+              finding,
+            ),
+        ),
+      ).length >= 2,
+      'Two correct judged findings must name the consent conflict and its user-owned scope boundary.',
+    );
+  },
+);
diff --git a/steps/keep-plan-reviews-host-guidance.steps.ts b/steps/keep-plan-reviews-host-guidance.steps.ts
new file mode 100644
index 000000000..8ac08d875
--- /dev/null
+++ b/steps/keep-plan-reviews-host-guidance.steps.ts
@@ -0,0 +1,185 @@
+import { strict as assert } from 'node:assert';
+import { spawnSync } from 'node:child_process';
+import { mkdirSync, mkdtempSync, readFileSync, rmSync, writeFileSync } from 'node:fs';
+import { tmpdir } from 'node:os';
+import path from 'node:path';
+
+import { After, Given, Then, When } from '@cucumber/cucumber';
+
+import type { SafewordWorld } from './world.js';
+
+const packageRoot = path.resolve(import.meta.dirname, '../packages/cli');
+interface HostGuidanceState {
+  root: string;
+  agent: 'codex' | 'claude' | 'opencode';
+  surface: string;
+  guidance?: string;
+}
+const states = new WeakMap<SafewordWorld, HostGuidanceState>();
+
+function assertAdvisory(guidance: string, surface: string): void {
+  assert.ok(
+    guidance
+      .split(/[.!?]\s/u)
+      .some(sentence => sentence.includes(surface) && /\badvisory\b/u.test(sentence)),
+    guidance,
+  );
+  assert.match(guidance, /Do not claim[^.]{0,100}planning review or approval[^.]{0,80}there/su);
+  for (const sentence of guidance.split(/[.!?]\s/u)) {
+    if (sentence.includes(surface)) {
+      if (!/Do not claim/u.test(sentence)) {
+        assert.doesNotMatch(
+          sentence,
+          /\b(?:enforc\w*|authoritativ\w*|approv\w*|gated|review(?:s|ed)?)\b/iu,
+        );
+      }
+    }
+  }
+}
+
+function setup(world: SafewordWorld, surface: string, agent: HostGuidanceState['agent']): void {
+  const root = mkdtempSync(path.join(tmpdir(), 'safeword-planning-host-guidance-'));
+  mkdirSync(path.join(root, 'project'));
+  writeFileSync(
+    path.join(root, 'project/package.json'),
+    '{"name":"host-guidance","private":true}\n',
+  );
+  states.set(world, { root, agent, surface });
+}
+
+After(function (this: SafewordWorld) {
+  const state = states.get(this);
+  if (state) rmSync(state.root, { recursive: true, force: true });
+  states.delete(this);
+});
+
+Given(
+  'repository instructions are generated for use by local Codex and may be read by Codex Cloud',
+  function (this: SafewordWorld) {
+    setup(this, 'Codex Cloud', 'codex');
+  },
+);
+
+Given(
+  'the OpenCode profile plugin is read from Desktop where native lifecycle hooks are unavailable',
+  function (this: SafewordWorld) {
+    setup(this, 'OpenCode Desktop', 'opencode');
+  },
+);
+
+Given(
+  /^planning guidance is generated for (local Claude Code|OpenCode CLI)$/,
+  function (this: SafewordWorld, surface: string) {
+    setup(this, surface, surface === 'local Claude Code' ? 'claude' : 'opencode');
+  },
+);
+
+When(
+  /^the Safeword CLI reconciles (?:the installed repository guidance|the installed OpenCode profile guidance|that installed guidance) through real project configuration$/,
+  function (this: SafewordWorld) {
+    const state = states.get(this);
+    assert.ok(state);
+    const project = path.join(state.root, 'project');
+    const environment = {
+      ...process.env,
+      CODEX_HOME: path.join(state.root, 'codex'),
+      CLAUDE_CONFIG_DIR: path.join(state.root, 'claude'),
+      OPENCODE_CONFIG_DIR: path.join(state.root, 'opencode'),
+      SAFEWORD_SKIP_INSTALL: '1',
+      SAFEWORD_SKIP_SKILLS: '1',
+    };
+    if (state.agent === 'codex') {
+      mkdirSync(environment.CODEX_HOME);
+      for (const args of [
+        ['plugin', 'marketplace', 'add', path.resolve(packageRoot, '../..'), '--json'],
+        ['plugin', 'add', 'safeword@safeword', '--json'],
+      ]) {
+        const enrolled = spawnSync('codex', args, {
+          encoding: 'utf8',
+          timeout: 60_000,
+          env: environment,
+        });
+        assert.equal(enrolled.status, 0, `${enrolled.stdout}\n${enrolled.stderr}`);
+      }
+    }
+    const result = spawnSync(
+      'bun',
+      [
+        path.join(packageRoot, 'src/cli.ts'),
+        'install',
+        `--agents=${state.agent}`,
+        '--no-input',
+        '--no-modify',
+        ...(state.agent === 'opencode' ? ['--offline'] : []),
+        '--json',
+        '--cwd',
+        project,
+      ],
+      {
+        cwd: project,
+        encoding: 'utf8',
+        timeout: 60_000,
+        env: environment,
+      },
+    );
+    const output = JSON.parse(result.stdout) as { errors: unknown[]; changed: boolean };
+    assert.deepEqual(output.errors, [], `${result.stdout}\n${result.stderr}`);
+    assert.equal(output.changed, true);
+    const entry =
+      state.agent === 'opencode'
+        ? path.join(state.root, 'opencode/skills/safeword-bdd/SKILL.md')
+        : path.join(project, '.safeword/SAFEWORD.md');
+    state.guidance = readFileSync(entry, 'utf8');
+  },
+);
+
+Then(
+  'it labels Codex Cloud execution advisory, claims neither review nor approval there, and directs authoritative planning to a supported gated surface',
+  function (this: SafewordWorld) {
+    const guidance = states.get(this)?.guidance ?? '';
+    assertAdvisory(guidance, 'Codex Cloud');
+    assert.throws(() =>
+      assertAdvisory(
+        `${guidance}\nCodex Cloud approves plans through the planning review gate.`,
+        'Codex Cloud',
+      ),
+    );
+    assert.match(guidance, /authoritative planning[^.]{0,100}supported gated surface/su);
+  },
+);
+
+Then(
+  'it labels Desktop execution advisory, claims neither review nor approval there, and names both OpenCode CLI and TUI as authoritative planning entry points',
+  function (this: SafewordWorld) {
+    const guidance = states.get(this)?.guidance ?? '';
+    assertAdvisory(guidance, 'OpenCode Desktop');
+    assert.throws(() =>
+      assertAdvisory(
+        `${guidance}\nPlanning approval is granted in OpenCode Desktop.`,
+        'OpenCode Desktop',
+      ),
+    );
+    assert.match(
+      guidance,
+      /planning review and approval are enforced[^.]{0,150}OpenCode CLI and TUI/su,
+    );
+  },
+);
+
+Then(
+  'it states that planning review and approval are enforced there and does not label that surface advisory',
+  function (this: SafewordWorld) {
+    const state = states.get(this);
+    assert.ok(state?.guidance);
+    const surface =
+      state.surface === 'local Claude Code' ? 'local Claude Code' : 'OpenCode CLI and TUI';
+    const enforced = /planning review and approval are enforced[^.]{0,200}/su.exec(
+      state.guidance,
+    )?.[0];
+    assert.ok(enforced?.includes(surface), state.guidance);
+    assert.doesNotMatch(enforced, /advisory/u);
+    for (const sentence of state.guidance.split(/[.!?]\s/u)) {
+      if (sentence.includes(surface)) assert.doesNotMatch(sentence, /\badvisory\b/u);
+    }
+  },
+);


Current PR5 complete unique-source review 16/19. Base 854a376861bc034d65cc81ddfa6a85d0ae55821e; head b722f9a27a1815abcfb08e6f6ca09dc7317efa46. Review actual correctness, authenticated approval, rejection findings and test discrimination. Every unique production source, template, test, step and generator changed in PR5 is supplied across these packets. Byte-identical installed mirrors and compiled bundles are omitted; all five generated surfaces passed at this head. Prior historical acceptance failures remain visible; full current run is in progress. Exactly 33 cases are user-deferred and unverified. This is source review, not native-host or merge approval. Flag only concrete in-scope defects; optional hardening does not block.

diff --git a/steps/keep-plan-reviews-independence.steps.ts b/steps/keep-plan-reviews-independence.steps.ts
new file mode 100644
index 000000000..deae84385
--- /dev/null
+++ b/steps/keep-plan-reviews-independence.steps.ts
@@ -0,0 +1,664 @@
+import { strict as assert } from 'node:assert';
+import { spawnSync } from 'node:child_process';
+import { existsSync, readFileSync, rmSync, writeFileSync } from 'node:fs';
+import path from 'node:path';
+
+import { After, Given, Then, When } from '@cucumber/cucumber';
+
+import { installedReviewCli } from '../packages/cli/tests/fixtures/execution-review.js';
+import { reviewerScript } from '../packages/cli/tests/fixtures/planning-reviewers.js';
+import {
+  cleanupTrustedReviewerDirectories,
+  createTrustedReviewerDirectory,
+} from '../packages/cli/tests/review-fixtures.js';
+import { fixtureProject } from './keep-plan-reviews-installed-context.steps.js';
+import { evaluateInstalledPhaseGate } from './keep-plan-reviews-stale-gates.steps.js';
+import type { SafewordWorld } from './world.js';
+
+const folder = '.project/tickets/CTX123-current-context';
+interface IndependentState {
+  root: string;
+  marker: string;
+  fallbackMarker?: string;
+  sameProcessReviewer?: 'claude' | 'codex';
+  env: Record<string, string>;
+  result?: {
+    data: {
+      status: string;
+      independence: string;
+      actual_reviewer: string;
+      review_id: string;
+      review_routes: {
+        reviewer: string;
+        model?: string;
+        independence: string;
+        status: string;
+        failure?: string;
+      }[];
+      continuation?: { tier: string; packet: { dispatch_id: string } };
+      continuation_attempts?: { tier: string; failure: string }[];
+    };
+    findings: { code: string; message: string }[];
+    errors: unknown[];
+  };
+  gate?: { exitCode: number; stdout: string; stderr: string };
+  evaluateGate?: () => Promise<{ exitCode: number; stdout: string; stderr: string }>;
+}
+const states = new WeakMap<SafewordWorld, IndependentState>();
+
+export async function prepare(world: SafewordWorld, verifiedAuthor: boolean) {
+  const bun = spawnSync('bun', ['-e', 'process.stdout.write(process.execPath)'], {
+    encoding: 'utf8',
+  });
+  assert.equal(bun.status, 0, bun.stderr);
+  const root = fixtureProject();
+  const reviewer = createTrustedReviewerDirectory('safeword-r6-independent-');
+  const marker = path.join(reviewer, 'invoked');
+  const state: IndependentState = {
+    root,
+    marker,
+    env: {
+      NODE_ENV: 'test',
+      PATH: `${reviewer}:${path.dirname(bun.stdout)}:${path.dirname(process.execPath)}:/usr/bin:/bin`,
+      SAFEWORD_AGENT_RUNTIME: 'claude',
+      CLAUDE_SESSION_ID: `r6-independent-${path.basename(root)}`,
+      CLAUDE_PROJECT_DIR: root,
+      CLAUDE_PLUGIN_ROOT: path.resolve(import.meta.dirname, '../plugin'),
+      PLUGIN_ROOT: path.resolve(import.meta.dirname, '../packages/cli/codex-plugin'),
+      SAFEWORD_AUTHOR_MODEL: verifiedAuthor ? 'claude-opus-5' : '',
+      SAFEWORD_REVIEW_KEY_ROOT: path.join(root, '.review-keys'),
+      XDG_STATE_HOME: path.join(root, '.review-keys'),
+      SAFEWORD_NO_UPDATE_CHECK: '1',
+    },
+  };
+  states.set(world, state);
+  const installed = await installedReviewCli(root)(
+    ['install', '--agents', 'cursor', '--offline', '--no-input', '--json', '--cwd', root],
+    { cwd: root, env: { NODE_ENV: 'test' } },
+  );
+  assert.equal(installed.exitCode, 0, installed.stdout);
+  const configPath = path.join(root, '.safeword/config.json');
+  const config = JSON.parse(readFileSync(configPath, 'utf8'));
+  writeFileSync(
+    configPath,
+    JSON.stringify({
+      ...config,
+      crossAgentReviewRoutes: { claude: [{ reviewer: 'codex', model: 'gpt-6.1-sol' }] },
+    }),
+  );
+  writeFileSync(
+    path.join(reviewer, 'codex'),
+    reviewerScript('codex', marker, path.join(reviewer, 'packet.json'), false, true),
+    { mode: 0o755 },
+  );
+  return state;
+}
+
+export async function coordinate(
+  state: IndependentState,
+  reviewer: 'codex' | 'claude' = 'codex',
+  status: 'approved' | 'changes_requested' | 'continuation_required' | 'blocked' = 'approved',
+) {
+  const result = await installedReviewCli(state.root)(
+    [
+      'review',
+      'run',
+      'plan-implementation',
+      `${folder}/impl-plan.md`,
+      '--context',
+      'features/current-context.feature',
+      '--context',
+      `${folder}/spec.md`,
+      '--json',
+      '--no-input',
+      '--cwd',
+      state.root,
+    ],
+    { cwd: state.root, env: state.env },
+  );
+  assert.equal(result.exitCode, status === 'approved' ? 0 : 2, result.stdout);
+  state.result = JSON.parse(result.stdout);
+  assert.ok(state.result);
+  if (status !== 'blocked') assert.deepEqual(state.result.errors, []);
+  assert.equal(state.result.data.status, status);
+  if (status === 'approved' || status === 'changes_requested')
+    assert.equal(state.result.data.actual_reviewer, reviewer);
+  assert.ok(existsSync(state.marker), 'The real coordinator must invoke the reviewer process');
+}
+
+function recordApproval(state: IndependentState) {
+  assert.ok(state.result);
+  const stamped = spawnSync(
+    'bun',
+    [
+      path.join(state.root, '.safeword/hooks/write-review-stamp.ts'),
+      '--ticket',
+      path.basename(folder),
+      '--phase',
+      'plan-implementation',
+      '--review-id',
+      state.result.data.review_id,
+      '--author-agent',
+      'claude',
+      '--reviewer-agent',
+      state.result.data.actual_reviewer,
+      '--independence',
+      state.result.data.independence,
+    ],
+    {
+      cwd: state.root,
+      env: { ...process.env, ...state.env },
+      encoding: 'utf8',
+      timeout: 60_000,
+    },
+  );
+  assert.equal(stamped.status, 0, stamped.stdout + stamped.stderr);
+}
+
+Given(
+  /^an approval is returned by (a different agent in a separate process using a model at least as capable as the author|a different agent when the author model cannot be verified)$/,
+  { timeout: 120_000 },
+  async function (this: SafewordWorld, identity: string) {
+    await prepare(this, identity.includes('at least as capable'));
+  },
+);
+
+When(
+  'the coordinator classifies its independence',
+  { timeout: 120_000 },
+  async function (this: SafewordWorld) {
+    const state = states.get(this);
+    assert.ok(state);
+    if (state.result === undefined) await coordinate(state);
+    else {
+      const receipt = await installedReviewCli(state.root)(
+        ['review', 'status', state.result.data.review_id, '--json', '--cwd', state.root],
+        { cwd: state.root, env: state.env },
+      );
+      assert.equal(JSON.parse(receipt.stdout).data.status, state.result.data.status);
+      assert.equal(JSON.parse(receipt.stdout).data.independence, state.result.data.independence);
+    }
+  },
+);
+
+Then('cross-agent independence is accepted', function (this: SafewordWorld) {
+  assert.equal(states.get(this)?.result?.data.independence, 'cross-agent');
+});
+
+Then('independent approval is refused', function (this: SafewordWorld) {
+  const state = states.get(this);
+  assert.ok(state?.result);
+  const result = state.result;
+  assert.notEqual(result.data.independence, 'cross-agent');
+  if (state.sameProcessReviewer !== undefined) {
+    assert.ok(result.data.continuation);
+    assert.equal(result.data.continuation.tier, 'self-review');
+    if (state.sameProcessReviewer === 'codex') {
+      assert.equal(result.data.status, 'blocked');
+      assert.equal(result.data.independence, 'none');
+      assert.ok(result.findings.some(finding => finding.code === 'REVIEW_ROUTES_EXHAUSTED'));
+      assert.deepEqual(result.data.continuation_attempts?.at(-1), {
+        tier: 'self-review',
+        failure: 'invalid_output',
+      });
+    } else {
+      assert.equal(result.data.status, 'approved');
+      assert.equal(result.data.independence, 'reduced');
+      assert.ok(
+        result.findings.some(
+          finding =>
+            finding.code === 'REVIEW_INDEPENDENCE_REDUCED' &&
+            finding.message.includes('own context'),
+        ),
+      );
+    }
+  } else {
+    assert.equal(result.data.independence, 'reduced');
+    assert.ok(result.findings.some(finding => finding.code === 'AUTHOR_CAPABILITY_UNKNOWN'));
+  }
+});
+
+Given(
+  'the review coordinator has returned an independent reviewer approval',
+  { timeout: 120_000 },
+  async function (this: SafewordWorld) {
+    const state = await prepare(this, true);
+    await coordinate(state);
+    assert.equal(state.result?.data.independence, 'cross-agent');
+    recordApproval(state);
+  },
+);
+
+Given(
+  /^the review coordinator has returned every configured independent route was attempted and returned a typed failure, then the permitted fallback (approves|declines)$/,
+  { timeout: 120_000 },
+  async function (this: SafewordWorld, verdict: string) {
+    const state = await prepare(this, true);
+    const directory = path.dirname(state.marker);
+    const configPath = path.join(state.root, '.safeword/config.json');
+    const config = JSON.parse(readFileSync(configPath, 'utf8'));
+    writeFileSync(
+      configPath,
+      JSON.stringify({
+        ...config,
+        crossAgentReviewRoutes: {
+          claude: [{ reviewer: 'codex', model: 'gpt-6.1-sol' }, { reviewer: 'claude' }],
+        },
+      }),
+    );
+    state.fallbackMarker = path.join(directory, 'same-agent-invoked');
+    writeFileSync(
+      path.join(directory, 'codex'),
+      reviewerScript('codex', state.marker, path.join(directory, 'codex-packet.json'), true, true),
+      { mode: 0o755 },
+    );
+    const approval = reviewerScript(
+      'claude',
+      state.fallbackMarker,
+      path.join(directory, 'claude-packet.json'),
+      false,
+      false,
+    );
+    const script =
+      verdict === 'approves'
+        ? approval
+        : approval.replace(
+            "verdict: 'approve', summary: 'Review approved.', findings: []",
+            "verdict: 'request_changes', summary: 'Review declined.', findings: [{ severity: 'error', message: 'The current plan requires repair.' }]",
+          );
+    if (verdict === 'declines') assert.notEqual(script, approval);
+    writeFileSync(path.join(directory, 'claude'), script, { mode: 0o755 });
+    await coordinate(state, 'claude', verdict === 'approves' ? 'approved' : 'changes_requested');
+    assert.ok(existsSync(state.fallbackMarker));
+    const independent = state.result?.data.review_routes.filter(
+      route => route.reviewer === 'codex',
+    );
+    assert.ok(independent?.length);
+    assert.ok(
+      independent.every(
+        route => route.status === 'attempted' && route.failure === 'process_failed',
+      ),
+    );
+    assert.equal(state.result?.data.independence, 'reduced');
+    if (verdict === 'approves') recordApproval(state);
+  },
+);
+
+async function hostContinuation(
+  world: SafewordWorld,
+  tier: 'fresh-context' | 'self-review',
+  reviewer: 'claude' | 'codex' = 'claude',
+) {
+  const state = await prepare(world, true);
+  const directory = path.dirname(state.marker);
+  const configPath = path.join(state.root, '.safeword/config.json');
+  const config = JSON.parse(readFileSync(configPath, 'utf8'));
+  writeFileSync(
+    configPath,
+    JSON.stringify({
+      ...config,
+      crossAgentReviewRoutes: {
+        claude: [{ reviewer: 'codex', model: 'gpt-6.1-sol' }, { reviewer: 'claude' }],
+      },
+    }),
+  );
+  state.fallbackMarker = path.join(directory, 'headless-failed');
+  writeFileSync(
+    path.join(directory, 'codex'),
+    reviewerScript('codex', state.marker, path.join(directory, 'codex-packet.json'), true, true),
+    { mode: 0o755 },
+  );
+  const script = reviewerScript(
+    'claude',
+    state.fallbackMarker,
+    path.join(directory, 'claude-packet.json'),
+    false,
+    false,
+  );
+  const failed = script.replace(
+    'function reviewOutput(packet)',
+    'process.exit(7);\nfunction reviewOutput(packet)',
+  );
+  assert.notEqual(failed, script);
+  writeFileSync(path.join(directory, 'claude'), failed, { mode: 0o755 });
+  await coordinate(state, 'claude', 'continuation_required');
+  assert.ok(existsSync(state.fallbackMarker));
+  assert.ok(state.result?.data.review_routes.some(item => item.reviewer === 'codex'));
+  assert.ok(state.result?.data.review_routes.some(item => item.reviewer === 'claude'));
+  assert.ok(
+    state.result?.data.review_routes.every(
+      item => item.status === 'attempted' && item.failure === 'process_failed',
+    ),
+    JSON.stringify(state.result?.data.review_routes),
+  );
+  assert.equal(state.result.data.continuation?.tier, 'fresh-context');
+  assert.ok(state.result.data.continuation);
+  const reviewId = state.result.data.review_id;
+  const dispatchId = state.result.data.continuation.packet.dispatch_id;
+  const cli = installedReviewCli(state.root);
+  if (tier === 'self-review') {
+    const failure = await cli(
+      [
+        'review',
+        'continue',
+        reviewId,
+        '--tier',
+        'fresh-context',
+        '--failure',
+        'process_failed',
+        '--offline',
+        '--json',
+        '--cwd',
+        state.root,
+      ],
+      { cwd: state.root, env: state.env },
+    );
+    assert.equal(failure.exitCode, 2, failure.stdout);
+    state.result = JSON.parse(failure.stdout);
+    assert.ok(state.result);
+    assert.equal(state.result.data.review_id, reviewId);
+    assert.equal(state.result.data.status, 'continuation_required');
+    assert.equal(state.result.data.continuation?.tier, 'self-review');
+    assert.deepEqual(state.result.data.continuation_attempts, [
+      { tier: 'fresh-context', failure: 'process_failed' },
+    ]);
+  }
+  assert.equal(state.result.data.continuation?.packet.dispatch_id, dispatchId);
+  writeFileSync(
+    path.join(state.root, 'host-review.json'),
+    JSON.stringify({
+      schema_version: 1,
+      dispatch_id: dispatchId,
+      reviewer_agent: reviewer,
+      verdict: 'approve',
+      summary: `Approved by host-reported ${tier}.`,
+      findings: [],
+      evidence_records: { schema_version: 1, records: [] },
+    }),
+  );
+  const completed = await cli(
+    [
+      'review',
+      'continue',
+      reviewId,
+      '--tier',
+      tier,
+      '--output',
+      'host-review.json',
+      '--offline',
+      '--json',
+      '--cwd',
+      state.root,
+    ],
+    { cwd: state.root, env: state.env },
+  );
+  assert.equal(completed.exitCode, reviewer === 'claude' ? 0 : 2, completed.stdout);
+  state.result = JSON.parse(completed.stdout);
+  assert.ok(state.result);
+  assert.equal(state.result.data.review_id, reviewId);
+  assert.equal(state.result.data.status, reviewer === 'claude' ? 'approved' : 'blocked');
+  if (reviewer === 'claude') {
+    assert.equal(state.result.data.actual_reviewer, reviewer);
+    assert.equal(state.result.data.independence, 'reduced');
+  }
+  assert.equal(state.result.data.continuation?.tier, tier);
+  assert.ok(state.result.data.continuation);
+  assert.equal(state.result.data.continuation.packet.dispatch_id, dispatchId);
+  if (reviewer === 'claude') recordApproval(state);
+  return state;
+}
+
+Given(
+  /^the review coordinator has returned (every independent route and same-agent headless review returned typed failures, then host-reported fresh-context review approves|every earlier route through host-reported fresh-context review returned typed failures, then bounded self-review approves)$/,
+  { timeout: 120_000 },
+  async function (this: SafewordWorld, route: string) {
+    await hostContinuation(
+      this,
+      route.includes('bounded self-review') ? 'self-review' : 'fresh-context',
+    );
+  },
+);
+
+Given(
+  /^an approval is returned by (a different agent in the same process using a model at least as capable as the author|the authoring agent in the same process)$/,
+  { timeout: 120_000 },
+  async function (this: SafewordWorld, identity: string) {
+    const reviewer = identity.startsWith('a different') ? 'codex' : 'claude';
+    const state = await hostContinuation(this, 'self-review', reviewer);
+    state.sameProcessReviewer = reviewer;
+  },
+);
+
+When('the phase gate evaluates the receipt', async function (this: SafewordWorld) {
+  const state = states.get(this);
+  if (!state) {
+    assert.ok(evaluateInstalledPhaseGate(this), 'A real coordinator receipt must be prepared');
+    return;
+  }
+  assert.ok(state.result);
+  state.gate = state.evaluateGate
+    ? await state.evaluateGate()
+    : await installedReviewCli(state.root)(
+        ['ticket', 'approve-plan', 'CTX123', '--json', '--no-input', '--cwd', state.root],
+        { cwd: state.root, env: state.env },
+      );
+});
+
+async function assertCurrentReceipt(
+  state: IndependentState,
+  expectedStatus: 'approved' | 'changes_requested',
+  reviewer: 'claude' | 'codex',
+  independence: 'cross-agent' | 'reduced',
+) {
+  assert.ok(state.result);
+  const status = await installedReviewCli(state.root)(
+    ['review', 'status', state.result.data.review_id, '--json', '--cwd', state.root],
+    { cwd: state.root, env: state.env },
+  );
+  assert.equal(status.exitCode, expectedStatus === 'approved' ? 0 : 2, status.stdout);
+  const receipt = JSON.parse(status.stdout).data;
+  assert.equal(receipt.review_id, state.result.data.review_id);
+  assert.equal(receipt.status, expectedStatus);
+  assert.equal(receipt.independence, independence);
+  assert.equal(receipt.actual_reviewer, reviewer);
+}
+
+Then(
+  'the review passes with cross-agent independence recorded',
+  async function (this: SafewordWorld) {
+    const state = states.get(this);
+    assert.ok(state?.gate && state.result);
+    assert.equal(state.gate.exitCode, 0, state.gate.stdout);
+    assert.equal(state.result.data.independence, 'cross-agent');
+    const rows = readFileSync(path.join(state.root, '.project/skill-invocations.log'), 'utf8')
+      .trim()
+      .split('\n');
+    const stamp = rows.find(row => row.endsWith(`review-id:${state.result?.data.review_id}`));
+    assert.ok(stamp, 'The real writer must persist this authenticated review ID');
+    assert.match(stamp, /author:claude reviewer:codex independence:cross-agent/u);
+    await assertCurrentReceipt(state, 'approved', 'codex', 'cross-agent');
+    assert.match(
+      readFileSync(path.join(state.root, folder, 'ticket.md'), 'utf8'),
+      /phase: plan-execution/u,
+    );
+  },
+);
+
+Then(
+  /^the review passes with reduced independence and (actual reviewer recorded without calling the capability degraded|the host-reported fresh-context reviewer recorded|the bounded self-reviewer recorded)$/,
+  async function (this: SafewordWorld, label: string) {
+    const state = states.get(this);
+    assert.ok(state?.gate && state.result);
+    if (label.includes('fresh-context') || label.includes('self-reviewer')) {
+      const tier = label.includes('fresh-context') ? 'fresh-context' : 'self-review';
+      assert.equal(state.result.data.continuation?.tier, tier);
+      assert.ok(
+        state.result.findings.some(
+          item =>
+            item.code === 'REVIEW_INDEPENDENCE_REDUCED' &&
+            item.message.includes(tier === 'fresh-context' ? 'fresh context' : 'own context'),
+        ),
+      );
+    }
+    assert.equal(state.gate.exitCode, 0, state.gate.stdout);
+    const stamp = readFileSync(path.join(state.root, '.project/skill-invocations.log'), 'utf8')
+      .trim()
+      .split('\n')
+      .find(row => row.endsWith(`review-id:${state.result?.data.review_id}`));
+    assert.ok(stamp);
+    assert.match(stamp, /author:claude reviewer:claude independence:reduced/u);
+    await assertCurrentReceipt(state, 'approved', 'claude', 'reduced');
+    assert.ok(
+      !state.result.findings.some(finding => finding.code === 'REVIEW_INDEPENDENCE_DEGRADED'),
+    );
+    assert.ok(!state.gate.stdout.includes('REVIEW_INDEPENDENCE_DEGRADED'));
+    assert.match(
+      readFileSync(path.join(state.root, folder, 'ticket.md'), 'utf8'),
+      /phase: plan-execution/u,
+    );
+  },
+);
+
+Given(
+  'the review coordinator has returned an unrecognized or unparseable reviewer result',
+  { timeout: 120_000 },
+  async function (this: SafewordWorld) {
+    const state = await prepare(this, true);
+    await coordinate(state);
+    recordApproval(state);
+    const approvedId = state.result?.data.review_id;
+    assert.ok(approvedId);
+    const cli = installedReviewCli(state.root);
+    const approved = await cli(
+      ['ticket', 'approve-plan', 'CTX123', '--json', '--no-input', '--cwd', state.root],
+      { cwd: state.root, env: state.env },
+    );
+    assert.equal(approved.exitCode, 0, approved.stdout);
+    const ticket = path.join(state.root, folder, 'ticket.md');
+    const advanced = readFileSync(ticket, 'utf8');
+    assert.match(advanced, /phase: plan-execution/u);
+    writeFileSync(ticket, advanced.replace('phase: plan-execution', 'phase: plan-implementation'));
+    const plan = path.join(state.root, folder, 'impl-plan.md');
+    writeFileSync(
+      plan,
+      `${readFileSync(plan, 'utf8')}\n<!-- current input for malformed-output proof -->\n`,
+    );
+    const superseded = await cli(['review', 'status', approvedId, '--json', '--cwd', state.root], {
+      cwd: state.root,
+      env: state.env,
+    });
+    assert.equal(JSON.parse(superseded.stdout).data.status, 'stale', superseded.stdout);
+    const configPath = path.join(state.root, '.safeword/config.json');
+    writeFileSync(
+      configPath,
+      JSON.stringify({
+        ...JSON.parse(readFileSync(configPath, 'utf8')),
+        crossAgentReview: 'require',
+      }),
+    );
+    const directory = path.dirname(state.marker);
+    const valid = reviewerScript(
+      'codex',
+      state.marker,
+      path.join(directory, 'packet.json'),
+      false,
+      true,
+    );
+    const malformed = valid
+      .replace(
+        'schema_version: 1, dispatch_id: packet.dispatch_id',
+        'schema_version: 0, dispatch_id: packet.dispatch_id',
+      )
+      .replace(
+        'findings: []',
+        "findings: [{ severity: 'error', message: 'Malformed producer finding must not escape.' }]",
+      );
+    assert.notEqual(malformed, valid);
+    rmSync(state.marker);
+    rmSync(path.join(directory, 'packet.json'));
+    writeFileSync(path.join(directory, 'codex'), malformed, { mode: 0o755 });
+    await coordinate(state, 'codex', 'blocked');
+    assert.deepEqual(state.result?.data.review_routes, [
+      {
+        reviewer: 'codex',
+        model: 'gpt-6.1-sol',
+        independence: 'cross-agent',
+        status: 'attempted',
+        failure: 'invalid_output',
+      },
+    ]);
+    assert.equal(state.result?.data.independence, 'none');
+    assert.ok(state.result && !('reviewer_output' in state.result.data));
+  },
+);
+
+Then('the phase remains blocked with no approval recorded', async function (this: SafewordWorld) {
+  const state = states.get(this);
+  assert.ok(state?.gate && state.result);
+  assert.equal(state.gate.exitCode, 2, state.gate.stdout);
+  if (state.result.data.status === 'changes_requested') {
+    assert.match(state.gate.stdout, /The current plan requires repair\./u);
+    await assertCurrentReceipt(state, 'changes_requested', 'claude', 'reduced');
+  } else {
+    assert.equal(state.result.data.status, 'blocked');
+    assert.equal(state.result.data.review_routes[0]?.failure, 'invalid_output');
+    const current = await installedReviewCli(state.root)(
+      ['review', 'status', state.result.data.review_id, '--json', '--cwd', state.root],
+      { cwd: state.root, env: state.env },
+    );
+    const receipt = JSON.parse(current.stdout).data;
+    assert.equal(receipt.review_id, state.result.data.review_id);
+    assert.equal(receipt.status, 'blocked', current.stdout);
+    assert.equal(receipt.independence, 'none');
+    assert.ok(!('reviewer_output' in receipt));
+    const ledgerPath = path.join(state.root, '.project/skill-invocations.log');
+    const ledgerBefore = readFileSync(ledgerPath, 'utf8');
+    const stamped = spawnSync(
+      'bun',
+      [
+        path.join(state.root, '.safeword/hooks/write-review-stamp.ts'),
+        '--ticket',
+        path.basename(folder),
+        '--phase',
+        'plan-implementation',
+        '--review-id',
+        receipt.review_id,
+        '--author-agent',
+        'claude',
+        '--reviewer-agent',
+        'codex',
+        '--independence',
+        'cross-agent',
+      ],
+      { cwd: state.root, env: { ...process.env, ...state.env }, encoding: 'utf8', timeout: 60_000 },
+    );
+    assert.equal(stamped.status, 1, stamped.stdout + stamped.stderr);
+    assert.match(stamped.stdout + stamped.stderr, /did not approve \(status: blocked\)/u);
+    assert.equal(readFileSync(ledgerPath, 'utf8'), ledgerBefore);
+    assert.ok(
+      !JSON.parse(state.gate.stdout).findings.some(
+        (finding: { code: string }) =>
+          finding.code === 'REVIEWER_FINDING' || finding.code === 'REVIEWER_SUMMARY',
+      ),
+      'An unrecognized result must not be rendered as reviewer findings',
+    );
+  }
+  assert.match(
+    readFileSync(path.join(state.root, folder, 'ticket.md'), 'utf8'),
+    /phase: plan-implementation/u,
+  );
+  const ledger = path.join(state.root, '.project/skill-invocations.log');
+  assert.ok(
+    !existsSync(ledger) ||
+      !readFileSync(ledger, 'utf8').includes(`review-id:${state.result.data.review_id}`),
+  );
+});
+
+After(function (this: SafewordWorld) {
+  const state = states.get(this);
+  if (state) {
+    rmSync(state.root, { recursive: true, force: true });
+    cleanupTrustedReviewerDirectories();
+  }
+  states.delete(this);
+});
diff --git a/steps/keep-plan-reviews-installed-context.steps.ts b/steps/keep-plan-reviews-installed-context.steps.ts
new file mode 100644
index 000000000..83e2b6804
--- /dev/null
+++ b/steps/keep-plan-reviews-installed-context.steps.ts
@@ -0,0 +1,663 @@
+import { strict as assert } from 'node:assert';
+import { spawnSync } from 'node:child_process';
+import { createHash } from 'node:crypto';
+import {
+  cpSync,
+  existsSync,
+  mkdirSync,
+  mkdtempSync,
+  readFileSync,
+  rmSync,
+  writeFileSync,
+} from 'node:fs';
+import { tmpdir } from 'node:os';
+import path from 'node:path';
+
+import { After, Given, Then, When } from '@cucumber/cucumber';
+
+import { SAFEWORD_SCHEMA } from '../packages/cli/src/schema.js';
+import { parsePlanningContract } from '../packages/cli/src/planning/phase-contract.js';
+import { extractPlanReviewRubric } from '../packages/cli/src/review/plan-rubric.js';
+import { writePlanningInventories } from '../packages/cli/tests/planning-fixtures.js';
+import {
+  createTrustedReviewerDirectory,
+  REVIEWER_CAPABILITIES,
+} from '../packages/cli/tests/review-fixtures.js';
+import type { SafewordWorld } from './world.js';
+
+const packageRoot = path.resolve(import.meta.dirname, '../packages/cli');
+const pluginRoot = path.resolve(import.meta.dirname, '../plugin');
+const ticketFolder = 'CTX123-current-context';
+const ticketRoot = `.project/tickets/${ticketFolder}`;
+
+interface InstalledContextState {
+  root: string;
+  reviewer: string;
+  overrideState: string;
+  runtimeRoot?: string;
+  gate?: ReturnType<typeof spawnSync>;
+  authorGate?: ReturnType<typeof spawnSync>;
+  reviewDispatch?: ReturnType<typeof spawnSync>;
+  contractCase?: 'reviewer-drift' | 'reviewer-missing' | 'canonical';
+  cosmeticContractChanged?: boolean;
+  reviewStatus?: ReturnType<typeof spawnSync>;
+  reviewId?: string;
+}
+const states = new WeakMap<SafewordWorld, InstalledContextState>();
+
+function copiedRuntimeReviewStatus(state: InstalledContextState) {
+  assert.ok(state.runtimeRoot && state.reviewId);
+  return spawnSync(
+    'bun',
+    [path.join(state.runtimeRoot, 'runtime/cli.js'), 'review', 'status', state.reviewId, '--json'],
+    {
+      cwd: state.root,
+      encoding: 'utf8',
+      timeout: 60_000,
+      env: {
+        ...process.env,
+        PATH: `${state.reviewer}:${process.env.PATH ?? ''}`,
+        CLAUDE_PROJECT_DIR: state.root,
+        CLAUDE_PLUGIN_ROOT: state.runtimeRoot,
+        CLAUDE_SESSION_ID: 'r3-installed',
+        SAFEWORD_AGENT_RUNTIME: 'claude',
+      },
+    },
+  );
+}
+
+export function fixtureProject(): string {
+  const root = mkdtempSync(path.join(tmpdir(), 'safeword-r3-installed-'));
+  writePlanningInventories(root);
+  mkdirSync(path.join(root, ticketRoot), { recursive: true });
+  mkdirSync(path.join(root, 'features'));
+  writeFileSync(path.join(root, 'package.json'), '{"name":"r3-installed","private":true}\n');
+  writeFileSync(
+    path.join(root, ticketRoot, 'ticket.md'),
+    `---\nid: CTX123\ntype: feature\nphase: plan-implementation\nstatus: in_progress\nproduct_plan_contract: v1\nscope: preserve authenticated approval\nout_of_scope: new approval authority\ndone_when: current context reaches review\nphase_anchors:\n  - scenario-gate: features/current-context.feature\n---\n# Ticket\n`,
+  );
+  writeFileSync(
+    path.join(root, ticketRoot, 'spec.md'),
+    `# Product Plan: Preserve approval\n\n<!-- safeword:product-plan-contract:v1 -->\n\n## Product Bet\n\n- **Expected outcome:** Builders advance with current approval.\n- **Persona outcome inventory:** Builder receives approval or a named refusal.\n- **Known facts:** Approval authenticates the current source.\n- **Assumptions:** Review latency is acceptable.\n- **Unresolved product decisions:** none\n- **Success threshold:** Current approval advances.\n- **Project non-goals:** No new approval authority.\n\n## Jobs To Be Done\n\n### approval.BU1 — Trust approval\n\n**Persona:** Builder (BU)\n\n> When I request approval, I want current evidence, so I can trust advancement.\n\n#### approval.BU1.R1 — Preserve approval\n\nOnly current approval advances.\n\n## Surfaces\n\nAffected:\n- Safeword CLI\n`,
+  );
+  writeFileSync(
+    path.join(root, ticketRoot, 'impl-plan.md'),
+    `# Implementation Plan: Preserve approval\n\n**Status:** planned\n\n## Approach\n\nUse the current review receipt to guard the transition.\n\n## Decisions\n\n### Recorded Decisions\n\n| Decision | Choice | Alternatives considered | Rejected because |\n| --- | --- | --- | --- |\n| review gate | current receipt | unchecked transition | stale approval can advance |\n\n## Design alignment\n\nskip: No additional principle trace applies to this fixture.\n\n## Architecture applicability\n\nskip: No durable architecture record applies.\n\n## Data applicability\n\nskip: No product data is stored.\n\n## Known deviations\n\nskip: No known deviations.\n\n## Doc impact\n\nskip: No documentation changes.\n\n## Assessment triggers\n\nRevisit when the approval authority changes.\n`,
+  );
+  writeFileSync(
+    path.join(root, 'features/current-context.feature'),
+    '@approval.BU1.R1 @surface.safeword-cli\nFeature: Trust current approval\n  Scenario: Approval\n    Given a current review\n    When the Builder requests approval\n    Then the current context reaches review\n',
+  );
+  return root;
+}
+
+function configure(root: string, override: string): void {
+  const configPath = path.join(root, '.safeword/config.json');
+  const installed = JSON.parse(readFileSync(configPath, 'utf8')) as Record<string, unknown>;
+  writeFileSync(
+    configPath,
+    JSON.stringify({
+      ...installed,
+      reviewGate: true,
+      crossAgentReview: 'prefer',
+      crossAgentReviewRoutes: { claude: [{ reviewer: 'opencode' }] },
+      paths: { ...(installed.paths as Record<string, unknown>), principles: override },
+      pathLineage: { principles: { packagedSourceVersion: SAFEWORD_SCHEMA.version } },
+    }),
+  );
+}
+
+export function reviewerExecutable(reviewer: string): void {
+  writeFileSync(
+    path.join(reviewer, 'opencode'),
+    String.raw`#!${process.execPath}
+if (process.argv.includes('--version')) { console.log('opencode 1.0.0'); process.exit(0); }
+if (process.argv.includes('--help')) { console.log(${JSON.stringify(REVIEWER_CAPABILITIES.opencode)}); process.exit(0); }
+let input = ''; process.stdin.setEncoding('utf8');
+process.stdin.on('data', chunk => { input += chunk; });
+process.stdin.on('end', () => {
+  const packet = JSON.parse(input.trim().split('\n').pop());
+  const output = { schema_version: 1, dispatch_id: packet.dispatch_id,
+    reviewer_agent: 'opencode', verdict: 'approve', summary: 'Current plan approved.',
+    findings: [], evidence_records: { schema_version: 1, records: [] } };
+  console.log(JSON.stringify({ type: 'text', part: { type: 'text', time: { end: 1 }, text: JSON.stringify(output) } }));
+});
+`,
+    { mode: 0o755 },
+  );
+}
+
+After(function (this: SafewordWorld) {
+  const state = states.get(this);
+  if (state) {
+    rmSync(state.root, { recursive: true, force: true });
+    rmSync(state.reviewer, { recursive: true, force: true });
+    if (state.runtimeRoot) rmSync(state.runtimeRoot, { recursive: true, force: true });
+  }
+  states.delete(this);
+});
+
+function establishApprovedPlanningContext(this: SafewordWorld, overrideState: string) {
+  const root = fixtureProject();
+  const reviewer = createTrustedReviewerDirectory('safeword-r3-reviewer-');
+  states.set(this, { root, reviewer, overrideState });
+  const install = spawnSync(
+    'bun',
+    [
+      path.join(packageRoot, 'src/cli.ts'),
+      'install',
+      '--agents=claude',
+      '--no-input',
+      '--no-modify',
+      '--json',
+      '--cwd',
+      root,
+    ],
+    {
+      cwd: root,
+      encoding: 'utf8',
+      timeout: 60_000,
+      env: {
+        ...process.env,
+        CLAUDE_CONFIG_DIR: path.join(root, 'claude'),
+        SAFEWORD_SKIP_INSTALL: '1',
+        SAFEWORD_SKIP_SKILLS: '1',
+      },
+    },
+  );
+  const installOutput = JSON.parse(install.stdout) as { errors: unknown[] };
+  assert.deepEqual(installOutput.errors, [], `${install.stdout}\n${install.stderr}`);
+  const override = 'docs/principles.md';
+  mkdirSync(path.join(root, 'docs'));
+  writeFileSync(path.join(root, override), '# Project principles\n\nKeep approval current.\n');
+  configure(root, override);
+  reviewerExecutable(reviewer);
+  const environment = {
+    ...process.env,
+    PATH: `${reviewer}:${process.env.PATH ?? ''}`,
+    CLAUDE_PROJECT_DIR: root,
+    CLAUDE_PLUGIN_ROOT: pluginRoot,
+    CLAUDE_SESSION_ID: 'r3-installed',
+    SAFEWORD_AGENT_RUNTIME: 'claude',
+  };
+  const reviewed = spawnSync(
+    'bun',
+    [
+      path.join(packageRoot, 'src/cli.ts'),
+      'review',
+      'run',
+      'plan-implementation',
+      `${ticketRoot}/impl-plan.md`,
+      '--json',
+      '--no-input',
+    ],
+    { cwd: root, encoding: 'utf8', timeout: 60_000, env: environment },
+  );
+  assert.equal(reviewed.status, 0, `${reviewed.stdout}\n${reviewed.stderr}`);
+  const result = JSON.parse(reviewed.stdout) as { data: { status: string; review_id: string } };
+  assert.equal(result.data.status, 'approved');
+  const state = states.get(this);
+  assert.ok(state);
+  state.reviewId = result.data.review_id;
+  const stamp = spawnSync(
+    'bun',
+    [
+      path.join(pluginRoot, 'runtime/hooks/write-review-stamp.ts'),
+      '--ticket',
+      ticketFolder,
+      '--author-agent',
+      'claude',
+      '--reviewer-agent',
+      'opencode',
+      '--independence',
+      'reduced',
+      '--review-id',
+      result.data.review_id,
+      'impl-plan',
+    ],
+    { cwd: root, encoding: 'utf8', timeout: 60_000, env: environment },
+  );
+  assert.equal(stamp.status, 0, `${stamp.stdout}\n${stamp.stderr}`);
+  const phaseStamp = spawnSync(
+    'bun',
+    [
+      path.join(pluginRoot, 'runtime/hooks/write-review-stamp.ts'),
+      '--ticket',
+      ticketFolder,
+      '--author-agent',
+      'claude',
+      '--reviewer-agent',
+      'opencode',
+      '--independence',
+      'reduced',
+      '--review-id',
+      result.data.review_id,
+      '--phase',
+      'plan-implementation',
+    ],
+    { cwd: root, encoding: 'utf8', timeout: 60_000, env: environment },
+  );
+  assert.equal(phaseStamp.status, 0, `${phaseStamp.stdout}\n${phaseStamp.stderr}`);
+  const current = spawnSync(
+    'bun',
+    [path.join(packageRoot, 'src/cli.ts'), 'review', 'status', result.data.review_id, '--json'],
+    { cwd: root, encoding: 'utf8', timeout: 60_000, env: environment },
+  );
+  const currentStatus = JSON.parse(current.stdout) as { data: { status: string } };
+  assert.equal(currentStatus.data.status, 'approved', `${current.stdout}\n${current.stderr}`);
+  if (overrideState === 'blank') writeFileSync(path.join(root, override), ' \n');
+  if (overrideState.startsWith('stale')) {
+    const configPath = path.join(root, '.safeword/config.json');
+    const config = JSON.parse(readFileSync(configPath, 'utf8')) as Record<string, unknown>;
+    writeFileSync(
+      configPath,
+      JSON.stringify({
+        ...config,
+        pathLineage: { principles: { packagedSourceVersion: '0.0.0' } },
+      }),
+    );
+  }
+}
+
+Given(
+  /^a planning phase with a current approving receipt has a required project-knowledge override that is (.+)$/,
+  establishApprovedPlanningContext,
+);
+
+Given(
+  /^a planning phase with a current approving receipt has an installed authoring contract that (.+)$/,
+  function (this: SafewordWorld, contractState: string) {
+    establishApprovedPlanningContext.call(this, 'current');
+    const state = states.get(this);
+    assert.ok(state);
+    state.runtimeRoot = mkdtempSync(path.join(tmpdir(), 'safeword-r5-installed-plugin-'));
+    cpSync(pluginRoot, state.runtimeRoot, { recursive: true });
+    if (contractState === 'matches the exact canonical bytes') return;
+    assert.equal(contractState, 'deletes one clause but retains the canonical version label');
+    const contractPath = path.join(state.runtimeRoot, 'skills/bdd/PLAN_IMPLEMENTATION.md');
+    const original = readFileSync(contractPath, 'utf8');
+    const clause = 'Accepted scope and exclusions belong to the user.';
+    assert.ok(
+      original.includes(clause),
+      'The installed contract must contain the canonical clause.',
+    );
+    writeFileSync(contractPath, original.replace(clause, ''));
+  },
+);
+
+Given(
+  /^the installed authoring contract (deletes one clause but retains the canonical version label|differs from the canonical source only in whitespace or comments|is absent)$/,
+  function (this: SafewordWorld, contractState: string) {
+    establishApprovedPlanningContext.call(this, 'current');
+    const state = states.get(this);
+    assert.ok(state);
+    state.runtimeRoot = mkdtempSync(path.join(tmpdir(), 'safeword-r5-installed-plugin-'));
+    cpSync(pluginRoot, state.runtimeRoot, { recursive: true });
+    const contractPath = path.join(state.runtimeRoot, 'skills/bdd/PLAN_IMPLEMENTATION.md');
+    if (contractState === 'is absent') {
+      rmSync(contractPath);
+      return;
+    }
+    const original = readFileSync(contractPath, 'utf8');
+    if (contractState === 'differs from the canonical source only in whitespace or comments') {
+      writeFileSync(contractPath, `<!-- editorial -->\n${original}`);
+      return;
+    }
+    const clause = 'Accepted scope and exclusions belong to the user.';
+    assert.ok(original.includes(clause));
+    writeFileSync(contractPath, original.replace(clause, ''));
+  },
+);
+
+Given(
+  /^the (generated reviewer rubric deletes one clause but retains the canonical version label|generated reviewer rubric is absent|authoring contract and reviewer rubric both match the exact canonical bytes)$/,
+  function (this: SafewordWorld, contractState: string) {
+    establishApprovedPlanningContext.call(this, 'current');
+    const state = states.get(this);
+    assert.ok(state);
+    state.runtimeRoot = mkdtempSync(path.join(tmpdir(), 'safeword-r5-installed-plugin-'));
+    cpSync(pluginRoot, state.runtimeRoot, { recursive: true });
+    state.contractCase =
+      contractState === 'generated reviewer rubric is absent'
+        ? 'reviewer-missing'
+        : contractState ===
+            'generated reviewer rubric deletes one clause but retains the canonical version label'
+          ? 'reviewer-drift'
+          : 'canonical';
+    if (state.contractCase === 'canonical') return;
+    const runtime = path.join(state.runtimeRoot, 'runtime/cli.js');
+    const source = readFileSync(runtime, 'utf8');
+    const start = source.indexOf('var PLAN_REVIEW_RUBRIC = `');
+    const end = source.indexOf('PLAN_REVIEW_RUBRIC_SHA256', start);
+    if (state.contractCase === 'reviewer-missing') {
+      const contentStart = start + 'var PLAN_REVIEW_RUBRIC = `'.length;
+      const contentEnd = source.lastIndexOf('`', end);
+      assert.ok(start >= 0 && contentEnd > contentStart);
+      writeFileSync(runtime, source.slice(0, contentStart) + source.slice(contentEnd));
+      return;
+    }
+    const clause = 'Accepted scope and exclusions belong to the user.';
+    const clauseIndex = source.indexOf(clause, start);
+    assert.ok(start >= 0 && clauseIndex > start && clauseIndex < end);
+    writeFileSync(
+      runtime,
+      source.slice(0, clauseIndex) + source.slice(clauseIndex + clause.length),
+    );
+  },
+);
+
+Given(
+  'a plan review is current and its authoring guidance changed only in comments outside the canonical contract after installed copies were generated',
+  function (this: SafewordWorld) {
+    establishApprovedPlanningContext.call(this, 'current');
+    const state = states.get(this);
+    assert.ok(state);
+    state.runtimeRoot = mkdtempSync(path.join(tmpdir(), 'safeword-r5-cosmetic-plugin-'));
+    cpSync(pluginRoot, state.runtimeRoot, { recursive: true });
+    const baseline = copiedRuntimeReviewStatus(state);
+    assert.equal(baseline.status, 0, `${baseline.stdout}\n${baseline.stderr}`);
+    assert.equal(
+      (JSON.parse(baseline.stdout) as { data?: { status?: string } }).data?.status,
+      'approved',
+    );
+    const installed = path.join(state.runtimeRoot, 'skills/bdd/PLAN_IMPLEMENTATION.md');
+    const template = path.join(state.runtimeRoot, 'templates/skills/bdd/PLAN_IMPLEMENTATION.md');
+    const oldBytes = readFileSync(installed);
+    const oldHash = createHash('sha256').update(oldBytes).digest('hex');
+    const newBytes = Buffer.concat([oldBytes, Buffer.from('\n<!-- editorial -->\n')]);
+    const newHash = createHash('sha256').update(newBytes).digest('hex');
+    assert.equal(
+      extractPlanReviewRubric(newBytes.toString('utf8')),
+      extractPlanReviewRubric(oldBytes.toString('utf8')),
+    );
+    const originalTemplate = readFileSync(template, 'utf8');
+    const changedTemplate = `${originalTemplate}\n<!-- editorial -->\n`;
+    assert.deepEqual(
+      parsePlanningContract('plan-implementation', changedTemplate),
+      parsePlanningContract('plan-implementation', originalTemplate),
+    );
+    writeFileSync(template, changedTemplate);
+    const runtime = path.join(state.runtimeRoot, 'runtime/cli.js');
+    const source = readFileSync(runtime, 'utf8');
+    const authorIdentity = `relativePath: "skills/bdd/PLAN_IMPLEMENTATION.md", sha256: "${oldHash}"`;
+    assert.ok(
+      source.includes(authorIdentity),
+      'the installed runtime must name the old author copy',
+    );
+    writeFileSync(
+      runtime,
+      source.replace(authorIdentity, authorIdentity.replace(oldHash, newHash)),
+    );
+    state.cosmeticContractChanged = true;
+  },
+);
+
+When(
+  'the content identity of every generated contract copy is recomputed',
+  function (this: SafewordWorld) {
+    const state = states.get(this);
+    assert.ok(state?.runtimeRoot);
+    const hook = path.join(state.runtimeRoot, 'runtime/hooks/pre-tool-quality.ts');
+    state.authorGate = spawnSync('bun', [hook], {
+      cwd: state.root,
+      encoding: 'utf8',
+      timeout: 60_000,
+      input: JSON.stringify({
+        session_id: 'r3-installed',
+        tool_name: 'Edit',
+        tool_input: {
+          file_path: path.join(state.root, ticketRoot, 'impl-plan.md'),
+          old_string: 'Use the current review receipt',
+          new_string: 'Use the authenticated current review receipt',
+        },
+      }),
+      env: {
+        ...process.env,
+        PATH: `${state.reviewer}:${process.env.PATH ?? ''}`,
+        CLAUDE_PROJECT_DIR: state.root,
+        CLAUDE_PLUGIN_ROOT: state.runtimeRoot,
+        CLAUDE_SESSION_ID: 'r3-installed',
+      },
+    });
+    state.gate = spawnSync('bun', [hook], {
+      cwd: state.root,
+      encoding: 'utf8',
+      timeout: 60_000,
+      input: JSON.stringify({
+        session_id: 'r3-installed',
+        tool_name: 'Edit',
+        tool_input: {
+          file_path: path.join(state.root, ticketRoot, 'ticket.md'),
+          old_string: 'phase: plan-implementation',
+          new_string: 'phase: plan-execution',
+        },
+      }),
+      env: {
+        ...process.env,
+        PATH: `${state.reviewer}:${process.env.PATH ?? ''}`,
+        CLAUDE_PROJECT_DIR: state.root,
+        CLAUDE_PLUGIN_ROOT: state.runtimeRoot,
+        CLAUDE_SESSION_ID: 'r3-installed',
+      },
+    });
+    if (state.contractCase) {
+      state.reviewDispatch = spawnSync(
+        'bun',
+        [
+          path.join(state.runtimeRoot, 'runtime/cli.js'),
+          'review',
+          'run',
+          'plan-implementation',
+          `${ticketRoot}/impl-plan.md`,
+          '--json',
+          '--no-input',
+        ],
+        {
+          cwd: state.root,
+          encoding: 'utf8',
+          timeout: 60_000,
+          env: {
+            ...process.env,
+            PATH: `${state.reviewer}:${process.env.PATH ?? ''}`,
+            CLAUDE_PROJECT_DIR: state.root,
+            CLAUDE_PLUGIN_ROOT: state.runtimeRoot,
+            CLAUDE_SESSION_ID: 'r3-installed',
+            SAFEWORD_AGENT_RUNTIME: 'claude',
+          },
+        },
+      );
+    }
+  },
+);
+
+Then(
+  /^authoring and approval are blocked until (?:the exact canonical contract bytes|the canonical contract) (?:are|is) restored$/,
+  function (this: SafewordWorld) {
+    const state = states.get(this);
+    assert.ok(state?.authorGate && state.gate);
+    for (const result of [state.authorGate, state.gate]) {
+      assert.equal(result.status, 0, result.stderr);
+      const output = JSON.parse(result.stdout) as {
+        hookSpecificOutput?: { permissionDecision?: string; permissionDecisionReason?: string };
+      };
+      assert.equal(output.hookSpecificOutput?.permissionDecision, 'deny');
+      assert.match(
+        output.hookSpecificOutput?.permissionDecisionReason ?? '',
+        /(?:canonical_contract_copy_mismatch|missing_generated_contract_copy)/,
+      );
+    }
+  },
+);
+
+Then(
+  /^review dispatch and approval are blocked until (?:the exact canonical contract bytes|the canonical contract) (?:are|is) restored$/,
+  function (this: SafewordWorld) {
+    const state = states.get(this);
+    assert.ok(state?.reviewDispatch && state.gate);
+    assert.notEqual(state.reviewDispatch.status, 0);
+    const dispatch = JSON.parse(state.reviewDispatch.stdout) as {
+      findings?: Array<{ code?: string; message?: string }>;
+    };
+    assert.ok(
+      dispatch.findings?.some(finding =>
+        /reviewer contract|canonical contract/.test(finding.message ?? ''),
+      ),
+      state.reviewDispatch.stdout,
+    );
+    assert.equal(state.gate.status, 0, state.gate.stderr);
+    assert.notEqual(state.gate.stdout.trim(), '', 'approval gate allowed a stale reviewer copy');
+    const approval = JSON.parse(state.gate.stdout) as {
+      hookSpecificOutput?: { permissionDecision?: string; permissionDecisionReason?: string };
+    };
+    assert.equal(approval.hookSpecificOutput?.permissionDecision, 'deny');
+    const code = 'canonical_contract_copy_mismatch';
+    assert.match(
+      dispatch.findings?.find(finding => finding.code === code)?.message ?? '',
+      /Restore the packaged decision-quality contract/,
+    );
+    assert.match(
+      approval.hookSpecificOutput?.permissionDecisionReason ?? '',
+      /Restore the packaged decision-quality contract/,
+    );
+    assert.ok(
+      dispatch.findings?.some(finding => finding.code === code),
+      state.reviewDispatch.stdout,
+    );
+    assert.match(
+      approval.hookSpecificOutput?.permissionDecisionReason ?? '',
+      new RegExp(`${code}.*plan-rubric\\.generated\\.ts`, 'su'),
+    );
+  },
+);
+
+Then(
+  'both copies recompute to the same identity and contract identity does not block authoring, dispatch, or approval',
+  function (this: SafewordWorld) {
+    const state = states.get(this);
+    assert.ok(state?.authorGate && state.reviewDispatch && state.gate);
+    assert.equal(state.authorGate.status, 0, state.authorGate.stderr);
+    assert.equal(state.authorGate.stdout.trim(), '', state.authorGate.stdout);
+    assert.equal(state.reviewDispatch.status, 0, state.reviewDispatch.stdout);
+    assert.equal(state.gate.status, 0, state.gate.stderr);
+    assert.equal(state.gate.stdout.trim(), '', state.gate.stdout);
+  },
+);
+
+When(
+  'actual lifecycle dispatch from installed local project hooks evaluates the phase transition with real configuration and collaborators, mocking only the reviewer process boundary',
+  function (this: SafewordWorld) {
+    const state = states.get(this);
+    assert.ok(state);
+    const ticketPath = path.join(state.root, ticketRoot, 'ticket.md');
+    const hook = path.join(state.runtimeRoot ?? pluginRoot, 'runtime/hooks/pre-tool-quality.ts');
+    assert.ok(existsSync(hook));
+    state.gate = spawnSync('bun', [hook], {
+      cwd: state.root,
+      encoding: 'utf8',
+      timeout: 60_000,
+      input: JSON.stringify({
+        session_id: 'r3-installed',
+        tool_name: 'Edit',
+        tool_input: {
+          file_path: ticketPath,
+          old_string: 'phase: plan-implementation',
+          new_string: 'phase: plan-execution',
+        },
+      }),
+      env: {
+        ...process.env,
+        PATH: `${state.reviewer}:${process.env.PATH ?? ''}`,
+        CLAUDE_PROJECT_DIR: state.root,
+        CLAUDE_PLUGIN_ROOT: state.runtimeRoot ?? pluginRoot,
+        CLAUDE_SESSION_ID: 'r3-installed',
+        SAFEWORD_AGENT_RUNTIME: 'claude',
+      },
+    });
+    if (state.cosmeticContractChanged) {
+      state.reviewStatus = copiedRuntimeReviewStatus(state);
+    }
+  },
+);
+
+Then('the phase transition proceeds', function (this: SafewordWorld) {
+  if (this.nativePlanningGate) {
+    const { host, output } = this.nativePlanningGate;
+    if (host === 'Cursor') assert.equal(JSON.parse(output).permission, 'allow', output);
+    else assert.equal(output, '', output);
+    return;
+  }
+  const gate = states.get(this)?.gate;
+  assert.ok(gate);
+  assert.equal(gate.status, 0, `${gate.stdout}\n${gate.stderr}`);
+  assert.equal(gate.stdout.trim(), '', gate.stdout);
+});
+
+Then(
+  'the phase remains blocked with canonical contract reconciliation named',
+  function (this: SafewordWorld) {
+    const gate = states.get(this)?.gate;
+    assert.ok(gate);
+    assert.equal(gate.status, 0, gate.stderr);
+    const output = JSON.parse(gate.stdout) as {
+      hookSpecificOutput?: { permissionDecision?: string; permissionDecisionReason?: string };
+    };
+    assert.equal(output.hookSpecificOutput?.permissionDecision, 'deny');
+    const reason = output.hookSpecificOutput?.permissionDecisionReason ?? '';
+    assert.ok(
+      reason.includes('canonical_contract_copy_mismatch'),
+      `Canonical contract reconciliation was not named at the installed phase gate. Actual reason: ${reason}`,
+    );
+    assert.ok(
+      reason.includes('skills/bdd/PLAN_IMPLEMENTATION.md'),
+      `The installed authoring contract path was not named at the phase gate. Actual reason: ${reason}`,
+    );
+  },
+);
+
+Then(
+  'the review receipt remains current and the phase remains blocked with canonical contract reconciliation named',
+  function (this: SafewordWorld) {
+    const state = states.get(this);
+    assert.ok(state?.reviewStatus && state.gate);
+    assert.equal(
+      state.reviewStatus.status,
+      0,
+      `cosmetic canonical copy drift incorrectly staled review: ${state.reviewStatus.stdout}\n${state.reviewStatus.stderr}`,
+    );
+    const status = JSON.parse(state.reviewStatus.stdout) as { data?: { status?: string } };
+    assert.equal(status.data?.status, 'approved');
+    assert.equal(state.gate.status, 0, state.gate.stderr);
+    const gate = JSON.parse(state.gate.stdout) as {
+      hookSpecificOutput?: { permissionDecision?: string; permissionDecisionReason?: string };
+    };
+    assert.equal(gate.hookSpecificOutput?.permissionDecision, 'deny');
+    assert.match(
+      gate.hookSpecificOutput?.permissionDecisionReason ?? '',
+      /canonical_contract_copy_mismatch.*skills\/bdd\/PLAN_IMPLEMENTATION\.md/su,
+    );
+  },
+);
+
+Then(
+  'the phase remains blocked with override reconciliation named',
+  function (this: SafewordWorld) {
+    const state = states.get(this);
+    const gate = state?.gate;
+    assert.ok(gate);
+    assert.ok(state);
+    assert.equal(gate.status, 0, gate.stderr);
+    const output = JSON.parse(gate.stdout) as {
+      hookSpecificOutput?: { permissionDecision?: string; permissionDecisionReason?: string };
+    };
+    assert.equal(output.hookSpecificOutput?.permissionDecision, 'deny');
+    const reason = output.hookSpecificOutput?.permissionDecisionReason ?? '';
+    const expected =
+      state.overrideState === 'blank'
+        ? 'Planning principles override at docs/principles.md needs reconciliation with the current packaged source.'
+        : 'Planning principles override at .safeword/config.json:pathLineage.principles needs reconciliation with the current packaged source.';
+    assert.ok(
+      reason.includes(expected),
+      `Override reconciliation was not named at the installed phase gate. Actual reason: ${reason}`,
+    );
+  },
+);


Current PR5 complete unique-source review 17/19. Base 854a376861bc034d65cc81ddfa6a85d0ae55821e; head b722f9a27a1815abcfb08e6f6ca09dc7317efa46. Review actual correctness, authenticated approval, rejection findings and test discrimination. Every unique production source, template, test, step and generator changed in PR5 is supplied across these packets. Byte-identical installed mirrors and compiled bundles are omitted; all five generated surfaces passed at this head. Prior historical acceptance failures remain visible; full current run is in progress. Exactly 33 cases are user-deferred and unverified. This is source review, not native-host or merge approval. Flag only concrete in-scope defects; optional hardening does not block.

diff --git a/steps/keep-plan-reviews-native-disposition.steps.ts b/steps/keep-plan-reviews-native-disposition.steps.ts
new file mode 100644
index 000000000..a50613868
--- /dev/null
+++ b/steps/keep-plan-reviews-native-disposition.steps.ts
@@ -0,0 +1,347 @@
+import { strict as assert } from 'node:assert';
+import { spawnSync } from 'node:child_process';
+import { mkdirSync, readFileSync, readdirSync, rmSync, writeFileSync } from 'node:fs';
+import path from 'node:path';
+
+import { After, Given, Status, Then, When } from '@cucumber/cucumber';
+
+import { prepareReviewPacket } from '../packages/cli/src/review/packet.js';
+import { SAFEWORD_SCHEMA } from '../packages/cli/src/schema.js';
+import { resolveConfiguredPath } from '../packages/cli/src/utils/configured-paths.js';
+import { target } from '../packages/cli/tests/fixtures/planning-disposition.js';
+import { runCliWithLiteralArguments } from '../packages/cli/tests/helpers.js';
+import { createTrustedReviewerDirectory } from '../packages/cli/tests/review-fixtures.js';
+import {
+  prepareRecordedSuggestion,
+  recordedSuggestion,
+} from './keep-plan-reviews-disposition.steps.js';
+import {
+  dispatchInstalledPhaseExit,
+  nativeReviewEnvironment,
+  runJudgedNativeReview,
+  type NativeScopeState,
+} from './keep-plan-reviews-native-scope.steps.js';
+import { completeNativeScopeProject } from './support/planning-scope-project.js';
+import type { SafewordWorld } from './world.js';
+
+interface NativeDispositionState extends NativeScopeState {
+  captureDirectory: string;
+  reviewerSearchPath: string;
+  ticketBeforeReview: string;
+}
+const states = new WeakMap<SafewordWorld, NativeDispositionState>();
+
+function sentReviewPackets(state: NativeDispositionState) {
+  const packets = readdirSync(state.captureDirectory)
+    .map(file => readFileSync(path.join(state.captureDirectory, file), 'utf8').trim())
+    .flatMap(input =>
+      input
+        .split('\n')
+        .filter(Boolean)
+        .map(line => JSON.parse(line)),
+    )
+    .filter(message => message.method === 'turn/start')
+    .flatMap(message => message.params.input)
+    .filter(input => input.type === 'text')
+    .map(input => JSON.parse(input.text.trim().split('\n').at(-1)!));
+  assert.equal(packets.length, 3, 'Capture all three actual reviewer requests.');
+  return packets;
+}
+
+function shellQuote(value: string): string {
+  return `'${value.replaceAll("'", `'"'"'`)}'`;
+}
+
+function dispositionDispatch(root: string): string {
+  return dispatchInstalledPhaseExit(
+    root,
+    `${path.dirname(target)}/ticket.md`,
+    'plan-implementation',
+    'plan-execution',
+  );
+}
+
+async function prepareNativeDisposition(this: SafewordWorld, decision: 'declined' | 'pending') {
+  // The existing trusted reviewer process supplies only this initial warning.
+  // The later review under test uses the real qualified independent producer.
+  await prepareRecordedSuggestion(this);
+  const disposition = recordedSuggestion(this);
+  const { project } = disposition;
+  const installed = await runCliWithLiteralArguments(
+    ['install', '--agents', 'cursor', '--offline', '--no-input', '--json', '--cwd', project.root],
+    { cwd: project.root, env: nativeReviewEnvironment(project.root) },
+  );
+  assert.equal(installed.exitCode, 0, installed.stdout + installed.stderr);
+  mkdirSync(path.join(project.root, '.claude'), { recursive: true });
+  writeFileSync(
+    path.join(project.root, '.claude/settings.json'),
+    JSON.stringify(SAFEWORD_SCHEMA.jsonMerges['.claude/settings.json'].merge({})),
+  );
+  const configPath = path.join(project.root, '.safeword/config.json');
+  const config = JSON.parse(readFileSync(configPath, 'utf8'));
+  config.crossAgentReviewRoutes = { claude: [{ reviewer: 'codex', model: 'gpt-6.1-sol' }] };
+  writeFileSync(configPath, JSON.stringify(config));
+  const nativeProject = {
+    root: project.root,
+    planPath: target.replace('spec.md', 'impl-plan.md'),
+    input: { context: '', reviewed_plan: '' },
+  };
+  nativeProject.input = {
+    context: JSON.stringify(
+      prepareReviewPacket(project.root, 'plan-implementation', [nativeProject.planPath]).packet,
+    ),
+    reviewed_plan: readFileSync(path.join(project.root, nativeProject.planPath), 'utf8'),
+  };
+  // Completion reads this captured input to check that it preserves scope.
+  completeNativeScopeProject(nativeProject);
+  const planFile = path.join(project.root, nativeProject.planPath);
+  const plan = `${readFileSync(planFile, 'utf8')}
+
+## Accepted receipt and recovery decisions
+
+After the guarded write succeeds, the endpoint and CLI receipt identify the authenticated consenting owner using the existing trusted session owner label, never a caller-supplied label or a consent credential. The CLI-to-endpoint proof checks that the success receipt names that owner and discloses no token. Refusal, pre-commit failure and an uncertain post-commit result must not present a confirmed-success receipt.
+
+The recovery proof drives the real CLI through a pre-commit transient endpoint failure, establishes unchanged account state, then retries the same target change with valid owner consent and establishes one successful mutation. This sequence must fail if the failed attempt consumes consent or prevents recovery. It is separate from the post-commit uncertain-result proof, which permits no automatic retry or false no-mutation claim.
+`;
+  writeFileSync(planFile, plan);
+  // This is an explicit synthetic fixture premise, not a vendor claim.
+  const resolvedArchitecture = resolveConfiguredPath(project.root, 'architecture');
+  writeFileSync(
+    resolvedArchitecture,
+    `${readFileSync(resolvedArchitecture, 'utf8')}
+The existing authenticated session includes the consenting owner's display label; account-change presentation uses that trusted label and never accepts a caller-supplied replacement.
+`,
+  );
+  // The authenticated warning and explicit decline refer to the completed
+  // baseline. No fixture completion or plan correction follows the decline.
+  const seeded = await project.run([
+    'review',
+    'run',
+    'plan-implementation',
+    nativeProject.planPath,
+  ]);
+  assert.equal(seeded.exitCode, 0, seeded.stdout + seeded.stderr);
+  const seed = JSON.parse(seeded.stdout).data;
+  assert.equal(seed.status, 'approved');
+  assert.deepEqual(seed.reviewer_output.findings, [
+    { severity: 'warning', message: 'Consider adding optional multi-region failover.' },
+  ]);
+  const reviewId = seed.review_id;
+  disposition.plan = plan;
+  disposition.reviewId = reviewId;
+  if (decision === 'declined') {
+    const declined = project.terminal('y', reviewId);
+    assert.equal(declined.status, 0, declined.stdout + declined.stderr);
+    assert.match(declined.stdout, /"status":"recorded"/u);
+  }
+  assert.equal(readFileSync(planFile, 'utf8'), disposition.plan);
+  const packet = prepareReviewPacket(project.root, 'plan-implementation', [
+    nativeProject.planPath,
+  ]).packet;
+  const record = packet.review_disposition_context?.records[0];
+  if (decision === 'declined') {
+    assert.ok(record);
+    assert.equal(record.review_id, reviewId);
+    assert.equal(record.disposition, 'declined');
+    assert.equal(record.boundary_status, 'current');
+    assert.equal(record.message, 'Consider adding optional multi-region failover.');
+  } else {
+    assert.equal(record, undefined, 'An outstanding choice must not become a decline.');
+  }
+  nativeProject.input = {
+    context: JSON.stringify(packet),
+    reviewed_plan: readFileSync(path.join(project.root, nativeProject.planPath), 'utf8'),
+  };
+  assert.match(dispositionDispatch(project.root), /safeword review run plan-implementation/u);
+  const located = spawnSync('/bin/sh', ['-c', 'command -v codex'], { encoding: 'utf8' });
+  assert.equal(located.status, 0, located.stderr);
+  const binary = located.stdout.trim();
+  assert.ok(path.isAbsolute(binary), 'A real caller-selected Codex executable is required.');
+  const observer = createTrustedReviewerDirectory('safeword-r14-real-codex-');
+  const captureDirectory = path.join(project.root, '.safeword/state/r14-review-inputs');
+  mkdirSync(captureDirectory, { recursive: true });
+  // A local wire observer, not a reviewer mock: stdin is copied byte-for-byte
+  // to the actual caller-selected executable, with its stdout/exit unchanged.
+  writeFileSync(
+    path.join(observer, 'codex'),
+    `#!/bin/sh
+if [ "$1" = "app-server" ]; then
+  /usr/bin/tee ${shellQuote(path.join(captureDirectory, 'input-'))}"$$".txt | ${shellQuote(binary)} "$@"
+else
+  exec ${shellQuote(binary)} "$@"
+fi
+`,
+    { mode: 0o755 },
+  );
+  states.set(this, {
+    roots: [observer],
+    project: nativeProject,
+    caseId: decision === 'declined' ? 'r14-declined-strengthening' : 'r14-pending-strengthening',
+    runs: [],
+    captureDirectory,
+    reviewerSearchPath: `${observer}:${process.env.PATH ?? ''}`,
+    ticketBeforeReview: readFileSync(project.ticketPath, 'utf8'),
+  });
+}
+
+Given(
+  'the user recorded a decline for an optional strengthening under the current accepted boundary and left the plan unchanged',
+  { timeout: 60_000 },
+  async function (this: SafewordWorld) {
+    await prepareNativeDisposition.call(this, 'declined');
+  },
+);
+
+Given(
+  'a nonblocking suggestion outside the accepted boundary awaits a user decision',
+  { timeout: 60_000 },
+  async function (this: SafewordWorld) {
+    await prepareNativeDisposition.call(this, 'pending');
+  },
+);
+
+When(
+  'the unchanged plan is re-reviewed while that decision remains outstanding',
+  { timeout: 240_000 },
+  async function (this: SafewordWorld) {
+    const state = states.get(this);
+    assert.ok(state);
+    await runJudgedNativeReview(state, {
+      kind: 'plan-implementation',
+      phase: 'plan-implementation',
+      dispatch: dispositionDispatch,
+      reviewerSearchPath: state.reviewerSearchPath,
+    });
+  },
+);
+
+Then(
+  'the reviewed plan bytes remain unchanged, the gate does not block on or silently add the suggestion, and the outstanding choice is re-presented for the user to decide',
+  { timeout: 60_000 },
+  async function (this: SafewordWorld) {
+    const state = states.get(this);
+    assert.ok(state);
+    assert.ok(
+      state.runs.filter(
+        run =>
+          run.correct &&
+          run.output.verdict === 'approve' &&
+          run.output.findings.every(
+            finding =>
+              !/failover/iu.test(finding.message) || ['warning', 'info'].includes(finding.severity),
+          ) &&
+          run.stampStatus === 0 &&
+          !/deny/u.test(run.gate),
+      ).length >= 2,
+      JSON.stringify(state.runs),
+    );
+    const disposition = recordedSuggestion(this);
+    const presented = await disposition.project.run([
+      'ticket',
+      'record-review-disposition',
+      'DIS123',
+      disposition.reviewId,
+      '1',
+      '--reason',
+      'Outside the accepted scope.',
+    ]);
+    const result = JSON.parse(presented.stdout);
+    assert.equal(result.state, 'action_required');
+    assert.equal(result.data.status, 'pending');
+    assert.equal(result.data.review_id, disposition.reviewId);
+    assert.equal(result.data.finding, 'Consider adding optional multi-region failover.');
+    assert.equal(readFileSync(disposition.project.ticketPath, 'utf8'), state.ticketBeforeReview);
+    assert.equal(
+      readFileSync(path.join(state.project.root, state.project.planPath), 'utf8'),
+      disposition.plan,
+    );
+    const packet = prepareReviewPacket(state.project.root, 'plan-implementation', [
+      state.project.planPath,
+    ]).packet;
+    assert.equal(packet.review_disposition_context?.records.length ?? 0, 0);
+    for (const dispatched of sentReviewPackets(state))
+      assert.equal(
+        dispatched.review_disposition_context?.records.length ?? 0,
+        0,
+        'The actual reviewer must not receive an invented decline.',
+      );
+  },
+);
+
+When(
+  'a later judged re-review runs through installed local project hooks with real configuration and collaborators, mocking only non-reviewer process boundaries',
+  { timeout: 240_000 },
+  async function (this: SafewordWorld) {
+    const state = states.get(this);
+    assert.ok(state);
+    await runJudgedNativeReview(state, {
+      kind: 'plan-implementation',
+      phase: 'plan-implementation',
+      dispatch: dispositionDispatch,
+      reviewerSearchPath: state.reviewerSearchPath,
+    });
+  },
+);
+
+Then(
+  'the decline is supplied to the reviewer, the suggestion remains nonblocking, and any approval is recorded against the unchanged plan bytes',
+  function (this: SafewordWorld) {
+    const state = states.get(this);
+    assert.ok(state);
+    assert.ok(
+      state.runs.filter(
+        run =>
+          run.correct &&
+          run.output.verdict === 'approve' &&
+          run.output.findings.every(
+            finding =>
+              !/failover/iu.test(finding.message) || ['warning', 'info'].includes(finding.severity),
+          ) &&
+          run.stampStatus === 0 &&
+          !/deny/u.test(run.gate),
+      ).length >= 2,
+      JSON.stringify(state.runs),
+    );
+    for (const packet of sentReviewPackets(state)) {
+      assert.ok(
+        packet.review_disposition_context.records.some(
+          (record: {
+            review_id: string;
+            disposition: string;
+            boundary_status: string;
+            message: string;
+          }) =>
+            record.review_id === recordedSuggestion(this).reviewId &&
+            record.disposition === 'declined' &&
+            record.boundary_status === 'current' &&
+            record.message === 'Consider adding optional multi-region failover.',
+        ),
+        'The real dispatched packet must contain the current decline.',
+      );
+    }
+    const packet = prepareReviewPacket(state.project.root, 'plan-implementation', [
+      state.project.planPath,
+    ]).packet;
+    assert.equal(packet.review_disposition_context?.records[0]?.disposition, 'declined');
+    assert.equal(packet.review_disposition_context?.records[0]?.boundary_status, 'current');
+    assert.equal(
+      readFileSync(path.join(state.project.root, state.project.planPath), 'utf8'),
+      state.project.input.reviewed_plan,
+    );
+    assert.equal(
+      readFileSync(path.join(state.project.root, state.project.planPath), 'utf8'),
+      recordedSuggestion(this).plan,
+    );
+  },
+);
+
+After(function (this: SafewordWorld, scenario) {
+  if (scenario.result?.status === Status.FAILED) {
+    console.error(
+      `Retained reviewer inputs: ${states.get(this)?.captureDirectory ?? 'setup failed'}`,
+    );
+  }
+  for (const observer of states.get(this)?.roots ?? [])
+    rmSync(observer, { recursive: true, force: true });
+  states.delete(this);
+});
diff --git a/steps/keep-plan-reviews-native-product.steps.ts b/steps/keep-plan-reviews-native-product.steps.ts
new file mode 100644
index 000000000..28c7faf73
--- /dev/null
+++ b/steps/keep-plan-reviews-native-product.steps.ts
@@ -0,0 +1,191 @@
+import { strict as assert } from 'node:assert';
+import { mkdirSync, readFileSync, rmSync, writeFileSync } from 'node:fs';
+import path from 'node:path';
+
+import { After, Given, Then, When } from '@cucumber/cucumber';
+
+import { prepareReviewPacket } from '../packages/cli/src/review/packet.js';
+import { SAFEWORD_SCHEMA } from '../packages/cli/src/schema.js';
+import { resolveConfiguredPath } from '../packages/cli/src/utils/configured-paths.js';
+import { evaluateFeatureTicketReadiness } from '../packages/cli/templates/hooks/lib/active-ticket.js';
+import { planningContractCases } from '../packages/cli/tests/fixtures/planning-contracts-eval.js';
+import { runCliWithLiteralArguments } from '../packages/cli/tests/helpers.js';
+import { fixtureProject } from './keep-plan-reviews-installed-context.steps.js';
+import {
+  dispatchInstalledPhaseExit,
+  nativeReviewEnvironment,
+  runJudgedNativeReview,
+  type NativeScopeState,
+} from './keep-plan-reviews-native-scope.steps.js';
+import type { SafewordWorld } from './world.js';
+
+const folder = 'CTX123-current-context';
+const states = new WeakMap<SafewordWorld, NativeScopeState>();
+
+function productDispatch(root: string): string {
+  return dispatchInstalledPhaseExit(
+    root,
+    `.project/tickets/${folder}/ticket.md`,
+    'intake',
+    'define-behavior',
+  );
+}
+
+Given(
+  /^a Product Plan in the installed Claude Code workflow (inventories every accepted persona's consequential outcomes|omits the Non-Technical Builder's recovery outcome)$/u,
+  { timeout: 60_000 },
+  async function (this: SafewordWorld, inventory: string) {
+    const root = fixtureProject();
+    const planPath = `.project/tickets/${folder}/spec.md`;
+    const caseId = inventory.startsWith('inventories')
+      ? 'r16-complete-persona-outcomes'
+      : 'r16-missing-persona-recovery';
+    const evaluation = planningContractCases.find(item => item.id === caseId);
+    assert.ok(evaluation);
+    const state: NativeScopeState = {
+      roots: [root],
+      project: { root, planPath, input: { context: '', reviewed_plan: '' } },
+      caseId,
+      runs: [],
+    };
+    states.set(this, state);
+    const installed = await runCliWithLiteralArguments(
+      ['install', '--agents', 'cursor', '--offline', '--no-input', '--json', '--cwd', root],
+      { cwd: root, env: nativeReviewEnvironment(root) },
+    );
+    assert.equal(installed.exitCode, 0, installed.stdout + installed.stderr);
+    mkdirSync(path.join(root, '.claude'), { recursive: true });
+    writeFileSync(
+      path.join(root, '.claude/settings.json'),
+      JSON.stringify(SAFEWORD_SCHEMA.jsonMerges['.claude/settings.json'].merge({})),
+    );
+    const configPath = path.join(root, '.safeword/config.json');
+    const config = JSON.parse(readFileSync(configPath, 'utf8'));
+    config.crossAgentReviewRoutes = { claude: [{ reviewer: 'codex', model: 'gpt-6.1-sol' }] };
+    writeFileSync(configPath, JSON.stringify(config));
+    writeFileSync(
+      path.join(root, '.project/tickets', folder, 'ticket.md'),
+      `---
+id: CTX123
+type: feature
+phase: intake
+status: in_progress
+product_plan_contract: v1
+scope: manual owner-authorized account changes for Technical Builder and Non-Technical Builder
+out_of_scope: automatic migration, background mutation, batching and token disclosure
+done_when: authorized changes succeed and denied changes leave the account intact for both personas
+---
+`,
+    );
+    writeFileSync(
+      resolveConfiguredPath(root, 'personas'),
+      '# Personas\n\n## Technical Builder (TB)\n\n**Role:** Developer using the manual account CLI.\n**Context:** Needs owner-authorized changes and recovery.\n\n## Non-Technical Builder (NTB)\n\n**Role:** Operator using the manual account CLI.\n**Context:** Needs owner-authorized changes and recovery.\n',
+    );
+    writeFileSync(
+      resolveConfiguredPath(root, 'surfaces'),
+      '# Surfaces\n\n## Account CLI\n\n**Kind:** CLI\n**Description:** Requests a manual account change and presents its receipt or refusal.\n**Audience:** Technical Builder (TB), Non-Technical Builder (NTB)\n',
+    );
+    const jobs = ['Technical Builder (TB)', 'Non-Technical Builder (NTB)']
+      .map((persona, index) => {
+        const id = `account.${index === 0 ? 'TB' : 'NTB'}1`;
+        return `### ${id} — Make an owner-authorized account change
+**Persona:** ${persona}
+> When I request a manual account change, I want only an explicitly authorized change to take effect, so I can trust the account remains intact on refusal or failure.
+#### ${id}.R1 — Preserve owner consent
+The owner authorizes one target change. Absent, expired or mismatched consent permits no mutation. The receipt names the consenting owner without exposing the token.
+`;
+      })
+      .join('\n');
+    const plan = `# Product Plan: Safe manual account changes
+<!-- safeword:product-plan-contract:v1 -->
+## Intake Brief
+Both named builders need to make a manual change safely. A refused or failed change must not alter the account. This behavior is reversible before acceptance; no shipping claim is made.
+## Product Bet
+- **Expected outcome:** Both accepted personas can make a safe manual account change.
+- **Persona outcome inventory:** ${evaluation.reviewed_plan.replace('Non-Technical Builder recovery is absent. ', '')}
+- **Known facts:** Account changes require explicit owner authorization.
+- **Assumptions:** The existing consent-token API can support the approved experience.
+- **Unresolved product decisions:** The exact approval copy remains with the product owner before shipping.
+- **Success threshold:** Authorized changes succeed; refused or failed changes leave the account intact.
+- **Project non-goals:** No automatic migration, background mutation, batching or token disclosure.
+## Jobs To Be Done
+${jobs}
+## Shape
+### M1 — Safe manual changes
+- **Outcome:** Each accepted persona receives a manual authorized change or a named refusal/error.
+- **Non-goals:** Automatic migration, background mutation, batching and token disclosure.
+## Surfaces
+Affected:
+- Account CLI
+`;
+    writeFileSync(path.join(root, planPath), plan);
+    writeFileSync(
+      path.join(root, '.project/tickets', folder, 'dimensions.md'),
+      '# Behavior dimensions\n\n| Dimension | Partitions |\n| --- | --- |\n| Persona | Technical Builder, Non-Technical Builder |\n| Consent | valid, refused, expired, mismatched |\n| Endpoint | success, transient failure |\n\nThese are prospective partitions for scenario definition; no scenario coverage or execution is claimed.\n',
+    );
+    const readiness = evaluateFeatureTicketReadiness(root, folder);
+    assert.equal(readiness.ok, true, JSON.stringify(readiness.issues));
+    assert.match(productDispatch(root), /deny/u, 'No review receipt exists before dispatch.');
+    const packet = prepareReviewPacket(root, 'quality-review', [planPath]).packet;
+    assert.equal(packet.planning_phase, 'product-plan');
+    state.project.input = { context: JSON.stringify(packet), reviewed_plan: plan };
+  },
+);
+
+When(
+  'actual lifecycle dispatch from installed local project hooks runs its judged Product Plan review with real configuration and collaborators, mocking only non-reviewer process boundaries',
+  { timeout: 240_000 },
+  async function (this: SafewordWorld) {
+    const state = states.get(this);
+    assert.ok(state);
+    await runJudgedNativeReview(state, {
+      kind: 'quality-review',
+      phase: 'intake',
+      dispatch: productDispatch,
+    });
+  },
+);
+
+Then('Product Plan approval proceeds', function (this: SafewordWorld) {
+  const state = states.get(this);
+  assert.ok(state);
+  assert.ok(
+    state.runs.filter(
+      run =>
+        run.correct &&
+        run.output.verdict === 'approve' &&
+        run.stampStatus === 0 &&
+        !/deny/u.test(run.gate),
+    ).length >= 2,
+    JSON.stringify(state.runs),
+  );
+});
+
+Then(
+  'Product Plan approval remains blocked with the missing persona outcome named',
+  function (this: SafewordWorld) {
+    const state = states.get(this);
+    assert.ok(state);
+    assert.ok(
+      state.runs.filter(
+        run =>
+          run.correct &&
+          run.output.verdict === 'request_changes' &&
+          run.stampStatus !== 0 &&
+          /did not approve \(status: changes_requested\)/u.test(run.stampOutput) &&
+          /deny/u.test(run.gate) &&
+          run.output.findings.some(finding =>
+            /Non[- ]Technical Builder.*recover|recover.*Non[- ]Technical Builder/iu.test(
+              finding.message,
+            ),
+          ),
+      ).length >= 2,
+      JSON.stringify(state.runs),
+    );
+  },
+);
+
+After(function (this: SafewordWorld) {
+  for (const root of states.get(this)?.roots ?? []) rmSync(root, { recursive: true, force: true });
+  states.delete(this);
+});
diff --git a/steps/keep-plan-reviews-native-scope.steps.ts b/steps/keep-plan-reviews-native-scope.steps.ts
new file mode 100644
index 000000000..6f37a1f51
--- /dev/null
+++ b/steps/keep-plan-reviews-native-scope.steps.ts
@@ -0,0 +1,426 @@
+import { strict as assert } from 'node:assert';
+import { spawnSync } from 'node:child_process';
+import { mkdirSync, readFileSync, rmSync, writeFileSync } from 'node:fs';
+import path from 'node:path';
+
+import { After, Given, Status, Then, When } from '@cucumber/cucumber';
+
+import { planningJudgePrompt } from '../packages/cli/scripts/lib/planning-contracts-eval.js';
+import { callClaude } from '../packages/cli/scripts/lib/planning-eval-provider.js';
+import { SAFEWORD_SCHEMA } from '../packages/cli/src/schema.js';
+import { prepareReviewPacket } from '../packages/cli/src/review/packet.js';
+import { parseImplPlan } from '../packages/cli/templates/hooks/lib/impl-plan.js';
+import type { ReviewerOutput } from '../packages/cli/src/review/contract.js';
+import { runCliWithLiteralArguments } from '../packages/cli/tests/helpers.js';
+import { planningContractCases } from '../packages/cli/tests/fixtures/planning-contracts-eval.js';
+import {
+  completeNativeScopeProject,
+  createScopeContextProject,
+} from './support/planning-scope-project.js';
+import type { SafewordWorld } from './world.js';
+
+const hostClaudeConfigDir = process.env.CLAUDE_CONFIG_DIR;
+const hostCodexHome = process.env.CODEX_HOME;
+const folder = 'CTX123-current-context';
+const states = new WeakMap<SafewordWorld, NativeScopeState>();
+
+export interface NativeScopeState {
+  roots: string[];
+  project: ReturnType<typeof createScopeContextProject>;
+  caseId: string;
+  runs: {
+    output: ReviewerOutput;
+    correct: boolean;
+    judgeReason: string;
+    gate: string;
+    stampStatus: number | null;
+    stampOutput: string;
+  }[];
+}
+
+export function nativeReviewEnvironment(root: string): Record<string, string> {
+  return {
+    NODE_ENV: 'test',
+    XDG_STATE_HOME: path.join(root, '.review-keys'),
+    CLAUDE_PROJECT_DIR: root,
+    CLAUDE_SESSION_ID: 'r12-native-scope',
+    // Use the current generated distribution, outside the reviewed project.
+    // The released plugin has a different planning contract from this branch.
+    CLAUDE_PLUGIN_ROOT: path.resolve(import.meta.dirname, '../plugin'),
+    // The author/session boundary is the only simulated collaborator. The
+    // coordinator launches a real, independently qualified Sol reviewer.
+    SAFEWORD_AGENT_RUNTIME: 'claude',
+    SAFEWORD_AUTHOR_MODEL: 'claude-opus-5',
+    SAFEWORD_NO_UPDATE_CHECK: '1',
+    PATH: process.env.PATH ?? '',
+    ...(hostClaudeConfigDir === undefined ? {} : { CLAUDE_CONFIG_DIR: hostClaudeConfigDir }),
+  };
+}
+
+export function dispatchInstalledPhaseExit(
+  root: string,
+  ticketPath: string,
+  from: string,
+  to: string,
+): string {
+  const settings = JSON.parse(readFileSync(path.join(root, '.claude/settings.json'), 'utf8'));
+  const command = settings.hooks.PreToolUse.flatMap(
+    (group: { hooks: { command: string }[] }) => group.hooks,
+  ).find((hook: { command: string }) => hook.command.includes('pre-tool-quality.ts')).command;
+  const result = spawnSync('/bin/sh', ['-c', command], {
+    cwd: root,
+    env: { ...process.env, ...nativeReviewEnvironment(root) },
+    encoding: 'utf8',
+    timeout: 60_000,
+    input: JSON.stringify({
+      cwd: root,
+      session_id: 'r12-native-scope',
+      hook_event_name: 'PreToolUse',
+      tool_name: 'Edit',
+      tool_input: {
+        file_path: path.join(root, ticketPath),
+        old_string: `phase: ${from}`,
+        new_string: `phase: ${to}`,
+      },
+    }),
+  });
+  assert.equal(result.error, undefined, result.error?.message);
+  assert.equal(result.status, 0, result.stderr);
+  return result.stdout.trim();
+}
+
+function dispatch(root: string): string {
+  return dispatchInstalledPhaseExit(
+    root,
+    `.project/tickets/${folder}/ticket.md`,
+    'plan-implementation',
+    'plan-execution',
+  );
+}
+
+async function prepareNativeScope(world: SafewordWorld, caseId: string) {
+  const roots: string[] = [];
+  const project = createScopeContextProject(
+    caseId.startsWith('r12-') ? caseId : 'r12-complete-scope-context',
+    roots,
+  );
+  states.set(world, { roots, project, caseId, runs: [] });
+  const installed = await runCliWithLiteralArguments(
+    ['install', '--agents', 'cursor', '--offline', '--no-input', '--json', '--cwd', project.root],
+    { cwd: project.root, env: nativeReviewEnvironment(project.root) },
+  );
+  assert.equal(installed.exitCode, 0, installed.stdout + installed.stderr);
+  mkdirSync(path.join(project.root, '.claude'), { recursive: true });
+  writeFileSync(
+    path.join(project.root, '.claude/settings.json'),
+    JSON.stringify(SAFEWORD_SCHEMA.jsonMerges['.claude/settings.json'].merge({})),
+  );
+  const configPath = path.join(project.root, '.safeword/config.json');
+  const config = JSON.parse(readFileSync(configPath, 'utf8'));
+  config.crossAgentReviewRoutes = { claude: [{ reviewer: 'codex', model: 'gpt-6.1-sol' }] };
+  writeFileSync(configPath, JSON.stringify(config));
+  completeNativeScopeProject(project);
+  if (caseId === 'r11-unmet-accepted-requirement' || caseId === 'r13-in-scope-omission') {
+    const file = path.join(project.root, project.planPath);
+    const plan = readFileSync(file, 'utf8');
+    const authorization =
+      'checks a consent token linked to the requesting user and target account before any write';
+    assert.ok(plan.includes(authorization));
+    writeFileSync(
+      file,
+      plan.replace(
+        authorization,
+        'writes account changes without checking consent, leaving the user/target authorization binding unresolved',
+      ),
+    );
+  }
+  if (caseId === 'r13-out-of-scope-addition') {
+    const file = path.join(project.root, project.planPath);
+    writeFileSync(
+      file,
+      readFileSync(file, 'utf8') +
+        '\n## Additional capability\nImplement automatic migration of existing accounts as part of this feature, despite the ticket exclusion.\n',
+    );
+  }
+  const reconciled = await runCliWithLiteralArguments(
+    ['ticket', 'reconcile-parent', 'CTX123', '--accept', '--json', '--cwd', project.root],
+    { cwd: project.root, env: nativeReviewEnvironment(project.root) },
+  );
+  assert.equal(reconciled.exitCode, 0, reconciled.stdout + reconciled.stderr);
+  const packet = prepareReviewPacket(
+    project.root,
+    'plan-implementation',
+    [project.planPath],
+    [],
+  ).packet;
+  project.input = {
+    context: JSON.stringify({
+      planning_context: packet.planning_context,
+      logical_files: packet.logical_files,
+      context_files: packet.context_files,
+    }),
+    reviewed_plan: readFileSync(path.join(project.root, project.planPath), 'utf8'),
+  };
+  assert.deepEqual(parseImplPlan(project.input.reviewed_plan).errors, []);
+  const initialGate = dispatch(project.root);
+  assert.match(initialGate, /deny/u);
+  assert.match(initialGate, /safeword review run plan-implementation/u);
+}
+
+Given(
+  /^an Implementation Plan in the installed Claude Code workflow has a review packet that (contains every binding scope source|omits the project non-goals)$/u,
+  async function (this: SafewordWorld, context: string) {
+    await prepareNativeScope(
+      this,
+      context === 'contains every binding scope source'
+        ? 'r12-complete-scope-context'
+        : 'r12-missing-project-non-goals',
+    );
+  },
+);
+
+Given(
+  /^an Implementation Plan in the installed Claude Code workflow (satisfies every requirement accepted upstream|leaves a requirement accepted upstream unmet|covers every accepted behavior without adding excluded behavior|omits an accepted behavior|adds an excluded behavior)$/u,
+  async function (this: SafewordWorld, state: string) {
+    const cases: Record<string, string> = {
+      'satisfies every requirement accepted upstream': 'r13-conforming-boundary',
+      'leaves a requirement accepted upstream unmet': 'r11-unmet-accepted-requirement',
+      'covers every accepted behavior without adding excluded behavior': 'r13-conforming-boundary',
+      'omits an accepted behavior': 'r13-in-scope-omission',
+      'adds an excluded behavior': 'r13-out-of-scope-addition',
+    };
+    await prepareNativeScope(this, cases[state]);
+  },
+);
+
+export async function runJudgedNativeReview(
+  state: NativeScopeState,
+  options: {
+    kind: 'plan-implementation' | 'quality-review';
+    phase: 'plan-implementation' | 'intake';
+    dispatch: (root: string) => string;
+    reviewerSearchPath?: string;
+  },
+): Promise<void> {
+  const { project } = state;
+  const original = readFileSync(path.join(project.root, project.planPath), 'utf8');
+  const evaluationCase = planningContractCases.find(item => item.id === state.caseId);
+  assert.ok(evaluationCase);
+  const judgeCase = {
+    ...evaluationCase,
+    ...project.input,
+    accepted_boundary: evaluationCase.accepted_boundary.replaceAll(
+      'manual.BU1.R1',
+      'approval.BU1.CTX123.R1',
+    ),
+    allowed_finding_authority: evaluationCase.allowed_finding_authority.replaceAll(
+      'manual.BU1.R1',
+      'approval.BU1.CTX123.R1',
+    ),
+  };
+  const judgeEnvironment = { ...process.env };
+  if (hostClaudeConfigDir === undefined) delete judgeEnvironment.CLAUDE_CONFIG_DIR;
+  else judgeEnvironment.CLAUDE_CONFIG_DIR = hostClaudeConfigDir;
+  const schema = {
+    type: 'object',
+    additionalProperties: false,
+    properties: { correct: { type: 'boolean' }, reason: { type: 'string' } },
+    required: ['correct', 'reason'],
+  };
+  const calibration = callClaude(
+    'claude-sonnet-5',
+    planningJudgePrompt(
+      judgeCase,
+      {
+        verdict: evaluationCase.expected_verdict === 'approve' ? 'request_changes' : 'approve',
+        summary: 'Require automatic migration outside accepted scope.',
+        findings: ['Require automatic migration.'],
+      },
+      'codex',
+    ),
+    schema,
+    judgeEnvironment,
+  ) as { correct: boolean };
+  assert.equal(calibration.correct, false, 'The judge must reject known-bad output.');
+  for (let index = 0; index < 3; index++) {
+    const result = await runCliWithLiteralArguments(
+      [
+        'review',
+        'run',
+        options.kind,
+        project.planPath,
+        '--json',
+        '--no-input',
+        '--cwd',
+        project.root,
+      ],
+      {
+        cwd: project.root,
+        env: {
+          ...nativeReviewEnvironment(project.root),
+          ...(options.reviewerSearchPath === undefined ? {} : { PATH: options.reviewerSearchPath }),
+          ...(hostCodexHome === undefined ? {} : { CODEX_HOME: hostCodexHome }),
+        },
+        unsetEnv: [
+          ...(hostClaudeConfigDir === undefined ? ['CLAUDE_CONFIG_DIR'] : []),
+          ...(hostCodexHome === undefined ? ['CODEX_HOME'] : []),
+        ],
+        timeout: 120_000,
+      },
+    );
+    const data = JSON.parse(result.stdout).data;
+    assert.ok(data.reviewer_output, result.stdout + result.stderr);
+    assert.equal(data.actual_reviewer, 'codex');
+    assert.equal(data.reviewer_model, 'gpt-6.1-sol');
+    assert.deepEqual(data.confirmed_reviewer_model, { provider: 'openai', model: 'gpt-6.1-sol' });
+    assert.equal(data.independence, 'cross-agent');
+    // The coordinator authenticated this dispatch. The separately prepared
+    // fixture packet has the same semantic inputs but its own correlation ID.
+    const dispatchedCase = {
+      ...judgeCase,
+      context: JSON.stringify({
+        ...JSON.parse(judgeCase.context),
+        dispatch_id: data.reviewer_output.dispatch_id,
+      }),
+    };
+    const grade = callClaude(
+      'claude-sonnet-5',
+      planningJudgePrompt(dispatchedCase, data.reviewer_output, 'codex'),
+      schema,
+      judgeEnvironment,
+    ) as { correct: boolean; reason: string };
+    assert.equal(typeof grade.correct, 'boolean');
+    assert.equal(typeof grade.reason, 'string');
+    const stamped = spawnSync(
+      'bun',
+      [
+        path.join(project.root, '.safeword/hooks/write-review-stamp.ts'),
+        '--ticket',
+        path.basename(path.dirname(project.planPath)),
+        '--phase',
+        options.phase,
+        '--review-id',
+        data.review_id,
+        '--author-agent',
+        data.author_agent,
+        '--reviewer-agent',
+        data.actual_reviewer,
+        '--independence',
+        data.independence,
+        '--model',
+        data.reviewer_model,
+      ],
+      {
+        cwd: project.root,
+        env: { ...process.env, ...nativeReviewEnvironment(project.root) },
+        encoding: 'utf8',
+        timeout: 60_000,
+      },
+    );
+    assert.equal(stamped.error, undefined, stamped.error?.message);
+    state.runs.push({
+      output: data.reviewer_output,
+      correct: grade.correct,
+      judgeReason: grade.reason,
+      gate: options.dispatch(project.root),
+      stampStatus: stamped.status,
+      stampOutput: stamped.stdout + stamped.stderr,
+    });
+    assert.equal(readFileSync(path.join(project.root, project.planPath), 'utf8'), original);
+  }
+}
+
+When(
+  'actual lifecycle dispatch from installed local project hooks runs its judged Implementation Plan review with real configuration and collaborators, mocking only non-reviewer process boundaries',
+  { timeout: 240_000 },
+  async function (this: SafewordWorld) {
+    const state = states.get(this);
+    assert.ok(state);
+    await runJudgedNativeReview(state, {
+      kind: 'plan-implementation',
+      phase: 'plan-implementation',
+      dispatch,
+    });
+  },
+);
+
+Then('Implementation Plan review dispatch proceeds', function (this: SafewordWorld) {
+  const state = states.get(this);
+  assert.ok(state);
+  assert.ok(
+    state.runs.filter(
+      run =>
+        run.correct && run.output.verdict === 'approve' && run.output.reviewer_agent === 'codex',
+    ).length >= 2,
+    JSON.stringify(state.runs),
+  );
+});
+
+Then('Implementation Plan approval proceeds', function (this: SafewordWorld) {
+  const state = states.get(this);
+  assert.ok(state);
+  assert.ok(
+    state.runs.filter(
+      run =>
+        run.correct &&
+        run.output.verdict === 'approve' &&
+        run.stampStatus === 0 &&
+        !/deny/u.test(run.gate),
+    ).length >= 2,
+    JSON.stringify(state.runs),
+  );
+});
+
+Then(
+  /^Implementation Plan approval remains blocked with (the violated Rule and unmet requirement|the omission|the overreach) named$/u,
+  function (this: SafewordWorld, defect: string) {
+    const state = states.get(this);
+    assert.ok(state);
+    const namedDefect =
+      defect === 'the overreach'
+        ? /(?:automatic|automatically).{0,40}migrat/iu
+        : defect === 'the omission'
+          ? /consent|authoriz/iu
+          : /(?=.*approval\.BU1\.CTX123\.R1)(?=.*(?:consent|authoriz))(?=.*(?:unresolved|binding|bound|unchecked|without))/isu;
+    assert.ok(
+      state.runs.filter(
+        run =>
+          run.correct &&
+          run.output.verdict === 'request_changes' &&
+          run.stampStatus !== 0 &&
+          /did not approve \(status: changes_requested\)/u.test(run.stampOutput) &&
+          /deny/u.test(run.gate) &&
+          run.output.findings.some(finding => namedDefect.test(finding.message)),
+      ).length >= 2,
+      JSON.stringify(state.runs),
+    );
+  },
+);
+
+Then(
+  'Implementation Plan approval remains blocked with the missing project boundary named',
+  function (this: SafewordWorld) {
+    const state = states.get(this);
+    assert.ok(state);
+    assert.ok(
+      state.runs.filter(
+        run =>
+          run.correct &&
+          run.output.verdict === 'request_changes' &&
+          run.stampStatus !== 0 &&
+          /did not approve \(status: changes_requested\)/u.test(run.stampOutput) &&
+          /deny/u.test(run.gate) &&
+          run.output.findings.some(finding => /project non.goals?/iu.test(finding.message)),
+      ).length >= 2,
+      JSON.stringify(state.runs),
+    );
+  },
+);
+
+After(function (this: SafewordWorld, { result }) {
+  const state = states.get(this);
+  if (state && result?.status === Status.FAILED)
+    console.error(`Native scope diagnostic fixture retained: ${state.project.root}`);
+  else if (state) for (const root of state.roots) rmSync(root, { recursive: true, force: true });
+  states.delete(this);
+});
diff --git a/steps/keep-plan-reviews-persona-coverage.steps.ts b/steps/keep-plan-reviews-persona-coverage.steps.ts
new file mode 100644
index 000000000..920d9bc93
--- /dev/null
+++ b/steps/keep-plan-reviews-persona-coverage.steps.ts
@@ -0,0 +1,56 @@
+import { strict as assert } from 'node:assert';
+
+import { Given, Then, When } from '@cucumber/cucumber';
+
+import {
+  assertPlanningEval,
+  runPlanningEval,
+  selectPlanningEval,
+} from './support/planning-eval.js';
+import type { SafewordWorld } from './world.js';
+
+const cases = {
+  'has at least one accepted scenario for every applicable outcome':
+    'r16-scenario-complete-coverage',
+  'has no accepted scenario for the Non-Technical Builder recovery outcome':
+    'r16-scenario-missing-recovery',
+} as const;
+
+Given(
+  /^an approved Product Plan persona-outcome inventory (.+)$/u,
+  function (this: SafewordWorld, coverage: keyof typeof cases) {
+    const selected = selectPlanningEval(this, cases[coverage]);
+    assert.equal(selected.kind, 'scenario-gate');
+    assert.match(
+      selected.context,
+      /Non-Technical Builder recovery returns to a pending change after obtaining fresh consent/u,
+    );
+    const hasRecovery = selected.reviewed_plan.includes('Scenario: Non-Technical Builder Recovery');
+    assert.equal(hasRecovery, selected.expected_verdict === 'approve');
+  },
+);
+
+When(
+  'the scenario gate evaluates behavior coverage',
+  { timeout: 240_000 },
+  function (this: SafewordWorld) {
+    runPlanningEval(this);
+  },
+);
+
+Then('scenario coverage does not block approval', function (this: SafewordWorld) {
+  assertPlanningEval(this, 'approve');
+});
+
+Then(
+  'scenario approval is blocked with that uncovered recovery outcome named',
+  function (this: SafewordWorld) {
+    const runs = assertPlanningEval(this, 'request_changes');
+    const namesRecovery = /Non[- ]Technical Builder.*recover|recover.*Non[- ]Technical Builder/iu;
+    assert.ok(
+      runs.filter(run => run.reviewer.findings.some(finding => namesRecovery.test(finding)))
+        .length >= 2,
+      'At least two correct judged rejections must name this persona and recovery in one finding.',
+    );
+  },
+);
diff --git a/steps/keep-plan-reviews-premature-fallback.steps.ts b/steps/keep-plan-reviews-premature-fallback.steps.ts
new file mode 100644
index 000000000..e8db3f763
--- /dev/null
+++ b/steps/keep-plan-reviews-premature-fallback.steps.ts
@@ -0,0 +1,184 @@
+import { strict as assert } from 'node:assert';
+import { existsSync, readFileSync, writeFileSync } from 'node:fs';
+import path from 'node:path';
+
+import { After, Given, Then, When } from '@cucumber/cucumber';
+
+import { installedReviewCli } from '../packages/cli/tests/fixtures/execution-review.js';
+import { reviewerScript } from '../packages/cli/tests/fixtures/planning-reviewers.js';
+import { prepare } from './keep-plan-reviews-independence.steps.js';
+import type { SafewordWorld } from './world.js';
+
+type State = Awaited<ReturnType<typeof prepare>> & { release: string; reviewId?: string };
+const states = new WeakMap<SafewordWorld, State>();
+const folder = '.project/tickets/CTX123-current-context';
+
+Given(
+  'at least one independent reviewer route remains available and unattempted',
+  { timeout: 120_000 },
+  async function (this: SafewordWorld) {
+    const base = await prepare(this, true);
+    const release = `${base.marker}-release`;
+    const state = Object.assign(base, { release });
+    states.set(this, state);
+    const configPath = path.join(state.root, '.safeword/config.json');
+    const config = JSON.parse(readFileSync(configPath, 'utf8'));
+    config.crossAgentReviewRoutes.claude = [
+      { reviewer: 'claude' },
+      { reviewer: 'codex', model: 'gpt-6.1-sol' },
+    ];
+    writeFileSync(configPath, JSON.stringify(config));
+    state.fallbackMarker = `${state.marker}-headless`;
+    writeFileSync(
+      path.join(path.dirname(state.marker), 'claude'),
+      reviewerScript(
+        'claude',
+        state.fallbackMarker,
+        `${state.fallbackMarker}.packet`,
+        false,
+        false,
+      ),
+      { mode: 0o755 },
+    );
+    const producer = reviewerScript('codex', state.marker, `${state.marker}.packet`, false, true);
+    const held = producer.replace(
+      'function reviewOutput(packet) {',
+      `function reviewOutput(packet) {
+    const deadline = Date.now() + 30000;
+    while (!require('node:fs').existsSync(${JSON.stringify(release)})) {
+      if (Date.now() > deadline) process.exit(7);
+      Atomics.wait(new Int32Array(new SharedArrayBuffer(4)), 0, 0, 20);
+    }
+    process.exit(7);`,
+    );
+    assert.notEqual(held, producer);
+    writeFileSync(path.join(path.dirname(state.marker), 'codex'), held, { mode: 0o755 });
+    assert.equal(existsSync(state.marker), false);
+    assert.equal(existsSync(state.fallbackMarker), false);
+  },
+);
+
+When(
+  'the permitted fallback is requested',
+  { timeout: 60_000 },
+  async function (this: SafewordWorld) {
+    const state = states.get(this);
+    assert.ok(state);
+    // The caller ranks headless first; the public coordinator must still dispatch
+    // independent review first. Only courtesy waiting is shortened, not funding.
+    const result = await installedReviewCli(state.root)(
+      [
+        'review',
+        'run',
+        'plan-implementation',
+        `${folder}/impl-plan.md`,
+        '--context',
+        'features/current-context.feature',
+        '--context',
+        `${folder}/spec.md`,
+        '--json',
+        '--no-input',
+        '--cwd',
+        state.root,
+      ],
+      { cwd: state.root, env: { ...state.env, SAFEWORD_REVIEW_FOREGROUND_MS: '100' } },
+    );
+    assert.equal(result.exitCode, 2, result.stdout);
+    const output = JSON.parse(result.stdout);
+    state.reviewId = output.data.review_id;
+    assert.equal(output.data.status, 'pending', result.stdout);
+    const deadline = Date.now() + 10000;
+    while (!existsSync(state.marker) && !existsSync(state.fallbackMarker!) && Date.now() < deadline)
+      await new Promise(resolve => setTimeout(resolve, 100));
+    const refused = await installedReviewCli(state.root)(
+      [
+        'review',
+        'continue',
+        state.reviewId!,
+        '--tier',
+        'fresh-context',
+        '--failure',
+        'process_failed',
+        '--json',
+        '--cwd',
+        state.root,
+      ],
+      { cwd: state.root, env: state.env },
+    );
+    assert.equal(refused.exitCode, 1, refused.stdout);
+    assert.deepEqual(
+      JSON.parse(refused.stdout).errors.map((error: { code: string }) => error.code),
+      ['REVIEW_JOB_INVALID'],
+    );
+  },
+);
+
+Then(
+  'fallback is refused and the phase remains blocked pending independent review',
+  { timeout: 60_000 },
+  async function (this: SafewordWorld) {
+    const state = states.get(this);
+    assert.ok(state?.reviewId && state.fallbackMarker);
+    const cli = installedReviewCli(state.root);
+    const blocked = await cli(
+      ['ticket', 'approve-plan', 'CTX123', '--json', '--no-input', '--cwd', state.root],
+      { cwd: state.root, env: state.env },
+    );
+    assert.equal(blocked.exitCode, 2, blocked.stdout);
+    const pending = await cli(['review', 'status', state.reviewId, '--json', '--cwd', state.root], {
+      cwd: state.root,
+      env: state.env,
+    });
+    assert.equal(JSON.parse(pending.stdout).data.status, 'pending');
+    assert.equal(existsSync(state.marker), true, 'The independent route is actually working.');
+    assert.equal(
+      existsSync(state.fallbackMarker),
+      false,
+      'Funded headless review must wait for independent exhaustion.',
+    );
+    assert.match(
+      readFileSync(path.join(state.root, folder, 'ticket.md'), 'utf8'),
+      /phase: plan-implementation/u,
+    );
+    writeFileSync(state.release, 'release');
+    let completion;
+    const deadline = Date.now() + 10000;
+    do {
+      await new Promise(resolve => setTimeout(resolve, 100));
+      const result = await cli(
+        ['review', 'status', state.reviewId, '--json', '--cwd', state.root],
+        { cwd: state.root, env: state.env },
+      );
+      completion = JSON.parse(result.stdout).data;
+    } while (completion.status === 'pending' && Date.now() < deadline);
+    assert.equal(completion.status, 'approved', JSON.stringify(completion));
+    assert.equal(completion.independence, 'reduced');
+    assert.deepEqual(completion.review_routes, [
+      {
+        reviewer: 'codex',
+        model: 'gpt-6.1-sol',
+        independence: 'cross-agent',
+        status: 'attempted',
+        failure: 'process_failed',
+      },
+      { reviewer: 'claude', independence: 'degraded', status: 'attempted' },
+    ]);
+    assert.equal(
+      existsSync(state.fallbackMarker),
+      true,
+      'Fallback becomes callable after the independent failure.',
+    );
+  },
+);
+
+After(async function (this: SafewordWorld) {
+  const state = states.get(this);
+  if (!state) return;
+  if (existsSync(path.dirname(state.release))) writeFileSync(state.release, 'release');
+  if (state.reviewId)
+    await installedReviewCli(state.root)(
+      ['review', 'cancel', state.reviewId, '--json', '--cwd', state.root],
+      { cwd: state.root, env: state.env },
+    );
+  states.delete(this);
+});
diff --git a/steps/keep-plan-reviews-product-outcomes.steps.ts b/steps/keep-plan-reviews-product-outcomes.steps.ts
new file mode 100644
index 000000000..243cd80f9
--- /dev/null
+++ b/steps/keep-plan-reviews-product-outcomes.steps.ts
@@ -0,0 +1,93 @@
+import { strict as assert } from 'node:assert';
+
+import { Given, Then, When } from '@cucumber/cucumber';
+
+import {
+  assertPlanningEval,
+  runPlanningEval,
+  selectPlanningEval,
+} from './support/planning-eval.js';
+import type { SafewordWorld } from './world.js';
+
+const inventories = {
+  "inventories every accepted persona's consequential success, refusal, failure, approval, trust, and recovery outcomes":
+    'r16-complete-persona-outcomes',
+  "marks the Non-Technical Builder's approval outcome explicitly inapplicable with a stated reason and inventories the rest":
+    'r16-explicitly-inapplicable-approval',
+  "omits the Non-Technical Builder's recovery outcome": 'r16-missing-persona-recovery',
+} as const;
+
+Given(
+  /^the Product Plan accepts a Technical Builder and a Non-Technical Builder and (.+)$/,
+  function (this: SafewordWorld, inventory: keyof typeof inventories) {
+    const caseId = inventories[inventory];
+    assert.ok(caseId, `Unknown persona inventory: ${inventory}`);
+    const packet = selectPlanningEval(this, caseId);
+    assert.match(packet.context, /Technical Builder and Non-Technical Builder/u);
+    assert.match(packet.reviewed_plan, /recovery/u);
+    if (caseId === 'r16-explicitly-inapplicable-approval') {
+      assert.match(packet.reviewed_plan, /approval is inapplicable because/u);
+      assert.doesNotMatch(packet.reviewed_plan, /each have defined.*approval/u);
+      assert.match(packet.reviewed_plan, /observer-only persona cannot authorize/u);
+    }
+    if (caseId === 'r16-missing-persona-recovery')
+      assert.match(packet.reviewed_plan, /Non-Technical Builder recovery is absent/u);
+  },
+);
+
+Given(
+  /^the Product Plan contains known facts, assumptions, and unresolved product decisions and (presents an assumption as a known fact|keeps known facts, assumptions, and unresolved product decisions distinct)$/,
+  function (this: SafewordWorld, epistemicState: string) {
+    const packet = selectPlanningEval(
+      this,
+      epistemicState.startsWith('presents')
+        ? 'r16-assumption-as-fact'
+        : 'r16-complete-persona-outcomes',
+    );
+    assert.match(packet.reviewed_plan, /Known fact:/u);
+    assert.match(packet.reviewed_plan, /Assumption(?:s)?:/u);
+    assert.match(packet.reviewed_plan, /Unresolved (?:product )?decision(?:s)?:/u);
+    if (epistemicState.startsWith('presents'))
+      assert.match(
+        packet.reviewed_plan,
+        /Known fact: Every builder can recover an expired consent token without assistance/u,
+      );
+  },
+);
+
+When(
+  'a judged semantic reviewer evaluation applies the canonical Product Plan completeness rubric',
+  { timeout: 240_000 },
+  function (this: SafewordWorld) {
+    runPlanningEval(this);
+  },
+);
+
+Then(
+  'persona-outcome completeness does not block Product Plan approval',
+  function (this: SafewordWorld) {
+    assertPlanningEval(this, 'approve');
+  },
+);
+
+Then('epistemic status does not block Product Plan approval', function (this: SafewordWorld) {
+  assertPlanningEval(this, 'approve');
+});
+
+Then(
+  'Product Plan approval is blocked naming that missing recovery outcome and reports no scenario-coverage verdict',
+  function (this: SafewordWorld) {
+    assertPlanningEval(this, 'request_changes', /Non-Technical Builder.{0,90}recovery/isu);
+  },
+);
+
+Then(
+  'Product Plan approval is blocked with the epistemic-status defect named',
+  function (this: SafewordWorld) {
+    assertPlanningEval(
+      this,
+      'request_changes',
+      /(?=.*(?:assum|unsupported|unproven))(?=.*fact)/isu,
+    );
+  },
+);
diff --git a/steps/keep-plan-reviews-receipt-provenance.steps.ts b/steps/keep-plan-reviews-receipt-provenance.steps.ts
new file mode 100644
index 000000000..1d6c97f21
--- /dev/null
+++ b/steps/keep-plan-reviews-receipt-provenance.steps.ts
@@ -0,0 +1,173 @@
+import { strict as assert } from 'node:assert';
+import { spawnSync } from 'node:child_process';
+import { cpSync, readFileSync, rmSync, writeFileSync } from 'node:fs';
+import path from 'node:path';
+
+import { After, Given, Then, When } from '@cucumber/cucumber';
+
+import {
+  admitThroughInstalledCli,
+  executionPlan,
+  featureFixture,
+  installedReviewCli,
+} from '../packages/cli/tests/fixtures/execution-review.js';
+import { cleanupTrustedReviewerDirectories } from '../packages/cli/tests/review-fixtures.js';
+import type { SafewordWorld } from './world.js';
+
+// A committed pre-fix plugin can run the identical assertions as a regression control.
+const pluginRoot = path.resolve(
+  process.env.SAFEWORD_RECEIPT_PROOF_PLUGIN_ROOT ?? path.resolve(import.meta.dirname, '../plugin'),
+);
+const ticketFolder = 'ABC123-feature';
+const implementation =
+  '# Implementation Plan\n\n**Status:** planned\n\n## Approach\nUse the authenticated current plan review.\n\n## Decisions\nskip: No unresolved decision.\n\n## Design alignment\nskip: No additional principle trace applies.\n\n## Known deviations\nskip: No known deviations.\n\n## Assessment triggers\nRevisit when approval authority changes.\n';
+
+interface ReceiptState {
+  root: string;
+  reviewer: string;
+  gate?: ReturnType<typeof spawnSync>;
+}
+const states = new WeakMap<SafewordWorld, ReceiptState>();
+
+Given(
+  /^the Execution Plan gate receives (.+)$/,
+  { timeout: 60_000 },
+  async function (this: SafewordWorld, identity: string) {
+    const root = featureFixture();
+    const current = { root, reviewer: '' };
+    states.set(this, current);
+    const ticketDirectory = path.join(root, '.project', 'tickets', ticketFolder);
+    writeFileSync(
+      path.join(ticketDirectory, 'ticket.md'),
+      '---\nid: ABC123\ntype: feature\nphase: plan-execution\n---\n',
+    );
+    writeFileSync(path.join(ticketDirectory, 'impl-plan.md'), implementation);
+    if (identity === 'an Implementation Plan approval for the current ticket and same plan bytes') {
+      const commonPlan = `${implementation}\n${executionPlan().replace(/^\*\*Status:\*\*.*\n/gmu, '')}`;
+      writeFileSync(path.join(ticketDirectory, 'impl-plan.md'), commonPlan);
+      writeFileSync(path.join(ticketDirectory, 'execution-plan.md'), commonPlan);
+    }
+    const runCli = installedReviewCli(root);
+    current.reviewer = await admitThroughInstalledCli(runCli, root);
+    const positive = await runCli(
+      ['ticket', 'coding-authorization', 'ABC123', '--json', '--cwd', root],
+      {
+        cwd: root,
+        env: {
+          NODE_ENV: 'test',
+          SAFEWORD_REVIEW_KEY_ROOT: path.join(root, '.review-keys'),
+        },
+      },
+    );
+    assert.equal(positive.exitCode, 0, positive.stdout);
+    assert.equal(JSON.parse(positive.stdout).data.coding_authorization, 'authorized');
+    if (
+      identity === 'an Execution Plan approval for the current ticket and exact current plan bytes'
+    )
+      return;
+
+    const ledgerPath = path.join(root, '.project', 'skill-invocations.log');
+    const rows = readFileSync(ledgerPath, 'utf8').trim().split('\n');
+    let alias: string;
+    if (identity === 'an Implementation Plan approval for the current ticket and same plan bytes') {
+      const receipt = rows.find(row => row.includes(':phase@plan-implementation '));
+      assert.ok(receipt);
+      assert.equal(
+        readFileSync(path.join(ticketDirectory, 'impl-plan.md'), 'utf8'),
+        readFileSync(path.join(ticketDirectory, 'execution-plan.md'), 'utf8'),
+      );
+      alias = receipt.replace(':phase@plan-implementation ', ':phase@plan-execution ');
+    } else {
+      assert.equal(identity, 'an Execution Plan approval for a sibling ticket and same plan bytes');
+      const sibling = 'XYZ789-feature';
+      const siblingDirectory = path.join(root, '.project', 'tickets', sibling);
+      cpSync(ticketDirectory, siblingDirectory, { recursive: true });
+      writeFileSync(
+        path.join(siblingDirectory, 'ticket.md'),
+        '---\nid: XYZ789\ntype: feature\nphase: plan-execution\n---\n',
+      );
+      await admitThroughInstalledCli(runCli, root, ['plan-execution'], { ticketFolder: sibling });
+      assert.equal(
+        readFileSync(path.join(siblingDirectory, 'execution-plan.md'), 'utf8'),
+        readFileSync(path.join(ticketDirectory, 'execution-plan.md'), 'utf8'),
+      );
+      alias = readFileSync(ledgerPath, 'utf8')
+        .trim()
+        .replace(`review:${sibling}:`, `review:${ticketFolder}:`);
+    }
+    writeFileSync(
+      ledgerPath,
+      `${[...rows.filter(row => !row.includes(':phase@plan-execution ')), alias].join('\n')}\n`,
+    );
+  },
+);
+
+When('the gate validates receipt provenance', function (this: SafewordWorld) {
+  const current = states.get(this);
+  assert.ok(current);
+  current.gate = spawnSync('bun', [path.join(pluginRoot, 'runtime/hooks/pre-tool-quality.ts')], {
+    cwd: current.root,
+    encoding: 'utf8',
+    timeout: 60_000,
+    input: JSON.stringify({
+      session_id: 'r9-receipt',
+      tool_name: 'Edit',
+      tool_input: {
+        file_path: path.join(current.root, '.project', 'tickets', ticketFolder, 'ticket.md'),
+        old_string: 'phase: plan-execution',
+        new_string: 'phase: implement',
+      },
+    }),
+    env: {
+      ...process.env,
+      NODE_ENV: 'test',
+      XDG_STATE_HOME: path.join(current.root, '.review-keys'),
+      SAFEWORD_REVIEW_KEY_ROOT: path.join(current.root, '.review-keys'),
+      PATH: `${current.reviewer}:${process.env.PATH ?? ''}`,
+      CLAUDE_PROJECT_DIR: current.root,
+      CLAUDE_PLUGIN_ROOT: pluginRoot,
+      CLAUDE_SESSION_ID: 'r9-receipt',
+      SAFEWORD_AGENT_RUNTIME: 'claude',
+    },
+  });
+});
+
+Then('the matching receipt does not block the phase transition', function (this: SafewordWorld) {
+  const gate = states.get(this)?.gate;
+  assert.ok(gate);
+  assert.equal(gate.status, 0, gate.stderr);
+  assert.equal(gate.stdout.trim(), '', gate.stdout);
+});
+
+Then(
+  /^the phase remains blocked with the mismatched (review kind|ticket) and re-review named$/,
+  function (this: SafewordWorld, mismatch: string) {
+    const current = states.get(this);
+    assert.ok(current?.gate);
+    assert.equal(current.gate.status, 0, current.gate.stderr);
+    const result = JSON.parse(current.gate.stdout);
+    assert.equal(result.hookSpecificOutput.permissionDecision, 'deny');
+    const message = result.hookSpecificOutput.permissionDecisionReason;
+    for (const name of mismatch === 'ticket'
+      ? [ticketFolder, 'XYZ789-feature']
+      : ['plan-implementation', 'plan-execution'])
+      assert.ok(message.includes(name), message);
+    assert.match(result.hookSpecificOutput.additionalContext, /review run plan-execution/u);
+    assert.match(
+      readFileSync(
+        path.join(current.root, '.project', 'tickets', ticketFolder, 'ticket.md'),
+        'utf8',
+      ),
+      /phase: plan-execution/u,
+    );
+  },
+);
+
+After(function (this: SafewordWorld) {
+  const current = states.get(this);
+  if (current) {
+    rmSync(current.root, { recursive: true, force: true });
+    cleanupTrustedReviewerDirectories();
+  }
+  states.delete(this);
+});
