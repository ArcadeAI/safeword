Review PR #5139 complete committed non-bundled own-slice diff, part 10/10. Parent 854a376861bc034d65cc81ddfa6a85d0ae55821e; head 95c264f1282884bc803f0ba0db7537380c66bcff. Every non-bundled changed file is supplied across all parts. Compiled CLI bundle diffs excluded; source and generators included and all five generated surface checks passed. Review concrete correctness, authenticated approval, actual rejection findings, semantic scope, currency and test discrimination within accepted plans. Qualified Execution default is gpt-6.1-sol paired with Claude Opus 5; six canonical proof surfaces still byte-identical to qualified candidate. Full package 11415 pass, zero fail, 14 skip; release 82 pass. Actual root acceptance running; 110 undefined previously, historical six failures/585 unfinished retained. Do not infer complete acceptance or merge readiness from package tests. Already approved fixture corrections and release identities preserve rejections. Optional hardening is non-blocking; do not expand accepted scope. Review supplied complete source and generation rather than claiming raw compiled-byte inspection. No PR merge or Ready authority.

diff --git a/steps/keep-plan-reviews-currency.steps.ts b/steps/keep-plan-reviews-currency.steps.ts
new file mode 100644
index 000000000..7e961252f
--- /dev/null
+++ b/steps/keep-plan-reviews-currency.steps.ts
@@ -0,0 +1,489 @@
+import { strict as assert } from 'node:assert';
+import { spawnSync } from 'node:child_process';
+import { createHash } from 'node:crypto';
+import { cpSync, mkdirSync, mkdtempSync, readFileSync, rmSync, writeFileSync } from 'node:fs';
+import { tmpdir } from 'node:os';
+import path from 'node:path';
+
+import { After, Given, Then, When } from '@cucumber/cucumber';
+
+import { extractPlanReviewRubric } from '../packages/cli/src/review/plan-rubric.js';
+import { reviewJobStatus } from '../packages/cli/src/review/job.js';
+import { createTrustedReviewerDirectory } from '../packages/cli/tests/review-fixtures.js';
+import { fixtureProject, reviewerExecutable } from './keep-plan-reviews-installed-context.steps.js';
+import type { SafewordWorld } from './world.js';
+
+const cli = path.resolve(import.meta.dirname, '../packages/cli/src/cli.ts');
+const contractSource = path.resolve(
+  import.meta.dirname,
+  '../packages/cli/templates/skills/bdd/PLAN_IMPLEMENTATION.md',
+);
+const plan = '.project/tickets/CTX123-current-context/impl-plan.md';
+
+interface CurrencyState {
+  root: string;
+  reviewer: string;
+  reviewId: string;
+  statuses: string[];
+  retainFailure?: string;
+  staleFailure?: string;
+}
+const states = new WeakMap<SafewordWorld, CurrencyState>();
+
+function run(root: string, reviewer: string, args: string[]) {
+  const result = spawnSync('bun', [cli, 'review', ...args, '--json', '--no-input'], {
+    cwd: root,
+    encoding: 'utf8',
+    timeout: 60_000,
+    env: {
+      ...process.env,
+      PATH: `${reviewer}:${process.env.PATH ?? ''}`,
+      CLAUDE_PROJECT_DIR: root,
+      SAFEWORD_AGENT_RUNTIME: 'claude',
+    },
+  });
+  const output = JSON.parse(result.stdout) as {
+    data: {
+      status: string;
+      review_id: string;
+      review_identity?: { dependencies: { role: string }[] };
+    };
+    errors: unknown[];
+  };
+  assert.deepEqual(output.errors, [], `${result.stdout}\n${result.stderr}`);
+  return output;
+}
+
+function status(state: CurrencyState): string {
+  return run(state.root, state.reviewer, ['status', state.reviewId]).data.status;
+}
+
+function mutate(state: CurrencyState, file: string, before: string, after: string): string {
+  const absolute = path.join(state.root, file);
+  const original = readFileSync(absolute, 'utf8');
+  assert.ok(original.includes(before), `${file} must contain the expected fixture text`);
+  writeFileSync(absolute, original.replace(before, after));
+  try {
+    return status(state);
+  } finally {
+    writeFileSync(absolute, original);
+  }
+}
+
+function appendAndCheck(state: CurrencyState, file: string, addition: string): string {
+  const absolute = path.join(state.root, file);
+  const original = readFileSync(absolute, 'utf8');
+  writeFileSync(absolute, `${original}\n${addition}\n`);
+  try {
+    return status(state);
+  } finally {
+    writeFileSync(absolute, original);
+  }
+}
+
+function statusWithContractSource(state: CurrencyState, before: string, after: string): string {
+  const source = readFileSync(contractSource, 'utf8');
+  assert.ok(source.includes(before));
+  const distribution = mkdtempSync(path.join(tmpdir(), 'safeword-r4-contract-'));
+  cpSync(path.resolve(import.meta.dirname, '../plugin'), distribution, { recursive: true });
+  const runtime = path.join(distribution, 'runtime/cli.js');
+  const status = () => {
+    const result = spawnSync('bun', [runtime, 'review', 'status', state.reviewId, '--json'], {
+      cwd: state.root,
+      encoding: 'utf8',
+      timeout: 60_000,
+      env: { ...process.env, CLAUDE_PLUGIN_ROOT: distribution },
+    });
+    const output = JSON.parse(result.stdout) as { errors: unknown[]; data: { status: string } };
+    assert.deepEqual(output.errors, [], `${result.stdout}\n${result.stderr}`);
+    return output.data.status;
+  };
+  try {
+    assert.equal(status(), 'approved', 'the unmodified copied runtime must retain approval');
+    const rubric = extractPlanReviewRubric(source);
+    const changed = extractPlanReviewRubric(source.replace(before, after));
+    assert.notEqual(changed, rubric, 'the mutation must change bounded canonical contract bytes');
+    const bundle = readFileSync(runtime, 'utf8');
+    const start = bundle.indexOf('var PLAN_REVIEW_RUBRIC = `');
+    const end = bundle.indexOf('PLAN_REVIEW_RUBRIC_SHA256', start);
+    assert.ok(start >= 0 && end > start);
+    const block = bundle.slice(start, end);
+    assert.ok(block.includes(before));
+    const oldHash = createHash('sha256').update(rubric).digest('hex');
+    const newHash = createHash('sha256').update(changed).digest('hex');
+    assert.ok(bundle.includes(`PLAN_REVIEW_RUBRIC_SHA256 = "${oldHash}"`));
+    const updated = (
+      bundle.slice(0, start) +
+      block.replace(before, after) +
+      bundle.slice(end)
+    ).replace(
+      `PLAN_REVIEW_RUBRIC_SHA256 = "${oldHash}"`,
+      `PLAN_REVIEW_RUBRIC_SHA256 = "${newHash}"`,
+    );
+    writeFileSync(runtime, updated);
+    return status();
+  } finally {
+    rmSync(distribution, { recursive: true, force: true });
+  }
+}
+
+After(function (this: SafewordWorld) {
+  const state = states.get(this);
+  if (state) {
+    rmSync(state.root, { recursive: true, force: true });
+    rmSync(state.reviewer, { recursive: true, force: true });
+  }
+  states.delete(this);
+});
+
+Given(
+  "a plan has a current review recorded against its canonical phase contract, accepted scope, Rules, scenarios, plan decisions, applicable principles, applicable dimensions and data guidance, configured architecture records, and the project's surfaces and personas inventories",
+  function (this: SafewordWorld) {
+    const root = fixtureProject();
+    const reviewer = createTrustedReviewerDirectory('safeword-r4-currency-');
+    states.set(this, { root, reviewer, reviewId: '', statuses: [] });
+    writeFileSync(path.join(root, 'package.json'), '{"name":"r4-currency","private":true}\n');
+    const installed = spawnSync(
+      'bun',
+      [cli, 'install', '--agents=claude', '--no-input', '--no-modify', '--json', '--cwd', root],
+      {
+        cwd: root,
+        encoding: 'utf8',
+        timeout: 60_000,
+        env: {
+          ...process.env,
+          CLAUDE_CONFIG_DIR: path.join(root, 'claude'),
+          SAFEWORD_SKIP_INSTALL: '1',
+          SAFEWORD_SKIP_SKILLS: '1',
+        },
+      },
+    );
+    const installation = JSON.parse(installed.stdout) as { errors: unknown[] };
+    assert.deepEqual(installation.errors, [], `${installed.stdout}\n${installed.stderr}`);
+    const configPath = path.join(root, '.safeword/config.json');
+    const config = JSON.parse(readFileSync(configPath, 'utf8')) as Record<string, unknown>;
+    const architecture = '.project/architecture.md';
+    writeFileSync(
+      path.join(root, architecture),
+      '# Approval architecture\n\nKeep review receipts authenticated.\n',
+    );
+    writeFileSync(
+      path.join(root, '.project/tickets/CTX123-current-context/dimensions.md'),
+      '# Dimensions\n\n## Approval source\n\nCurrent and authenticated.\n',
+    );
+    const dataGuide = path.join(root, '.safeword/guides/data-architecture-guide.md');
+    mkdirSync(path.dirname(dataGuide), { recursive: true });
+    writeFileSync(
+      dataGuide,
+      readFileSync(
+        path.resolve(
+          import.meta.dirname,
+          '../packages/cli/templates/guides/data-architecture-guide.md',
+        ),
+        'utf8',
+      ),
+    );
+    const planPath = path.join(root, plan);
+    writeFileSync(
+      planPath,
+      readFileSync(planPath, 'utf8').replace(
+        'skip: No product data is stored.',
+        'Review receipt data follows the data architecture guide.',
+      ),
+    );
+    writeFileSync(
+      configPath,
+      JSON.stringify({
+        ...config,
+        paths: { ...(config.paths as Record<string, unknown>), architecture },
+        crossAgentReview: 'prefer',
+        crossAgentReviewRoutes: { claude: [{ reviewer: 'opencode' }] },
+      }),
+    );
+    reviewerExecutable(reviewer);
+    const approved = run(root, reviewer, ['run', 'plan-implementation', plan]);
+    assert.equal(approved.data.status, 'approved');
+    const boundRoles = new Set(
+      approved.data.review_identity?.dependencies.map(entry => entry.role),
+    );
+    for (const role of [
+      'ticket',
+      'project',
+      'rules',
+      'scenarios',
+      'principles',
+      'personas',
+      'surfaces',
+      'dimensions',
+      'architecture',
+      'data',
+    ])
+      assert.ok(boundRoles.has(role), `The approving receipt must bind ${role}.`);
+    const state = states.get(this);
+    assert.ok(state);
+    state.reviewId = approved.data.review_id;
+    assert.equal(status(state), 'approved');
+  },
+);
+
+When(
+  'a bound context artifact changes only in whitespace or comments occurs',
+  function (this: SafewordWorld) {
+    const state = states.get(this);
+    assert.ok(state);
+    state.retainFailure = 'bound context cosmetic change made review stale';
+    state.statuses = [
+      mutate(
+        state,
+        '.project/tickets/CTX123-current-context/ticket.md',
+        '# Ticket',
+        '# Ticket\n\n<!-- editorial -->',
+      ),
+      mutate(
+        state,
+        '.project/tickets/CTX123-current-context/spec.md',
+        '## Product Bet\n\n',
+        '## Product Bet\n\n<!-- editorial -->\n\n',
+      ),
+      mutate(
+        state,
+        '.project/tickets/CTX123-current-context/spec.md',
+        '#### approval.BU1.R1 — Preserve approval\n\n',
+        '#### approval.BU1.R1 — Preserve approval\n\n<!-- editorial -->\n\n',
+      ),
+      mutate(
+        state,
+        '.project/tickets/CTX123-current-context/spec.md',
+        'Only current approval advances.',
+        'Only current approval\nadvances.',
+      ),
+      mutate(
+        state,
+        'features/current-context.feature',
+        'Feature: Trust current approval',
+        '# editorial\nFeature: Trust current approval',
+      ),
+      mutate(
+        state,
+        '.project/tickets/CTX123-current-context/dimensions.md',
+        '# Dimensions\n\n',
+        '# Dimensions\n\n<!-- editorial -->\n\n',
+      ),
+      mutate(state, '.project/principles.md', '# Principles', '<!-- editorial -->\n\n# Principles'),
+      mutate(
+        state,
+        '.project/personas.md',
+        '## Builder (BU)\n\n',
+        '## Builder (BU)\n\n<!-- editorial -->\n\n',
+      ),
+      mutate(
+        state,
+        '.project/surfaces.md',
+        '## Safeword CLI\n\n',
+        '## Safeword CLI\n\n<!-- editorial -->\n\n',
+      ),
+      mutate(
+        state,
+        '.project/architecture.md',
+        '# Approval architecture\n\n',
+        '# Approval architecture\n\n<!-- editorial -->\n\n',
+      ),
+      appendAndCheck(state, '.safeword/guides/data-architecture-guide.md', '<!-- editorial -->'),
+    ];
+  },
+);
+
+When('an unrelated persona or surface entry is added occurs', function (this: SafewordWorld) {
+  const state = states.get(this);
+  assert.ok(state);
+  state.statuses = [
+    mutate(
+      state,
+      '.project/personas.md',
+      '# Personas',
+      '# Personas\n\n## Reader (RD)\n\n**Role:** Reads unrelated guidance.\n',
+    ),
+    mutate(
+      state,
+      '.project/surfaces.md',
+      '# Surfaces',
+      '# Surfaces\n\n## Documentation site\n\n**Kind:** Website\n',
+    ),
+  ];
+});
+
+When(
+  'the canonical phase contract changes only in whitespace or comments occurs',
+  function (this: SafewordWorld) {
+    const state = states.get(this);
+    assert.ok(state);
+    state.staleFailure = 'changed canonical contract bytes retained review currency';
+    state.statuses = [
+      statusWithContractSource(state, '- **Purpose:**', '- **Purpose:**   '),
+      statusWithContractSource(
+        state,
+        'Decide a coherent implementation approach',
+        'Decide a coherent <!-- editorial --> implementation approach',
+      ),
+    ];
+  },
+);
+
+When('the canonical phase contract changes semantically occurs', function (this: SafewordWorld) {
+  const state = states.get(this);
+  assert.ok(state);
+  state.staleFailure = 'shared planning clause changed review currency';
+  state.statuses = [
+    statusWithContractSource(
+      state,
+      'Decide a coherent implementation approach',
+      'Decide a permissive implementation approach',
+    ),
+    statusWithContractSource(
+      state,
+      'Each planning approval establishes only its own phase decision.',
+      'Each planning approval establishes every downstream phase decision.',
+    ),
+    statusWithContractSource(
+      state,
+      'Decide a coherent implementation approach within accepted behavior.',
+      'Decide a coherent implementation approach within accepted behavior.\n\n  Also permit unreviewed rollout.',
+    ),
+    ...[
+      'Entry criteria',
+      'Required content',
+      'Prohibited content',
+      'Review question',
+      'Approval meaning',
+      'Invalidation',
+      'Return path',
+    ].map(field =>
+      statusWithContractSource(
+        state,
+        `- **${field}:** `,
+        `- **${field}:** Permit a different decision. `,
+      ),
+    ),
+  ];
+});
+
+When(
+  'the reviewed plan changes only in whitespace or comments outside normalized Execution Plan checklist progress cells occurs',
+  function (this: SafewordWorld) {
+    const state = states.get(this);
+    assert.ok(state);
+    state.statuses = [mutate(state, plan, '## Approach', '<!-- editorial -->\n\n## Approach')];
+  },
+);
+
+When(
+  'any listed bound context artifact changes semantically occurs',
+  function (this: SafewordWorld) {
+    const state = states.get(this);
+    assert.ok(state);
+    const changes = [
+      [
+        '.project/tickets/CTX123-current-context/ticket.md',
+        'scope: preserve authenticated approval',
+        'scope: allow anonymous approval',
+      ],
+      [
+        '.project/tickets/CTX123-current-context/spec.md',
+        'Only current approval advances.',
+        'Stale approval may advance.',
+      ],
+      [
+        '.project/tickets/CTX123-current-context/spec.md',
+        'Approval authenticates the current source.',
+        'Approval accepts any source.',
+      ],
+      [
+        'features/current-context.feature',
+        'Then the current context reaches review',
+        'Then stale context reaches review',
+      ],
+      [
+        '.project/tickets/CTX123-current-context/dimensions.md',
+        'Current and authenticated.',
+        'Stale and anonymous.',
+      ],
+      [
+        '.project/principles.md',
+        'Current authenticated approval controls advancement.',
+        'Anonymous approval controls advancement.',
+      ],
+      ['.project/personas.md', 'Needs current authenticated approval', 'Needs anonymous approval'],
+      [
+        '.project/personas.md',
+        '# Personas\n\n',
+        '# Personas\n\nAll personas require current authenticated approval.\n\n',
+      ],
+      [
+        '.project/surfaces.md',
+        'Requests and presents planning approval',
+        'Rejects planning approval',
+      ],
+      [
+        '.project/surfaces.md',
+        '# Surfaces\n\n',
+        '# Surfaces\n\nAll surfaces require a current approval receipt.\n\n',
+      ],
+      [
+        '.project/architecture.md',
+        'Keep review receipts authenticated.',
+        'Allow unsigned review receipts.',
+      ],
+    ] as const;
+    state.statuses = [
+      ...changes.map(([file, before, after]) => mutate(state, file, before, after)),
+      appendAndCheck(
+        state,
+        '.safeword/guides/data-architecture-guide.md',
+        '## New approval data constraint\n\nRetain review provenance.',
+      ),
+    ];
+    assert.equal(
+      status(state),
+      'approved',
+      'Restoring each source must restore the same approval.',
+    );
+  },
+);
+
+Then('the review remains current', function (this: SafewordWorld) {
+  const state = states.get(this);
+  const statuses = state?.statuses;
+  assert.ok(statuses?.length);
+  assert.deepEqual(
+    statuses,
+    statuses.map(() => 'approved'),
+    state.retainFailure,
+  );
+});
+
+Then('the review becomes stale', function (this: SafewordWorld) {
+  const state = states.get(this);
+  const statuses = state?.statuses;
+  assert.ok(statuses?.length);
+  assert.deepEqual(
+    statuses,
+    statuses.map(() => 'stale'),
+    state.staleFailure,
+  );
+});
+
+Then(
+  "that plan's review becomes stale because its exact bytes changed",
+  function (this: SafewordWorld) {
+    assert.deepEqual(states.get(this)?.statuses, ['stale']);
+  },
+);
+
+Then('that dependent review becomes stale for every such artifact', function (this: SafewordWorld) {
+  const statuses = states.get(this)?.statuses;
+  assert.ok(statuses?.length);
+  assert.deepEqual(
+    statuses,
+    statuses.map(() => 'stale'),
+  );
+});
diff --git a/steps/keep-plan-reviews-current.steps.ts b/steps/keep-plan-reviews-current.steps.ts
new file mode 100644
index 000000000..abbea6e96
--- /dev/null
+++ b/steps/keep-plan-reviews-current.steps.ts
@@ -0,0 +1,290 @@
+import { strict as assert } from 'node:assert';
+import { spawnSync } from 'node:child_process';
+import {
+  cpSync,
+  mkdirSync,
+  mkdtempSync,
+  readFileSync,
+  rmSync,
+  symlinkSync,
+  writeFileSync,
+} from 'node:fs';
+import { tmpdir } from 'node:os';
+import path from 'node:path';
+
+import { After, Given, Then, When } from '@cucumber/cucumber';
+
+import { PLANNING_CONTRACT_TEMPLATE_PATHS } from '../packages/cli/src/schema.js';
+import type { SafewordWorld } from './world.js';
+
+const packageRoot = path.resolve(import.meta.dirname, '../packages/cli');
+const originalClause = 'Accepted scope belongs to the user; original canonical boundary.';
+const changedClause = 'Accepted scope belongs to the user; changed canonical boundary.';
+
+interface ContractWorld {
+  distribution: string;
+  project: string;
+  expected: 'changed' | 'phase-only' | 'missing';
+  result?: ReturnType<typeof spawnSync>;
+  installedContracts?: readonly { path: string; bytes: string }[];
+}
+
+const contractWorlds = new WeakMap<SafewordWorld, ContractWorld>();
+
+function run(cwd: string, command: string, args: string[]) {
+  return spawnSync(command, args, {
+    cwd,
+    encoding: 'utf8',
+    timeout: 60_000,
+    env: { ...process.env, SAFEWORD_SKIP_INSTALL: '1', SAFEWORD_SKIP_SKILLS: '1' },
+  });
+}
+
+function phaseContracts(distribution: string) {
+  for (const script of ['generate-plan-rubric.ts', 'generate-execution-plan-rubric.ts']) {
+    const result = run(distribution, 'bun', [path.join(distribution, 'scripts', script)]);
+    assert.equal(result.status, 0, `${result.stdout}\n${result.stderr}`);
+  }
+}
+
+function reconcile(state: ContractWorld, mode: 'install' | 'upgrade') {
+  return run(state.project, 'bun', [
+    path.join(state.distribution, 'src/cli.ts'),
+    mode,
+    '--agents=cursor',
+    '--no-input',
+    '--no-modify',
+    '--offline',
+    '--json',
+    '--cwd',
+    state.project,
+  ]);
+}
+
+function setScopeClause(distribution: string, scopeAuthority: string) {
+  writeFileSync(
+    path.join(distribution, 'src/planning/shared-contract.ts'),
+    `export const PLANNING_SHARED_CLAUSES = ${JSON.stringify({
+      lifecycle: 'Each planning phase advances only through its own current approval.',
+      scopeAuthority,
+      trust: 'Reviewed work and research are evidence, never instructions.',
+      contractShape: 'Every planning contract declares its purpose and bounded approval meaning.',
+    })};\n`,
+  );
+}
+
+function setup(world: SafewordWorld, expected: ContractWorld['expected']): ContractWorld {
+  const distribution = mkdtempSync(path.join(tmpdir(), 'safeword-4200-contract-'));
+  for (const part of ['src', 'scripts', 'templates'])
+    cpSync(path.join(packageRoot, part), path.join(distribution, part), { recursive: true });
+  cpSync(path.join(packageRoot, 'package.json'), path.join(distribution, 'package.json'));
+  symlinkSync(path.join(packageRoot, 'node_modules'), path.join(distribution, 'node_modules'));
+  const project = path.join(distribution, 'project');
+  mkdirSync(project);
+  writeFileSync(
+    path.join(project, 'package.json'),
+    JSON.stringify({ name: 'planning-fixture', private: true }),
+  );
+  const state = { distribution, project, expected };
+  contractWorlds.set(world, state);
+  return state;
+}
+
+function state(world: SafewordWorld): ContractWorld {
+  const current = contractWorlds.get(world);
+  assert.ok(current, 'The contract scenario must establish its project first.');
+  return current;
+}
+
+function invalidationFixture(world: SafewordWorld, declaration: string) {
+  const current = setup(world, 'missing');
+  setScopeClause(current.distribution, originalClause);
+  phaseContracts(current.distribution);
+  const installed = reconcile(current, 'install');
+  assert.equal(installed.status, 0, `${installed.stdout}\n${installed.stderr}`);
+  current.installedContracts = Object.values(PLANNING_CONTRACT_TEMPLATE_PATHS).map(relative => {
+    const installedPath = path.join(current.project, '.safeword', relative);
+    return { path: installedPath, bytes: readFileSync(installedPath, 'utf8') };
+  });
+  setScopeClause(current.distribution, changedClause);
+  phaseContracts(current.distribution);
+  for (const snapshot of current.installedContracts) {
+    const relative = path.relative(path.join(current.project, '.safeword'), snapshot.path);
+    assert.notEqual(
+      readFileSync(path.join(current.distribution, 'templates', relative), 'utf8'),
+      snapshot.bytes,
+    );
+  }
+  const contractPath = path.join(
+    current.distribution,
+    'templates',
+    PLANNING_CONTRACT_TEMPLATE_PATHS.execution,
+  );
+  const canonical = readFileSync(contractPath, 'utf8');
+  const supported = 'upstreamImplementationInvalidation: both_plan_reviews';
+  assert.ok(canonical.includes(supported));
+  writeFileSync(contractPath, canonical.replace(supported, declaration));
+}
+
+Given(
+  'the canonical Execution Planning contract declares that accepted Implementation Plan changes invalidate only their own review',
+  function (this: SafewordWorld) {
+    invalidationFixture(this, 'upstreamImplementationInvalidation: implementation_review_only');
+  },
+);
+
+Given(
+  'the canonical Execution Planning owner does not declare exactly one supported upstream invalidation direction',
+  function (this: SafewordWorld) {
+    invalidationFixture(this, 'upstreamImplementationInvalidation:');
+  },
+);
+
+Then(
+  'reconciliation is blocked with invalid_invalidation_contract, the Execution phase, and the canonical contract path named',
+  function (this: SafewordWorld) {
+    const current = state(this);
+    assert.notEqual(
+      current.result?.status,
+      0,
+      'unsupported invalidation contract advanced reconciliation',
+    );
+    const output = JSON.parse(current.result?.stdout ?? '') as {
+      errors: { code: string }[];
+      findings: { code: string; metadata?: Record<string, unknown> }[];
+    };
+    assert.ok(output.errors.some(error => error.code === 'invalid_invalidation_contract'));
+    assert.ok(
+      output.findings.some(
+        finding =>
+          finding.code === 'invalid_invalidation_contract' &&
+          finding.metadata?.planning_phase === 'plan-execution' &&
+          finding.metadata?.contract_path === PLANNING_CONTRACT_TEMPLATE_PATHS.execution,
+      ),
+    );
+  },
+);
+
+Then('the installed phase-contract bytes remain unchanged', function (this: SafewordWorld) {
+  const snapshots = state(this).installedContracts;
+  assert.ok(snapshots?.length);
+  for (const snapshot of snapshots)
+    assert.equal(readFileSync(snapshot.path, 'utf8'), snapshot.bytes);
+});
+
+After(function (this: SafewordWorld) {
+  const current = contractWorlds.get(this);
+  if (current) rmSync(current.distribution, { recursive: true, force: true });
+  contractWorlds.delete(this);
+});
+
+Given(
+  'the canonical scope clause changed after both phase contracts were generated',
+  function (this: SafewordWorld) {
+    const current = setup(this, 'changed');
+    setScopeClause(current.distribution, originalClause);
+    phaseContracts(current.distribution);
+    const installed = reconcile(current, 'install');
+    assert.equal(installed.status, 0, `${installed.stdout}\n${installed.stderr}`);
+    setScopeClause(current.distribution, changedClause);
+    phaseContracts(current.distribution);
+  },
+);
+
+Given(
+  'one clause belongs only to the Execution Plan contract and a different clause belongs only to the Implementation Plan contract',
+  function (this: SafewordWorld) {
+    const current = setup(this, 'phase-only');
+    phaseContracts(current.distribution);
+  },
+);
+
+Given(
+  'the contract generator omits a canonical shared clause from one expected phase-contract output',
+  function (this: SafewordWorld) {
+    const current = setup(this, 'missing');
+    phaseContracts(current.distribution);
+    const installed = reconcile(current, 'install');
+    assert.equal(installed.status, 0, `${installed.stdout}\n${installed.stderr}`);
+    const contractPath = path.join(
+      current.distribution,
+      'templates/skills/bdd/PLAN_IMPLEMENTATION.md',
+    );
+    const contract = readFileSync(contractPath, 'utf8');
+    const start = contract.indexOf('<!-- SAFEWORD:PLANNING_SHARED_CLAUSE:scopeAuthority -->');
+    const end = contract.indexOf('<!-- SAFEWORD:PLANNING_SHARED_CLAUSE:trust -->', start);
+    assert.ok(start >= 0 && end > start, 'The generated clause markers must be present.');
+    writeFileSync(contractPath, contract.slice(0, start) + contract.slice(end));
+  },
+);
+
+function reconcileStep(this: SafewordWorld) {
+  const current = state(this);
+  current.result = reconcile(current, current.expected === 'phase-only' ? 'install' : 'upgrade');
+}
+
+When(
+  'the Safeword CLI reconciles the installed phase contracts through real project configuration',
+  reconcileStep,
+);
+When(
+  'the Safeword CLI reconciles both installed phase contracts through real project configuration',
+  reconcileStep,
+);
+
+Then(
+  'both generated contracts contain the same changed clause and neither retains the old text',
+  function (this: SafewordWorld) {
+    const current = state(this);
+    assert.equal(current.result?.status, 0, `${current.result?.stdout}\n${current.result?.stderr}`);
+    for (const name of ['PLAN_IMPLEMENTATION.md', 'PLAN_EXECUTION.md']) {
+      const installed = readFileSync(
+        path.join(current.project, '.safeword/skills/bdd', name),
+        'utf8',
+      );
+      assert.ok(installed.includes(changedClause), `${name} must receive the changed clause.`);
+      assert.ok(!installed.includes(originalClause), `${name} must drop the old clause.`);
+    }
+  },
+);
+
+Then(
+  'each clause appears only in its owning phase contract and neither appears in the other contract',
+  function (this: SafewordWorld) {
+    const current = state(this);
+    assert.equal(current.result?.status, 0, `${current.result?.stdout}\n${current.result?.stderr}`);
+    const implementation = readFileSync(
+      path.join(current.project, '.safeword/skills/bdd/PLAN_IMPLEMENTATION.md'),
+      'utf8',
+    );
+    const execution = readFileSync(
+      path.join(current.project, '.safeword/skills/bdd/PLAN_EXECUTION.md'),
+      'utf8',
+    );
+    assert.ok(implementation.includes('Direction and completeness'));
+    assert.ok(!implementation.includes('Startable steps:'));
+    assert.ok(execution.includes('Startable steps:'));
+    assert.ok(!execution.includes('Direction and completeness'));
+  },
+);
+
+Then(
+  'reconciliation is blocked with the missing shared clause and affected phase contract named',
+  function (this: SafewordWorld) {
+    const current = state(this);
+    assert.notEqual(current.result?.status, 0);
+    const output = JSON.parse(current.result?.stdout ?? '') as {
+      errors: { code: string }[];
+      findings: { code: string; metadata?: Record<string, unknown> }[];
+    };
+    assert.ok(output.errors.some(error => error.code === 'missing_generated_shared_clause'));
+    assert.ok(
+      output.findings.some(
+        finding =>
+          finding.code === 'missing_generated_shared_clause' &&
+          finding.metadata?.clause_id === 'scopeAuthority' &&
+          finding.metadata?.contract_path === 'skills/bdd/PLAN_IMPLEMENTATION.md',
+      ),
+    );
+  },
+);
diff --git a/steps/keep-plan-reviews-host-guidance.steps.ts b/steps/keep-plan-reviews-host-guidance.steps.ts
new file mode 100644
index 000000000..8ac08d875
--- /dev/null
+++ b/steps/keep-plan-reviews-host-guidance.steps.ts
@@ -0,0 +1,185 @@
+import { strict as assert } from 'node:assert';
+import { spawnSync } from 'node:child_process';
+import { mkdirSync, mkdtempSync, readFileSync, rmSync, writeFileSync } from 'node:fs';
+import { tmpdir } from 'node:os';
+import path from 'node:path';
+
+import { After, Given, Then, When } from '@cucumber/cucumber';
+
+import type { SafewordWorld } from './world.js';
+
+const packageRoot = path.resolve(import.meta.dirname, '../packages/cli');
+interface HostGuidanceState {
+  root: string;
+  agent: 'codex' | 'claude' | 'opencode';
+  surface: string;
+  guidance?: string;
+}
+const states = new WeakMap<SafewordWorld, HostGuidanceState>();
+
+function assertAdvisory(guidance: string, surface: string): void {
+  assert.ok(
+    guidance
+      .split(/[.!?]\s/u)
+      .some(sentence => sentence.includes(surface) && /\badvisory\b/u.test(sentence)),
+    guidance,
+  );
+  assert.match(guidance, /Do not claim[^.]{0,100}planning review or approval[^.]{0,80}there/su);
+  for (const sentence of guidance.split(/[.!?]\s/u)) {
+    if (sentence.includes(surface)) {
+      if (!/Do not claim/u.test(sentence)) {
+        assert.doesNotMatch(
+          sentence,
+          /\b(?:enforc\w*|authoritativ\w*|approv\w*|gated|review(?:s|ed)?)\b/iu,
+        );
+      }
+    }
+  }
+}
+
+function setup(world: SafewordWorld, surface: string, agent: HostGuidanceState['agent']): void {
+  const root = mkdtempSync(path.join(tmpdir(), 'safeword-planning-host-guidance-'));
+  mkdirSync(path.join(root, 'project'));
+  writeFileSync(
+    path.join(root, 'project/package.json'),
+    '{"name":"host-guidance","private":true}\n',
+  );
+  states.set(world, { root, agent, surface });
+}
+
+After(function (this: SafewordWorld) {
+  const state = states.get(this);
+  if (state) rmSync(state.root, { recursive: true, force: true });
+  states.delete(this);
+});
+
+Given(
+  'repository instructions are generated for use by local Codex and may be read by Codex Cloud',
+  function (this: SafewordWorld) {
+    setup(this, 'Codex Cloud', 'codex');
+  },
+);
+
+Given(
+  'the OpenCode profile plugin is read from Desktop where native lifecycle hooks are unavailable',
+  function (this: SafewordWorld) {
+    setup(this, 'OpenCode Desktop', 'opencode');
+  },
+);
+
+Given(
+  /^planning guidance is generated for (local Claude Code|OpenCode CLI)$/,
+  function (this: SafewordWorld, surface: string) {
+    setup(this, surface, surface === 'local Claude Code' ? 'claude' : 'opencode');
+  },
+);
+
+When(
+  /^the Safeword CLI reconciles (?:the installed repository guidance|the installed OpenCode profile guidance|that installed guidance) through real project configuration$/,
+  function (this: SafewordWorld) {
+    const state = states.get(this);
+    assert.ok(state);
+    const project = path.join(state.root, 'project');
+    const environment = {
+      ...process.env,
+      CODEX_HOME: path.join(state.root, 'codex'),
+      CLAUDE_CONFIG_DIR: path.join(state.root, 'claude'),
+      OPENCODE_CONFIG_DIR: path.join(state.root, 'opencode'),
+      SAFEWORD_SKIP_INSTALL: '1',
+      SAFEWORD_SKIP_SKILLS: '1',
+    };
+    if (state.agent === 'codex') {
+      mkdirSync(environment.CODEX_HOME);
+      for (const args of [
+        ['plugin', 'marketplace', 'add', path.resolve(packageRoot, '../..'), '--json'],
+        ['plugin', 'add', 'safeword@safeword', '--json'],
+      ]) {
+        const enrolled = spawnSync('codex', args, {
+          encoding: 'utf8',
+          timeout: 60_000,
+          env: environment,
+        });
+        assert.equal(enrolled.status, 0, `${enrolled.stdout}\n${enrolled.stderr}`);
+      }
+    }
+    const result = spawnSync(
+      'bun',
+      [
+        path.join(packageRoot, 'src/cli.ts'),
+        'install',
+        `--agents=${state.agent}`,
+        '--no-input',
+        '--no-modify',
+        ...(state.agent === 'opencode' ? ['--offline'] : []),
+        '--json',
+        '--cwd',
+        project,
+      ],
+      {
+        cwd: project,
+        encoding: 'utf8',
+        timeout: 60_000,
+        env: environment,
+      },
+    );
+    const output = JSON.parse(result.stdout) as { errors: unknown[]; changed: boolean };
+    assert.deepEqual(output.errors, [], `${result.stdout}\n${result.stderr}`);
+    assert.equal(output.changed, true);
+    const entry =
+      state.agent === 'opencode'
+        ? path.join(state.root, 'opencode/skills/safeword-bdd/SKILL.md')
+        : path.join(project, '.safeword/SAFEWORD.md');
+    state.guidance = readFileSync(entry, 'utf8');
+  },
+);
+
+Then(
+  'it labels Codex Cloud execution advisory, claims neither review nor approval there, and directs authoritative planning to a supported gated surface',
+  function (this: SafewordWorld) {
+    const guidance = states.get(this)?.guidance ?? '';
+    assertAdvisory(guidance, 'Codex Cloud');
+    assert.throws(() =>
+      assertAdvisory(
+        `${guidance}\nCodex Cloud approves plans through the planning review gate.`,
+        'Codex Cloud',
+      ),
+    );
+    assert.match(guidance, /authoritative planning[^.]{0,100}supported gated surface/su);
+  },
+);
+
+Then(
+  'it labels Desktop execution advisory, claims neither review nor approval there, and names both OpenCode CLI and TUI as authoritative planning entry points',
+  function (this: SafewordWorld) {
+    const guidance = states.get(this)?.guidance ?? '';
+    assertAdvisory(guidance, 'OpenCode Desktop');
+    assert.throws(() =>
+      assertAdvisory(
+        `${guidance}\nPlanning approval is granted in OpenCode Desktop.`,
+        'OpenCode Desktop',
+      ),
+    );
+    assert.match(
+      guidance,
+      /planning review and approval are enforced[^.]{0,150}OpenCode CLI and TUI/su,
+    );
+  },
+);
+
+Then(
+  'it states that planning review and approval are enforced there and does not label that surface advisory',
+  function (this: SafewordWorld) {
+    const state = states.get(this);
+    assert.ok(state?.guidance);
+    const surface =
+      state.surface === 'local Claude Code' ? 'local Claude Code' : 'OpenCode CLI and TUI';
+    const enforced = /planning review and approval are enforced[^.]{0,200}/su.exec(
+      state.guidance,
+    )?.[0];
+    assert.ok(enforced?.includes(surface), state.guidance);
+    assert.doesNotMatch(enforced, /advisory/u);
+    for (const sentence of state.guidance.split(/[.!?]\s/u)) {
+      if (sentence.includes(surface)) assert.doesNotMatch(sentence, /\badvisory\b/u);
+    }
+  },
+);
diff --git a/steps/keep-plan-reviews-installed-context.steps.ts b/steps/keep-plan-reviews-installed-context.steps.ts
new file mode 100644
index 000000000..ff1544159
--- /dev/null
+++ b/steps/keep-plan-reviews-installed-context.steps.ts
@@ -0,0 +1,657 @@
+import { strict as assert } from 'node:assert';
+import { spawnSync } from 'node:child_process';
+import { createHash } from 'node:crypto';
+import {
+  cpSync,
+  existsSync,
+  mkdirSync,
+  mkdtempSync,
+  readFileSync,
+  rmSync,
+  writeFileSync,
+} from 'node:fs';
+import { tmpdir } from 'node:os';
+import path from 'node:path';
+
+import { After, Given, Then, When } from '@cucumber/cucumber';
+
+import { SAFEWORD_SCHEMA } from '../packages/cli/src/schema.js';
+import { parsePlanningContract } from '../packages/cli/src/planning/phase-contract.js';
+import { extractPlanReviewRubric } from '../packages/cli/src/review/plan-rubric.js';
+import { writePlanningInventories } from '../packages/cli/tests/planning-fixtures.js';
+import {
+  createTrustedReviewerDirectory,
+  REVIEWER_CAPABILITIES,
+} from '../packages/cli/tests/review-fixtures.js';
+import type { SafewordWorld } from './world.js';
+
+const packageRoot = path.resolve(import.meta.dirname, '../packages/cli');
+const pluginRoot = path.resolve(import.meta.dirname, '../plugin');
+const ticketFolder = 'CTX123-current-context';
+const ticketRoot = `.project/tickets/${ticketFolder}`;
+
+interface InstalledContextState {
+  root: string;
+  reviewer: string;
+  overrideState: string;
+  runtimeRoot?: string;
+  gate?: ReturnType<typeof spawnSync>;
+  authorGate?: ReturnType<typeof spawnSync>;
+  reviewDispatch?: ReturnType<typeof spawnSync>;
+  contractCase?: 'reviewer-drift' | 'reviewer-missing' | 'canonical';
+  cosmeticContractChanged?: boolean;
+  reviewStatus?: ReturnType<typeof spawnSync>;
+  reviewId?: string;
+}
+const states = new WeakMap<SafewordWorld, InstalledContextState>();
+
+function copiedRuntimeReviewStatus(state: InstalledContextState) {
+  assert.ok(state.runtimeRoot && state.reviewId);
+  return spawnSync(
+    'bun',
+    [path.join(state.runtimeRoot, 'runtime/cli.js'), 'review', 'status', state.reviewId, '--json'],
+    {
+      cwd: state.root,
+      encoding: 'utf8',
+      timeout: 60_000,
+      env: {
+        ...process.env,
+        PATH: `${state.reviewer}:${process.env.PATH ?? ''}`,
+        CLAUDE_PROJECT_DIR: state.root,
+        CLAUDE_PLUGIN_ROOT: state.runtimeRoot,
+        CLAUDE_SESSION_ID: 'r3-installed',
+        SAFEWORD_AGENT_RUNTIME: 'claude',
+      },
+    },
+  );
+}
+
+export function fixtureProject(): string {
+  const root = mkdtempSync(path.join(tmpdir(), 'safeword-r3-installed-'));
+  writePlanningInventories(root);
+  mkdirSync(path.join(root, ticketRoot), { recursive: true });
+  mkdirSync(path.join(root, 'features'));
+  writeFileSync(path.join(root, 'package.json'), '{"name":"r3-installed","private":true}\n');
+  writeFileSync(
+    path.join(root, ticketRoot, 'ticket.md'),
+    `---\nid: CTX123\ntype: feature\nphase: plan-implementation\nstatus: in_progress\nproduct_plan_contract: v1\nscope: preserve authenticated approval\nout_of_scope: new approval authority\ndone_when: current context reaches review\nphase_anchors:\n  - scenario-gate: features/current-context.feature\n---\n# Ticket\n`,
+  );
+  writeFileSync(
+    path.join(root, ticketRoot, 'spec.md'),
+    `# Product Plan: Preserve approval\n\n<!-- safeword:product-plan-contract:v1 -->\n\n## Product Bet\n\n- **Expected outcome:** Builders advance with current approval.\n- **Persona outcome inventory:** Builder receives approval or a named refusal.\n- **Known facts:** Approval authenticates the current source.\n- **Assumptions:** Review latency is acceptable.\n- **Unresolved product decisions:** none\n- **Success threshold:** Current approval advances.\n- **Project non-goals:** No new approval authority.\n\n## Jobs To Be Done\n\n### approval.BU1 — Trust approval\n\n**Persona:** Builder (BU)\n\n> When I request approval, I want current evidence, so I can trust advancement.\n\n#### approval.BU1.R1 — Preserve approval\n\nOnly current approval advances.\n\n## Surfaces\n\nAffected:\n- Safeword CLI\n`,
+  );
+  writeFileSync(
+    path.join(root, ticketRoot, 'impl-plan.md'),
+    `# Implementation Plan: Preserve approval\n\n**Status:** planned\n\n## Approach\n\nUse the current review receipt to guard the transition.\n\n## Decisions\n\n### Recorded Decisions\n\n| Decision | Choice | Alternatives considered | Rejected because |\n| --- | --- | --- | --- |\n| review gate | current receipt | unchecked transition | stale approval can advance |\n\n## Design alignment\n\nskip: No additional principle trace applies to this fixture.\n\n## Architecture applicability\n\nskip: No durable architecture record applies.\n\n## Data applicability\n\nskip: No product data is stored.\n\n## Known deviations\n\nskip: No known deviations.\n\n## Doc impact\n\nskip: No documentation changes.\n\n## Assessment triggers\n\nRevisit when the approval authority changes.\n`,
+  );
+  writeFileSync(
+    path.join(root, 'features/current-context.feature'),
+    '@approval.BU1.R1 @surface.safeword-cli\nFeature: Trust current approval\n  Scenario: Approval\n    Given a current review\n    When the Builder requests approval\n    Then the current context reaches review\n',
+  );
+  return root;
+}
+
+function configure(root: string, override: string): void {
+  const configPath = path.join(root, '.safeword/config.json');
+  const installed = JSON.parse(readFileSync(configPath, 'utf8')) as Record<string, unknown>;
+  writeFileSync(
+    configPath,
+    JSON.stringify({
+      ...installed,
+      reviewGate: true,
+      crossAgentReview: 'prefer',
+      crossAgentReviewRoutes: { claude: [{ reviewer: 'opencode' }] },
+      paths: { ...(installed.paths as Record<string, unknown>), principles: override },
+      pathLineage: { principles: { packagedSourceVersion: SAFEWORD_SCHEMA.version } },
+    }),
+  );
+}
+
+export function reviewerExecutable(reviewer: string): void {
+  writeFileSync(
+    path.join(reviewer, 'opencode'),
+    String.raw`#!${process.execPath}
+if (process.argv.includes('--version')) { console.log('opencode 1.0.0'); process.exit(0); }
+if (process.argv.includes('--help')) { console.log(${JSON.stringify(REVIEWER_CAPABILITIES.opencode)}); process.exit(0); }
+let input = ''; process.stdin.setEncoding('utf8');
+process.stdin.on('data', chunk => { input += chunk; });
+process.stdin.on('end', () => {
+  const packet = JSON.parse(input.trim().split('\n').pop());
+  const output = { schema_version: 1, dispatch_id: packet.dispatch_id,
+    reviewer_agent: 'opencode', verdict: 'approve', summary: 'Current plan approved.',
+    findings: [], evidence_records: { schema_version: 1, records: [] } };
+  console.log(JSON.stringify({ type: 'text', part: { type: 'text', time: { end: 1 }, text: JSON.stringify(output) } }));
+});
+`,
+    { mode: 0o755 },
+  );
+}
+
+After(function (this: SafewordWorld) {
+  const state = states.get(this);
+  if (state) {
+    rmSync(state.root, { recursive: true, force: true });
+    rmSync(state.reviewer, { recursive: true, force: true });
+    if (state.runtimeRoot) rmSync(state.runtimeRoot, { recursive: true, force: true });
+  }
+  states.delete(this);
+});
+
+function establishApprovedPlanningContext(this: SafewordWorld, overrideState: string) {
+  const root = fixtureProject();
+  const reviewer = createTrustedReviewerDirectory('safeword-r3-reviewer-');
+  states.set(this, { root, reviewer, overrideState });
+  const install = spawnSync(
+    'bun',
+    [
+      path.join(packageRoot, 'src/cli.ts'),
+      'install',
+      '--agents=claude',
+      '--no-input',
+      '--no-modify',
+      '--json',
+      '--cwd',
+      root,
+    ],
+    {
+      cwd: root,
+      encoding: 'utf8',
+      timeout: 60_000,
+      env: {
+        ...process.env,
+        CLAUDE_CONFIG_DIR: path.join(root, 'claude'),
+        SAFEWORD_SKIP_INSTALL: '1',
+        SAFEWORD_SKIP_SKILLS: '1',
+      },
+    },
+  );
+  const installOutput = JSON.parse(install.stdout) as { errors: unknown[] };
+  assert.deepEqual(installOutput.errors, [], `${install.stdout}\n${install.stderr}`);
+  const override = 'docs/principles.md';
+  mkdirSync(path.join(root, 'docs'));
+  writeFileSync(path.join(root, override), '# Project principles\n\nKeep approval current.\n');
+  configure(root, override);
+  reviewerExecutable(reviewer);
+  const environment = {
+    ...process.env,
+    PATH: `${reviewer}:${process.env.PATH ?? ''}`,
+    CLAUDE_PROJECT_DIR: root,
+    CLAUDE_PLUGIN_ROOT: pluginRoot,
+    CLAUDE_SESSION_ID: 'r3-installed',
+    SAFEWORD_AGENT_RUNTIME: 'claude',
+  };
+  const reviewed = spawnSync(
+    'bun',
+    [
+      path.join(packageRoot, 'src/cli.ts'),
+      'review',
+      'run',
+      'plan-implementation',
+      `${ticketRoot}/impl-plan.md`,
+      '--json',
+      '--no-input',
+    ],
+    { cwd: root, encoding: 'utf8', timeout: 60_000, env: environment },
+  );
+  assert.equal(reviewed.status, 0, `${reviewed.stdout}\n${reviewed.stderr}`);
+  const result = JSON.parse(reviewed.stdout) as { data: { status: string; review_id: string } };
+  assert.equal(result.data.status, 'approved');
+  const state = states.get(this);
+  assert.ok(state);
+  state.reviewId = result.data.review_id;
+  const stamp = spawnSync(
+    'bun',
+    [
+      path.join(pluginRoot, 'runtime/hooks/write-review-stamp.ts'),
+      '--ticket',
+      ticketFolder,
+      '--author-agent',
+      'claude',
+      '--reviewer-agent',
+      'opencode',
+      '--independence',
+      'reduced',
+      '--review-id',
+      result.data.review_id,
+      'impl-plan',
+    ],
+    { cwd: root, encoding: 'utf8', timeout: 60_000, env: environment },
+  );
+  assert.equal(stamp.status, 0, `${stamp.stdout}\n${stamp.stderr}`);
+  const phaseStamp = spawnSync(
+    'bun',
+    [
+      path.join(pluginRoot, 'runtime/hooks/write-review-stamp.ts'),
+      '--ticket',
+      ticketFolder,
+      '--author-agent',
+      'claude',
+      '--reviewer-agent',
+      'opencode',
+      '--independence',
+      'reduced',
+      '--review-id',
+      result.data.review_id,
+      '--phase',
+      'plan-implementation',
+    ],
+    { cwd: root, encoding: 'utf8', timeout: 60_000, env: environment },
+  );
+  assert.equal(phaseStamp.status, 0, `${phaseStamp.stdout}\n${phaseStamp.stderr}`);
+  const current = spawnSync(
+    'bun',
+    [path.join(packageRoot, 'src/cli.ts'), 'review', 'status', result.data.review_id, '--json'],
+    { cwd: root, encoding: 'utf8', timeout: 60_000, env: environment },
+  );
+  const currentStatus = JSON.parse(current.stdout) as { data: { status: string } };
+  assert.equal(currentStatus.data.status, 'approved', `${current.stdout}\n${current.stderr}`);
+  if (overrideState === 'blank') writeFileSync(path.join(root, override), ' \n');
+  if (overrideState.startsWith('stale')) {
+    const configPath = path.join(root, '.safeword/config.json');
+    const config = JSON.parse(readFileSync(configPath, 'utf8')) as Record<string, unknown>;
+    writeFileSync(
+      configPath,
+      JSON.stringify({
+        ...config,
+        pathLineage: { principles: { packagedSourceVersion: '0.0.0' } },
+      }),
+    );
+  }
+}
+
+Given(
+  /^a planning phase with a current approving receipt has a required project-knowledge override that is (.+)$/,
+  establishApprovedPlanningContext,
+);
+
+Given(
+  /^a planning phase with a current approving receipt has an installed authoring contract that (.+)$/,
+  function (this: SafewordWorld, contractState: string) {
+    establishApprovedPlanningContext.call(this, 'current');
+    const state = states.get(this);
+    assert.ok(state);
+    state.runtimeRoot = mkdtempSync(path.join(tmpdir(), 'safeword-r5-installed-plugin-'));
+    cpSync(pluginRoot, state.runtimeRoot, { recursive: true });
+    if (contractState === 'matches the exact canonical bytes') return;
+    assert.equal(contractState, 'deletes one clause but retains the canonical version label');
+    const contractPath = path.join(state.runtimeRoot, 'skills/bdd/PLAN_IMPLEMENTATION.md');
+    const original = readFileSync(contractPath, 'utf8');
+    const clause = 'Accepted scope and exclusions belong to the user.';
+    assert.ok(
+      original.includes(clause),
+      'The installed contract must contain the canonical clause.',
+    );
+    writeFileSync(contractPath, original.replace(clause, ''));
+  },
+);
+
+Given(
+  /^the installed authoring contract (deletes one clause but retains the canonical version label|differs from the canonical source only in whitespace or comments|is absent)$/,
+  function (this: SafewordWorld, contractState: string) {
+    establishApprovedPlanningContext.call(this, 'current');
+    const state = states.get(this);
+    assert.ok(state);
+    state.runtimeRoot = mkdtempSync(path.join(tmpdir(), 'safeword-r5-installed-plugin-'));
+    cpSync(pluginRoot, state.runtimeRoot, { recursive: true });
+    const contractPath = path.join(state.runtimeRoot, 'skills/bdd/PLAN_IMPLEMENTATION.md');
+    if (contractState === 'is absent') {
+      rmSync(contractPath);
+      return;
+    }
+    const original = readFileSync(contractPath, 'utf8');
+    if (contractState === 'differs from the canonical source only in whitespace or comments') {
+      writeFileSync(contractPath, `<!-- editorial -->\n${original}`);
+      return;
+    }
+    const clause = 'Accepted scope and exclusions belong to the user.';
+    assert.ok(original.includes(clause));
+    writeFileSync(contractPath, original.replace(clause, ''));
+  },
+);
+
+Given(
+  /^the (generated reviewer rubric deletes one clause but retains the canonical version label|generated reviewer rubric is absent|authoring contract and reviewer rubric both match the exact canonical bytes)$/,
+  function (this: SafewordWorld, contractState: string) {
+    establishApprovedPlanningContext.call(this, 'current');
+    const state = states.get(this);
+    assert.ok(state);
+    state.runtimeRoot = mkdtempSync(path.join(tmpdir(), 'safeword-r5-installed-plugin-'));
+    cpSync(pluginRoot, state.runtimeRoot, { recursive: true });
+    state.contractCase =
+      contractState === 'generated reviewer rubric is absent'
+        ? 'reviewer-missing'
+        : contractState ===
+            'generated reviewer rubric deletes one clause but retains the canonical version label'
+          ? 'reviewer-drift'
+          : 'canonical';
+    if (state.contractCase === 'canonical') return;
+    const runtime = path.join(state.runtimeRoot, 'runtime/cli.js');
+    const source = readFileSync(runtime, 'utf8');
+    const start = source.indexOf('var PLAN_REVIEW_RUBRIC = `');
+    const end = source.indexOf('PLAN_REVIEW_RUBRIC_SHA256', start);
+    if (state.contractCase === 'reviewer-missing') {
+      const contentStart = start + 'var PLAN_REVIEW_RUBRIC = `'.length;
+      const contentEnd = source.lastIndexOf('`', end);
+      assert.ok(start >= 0 && contentEnd > contentStart);
+      writeFileSync(runtime, source.slice(0, contentStart) + source.slice(contentEnd));
+      return;
+    }
+    const clause = 'Accepted scope and exclusions belong to the user.';
+    const clauseIndex = source.indexOf(clause, start);
+    assert.ok(start >= 0 && clauseIndex > start && clauseIndex < end);
+    writeFileSync(
+      runtime,
+      source.slice(0, clauseIndex) + source.slice(clauseIndex + clause.length),
+    );
+  },
+);
+
+Given(
+  'a plan review is current and its authoring guidance changed only in comments outside the canonical contract after installed copies were generated',
+  function (this: SafewordWorld) {
+    establishApprovedPlanningContext.call(this, 'current');
+    const state = states.get(this);
+    assert.ok(state);
+    state.runtimeRoot = mkdtempSync(path.join(tmpdir(), 'safeword-r5-cosmetic-plugin-'));
+    cpSync(pluginRoot, state.runtimeRoot, { recursive: true });
+    const baseline = copiedRuntimeReviewStatus(state);
+    assert.equal(baseline.status, 0, `${baseline.stdout}\n${baseline.stderr}`);
+    assert.equal(
+      (JSON.parse(baseline.stdout) as { data?: { status?: string } }).data?.status,
+      'approved',
+    );
+    const installed = path.join(state.runtimeRoot, 'skills/bdd/PLAN_IMPLEMENTATION.md');
+    const template = path.join(state.runtimeRoot, 'templates/skills/bdd/PLAN_IMPLEMENTATION.md');
+    const oldBytes = readFileSync(installed);
+    const oldHash = createHash('sha256').update(oldBytes).digest('hex');
+    const newBytes = Buffer.concat([oldBytes, Buffer.from('\n<!-- editorial -->\n')]);
+    const newHash = createHash('sha256').update(newBytes).digest('hex');
+    assert.equal(
+      extractPlanReviewRubric(newBytes.toString('utf8')),
+      extractPlanReviewRubric(oldBytes.toString('utf8')),
+    );
+    const originalTemplate = readFileSync(template, 'utf8');
+    const changedTemplate = `${originalTemplate}\n<!-- editorial -->\n`;
+    assert.deepEqual(
+      parsePlanningContract('plan-implementation', changedTemplate),
+      parsePlanningContract('plan-implementation', originalTemplate),
+    );
+    writeFileSync(template, changedTemplate);
+    const runtime = path.join(state.runtimeRoot, 'runtime/cli.js');
+    const source = readFileSync(runtime, 'utf8');
+    const authorIdentity = `relativePath: "skills/bdd/PLAN_IMPLEMENTATION.md", sha256: "${oldHash}"`;
+    assert.ok(
+      source.includes(authorIdentity),
+      'the installed runtime must name the old author copy',
+    );
+    writeFileSync(
+      runtime,
+      source.replace(authorIdentity, authorIdentity.replace(oldHash, newHash)),
+    );
+    state.cosmeticContractChanged = true;
+  },
+);
+
+When(
+  'the content identity of every generated contract copy is recomputed',
+  function (this: SafewordWorld) {
+    const state = states.get(this);
+    assert.ok(state?.runtimeRoot);
+    const hook = path.join(state.runtimeRoot, 'runtime/hooks/pre-tool-quality.ts');
+    state.authorGate = spawnSync('bun', [hook], {
+      cwd: state.root,
+      encoding: 'utf8',
+      timeout: 60_000,
+      input: JSON.stringify({
+        session_id: 'r3-installed',
+        tool_name: 'Edit',
+        tool_input: {
+          file_path: path.join(state.root, ticketRoot, 'impl-plan.md'),
+          old_string: 'Use the current review receipt',
+          new_string: 'Use the authenticated current review receipt',
+        },
+      }),
+      env: {
+        ...process.env,
+        PATH: `${state.reviewer}:${process.env.PATH ?? ''}`,
+        CLAUDE_PROJECT_DIR: state.root,
+        CLAUDE_PLUGIN_ROOT: state.runtimeRoot,
+        CLAUDE_SESSION_ID: 'r3-installed',
+      },
+    });
+    state.gate = spawnSync('bun', [hook], {
+      cwd: state.root,
+      encoding: 'utf8',
+      timeout: 60_000,
+      input: JSON.stringify({
+        session_id: 'r3-installed',
+        tool_name: 'Edit',
+        tool_input: {
+          file_path: path.join(state.root, ticketRoot, 'ticket.md'),
+          old_string: 'phase: plan-implementation',
+          new_string: 'phase: plan-execution',
+        },
+      }),
+      env: {
+        ...process.env,
+        PATH: `${state.reviewer}:${process.env.PATH ?? ''}`,
+        CLAUDE_PROJECT_DIR: state.root,
+        CLAUDE_PLUGIN_ROOT: state.runtimeRoot,
+        CLAUDE_SESSION_ID: 'r3-installed',
+      },
+    });
+    if (state.contractCase) {
+      state.reviewDispatch = spawnSync(
+        'bun',
+        [
+          path.join(state.runtimeRoot, 'runtime/cli.js'),
+          'review',
+          'run',
+          'plan-implementation',
+          `${ticketRoot}/impl-plan.md`,
+          '--json',
+          '--no-input',
+        ],
+        {
+          cwd: state.root,
+          encoding: 'utf8',
+          timeout: 60_000,
+          env: {
+            ...process.env,
+            PATH: `${state.reviewer}:${process.env.PATH ?? ''}`,
+            CLAUDE_PROJECT_DIR: state.root,
+            CLAUDE_PLUGIN_ROOT: state.runtimeRoot,
+            CLAUDE_SESSION_ID: 'r3-installed',
+            SAFEWORD_AGENT_RUNTIME: 'claude',
+          },
+        },
+      );
+    }
+  },
+);
+
+Then(
+  /^authoring and approval are blocked until (?:the exact canonical contract bytes|the canonical contract) (?:are|is) restored$/,
+  function (this: SafewordWorld) {
+    const state = states.get(this);
+    assert.ok(state?.authorGate && state.gate);
+    for (const result of [state.authorGate, state.gate]) {
+      assert.equal(result.status, 0, result.stderr);
+      const output = JSON.parse(result.stdout) as {
+        hookSpecificOutput?: { permissionDecision?: string; permissionDecisionReason?: string };
+      };
+      assert.equal(output.hookSpecificOutput?.permissionDecision, 'deny');
+      assert.match(
+        output.hookSpecificOutput?.permissionDecisionReason ?? '',
+        /(?:canonical_contract_copy_mismatch|missing_generated_contract_copy)/,
+      );
+    }
+  },
+);
+
+Then(
+  /^review dispatch and approval are blocked until (?:the exact canonical contract bytes|the canonical contract) (?:are|is) restored$/,
+  function (this: SafewordWorld) {
+    const state = states.get(this);
+    assert.ok(state?.reviewDispatch && state.gate);
+    assert.notEqual(state.reviewDispatch.status, 0);
+    const dispatch = JSON.parse(state.reviewDispatch.stdout) as {
+      findings?: Array<{ code?: string; message?: string }>;
+    };
+    assert.ok(
+      dispatch.findings?.some(finding =>
+        /reviewer contract|canonical contract/.test(finding.message ?? ''),
+      ),
+      state.reviewDispatch.stdout,
+    );
+    assert.equal(state.gate.status, 0, state.gate.stderr);
+    assert.notEqual(state.gate.stdout.trim(), '', 'approval gate allowed a stale reviewer copy');
+    const approval = JSON.parse(state.gate.stdout) as {
+      hookSpecificOutput?: { permissionDecision?: string; permissionDecisionReason?: string };
+    };
+    assert.equal(approval.hookSpecificOutput?.permissionDecision, 'deny');
+    const code = 'canonical_contract_copy_mismatch';
+    assert.match(
+      dispatch.findings?.find(finding => finding.code === code)?.message ?? '',
+      /Restore the packaged decision-quality contract/,
+    );
+    assert.match(
+      approval.hookSpecificOutput?.permissionDecisionReason ?? '',
+      /Restore the packaged decision-quality contract/,
+    );
+    assert.ok(
+      dispatch.findings?.some(finding => finding.code === code),
+      state.reviewDispatch.stdout,
+    );
+    assert.match(
+      approval.hookSpecificOutput?.permissionDecisionReason ?? '',
+      new RegExp(`${code}.*plan-rubric\\.generated\\.ts`, 'su'),
+    );
+  },
+);
+
+Then(
+  'both copies recompute to the same identity and contract identity does not block authoring, dispatch, or approval',
+  function (this: SafewordWorld) {
+    const state = states.get(this);
+    assert.ok(state?.authorGate && state.reviewDispatch && state.gate);
+    assert.equal(state.authorGate.status, 0, state.authorGate.stderr);
+    assert.equal(state.authorGate.stdout.trim(), '', state.authorGate.stdout);
+    assert.equal(state.reviewDispatch.status, 0, state.reviewDispatch.stdout);
+    assert.equal(state.gate.status, 0, state.gate.stderr);
+    assert.equal(state.gate.stdout.trim(), '', state.gate.stdout);
+  },
+);
+
+When(
+  'actual lifecycle dispatch from installed local project hooks evaluates the phase transition with real configuration and collaborators, mocking only the reviewer process boundary',
+  function (this: SafewordWorld) {
+    const state = states.get(this);
+    assert.ok(state);
+    const ticketPath = path.join(state.root, ticketRoot, 'ticket.md');
+    const hook = path.join(state.runtimeRoot ?? pluginRoot, 'runtime/hooks/pre-tool-quality.ts');
+    assert.ok(existsSync(hook));
+    state.gate = spawnSync('bun', [hook], {
+      cwd: state.root,
+      encoding: 'utf8',
+      timeout: 60_000,
+      input: JSON.stringify({
+        session_id: 'r3-installed',
+        tool_name: 'Edit',
+        tool_input: {
+          file_path: ticketPath,
+          old_string: 'phase: plan-implementation',
+          new_string: 'phase: plan-execution',
+        },
+      }),
+      env: {
+        ...process.env,
+        PATH: `${state.reviewer}:${process.env.PATH ?? ''}`,
+        CLAUDE_PROJECT_DIR: state.root,
+        CLAUDE_PLUGIN_ROOT: state.runtimeRoot ?? pluginRoot,
+        CLAUDE_SESSION_ID: 'r3-installed',
+        SAFEWORD_AGENT_RUNTIME: 'claude',
+      },
+    });
+    if (state.cosmeticContractChanged) {
+      state.reviewStatus = copiedRuntimeReviewStatus(state);
+    }
+  },
+);
+
+Then('the phase transition proceeds', function (this: SafewordWorld) {
+  const gate = states.get(this)?.gate;
+  assert.ok(gate);
+  assert.equal(gate.status, 0, `${gate.stdout}\n${gate.stderr}`);
+  assert.equal(gate.stdout.trim(), '', gate.stdout);
+});
+
+Then(
+  'the phase remains blocked with canonical contract reconciliation named',
+  function (this: SafewordWorld) {
+    const gate = states.get(this)?.gate;
+    assert.ok(gate);
+    assert.equal(gate.status, 0, gate.stderr);
+    const output = JSON.parse(gate.stdout) as {
+      hookSpecificOutput?: { permissionDecision?: string; permissionDecisionReason?: string };
+    };
+    assert.equal(output.hookSpecificOutput?.permissionDecision, 'deny');
+    const reason = output.hookSpecificOutput?.permissionDecisionReason ?? '';
+    assert.ok(
+      reason.includes('canonical_contract_copy_mismatch'),
+      `Canonical contract reconciliation was not named at the installed phase gate. Actual reason: ${reason}`,
+    );
+    assert.ok(
+      reason.includes('skills/bdd/PLAN_IMPLEMENTATION.md'),
+      `The installed authoring contract path was not named at the phase gate. Actual reason: ${reason}`,
+    );
+  },
+);
+
+Then(
+  'the review receipt remains current and the phase remains blocked with canonical contract reconciliation named',
+  function (this: SafewordWorld) {
+    const state = states.get(this);
+    assert.ok(state?.reviewStatus && state.gate);
+    assert.equal(
+      state.reviewStatus.status,
+      0,
+      `cosmetic canonical copy drift incorrectly staled review: ${state.reviewStatus.stdout}\n${state.reviewStatus.stderr}`,
+    );
+    const status = JSON.parse(state.reviewStatus.stdout) as { data?: { status?: string } };
+    assert.equal(status.data?.status, 'approved');
+    assert.equal(state.gate.status, 0, state.gate.stderr);
+    const gate = JSON.parse(state.gate.stdout) as {
+      hookSpecificOutput?: { permissionDecision?: string; permissionDecisionReason?: string };
+    };
+    assert.equal(gate.hookSpecificOutput?.permissionDecision, 'deny');
+    assert.match(
+      gate.hookSpecificOutput?.permissionDecisionReason ?? '',
+      /canonical_contract_copy_mismatch.*skills\/bdd\/PLAN_IMPLEMENTATION\.md/su,
+    );
+  },
+);
+
+Then(
+  'the phase remains blocked with override reconciliation named',
+  function (this: SafewordWorld) {
+    const state = states.get(this);
+    const gate = state?.gate;
+    assert.ok(gate);
+    assert.ok(state);
+    assert.equal(gate.status, 0, gate.stderr);
+    const output = JSON.parse(gate.stdout) as {
+      hookSpecificOutput?: { permissionDecision?: string; permissionDecisionReason?: string };
+    };
+    assert.equal(output.hookSpecificOutput?.permissionDecision, 'deny');
+    const reason = output.hookSpecificOutput?.permissionDecisionReason ?? '';
+    const expected =
+      state.overrideState === 'blank'
+        ? 'Planning principles override at docs/principles.md needs reconciliation with the current packaged source.'
+        : 'Planning principles override at .safeword/config.json:pathLineage.principles needs reconciliation with the current packaged source.';
+    assert.ok(
+      reason.includes(expected),
+      `Override reconciliation was not named at the installed phase gate. Actual reason: ${reason}`,
+    );
+  },
+);
diff --git a/steps/keep-plan-reviews-scope-eval.steps.ts b/steps/keep-plan-reviews-scope-eval.steps.ts
new file mode 100644
index 000000000..d08310c23
--- /dev/null
+++ b/steps/keep-plan-reviews-scope-eval.steps.ts
@@ -0,0 +1,47 @@
+import { strict as assert } from 'node:assert';
+
+import { Given, Then, When } from '@cucumber/cucumber';
+
+import {
+  assertPlanningEval,
+  runPlanningEval,
+  selectPlanningEval,
+} from './support/planning-eval.js';
+import type { SafewordWorld } from './world.js';
+
+const cases = {
+  'omits authorization behavior': 'r13-in-scope-omission',
+  'includes automatic account migration': 'r13-out-of-scope-addition',
+  'decides authorization and excludes account migration': 'r13-conforming-boundary',
+} as const;
+
+Given(
+  /^an accepted boundary requires authorization and excludes automatic account migration and the plan (.+)$/,
+  function (this: SafewordWorld, planState: keyof typeof cases) {
+    const caseId = cases[planState];
+    assert.ok(caseId, `Unknown R13 plan state: ${planState}`);
+    const evaluationCase = selectPlanningEval(this, caseId);
+    assert.match(evaluationCase.accepted_boundary, /explicit user authorization/u);
+    assert.match(evaluationCase.accepted_boundary, /no automatic account migration/u);
+  },
+);
+
+When(
+  'a judged semantic reviewer evaluation applies the canonical bidirectional scope-completeness rubric to the plan',
+  { timeout: 240_000 },
+  function (this: SafewordWorld) {
+    runPlanningEval(this);
+  },
+);
+
+Then('approval is blocked with the in-scope omission named', function (this: SafewordWorld) {
+  assertPlanningEval(this, 'request_changes', /authoriz/iu);
+});
+
+Then('approval is blocked with the out-of-scope proposal named', function (this: SafewordWorld) {
+  assertPlanningEval(this, 'request_changes', /automatic.{0,20}migrat/iu);
+});
+
+Then('scope completeness does not block approval', function (this: SafewordWorld) {
+  assertPlanningEval(this, 'approve');
+});
diff --git a/steps/plan-implementation-phase.steps.ts b/steps/plan-implementation-phase.steps.ts
index b62ac024a..2368250c1 100644
--- a/steps/plan-implementation-phase.steps.ts
+++ b/steps/plan-implementation-phase.steps.ts
@@ -440,7 +440,11 @@ function runPreTool(
 ): HookVerdict {
   const stdout = execFileSync('bun', [PRE_TOOL_HOOK], {
     cwd: PROJECT_ROOT,
-    env: { ...process.env, CLAUDE_PROJECT_DIR: world.projectDirectory },
+    env: {
+      ...process.env,
+      CLAUDE_PROJECT_DIR: world.projectDirectory,
+      SAFEWORD_PLUGIN_CLI: nodePath.join(CODEX_PLUGIN_ROOT, 'runtime', 'cli.js'),
+    },
     input: JSON.stringify({ session_id: sessionId, tool_name: toolName, tool_input: toolInput }),
     encoding: 'utf8',
   });
@@ -507,6 +511,7 @@ function arrangeRepairReviewer(world: PlanWorld, plan: string): void {
   writeFileSync(
     reviewer,
     `#!/bin/sh
+if [ "${'$'}{1:-}" = "--version" ]; then echo 'claude 1.0.0'; exit 0; fi
 if printf '%s' "$*" | /usr/bin/grep -q -- '--help'; then
   echo '${REVIEWER_CAPABILITIES.claude}'
   exit 0
@@ -514,13 +519,13 @@ fi
 payload=$(/bin/cat)
 dispatch_id=$(printf '%s' "$payload" | /usr/bin/sed -n 's/.*"dispatch_id":"\\([^"]*\\)".*/\\1/p')
 if printf '%s' "$payload" | /usr/bin/grep -q 'REPAIR_COMPLETE'; then
-  printf '{"schema_version":1,"dispatch_id":"%s","reviewer_agent":"claude","verdict":"approve","summary":"Current exact bytes are complete.","findings":[]}\\n' "$dispatch_id"
+  printf '{"schema_version":1,"dispatch_id":"%s","reviewer_agent":"claude","verdict":"approve","summary":"Current exact bytes are complete.","findings":[],"evidence_records":{"schema_version":1,"records":[]}}\\n' "$dispatch_id"
 elif printf '%s' "$payload" | /usr/bin/grep -q 'REPAIR_EXTERNAL'; then
-  printf '{"schema_version":1,"dispatch_id":"%s","reviewer_agent":"claude","verdict":"request_changes","summary":"Plan is waiting on its behavior owner.","findings":[{"severity":"error","message":"Pending user decision: choose deny-by-default or cached access. Deny-by-default prevents exposure but reduces availability; cached access preserves availability but can serve stale authority. Resume: ask the user to choose one outcome, record it, then re-run plan review."}]}\\n' "$dispatch_id"
+  printf '{"schema_version":1,"dispatch_id":"%s","reviewer_agent":"claude","verdict":"request_changes","summary":"Plan is waiting on its behavior owner.","findings":[{"severity":"error","message":"Pending user decision: choose deny-by-default or cached access. Deny-by-default prevents exposure but reduces availability; cached access preserves availability but can serve stale authority. Resume: ask the user to choose one outcome, record it, then re-run plan review."}],"evidence_records":{"schema_version":1,"records":[]}}\\n' "$dispatch_id"
 elif printf '%s' "$payload" | /usr/bin/grep -q 'REPAIR_AUTH_MISSING'; then
-  printf '{"schema_version":1,"dispatch_id":"%s","reviewer_agent":"claude","verdict":"request_changes","summary":"Authorization remains unresolved.","findings":[{"severity":"error","message":"Authorization boundary is still missing; return to repair and decide where every request is checked."}]}\\n' "$dispatch_id"
+  printf '{"schema_version":1,"dispatch_id":"%s","reviewer_agent":"claude","verdict":"request_changes","summary":"Authorization remains unresolved.","findings":[{"severity":"error","message":"Authorization boundary is still missing; return to repair and decide where every request is checked."}],"evidence_records":{"schema_version":1,"records":[]}}\\n' "$dispatch_id"
 else
-  printf '{"schema_version":1,"dispatch_id":"%s","reviewer_agent":"claude","verdict":"request_changes","summary":"Three current design defects block approval.","findings":[{"severity":"error","message":"Authorization boundary is missing."},{"severity":"error","message":"Persisted resource owner conflicts with its policy-service source of truth."},{"severity":"error","message":"Rollback behavior is undecided."}]}\\n' "$dispatch_id"
+  printf '{"schema_version":1,"dispatch_id":"%s","reviewer_agent":"claude","verdict":"request_changes","summary":"Three current design defects block approval.","findings":[{"severity":"error","message":"Authorization boundary is missing."},{"severity":"error","message":"Persisted resource owner conflicts with its policy-service source of truth."},{"severity":"error","message":"Rollback behavior is undecided."}],"evidence_records":{"schema_version":1,"records":[]}}\\n' "$dispatch_id"
 fi
 `,
   );
@@ -588,7 +593,7 @@ function arrangeArchitectureReceipt(world: PlanWorld): void {
   const reviewer = nodePath.join(world.reviewerBinDirectory, 'claude');
   writeFileSync(
     reviewer,
-    `#!/bin/sh\nif printf '%s' "$*" | /usr/bin/grep -q -- '--help'; then\n  echo '${REVIEWER_CAPABILITIES.claude}'\n  exit 0\nfi\npayload=$(/bin/cat)\ndispatch_id=$(printf '%s' "$payload" | /usr/bin/sed -n 's/.*"dispatch_id":"\\([^"]*\\)".*/\\1/p')\nprintf '{"schema_version":1,"dispatch_id":"%s","reviewer_agent":"claude","verdict":"request_changes","summary":"The architecture decision needs attention.","findings":[{"severity":"error","message":"The shared-contract choice needs a resolvable durable architecture record; impl-plan.md has no configured architecture link."}]}\\n' "$dispatch_id"\n`,
+    `#!/bin/sh\nif [ "${'$'}{1:-}" = "--version" ]; then echo 'claude 1.0.0'; exit 0; fi\nif printf '%s' "$*" | /usr/bin/grep -q -- '--help'; then\n  echo '${REVIEWER_CAPABILITIES.claude}'\n  exit 0\nfi\npayload=$(/bin/cat)\ndispatch_id=$(printf '%s' "$payload" | /usr/bin/sed -n 's/.*"dispatch_id":"\\([^"]*\\)".*/\\1/p')\nprintf '{"schema_version":1,"dispatch_id":"%s","reviewer_agent":"claude","verdict":"request_changes","summary":"The architecture decision needs attention.","findings":[{"severity":"error","message":"The shared-contract choice needs a resolvable durable architecture record; impl-plan.md has no configured architecture link."}],"evidence_records":{"schema_version":1,"records":[]}}\\n' "$dispatch_id"\n`,
   );
   chmodSync(reviewer, 0o755);
 }
@@ -600,7 +605,11 @@ function assertInstalledPlanGateIsLive(world: PlanWorld): void {
     [world.installedCliPath, 'hook', 'codex', 'pre-tool-use', '--plugin-hook'],
     {
       cwd: world.projectDirectory,
-      env: { ...process.env, CLAUDE_PROJECT_DIR: world.projectDirectory },
+      env: {
+        ...process.env,
+        CLAUDE_PROJECT_DIR: world.projectDirectory,
+        SAFEWORD_PLUGIN_CLI: world.installedCliPath,
+      },
       input: JSON.stringify({
         hook_event_name: 'PreToolUse',
         session_id: SESSION_ID,
@@ -896,7 +905,7 @@ Given(
     const reviewer = nodePath.join(this.reviewerBinDirectory, 'claude');
     writeFileSync(
       reviewer,
-      `#!/bin/sh\nif printf '%s' "$*" | /usr/bin/grep -q -- '--help'; then\n  echo '${REVIEWER_CAPABILITIES.claude}'\n  exit 0\nfi\nprintf 'invoked\\n' >> "$SAFEWORD_REVIEW_LAUNCH_LOG"\npayload=$(/bin/cat)\ndispatch_id=$(printf '%s' "$payload" | /usr/bin/sed -n 's/.*"dispatch_id":"\\([^"]*\\)".*/\\1/p')\nprintf '{"schema_version":1,"dispatch_id":"%s","reviewer_agent":"claude","verdict":"approve","summary":"The plan is otherwise reviewable.","findings":[]}\\n' "$dispatch_id"\n`,
+      `#!/bin/sh\nif [ "${'$'}{1:-}" = "--version" ]; then echo 'claude 1.0.0'; exit 0; fi\nif printf '%s' "$*" | /usr/bin/grep -q -- '--help'; then\n  echo '${REVIEWER_CAPABILITIES.claude}'\n  exit 0\nfi\nprintf 'invoked\\n' >> "$SAFEWORD_REVIEW_LAUNCH_LOG"\npayload=$(/bin/cat)\ndispatch_id=$(printf '%s' "$payload" | /usr/bin/sed -n 's/.*"dispatch_id":"\\([^"]*\\)".*/\\1/p')\nprintf '{"schema_version":1,"dispatch_id":"%s","reviewer_agent":"claude","verdict":"approve","summary":"The plan is otherwise reviewable.","findings":[],"evidence_records":{"schema_version":1,"records":[]}}\\n' "$dispatch_id"\n`,
     );
     chmodSync(reviewer, 0o755);
   },
diff --git a/steps/planning-contract-shape.steps.ts b/steps/planning-contract-shape.steps.ts
new file mode 100644
index 000000000..1599a2d90
--- /dev/null
+++ b/steps/planning-contract-shape.steps.ts
@@ -0,0 +1,104 @@
+import { strict as assert } from 'node:assert';
+
+import { Given, Then, When } from '@cucumber/cucumber';
+
+import { PLANNING_CONTRACTS } from '../packages/cli/src/planning/contracts.generated.js';
+import {
+  assertPlanningEval,
+  runPlanningEval,
+  selectedPlanningEval,
+  selectPlanningEval,
+} from './support/planning-eval.js';
+import type { SafewordWorld } from './world.js';
+
+const phases = {
+  'Product Plan/spec': {
+    phase: 'product-plan',
+    claim: 'the right complete behavior for accepted personas',
+    meaning:
+      /behavior is ready for scenario definition.*not scenario acceptance, design approval, startable delivery, or completion/iu,
+  },
+  'Implementation Plan': {
+    phase: 'plan-implementation',
+    claim: 'the accepted coherent implementation design',
+    meaning:
+      /approach is ready for Execution Planning.*does not approve delivery sequencing, coding, verification, merge, or deployment/iu,
+  },
+  'Execution Plan': {
+    phase: 'plan-execution',
+    claim: 'startable and provable delivery of the accepted design',
+    meaning:
+      /authorizes its bounded coding work when the configured authority permits it.*does not establish implementation, verification, merge, promotion, or deployment completion/iu,
+  },
+} as const;
+const omissions = {
+  'its review question': { field: 'reviewQuestion', finding: /review\s*question/iu },
+  'prohibited content': { field: 'prohibitedContent', finding: /prohibited\s*content/iu },
+  'its return path': { field: 'returnPath', finding: /return\s*path/iu },
+} as const;
+
+Given(
+  /^the canonical (Product Plan\/spec|Implementation Plan|Execution Plan) contract is presented$/,
+  function (this: SafewordWorld, artifact: keyof typeof phases) {
+    const { phase } = phases[artifact];
+    const evaluation = selectPlanningEval(this, `r10-shape-${phase}`);
+    const contract = PLANNING_CONTRACTS[phase];
+    assert.equal(evaluation.reviewed_plan, JSON.stringify(contract));
+    for (const field of [
+      'purpose',
+      'entryCriteria',
+      'requiredContent',
+      'prohibitedContent',
+      'reviewQuestion',
+      'approvalMeaning',
+      'invalidation',
+      'returnPath',
+    ] as const) {
+      assert.ok(Object.hasOwn(contract, field), `Canonical ${phase} lacks ${field}`);
+      assert.ok(contract[field].trim(), `Canonical ${phase} has empty ${field}`);
+    }
+    assert.match(contract.approvalMeaning, phases[artifact].meaning);
+  },
+);
+
+Given(
+  /^a canonical planning contract omits (its review question|prohibited content|its return path)$/,
+  function (this: SafewordWorld, requiredElement: keyof typeof omissions) {
+    const { field } = omissions[requiredElement];
+    assert.ok(Object.hasOwn(PLANNING_CONTRACTS['product-plan'], field));
+    const evaluation = selectPlanningEval(this, `r10-shape-missing-${field}`);
+    const supplied = JSON.parse(evaluation.reviewed_plan) as Record<string, unknown>;
+    const expected: Record<string, unknown> = { ...PLANNING_CONTRACTS['product-plan'] };
+    delete expected[field];
+    assert.deepEqual(supplied, expected);
+    assert.equal(Object.hasOwn(supplied, field), false);
+  },
+);
+
+When(
+  'a judged semantic reviewer evaluation checks its completeness against the canonical contract-shape rubric',
+  { timeout: 240_000 },
+  function (this: SafewordWorld) {
+    runPlanningEval(this);
+  },
+);
+
+Then(
+  /^it declares purpose, entry requirements, required and prohibited content, its review question, approval meaning, invalidating changes, and return path and limits approval to (.+)$/,
+  function (this: SafewordWorld, approvedClaim: string) {
+    const evaluation = selectedPlanningEval(this);
+    const phase = Object.values(phases).find(item => `r10-shape-${item.phase}` === evaluation.id);
+    assert.ok(phase);
+    assert.equal(approvedClaim, phase.claim);
+    assertPlanningEval(this, 'approve');
+  },
+);
+
+Then(
+  /^the contract is rejected with the missing (its review question|prohibited content|its return path) named$/,
+  function (this: SafewordWorld, requiredElement: keyof typeof omissions) {
+    const { field, finding } = omissions[requiredElement];
+    assert.equal(selectedPlanningEval(this).id, `r10-shape-missing-${field}`);
+    assertPlanningEval(this, 'request_changes', finding);
+  },
+);
diff --git a/steps/planning-correction-currency.steps.ts b/steps/planning-correction-currency.steps.ts
new file mode 100644
index 000000000..f60739685
--- /dev/null
+++ b/steps/planning-correction-currency.steps.ts
@@ -0,0 +1,209 @@
+import { strict as assert } from 'node:assert';
+import { spawnSync, type SpawnSyncReturns } from 'node:child_process';
+import { readFileSync, rmSync, writeFileSync } from 'node:fs';
+import path from 'node:path';
+
+import { After, Given, Then, When } from '@cucumber/cucumber';
+
+import { createTrustedReviewerDirectory } from '../packages/cli/tests/review-fixtures.js';
+import { getTemplatesDirectory } from '../packages/cli/src/utils/fs.js';
+import { fixtureProject, reviewerExecutable } from './keep-plan-reviews-installed-context.steps.js';
+import type { SafewordWorld } from './world.js';
+
+const cli = path.resolve(import.meta.dirname, '../packages/cli/src/cli.ts');
+const pluginRoot = path.resolve(import.meta.dirname, '../plugin');
+const ticket = '.project/tickets/CTX123-current-context';
+const target = `${ticket}/impl-plan.md`;
+
+interface CorrectionState {
+  root: string;
+  reviewer: string;
+  environment: NodeJS.ProcessEnv;
+  initialReviewId?: string;
+  freshReviewId?: string;
+  gate?: SpawnSyncReturns<string>;
+}
+const states = new WeakMap<SafewordWorld, CorrectionState>();
+
+function command(state: CorrectionState, args: string[]) {
+  return spawnSync('bun', [cli, ...args, '--json', '--no-input'], {
+    cwd: state.root,
+    env: state.environment,
+    encoding: 'utf8',
+    timeout: 60_000,
+  });
+}
+
+function review(state: CorrectionState, status: 'approved' | 'changes_requested'): string {
+  const result = command(state, ['review', 'run', 'plan-implementation', target]);
+  const output = JSON.parse(result.stdout);
+  assert.deepEqual(output.errors, [], `${result.stdout}\n${result.stderr}`);
+  assert.equal(output.data.status, status, result.stdout);
+  assert.equal(typeof output.data.review_id, 'string');
+  return output.data.review_id;
+}
+
+function rejectedPlan(world: SafewordWorld): CorrectionState {
+  const root = fixtureProject();
+  const reviewer = createTrustedReviewerDirectory('safeword-r11-currency-');
+  const environment: NodeJS.ProcessEnv = {
+    ...process.env,
+    PATH: `${reviewer}:${process.env.PATH ?? ''}`,
+    CLAUDE_PROJECT_DIR: root,
+    CLAUDE_PLUGIN_ROOT: pluginRoot,
+    CLAUDE_SESSION_ID: 'r11-currency',
+    SAFEWORD_REVIEW_KEY_ROOT: path.join(root, '.review-keys'),
+    CLAUDE_CONFIG_DIR: path.join(root, 'claude'),
+    SAFEWORD_SKIP_INSTALL: '1',
+    SAFEWORD_SKIP_SKILLS: '1',
+    SAFEWORD_AGENT_RUNTIME: 'claude',
+    SAFEWORD_NO_UPDATE_CHECK: '1',
+  };
+  delete environment.SAFEWORD_AUTHOR_MODEL;
+  const state: CorrectionState = { root, reviewer, environment };
+  states.set(world, state);
+  const installed = command(state, ['install', '--agents=claude', '--no-modify', '--cwd', root]);
+  const installation = JSON.parse(installed.stdout);
+  assert.deepEqual(installation.errors, [], `${installed.stdout}\n${installed.stderr}`);
+  assert.ok(
+    installation.findings.some(
+      (finding: { code: string }) => finding.code === 'SETUP_POSTCONDITION_VERIFIED',
+    ),
+  );
+  const configPath = path.join(root, '.safeword/config.json');
+  const config = JSON.parse(readFileSync(configPath, 'utf8'));
+  writeFileSync(
+    configPath,
+    JSON.stringify({
+      ...config,
+      reviewGate: true,
+      crossAgentReview: 'prefer',
+      crossAgentReviewRoutes: { claude: [{ reviewer: 'opencode' }] },
+    }),
+  );
+  reviewerExecutable(reviewer);
+  const executable = path.join(reviewer, 'opencode');
+  const source = readFileSync(executable, 'utf8');
+  assert.ok(source.includes("verdict: 'approve'"));
+  assert.ok(source.includes('findings: []'));
+  writeFileSync(
+    executable,
+    source
+      .replace("verdict: 'approve'", "verdict: 'request_changes'")
+      .replace(
+        'findings: []',
+        "findings: [{ severity: 'error', message: 'Accepted Rule approval.BU1.R1 requires authenticated current approval; explicitly reject missing authentication before advancing.' }]",
+      ),
+  );
+  state.initialReviewId = review(state, 'changes_requested');
+  return state;
+}
+
+function correct(state: CorrectionState): void {
+  const file = path.join(state.root, target);
+  writeFileSync(
+    file,
+    `${readFileSync(file, 'utf8')}\n## Required correction\n\nReject missing authentication before advancing under accepted Rule approval.BU1.R1.\n`,
+  );
+}
+
+Given(
+  'a review blocked on a uniquely determined correction under an accepted decision',
+  { timeout: 120_000 },
+  function (this: SafewordWorld) {
+    rejectedPlan(this);
+  },
+);
+
+When(
+  'the correction changes the plan bytes without a fresh review',
+  function (this: SafewordWorld) {
+    const state = states.get(this);
+    assert.ok(state);
+    correct(state);
+    state.gate = command(state, ['ticket', 'approve-plan', 'CTX123', '--cwd', state.root]);
+  },
+);
+
+Then(
+  'the corrected plan remains blocked until a verdict is recorded against those exact bytes',
+  function (this: SafewordWorld) {
+    const state = states.get(this);
+    assert.ok(state?.gate);
+    assert.equal(state.gate.status, 2, state.gate.stdout);
+    assert.match(
+      readFileSync(path.join(state.root, ticket, 'ticket.md'), 'utf8'),
+      /phase: plan-implementation/u,
+    );
+    assert.ok(state.initialReviewId);
+    const status = command(state, ['review', 'status', state.initialReviewId]);
+    const output = JSON.parse(status.stdout);
+    assert.equal(output.data.status, 'stale');
+  },
+);
+
+Given(
+  'corrected plan bytes have a fresh approving verdict recorded against those exact bytes',
+  { timeout: 180_000 },
+  function (this: SafewordWorld) {
+    const state = rejectedPlan(this);
+    correct(state);
+    reviewerExecutable(state.reviewer);
+    state.freshReviewId = review(state, 'approved');
+    assert.notEqual(state.freshReviewId, state.initialReviewId);
+    const recorded = spawnSync(
+      'bun',
+      [
+        path.join(pluginRoot, 'runtime/hooks/write-review-stamp.ts'),
+        '--ticket',
+        'CTX123-current-context',
+        '--author-agent',
+        'claude',
+        '--reviewer-agent',
+        'opencode',
+        '--independence',
+        'reduced',
+        '--review-id',
+        state.freshReviewId,
+        '--phase',
+        'plan-implementation',
+      ],
+      { cwd: state.root, env: state.environment, encoding: 'utf8', timeout: 60_000 },
+    );
+    assert.equal(recorded.status, 0, `${recorded.stdout}\n${recorded.stderr}`);
+  },
+);
+
+When('the phase gate reevaluates the prior correction block', function (this: SafewordWorld) {
+  const state = states.get(this);
+  assert.ok(state);
+  state.gate = command(state, ['ticket', 'approve-plan', 'CTX123', '--cwd', state.root]);
+});
+
+Then(
+  'the prior block is cleared and that correction no longer prevents the phase transition',
+  function (this: SafewordWorld) {
+    const state = states.get(this);
+    assert.ok(state?.gate);
+    assert.equal(state.gate.status, 0, `${state.gate.stdout}\n${state.gate.stderr}`);
+    assert.equal(
+      readFileSync(path.join(state.root, ticket, 'execution-plan.md'), 'utf8'),
+      readFileSync(
+        path.join(getTemplatesDirectory(), 'doc-templates/execution-plan-template.md'),
+        'utf8',
+      ),
+    );
+    assert.match(
+      readFileSync(path.join(state.root, ticket, 'ticket.md'), 'utf8'),
+      /phase: plan-execution/u,
+    );
+  },
+);
+
+After(function (this: SafewordWorld) {
+  const state = states.get(this);
+  if (!state) return;
+  rmSync(state.root, { recursive: true, force: true });
+  rmSync(state.reviewer, { recursive: true, force: true });
+  states.delete(this);
+});
diff --git a/steps/support/planning-eval.ts b/steps/support/planning-eval.ts
new file mode 100644
index 000000000..daf8d1361
--- /dev/null
+++ b/steps/support/planning-eval.ts
@@ -0,0 +1,117 @@
+import { strict as assert } from 'node:assert';
+import { spawnSync } from 'node:child_process';
+import { mkdtempSync, readFileSync, rmSync } from 'node:fs';
+import { tmpdir } from 'node:os';
+import path from 'node:path';
+
+import { After } from '@cucumber/cucumber';
+
+import { planningContractCases } from '../../packages/cli/tests/fixtures/planning-contracts-eval.js';
+import type { SafewordWorld } from '../world.js';
+
+const root = path.resolve(import.meta.dirname, '../..');
+const hostClaudeConfigDir = process.env.CLAUDE_CONFIG_DIR;
+
+interface EvalRun {
+  reviewer: { verdict: string; findings: string[]; scope_expanded: boolean };
+  judge: { correct: boolean };
+}
+
+interface EvalReport {
+  selected_case: string;
+  complete: boolean;
+  results: { case_id: string; status: string; runs: EvalRun[] }[];
+}
+
+interface EvalState {
+  caseId: string;
+  reportDirectory: string;
+  reportPath: string;
+  output?: ReturnType<typeof spawnSync>;
+  report?: EvalReport;
+}
+
+const states = new WeakMap<SafewordWorld, EvalState>();
+
+export function selectPlanningEval(world: SafewordWorld, caseId: string) {
+  const evaluationCase = planningContractCases.find(item => item.id === caseId);
+  assert.ok(evaluationCase, `Missing judged case ${caseId}`);
+  const reportDirectory = mkdtempSync(path.join(tmpdir(), 'safeword-planning-eval-'));
+  states.set(world, {
+    caseId,
+    reportDirectory,
+    reportPath: path.join(reportDirectory, 'result.json'),
+  });
+  return evaluationCase;
+}
+
+export function selectedPlanningEval(world: SafewordWorld) {
+  const state = states.get(world);
+  assert.ok(state, 'A judged evaluation case must be selected first.');
+  const evaluationCase = planningContractCases.find(item => item.id === state.caseId);
+  assert.ok(evaluationCase);
+  return evaluationCase;
+}
+
+export function runPlanningEval(world: SafewordWorld): void {
+  const state = states.get(world);
+  assert.ok(state, 'A judged evaluation case must be selected first.');
+  const environment: NodeJS.ProcessEnv = {
+    ...process.env,
+    SAFEWORD_PLANNING_EVAL_CASE: state.caseId,
+    SAFEWORD_PLANNING_EVAL_OUTPUT: state.reportPath,
+  };
+  delete environment.NODE_OPTIONS;
+  if (hostClaudeConfigDir === undefined) delete environment.CLAUDE_CONFIG_DIR;
+  else environment.CLAUDE_CONFIG_DIR = hostClaudeConfigDir;
+  state.output = spawnSync(
+    'scripts/dev',
+    ['bun', 'packages/cli/scripts/planning-contracts-eval.ts'],
+    {
+      cwd: root,
+      env: environment,
+      encoding: 'utf8',
+      timeout: 210_000,
+      maxBuffer: 1024 * 1024,
+    },
+  );
+  if (state.output.status === 0)
+    state.report = JSON.parse(readFileSync(state.reportPath, 'utf8')) as EvalReport;
+}
+
+export function assertPlanningEval(
+  world: SafewordWorld,
+  verdict: 'approve' | 'request_changes',
+  requiredFinding?: RegExp,
+): void {
+  const state = states.get(world);
+  assert.ok(state?.output, 'The judged evaluation must run first.');
+  assert.equal(
+    state.output.status,
+    0,
+    `Judged evaluation failed: ${state.output.error?.message ?? state.output.stderr}`,
+  );
+  const report = state.report;
+  assert.ok(report?.complete && report.selected_case === state.caseId);
+  assert.equal(report.results.length, 1);
+  const result = report.results[0];
+  assert.equal(result?.case_id, state.caseId);
+  assert.equal(result.status, 'pass');
+  const matching = result.runs.filter(
+    run =>
+      run.reviewer.verdict === verdict &&
+      !run.reviewer.scope_expanded &&
+      run.judge.correct &&
+      (requiredFinding === undefined || requiredFinding.test(run.reviewer.findings.join(' '))),
+  );
+  assert.ok(
+    matching.length >= 2,
+    `Only ${matching.length}/3 judged runs supported ${state.caseId}.`,
+  );
+}
+
+After(function (this: SafewordWorld) {
+  const state = states.get(this);
+  if (state) rmSync(state.reportDirectory, { recursive: true, force: true });
+  states.delete(this);
+});
