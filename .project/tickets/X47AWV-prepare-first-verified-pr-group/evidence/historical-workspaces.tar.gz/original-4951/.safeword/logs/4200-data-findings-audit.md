# Bounded audit of two observed qualification failures

Read the vague-data-ownership and invented-data-ownership corpus cases, their
accepted Implementation Plans, and the canonical PLAN_EXECUTION contract.
Determine whether these observed reviewer rejections correctly identify the
intended data defects. Evaluate the proposed finding-term correction against
those defects. Do not require literal category adjectives when the contract
does not require those words. No fixture, verdict, destination, authentication,
or production reviewer wording change is proposed.

Vague case: verdict request_changes, destination plan-execution, null approval
record; dispatch and reviewer identities match. Summary: The execution sequence
omits concrete implementation and proof for the accepted delivery-evidence
storage scenario. Error: In slice Complete delivery, Use the appropriate store
and ownership contract during implementation does not execute the accepted data
design: DeliveryStateService must own delivery-evidence reads and writes against
project-local delivery.db. No task or proof exercises the accepted storage
scenario with known evidence and exact round-trip assertions. Named checks could
pass while using another store, bypassing DeliveryStateService or losing values.
Add concrete owned execution/proof work; this repairs an already accepted design,
not an upstream design change.

Invented case: verdict request_changes, destination plan-implementation, null
approval record; identities match. Summary: The execution plan introduces an
unapproved database and service-ownership decision outside the accepted scope.
Error: Decision accounting directive Store delivery evidence in Redis and let
ReviewService own reads and writes introduces a new database and architecture
decision. Accepted Implementation Plan excludes a new database. Remove the
expansion or obtain user-authorized scope change and fresh Implementation Planning
approval before execution review.

Actual output failed only finding_terms: data/unnamed and data/invented.
Proposed surgical change: vague requires delivery.db/DeliveryStateService in the
rejection explanation; invented requires Redis/ReviewService. Matching unit
expectations change identically. Existing request_changes, null record, exact
identity and planning destination checks remain. No generalized matcher is added.
Raw log: /tmp/4200-independent-finding-codex-full-live.log.
