# Finding-authority scenario bindings

Four R11 cases pass 224 Cucumber steps in
/tmp/4200-r11-finding-authority-complete.json. Each semantic case uses the
existing pinned Opus-5 reviewer/Sonnet-5 judge with three repetitions and at
least two correct, scope-preserving verdicts. The static corpus contract passes
two package tests in /tmp/4200-r11-eval-manifest-regression.log.

The two nonblocking inputs use the existing optional event-bus replacement
fixture: the same recorded preference is both optional resilience and a
reviewer-authored replacement architecture. Two new negative cases distinguish
an unresolved accepted authorization requirement from the uniquely determined
correction to move an already chosen token check before writes. Expectations,
model pins, rubric bytes, thresholds and production behavior are unchanged.
Only this semantic corpus digest changes; the 63-case qualification corpus and
18-run capability corpus are separate and unchanged.

Check that the examples isolate real accepted defects, the step assertions
prove the named finding authority without style-only failures or false passes,
and fixture reuse preserves the two nonblocking scenario meanings. These are
semantic reviewer tests, not installed-gate proof; those R11 cases remain open.
The historical six failures/585 unfinished and the other unbound cases remain.
