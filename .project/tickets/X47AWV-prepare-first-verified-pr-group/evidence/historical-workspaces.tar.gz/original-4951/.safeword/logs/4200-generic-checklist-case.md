# Qualification case validity

Decide whether the candidate Execution Plan satisfies the canonical contract. Ground the verdict in specific requirements. Check whether concrete task and proof mappings can compensate for every checklist obligation saying only Complete the standard delivery work. Do not change the canonical contract or infer missing obligation text.

## Accepted Implementation Plan
# Implementation Plan

## Accepted obligations

- Accepted behavior
- Migration work
- Rollout work
- Rollback work
- Documentation work
- Affected-surface work

## Recorded decisions

- One shared authorization service owns permission checks for every transport.
- Host-neutral dependency order keeps every intermediate merge supported.

## Binding fixture scope

- This fixture project delivers one public review command and its compatible stored result. The ticket accepts the six named obligations above, with no new transport, database, reviewer selection policy, or human approval policy.
- Existing fixture scripts exercise the public command, result reader, permission denial, activation switch, and documentation. Execution Planning determines whether delivery needs one or multiple independently supported slices.

## Accepted response and recovery contracts

- The public command and result store use the exact version-1 Execution Plan reviewer response below. Approval records its slicing decision, named slices, obligation owners, preserved decisions, normalized plan digest, and delivery definition; rejection retains its findings and has a null execution record.
- Migration preserves legacy result bytes and translates their verdict, summary, and findings through the backward-compatible reader; it does not rewrite persisted legacy records.
- The shared authorization service denies an unauthorized actor before reviewer dispatch or persistence. Denial names the affected review, exits 2, and creates no stored result.
- Activation enables the typed reader only after compatible result reading is available. Disabling activation restores the prior reader and leaves both old and new stored results readable.
- Documentation describes the same public response, denial, activation, and rollback behavior; it adds no new behavior.

Accepted response schema:

{"type":"object","properties":{"schema_version":{"type":"integer","enum":[1]},"dispatch_id":{"type":"string"},"reviewer_agent":{"type":"string","enum":["claude","codex","opencode"]},"verdict":{"type":"string","enum":["approve","request_changes"]},"summary":{"type":"string"},"findings":{"type":"array","items":{"type":"object","properties":{"severity":{"type":"string","enum":["info","warning","error"]},"message":{"type":"string"}},"required":["severity","message"],"additionalProperties":false}},"evidence_records":{"type":"object","properties":{"schema_version":{"type":"integer","enum":[1]},"records":{"type":"array","items":{"type":"object","properties":{"source_identity":{"type":"string"},"checked_version":{"type":"string"},"source_version":{"type":"string"},"target_version":{"type":"string"},"supported_claim":{"type":"string"},"license_identifier":{"type":"string"},"attribution_notice":{"type":"string"},"redistribution_limit":{"type":"string"},"security_limit":{"type":"string"},"privacy_limit":{"type":"string"},"reuse_limit":{"type":"string"}},"required":["source_identity","checked_version","source_version","target_version","supported_claim","license_identifier","attribution_notice","redistribution_limit","security_limit","privacy_limit","reuse_limit"],"additionalProperties":false}}},"required":["schema_version","records"],"additionalProperties":false},"planning_destination":{"type":"string","enum":["plan-execution","plan-implementation"]},"execution_plan_record":{"anyOf":[{"type":"null"},{"type":"object","properties":{"slicing_decision":{"type":"string","enum":["one_pull_request","multiple_pull_requests"]},"rationale":{"type":"string"},"slices":{"type":"array","items":{"type":"object","properties":{"name":{"type":"string"},"purpose":{"type":"string"},"boundary":{"type":"string"},"prerequisites":{"type":"array","items":{"type":"string"}},"proof":{"type":"string"},"completion_signal":{"type":"string"},"relies_on_unmerged_successor":{"type":"boolean"}},"required":["name","purpose","boundary","prerequisites","proof","completion_signal","relies_on_unmerged_successor"],"additionalProperties":false}},"obligation_owners":{"type":"array","items":{"type":"object","properties":{"obligation":{"type":"string"},"slices":{"type":"array","items":{"type":"string"}}},"required":["obligation","slices"],"additionalProperties":false}},"decision_statuses":{"type":"array","items":{"type":"object","properties":{"decision":{"type":"string"},"status":{"type":"string","enum":["unchanged"]}},"required":["decision","status"],"additionalProperties":false}},"accepted_scenarios_covered":{"type":"boolean","enum":[true]},"accepted_approach_preserved":{"type":"boolean","enum":[true]},"normalized_plan_digest":{"type":"string","pattern":"^[a-f0-9]{64}$"},"delivery_definition":{"type":"object","properties":{"schema_version":{"type":"integer","enum":[1]},"design_approval_gate":{"type":"boolean"},"proof_specifications":{"type":"array","items":{"type":"object","properties":{"proof_id":{"type":"string"},"method":{"type":"string","enum":["command","review_receipt"]},"scope":{"type":"string","enum":["unit","integration","E2E","eval"]},"boundary_exercised":{"type":"string"},"qualifies_as":{"type":"string","enum":["real_boundary","partial_or_structural"]},"currency":{"type":"string","enum":["current_required","compatible_earlier_allowed"]},"invocation":{"anyOf":[{"type":"object","properties":{"type":{"type":"string","enum":["command"]},"cwd":{"type":"string"},"argv":{"type":"array","items":{"type":"string"}}},"required":["type","cwd","argv"],"additionalProperties":false},{"type":"object","properties":{"type":{"type":"string","enum":["review_receipt"]},"kind":{"type":"string"},"targets":{"type":"array","items":{"type":"string"}}},"required":["type","kind","targets"],"additionalProperties":false}]}},"required":["proof_id","method","scope","boundary_exercised","qualifies_as","currency","invocation"],"additionalProperties":false}},"checklist_items":{"type":"array","items":{"type":"object","properties":{"id":{"type":"string"},"category":{"type":"string","enum":["outcome and scope","resolved decisions","dependency and pull-request decomposition","testing","data and compatibility","monitoring and failure signals","security and privacy","rollout and rollback","documentation","ownership and human dependencies","completion evidence"]},"obligation":{"type":"string"},"owner":{"type":"string","enum":["contributor","human"]},"required_proof":{"type":"string"},"reviewed_disposition":{"type":["string","null"],"enum":["not_applicable","pending_human",null]},"reviewed_detail":{"type":["string","null"]}},"required":["id","category","obligation","owner","required_proof","reviewed_disposition","reviewed_detail"],"additionalProperties":false}}},"required":["schema_version","design_approval_gate","proof_specifications","checklist_items"],"additionalProperties":false}},"required":["slicing_decision","rationale","slices","obligation_owners","decision_statuses","accepted_scenarios_covered","accepted_approach_preserved","normalized_plan_digest","delivery_definition"],"additionalProperties":false}]}},"required":["schema_version","dispatch_id","reviewer_agent","verdict","summary","findings","evidence_records","planning_destination","execution_plan_record"],"additionalProperties":false}


## Accepted scenarios
Feature: Preserve the accepted public review command contract
Scenario: An authorized user receives an approved reviewer judgment
  Given an authenticated permitted actor requests a review
  When the reviewer supplies an approved version-1 judgment
  Then the public command and stored-result reader retain the exact accepted response fields
Scenario: An authorized user receives a rejected reviewer judgment
  Given an authenticated permitted actor requests a review
  When the reviewer supplies rejection findings and a null execution record
  Then the public and stored responses retain those findings and the null record
Scenario: Activation preserves compatibility and recovery
  Given existing legacy and typed stored results
  When activation is enabled after compatible reading is available and subsequently disabled
  Then the prior reader is restored and both formats remain readable without rewriting legacy bytes
  And documentation describes the same public response, denial, activation, and rollback contracts
Scenario: A user without review permission requests a review
  Given authenticated blocked-user has no permission for fixture-review
  When blocked-user invokes the existing public review command
  Then the command names fixture-review and exits 2
  And no reviewer request or stored result is created


## Candidate Execution Plan
# Execution Plan

## Pull-request slicing

Decision: one pull request.
Rationale: The public review result, its compatible persistence, permission check, failure signal, rollout switch, rollback, and documentation are inseparable facets of one command contract; none is independently useful and every proof protects that same response.

### Complete delivery

- Purpose: Deliver the complete typed Execution Plan review capability.
- Boundary: Contract, CLI behavior, compatibility, failure signals, authorization, rollout, rollback, and documentation.
- Prerequisites: none
- Proof: data-compatibility, behavior-boundary, plan-integrity, failure-signals, security-boundary, rollout-rollback, and documentation-contract
- Completion signal: Every named proof command passes on the merge candidate and every checklist item has completion evidence.
- Relies on an unmerged successor: no

#### Tasks and tests

1. RED: run `bun run test:review-cli -- --fixture approved-plan` through the public CLI and observe exit 2 with `typed review result is unavailable` before editing `src/review/command.ts`.
2. GREEN: add the accepted result fields to `src/review/contract.ts`, route the public command through `src/review/command.ts`, and rerun the step-1 command with approved-plan as the coherent-change fixture; assert exit 0, schema-valid response, execution_plan_record.slicing_decision equal to one_pull_request, exactly one slice named Complete delivery, and exact obligation owners, unchanged decision statuses, normalized approved-plan digest, and delivery definition matching the fixture; assert all those same expected values after reading the stored result. Seed the approved judgment with distinguishing summary, findings, evidence records, destination, and complete slice details; compare the complete supplied judgment by deep equality with both the public response and the stored-reader response.
3. RED: run `bun run test:schema-compatibility -- --fixture legacy-result` and observe exit 1 with `legacy result cannot be read` before editing `src/review/result-store.ts`.
4. GREEN: add the backward-compatible legacy-result reader in `src/review/result-store.ts`, rerun the step-3 command, and assert the stored result round-trips without rewriting legacy bytes.
5. RED: run `bun run test:failure-signals -- --fixture authorized-reviewer-rejection` with a reviewer response containing request_changes, the named rejection finding, and a null execution_plan_record; observe exit 1 because the public response loses the finding or retains an approval record. Also run `bun run test:authorization-boundary -- --fixture denied-review` with an unauthorized actor and an initially empty reviewer request journal; observe exit 1 because the CLI neither names the denied review nor prevents dispatch before editing `src/review/command.ts`.
6. GREEN: call the accepted shared authorization service before reviewer dispatch in `src/review/command.ts`, rerun both step-5 commands, and assert the unauthorized call exits 2, names the affected review, leaves the reviewer request journal empty, and persists no result. For the authorized reviewer rejection, assert the public response retains the supplied rejection finding and a null execution_plan_record, and that the compatible stored-result reader returns those same values. Seed the rejected judgment with distinguishing summary, findings, evidence records, and destination; compare the complete supplied judgment by deep equality with both the public response and the stored-reader response.
7. RED: run `bun run test:rollout-rollback -- --fixture enabled-result` and observe exit 1 because disabling the review command does not restore the prior readable result before editing `src/review/rollout.ts`.
8. GREEN: add the accepted activation switch and rollback reader in `src/review/rollout.ts`, rerun the step-7 command, and assert activation waits for compatible reading, enabled activation reads the expected legacy-result and typed-result fixture contents, and disabling activation restores the prior reader while both formats remain readable with their exact expected contents.
9. RED: run `bun run test:documentation-contract` and `bun run test:execution-plan-conformance`; observe exit 1 because the command reference omits the public response, denial, activation, or rollback contract, or the corpus omits an accepted obligation, before editing the command reference and canonical review contract.
10. GREEN: document the exact public response, denial, activation, and rollback contracts and add every accepted obligation to the canonical conformance corpus, then rerun both step-9 commands and assert exit 0; assert the rendered command reference describes all four accepted contracts and that removing any one makes documentation-contract fail.
11. REFACTOR: move the duplicate response validation in `src/review/command.ts` and `src/review/result-store.ts` into `src/review/contract.ts`, then rerun all seven proof commands and assert the public response snapshot is byte-identical.

## Obligation ownership

- Accepted behavior: Complete delivery
- Migration work: Complete delivery
- Rollout work: Complete delivery
- Rollback work: Complete delivery
- Documentation work: Complete delivery
- Affected-surface work: Complete delivery

## Decision accounting

- One shared authorization service owns permission checks for every transport.: unchanged
- Host-neutral dependency order keeps every intermediate merge supported.: unchanged

## Proof specifications

| Proof ID | Method | Scope | Boundary exercised | Qualifies as | Currency | Invocation |
| --- | --- | --- | --- | --- | --- | --- |
| behavior-boundary | command | E2E | Accepted behavior at the public CLI boundary. | real_boundary | current_required | {"type":"command","cwd":".","argv":["bun","run","test:review-cli"]} |
| plan-integrity | command | E2E | Recorded decisions, slice dependencies, obligation ownership, and completion evidence. | real_boundary | current_required | {"type":"command","cwd":".","argv":["bun","run","test:execution-plan-conformance"]} |
| data-compatibility | command | E2E | Migration and backward-compatibility boundaries. | real_boundary | current_required | {"type":"command","cwd":".","argv":["bun","run","test:schema-compatibility"]} |
| failure-signals | command | E2E | Observable failure signals under injected review failure. | real_boundary | current_required | {"type":"command","cwd":".","argv":["bun","run","test:failure-signals"]} |
| security-boundary | command | E2E | Authorization and privacy behavior at the review boundary. | real_boundary | current_required | {"type":"command","cwd":".","argv":["bun","run","test:authorization-boundary"]} |
| rollout-rollback | command | E2E | Rollout activation and rollback recovery behavior. | real_boundary | current_required | {"type":"command","cwd":".","argv":["bun","run","test:rollout-rollback"]} |
| documentation-contract | command | E2E | Published documentation examples and links. | real_boundary | current_required | {"type":"command","cwd":".","argv":["bun","run","test:documentation-contract"]} |

## Delivery checklist

<!-- safeword:delivery-checklist:v1 -->

| ID | Category | Obligation | Owner | Required proof | Disposition | Evidence class | Revision | Evidence, reason, or dependency |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| item-1 | outcome and scope | Complete the standard delivery work. | contributor | behavior-boundary | open | missing | | |
| item-2 | resolved decisions | Complete the standard delivery work. | contributor | plan-integrity | open | missing | | |
| item-3 | dependency and pull-request decomposition | Complete the standard delivery work. | contributor | plan-integrity | open | missing | | |
| item-4 | testing | Complete the standard delivery work. | contributor | behavior-boundary | open | missing | | |
| item-5 | data and compatibility | Complete the standard delivery work. | contributor | data-compatibility | open | missing | | |
| item-6 | monitoring and failure signals | Complete the standard delivery work. | contributor | failure-signals | open | missing | | |
| item-7 | security and privacy | Complete the standard delivery work. | contributor | security-boundary | open | missing | | |
| item-8 | rollout and rollback | Complete the standard delivery work. | contributor | rollout-rollback | open | missing | | |
| item-9 | documentation | Complete the standard delivery work. | contributor | documentation-contract | open | missing | | |
| item-10 | ownership and human dependencies | Complete the standard delivery work. | contributor | plan-integrity | open | missing | | |
| item-11 | completion evidence | Complete the standard delivery work. | contributor | plan-integrity | open | missing | | |
