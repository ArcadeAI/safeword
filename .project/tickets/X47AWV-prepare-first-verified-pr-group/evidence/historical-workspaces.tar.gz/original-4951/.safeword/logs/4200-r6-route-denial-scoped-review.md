# R6 planning-only diagnostic repair

Final scope correction to the previously approved denial repair
423f6a01-7ab2-404a-adda-a7537e775519: only plan-implementation and plan-execution
phase exits may display the authenticated rejection reason. Other phase exits
retain their prior behavior. The full normal run found two implementation-phase
message expectations affected by the broader first version; it was interrupted
after those failures, not counted as a pass. Narrowing the production scope
preserves those unrelated expectations without editing tests. The final targeted
run includes all 24 phase-review gate controls and the 74 prior receipt/helper
controls. Final full verification will be recorded outside this context.

The verifier callback, no-surviving-stamp guard, and the exact blocked-review
root proof are unchanged from that approval. One root acceptance row is covered:
typed no-independent-route-attempted, row172. Nine related scenarios / 513 steps
passed, including valid admission after the rejected stamp. The ungated-origin
row stays undefined after the earlier review rejected its wrong-kind substitute.
No new host-origin mechanism, receipt authority, bypass, model qualification or
test expectation change is added. Initial failures and rejected evidence remain
visible in the ticket and prior immutable review contexts.

This context supplements the immutable repaired-review context. Only the new
planning-exit scope guard needs a fresh review. The generated surfaces reflect
this guard; lifecycle result hashes remain unchanged. Do not claim old review
receipts remain current for changed source bytes. Broader acceptance, RGR, the
forty undefined cases, historical six failures/585 unfinished, sixteen host
deferrals and separately user-deferred R7 remain open. No Ready/merge authority.
