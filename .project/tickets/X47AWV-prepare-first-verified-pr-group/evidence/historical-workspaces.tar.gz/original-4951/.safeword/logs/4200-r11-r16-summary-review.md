# Finding authority and Product Plan characterization

Review the strengthened R11 assertion/harness and five new R16 Product Plan
bindings. Production code/prompts and qualification/capability corpora are
unchanged. The existing neutral semantic projection now preserves production's
summary field; the judge explicitly requires a recorded reviewer-only event-bus
proposal to be identified and classified optional/nonblocking. No advisory
finding is required. Step assertions also require the named proposal in the
summary and require after/before/write ordering in the unique correction finding.
Negative R11 Given steps check actual defective bytes so a failed String.replace
cannot silently produce a conforming plan.

Review 6ab2f688-a663-414a-b6d5-c311377d1fe3 rejected bare approval as proof of
nonblocking recording. The strengthened four-case run records three passes and
one failed judged correction case in /tmp/4200-r11-summary-proof.json; a focused
diagnostic is running. The harness now retains failed reports and includes stdout
in failures; it previously lost the underlying failure reason. Nothing is hidden
or called complete. Successful report cleanup is unchanged.

R16 reuses the existing missing-recovery negative, adds complete-outcome and
reasoned-inapplicability controls, and repairs the unsupported-assumption fixture
to retain complete persona outcomes so unrelated omissions cannot cause rejection.
The complete positive also checks epistemic distinction. Five real pinned
Opus-5/Sonnet-5 semantic cases are running with three repetitions/two correct
judged verdicts each. Semantic corpus/judge digests are updated; model pins,
threshold, 63-case Execution qualification, 18-run capability corpus, and
production contracts remain unchanged. No paid Astra runs were launched.

Challenge causal discrimination, fixture isolation, consistency of the reasoned
inapplicability, diagnostic evidence, and scope. Installed R11/R16 lifecycle
cases remain unbound. Sixteen host cases remain deferred to MCWV4B; historical
six failures/585 unfinished are not replaced by these targeted runs. No feature
completion, Ready promotion, or merge claim is made.

Review d029002f-db56-487a-a6e3-477bec9df142 rejected the inapplicability
control because it still inventoried approval for both personas. That fixture
is now a separate, coherent observer-only inventory: the observer has success,
refusal, failure, trust, and recovery, and an explicit accepted reason for
approval inapplicability. The Given checks that the shared approval inventory
is absent. The unsupported-fact Given checks the actual mutated fact text.

Calibration now supplies the optional-proposal judge a correctly shaped bare
approval with correct verdict and no scope expansion, but no recorded proposal.
It must reject that seed before the real samples. The calibrated nonblocking
root row passes 1/1 in /tmp/4200-r11-calibrated-nonblocking.json. The unique
correction plus repaired inapplicability rows pass 2/2 (114 steps) in
/tmp/4200-r11-r16-corrections-root.json; the epistemic control passes 1/1 in
/tmp/4200-r16-epistemic-control-current.json. Three other R16 rows passed in the
first run, which retains two failures: the contradictory fixture and a manifest
race caused by my editing corpus bytes during that active run. Source files are
now frozen while tests/review run. Three other R11 rows passed in its first run;
its failed correction remains recorded and the focused rerun passes. No fresh
whole-feature aggregate is claimed. Static manifest tests pass 2/2, all three
package typechecks pass, and source lint has zero findings.

The two nonblocking rows intentionally interpret the same recorded proposal;
they are shared proof, not independent cases. No-scenario-coverage claims remain
judged semantically against the required bounded Product approval meaning and
the negative case's explicit allowed authority. Tight existing subprocess budgets
remain an acknowledged fail-loudly latency limitation; no timeout tuning is added.

Review e3bbcd47-b4b1-4ebf-ac51-caf75442bb1f approved the prior repair but
identified eval-only coaching of proposal disposition. The projection no longer
contains that extra instruction. The canonical rubric alone supplies finding
authority; the neutral schema simply retains summary alongside findings. The
record assertion/judge now accepts the proposal in either summary or a
nonblocking finding instead of imposing a summary-only output convention.
The discriminating bare-approval calibration remains. Only the nonblocking
root row needs a new run for this change; it is running with frozen sources.
Review these final small changes without strengthening production contracts or
conflating advisory findings with rejection rendering. The package manifest
contract passes 2/2 with the new judge digest. Other prior advisories remain
explicitly bounded limitations rather than new requested scope.
