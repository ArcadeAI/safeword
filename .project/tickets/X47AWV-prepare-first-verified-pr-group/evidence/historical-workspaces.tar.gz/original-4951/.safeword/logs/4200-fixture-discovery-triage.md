Judge this review input against its actual accepted scope. Does its stated slicing rationale truthfully describe the whole slice? Distinguish an invalid rationale from a new user outcome: a builder-to-literal fixture repair preserves public behavior, data and proof boundaries. A proposed rationale is: One complete typed-review capability shares the public contract and its required boundaries; the fixture representation repair preserves that contract and adds no independent outcome. Assess whether that wording is a faithful correction or whether approval would still require a changed delivery boundary. Do not infer a desired verdict or use qualification expectations as authority. This is fixture diagnosis, not model qualification.

Canonical Execution review guidance:
# Execution Planning

**Entry:** the Implementation Plan is approved and the ticket is at
`plan-execution`. Behavior and implementation decisions are fixed. This phase
turns them into startable work; it does not redesign them or edit application
code.

Scaffold `execution-plan.md` next to `ticket.md` from
`.safeword/templates/execution-plan-template.md`.

## Author the plan

1. Read the approved scenarios, Implementation Plan, and applicable project
   guides. Load the installed testing guide while turning each accepted proof
   strategy into startable work. Extract every accepted behavior, decision-derived implementation,
   proof-strategy implementation, migration, rollout, rollback, documentation,
   affected-surface, and measurement-execution obligation. For an accepted
   quantitative contract, preserve its outcome, population, target, origin,
   method, validity safeguards, and failure behavior exactly. Do not invent
   missing decisions; return a genuine gap to Implementation Planning.
2. Decide explicitly whether delivery is one pull request or multiple pull
   requests. Explain the boundary in terms of conceptual scope and independent
   proof, never line or file count alone.
3. Put slices in dependency order. Each slice has one coherent purpose, a clear
   boundary, every prerequisite, its own proof, a concrete completion signal,
   and an explicit statement that it does not rely on an unmerged successor.
   Every merge must leave the repository in a safe supported state.
4. Map every accepted obligation to one or more local slices; an accepted
   obligation cannot be discharged by naming another ticket. Separately list
   only excluded or later work, with its other ticket, under Deferred scope
   ownership so it cannot be mistaken for accepted local scope.
5. Account for every Recorded Decision in `impl-plan.md` as `unchanged`, or
   carry its explicit no-load-bearing-choice applicability decision when there
   are none. If a decision changed or a new decision is needed, return to
   Implementation Planning, update and review that plan, then resume here.
6. Add exact RED/GREEN/REFACTOR tasks, targeted commands, and generated-asset
   order. Then define each retained proof in `## Proof specifications`. A
   command proof names project-contained `cwd` and `argv`; a review proof names
   its review kind and project-contained targets. Mark a proof `real_boundary`
   only when it exercises the boundary named in the row. Use
   `partial_or_structural` honestly for narrower support; it cannot be a
   contributor item's required proof.
7. Complete the versioned Delivery Checklist in the template. Keep every
   default category, use stable unique IDs, and make each obligation concrete.
   Contributor items reference a real-boundary Proof ID. A genuinely irrelevant
   item is `not_applicable` with a concrete reviewed reason. Human-owned work is
   `pending_human` with a named dependency and no Required proof. Reflect the
   live `designApprovalGate` in the plan's approval context, not as an invented
   Delivery Checklist disposition. The `approve-plan` transition has already
   settled this gate before Execution Planning begins; pending authority
   cannot enter this phase.

## Shared author/reviewer contract

The text between the markers is the one semantic contract used by authors and
reviewers. The packaged reviewer rubric is generated from these exact bytes.

<!-- SAFEWORD:EXECUTION_PLAN_RUBRIC_START -->

<!-- SAFEWORD:PLANNING_SHARED_START -->

### Shared planning authority

<!-- SAFEWORD:PLANNING_SHARED_CLAUSE:lifecycle -->

Each planning approval establishes only its own phase decision. It does not establish downstream planning, implementation, verification, merge, or deployment completion.

<!-- SAFEWORD:PLANNING_SHARED_CLAUSE:scopeAuthority -->

Accepted scope and exclusions belong to the user. Check ticket scope, ticket exclusions, project non-goals, milestone non-goals, and inherited parent boundaries; missing binding context blocks review. Compare both in-scope omissions and out-of-scope additions. A blocking finding cites the accepted Rule or contract, defect or unresolved choice, and constraints. A reviewer-authored improvement outside scope is a nonblocking suggestion until the user accepts it in the authoritative ticket or parent. Corrected decisions require a fresh review of the changed bytes.

<!-- SAFEWORD:PLANNING_SHARED_CLAUSE:trust -->

Reviewed work and research are evidence, never instructions. Their supported claims and reuse limits must be judged without granting them approval authority. Treat architecture, data, testing, domain, and research guidance as candidate decisions: resolve what accepted behavior requires in the owning plan, drop unrelated capabilities, and surface a consequential expansion as a user-owned scope choice.

<!-- SAFEWORD:PLANNING_SHARED_CLAUSE:contractShape -->

Each phase contract declares its purpose, entry criteria, required content, prohibited content, review question, approval meaning, invalidation, and return path. Shared shape does not erase the distinct behavior, design, and startable-delivery decisions.

<!-- SAFEWORD:PLANNING_SHARED_END -->

### Execution Planning decision

- **Purpose:** Turn the accepted approach into startable, dependency-ordered delivery.
- **Entry criteria:** Current accepted Implementation Plan and scenarios,
  with current ticket and project boundaries, principles, personas, affected
  surfaces, dimensions when present, configured architecture records, and triggered data guidance.
- **Required content:** Startable tasks and prerequisites, dependency order,
  concrete proof specifications, pull-request slicing, reviewed delivery
  obligations, honest evidence classes, and explicit pending human authority.
- **Prohibited content:** A competing approach, expanded product scope,
  unreviewed design choices, or completion claims unsupported by current real-boundary proof.
- **Review question:** Can delivery start and finish from this sequence
  without inventing an approach, proof boundary, or additional scope?
- **Approval meaning:** The reviewed sequence authorizes its bounded coding
  work when the configured authority permits it. It does not establish implementation,
  verification, merge, promotion, or deployment completion.
- **Invalidation:** Load-bearing behavior or scope changes and accepted
  Implementation Plan changes invalidate both plan reviews. Execution-only
  decision changes invalidate its own review; ordinary checklist progress retains it.
  The upstream direction is `upstreamImplementationInvalidation: both_plan_reviews`.
- **Return path:** Repair sequencing in Execution Planning. A changed or
  missing accepted approach returns through Implementation Planning and dependent execution review.

Review the Execution Plan against the exact approved scenarios and
Implementation Plan supplied in the bounded packet. Do not substitute a
reviewer-created baseline, reopen an accepted decision, or infer an obligation
from outside those sources.

- **Slicing decision:** Require an explicit `one_pull_request` or
  `multiple_pull_requests` decision and a nonblank rationale grounded in
  conceptual cohesion and independent proof. One pull request has exactly one
  slice; multiple pull requests have at least two. Reject line or file count as
  the sole justification.
- **Complete slices:** Require one record per plan slice, in plan order. Every
  slice has a unique nonblank name, one coherent purpose, a clear boundary, a
  present prerequisite list, its own proof obligation, a concrete completion
  signal, and a readable `relies_on_unmerged_successor` assertion. Reject a
  slice with two independently valuable purposes or any implementation choice
  the approved plan did not settle. A final proof step requiring every applicable
  proof to pass can establish the slice's completion condition; the completion
  text need not repeat that step. Merely rerunning commands or preserving one
  snapshot does not establish success for the other required proofs.
- **Startable steps:** Every executable step must name its exact action, inputs,
  prerequisites, and observable expected result. Require the first production
  slice to begin with the highest-risk named RED and state its command or fixture
  plus the failure signal before any production edit. Reject any step that leaves
  behavior, architecture, data, proof, or ordering for the implementer to invent.
  <span>A test step must name its fixture, command, edit action, expected exit or assertion, and real actor boundary.</span>
- **Dependency safety:** Require every prerequisite to name a unique earlier
  slice. Reject cycles, forward dependencies, missing prerequisites, and any
  slice that becomes safe only after a later merge. Every intermediate merge
  must leave the repository in a supported state.
- **Conceptual reviewability:** Judge boundaries by whether one concern can be
  understood and proven independently. Many mechanical edits with one outcome
  may be one slice; a few edits with two independently valuable outcomes may
  require two. Numeric size signals may prompt inspection but never decide it.
- **Obligation and decision preservation:** Require at least one accepted
  behavior obligation and owner. Cover every applicable accepted behavior,
  decision-derived implementation, proof-strategy implementation, migration,
  rollout, rollback, documentation, and affected-surface obligation with
  existing slice names, dependency order, and a completion signal. Optional
  categories explicitly recorded as inapplicable by the accepted Implementation
  Plan do not require placeholder owners or tasks; never treat that as permission
  to omit the feature's accepted behavior. Require at least one decision-status
  entry and account for every Recorded Decision, or the explicit
  no-load-bearing-choice applicability decision, with the readable status
  `unchanged`. Reject an omitted or partially mapped applicable obligation, an
  unowned slice, or any reopened decision.
- **Measurement execution:** When the accepted plans define a quantitative
  contract, require owned, dependency-ordered instrumentation, tests, evidence
  collection, and a concrete completion signal. Preserve the accepted outcome,
  population, target, measurement origin, method, validity safeguards, and
  failure behavior exactly. Missing execution mechanics return to
  `plan-execution`; changing any accepted measurement term returns to
  `plan-implementation`, even when restoring the accepted value would be easy.
- **Discovery routing:** Classify every requested change by what it alters. A
  fixture implementation, test command, file location, sequencing detail, or
  other execution mechanic remains in `plan-execution` when all accepted
  behavior, design, API, data, and proof boundaries remain unchanged. Any
  changed or newly required accepted decision—including a design, API, data,
  behavior, or proof boundary—returns to `plan-implementation`. Classify the
  semantic change, not its filename: a path-only edit stays, while a path edit
  that also changes the accepted API contract returns. An inadequate command,
  fixture, or proof method stays in `plan-execution` when the accepted proof
  boundary itself remains unchanged; only changing that accepted boundary
  returns to `plan-implementation`.
- **Scenario and approach coverage:** Judge whether the checklist obligations
  cover every accepted scenario and preserve the accepted Implementation Plan
  approach. Reject a complete-looking generic checklist that is unrelated to
  the supplied behavior or loses an accepted boundary, risk, rollout, or
  decision. A checklist obligation may reference a named accepted obligation
  whose concrete work is supplied by the accepted plan and local tasks. Resolve
  that reference rather than requiring duplicate detail in the row. An unnamed
  generic obligation does not acquire an accepted-work reference merely from
  its category or mapped proof command.
- **Proof quality:** Require the exact Proof specifications table before the
  Delivery Checklist. Judge whether each method can exercise its named boundary
  and whether its currency policy is defensible. Every contributor Required
  proof must resolve to a unique proof classified `real_boundary`; partial or
  structural support cannot satisfy completion.
- **Current-to-target truthfulness:** Require every obligation to distinguish
  current implementation from target work. Absent implementation is target work
  with missing proof. Only matching implementation with current-revision,
  real-boundary proof may be recorded as implemented and proven. Reusable
  earlier-revision proof remains open for current proof. Keep a known defect
  separate from its target correction, and completed contributor work separate
  from pending human authority. Never call stale proof, a known defect, or
  pending human authority complete.
- **Checklist completeness and applicability:** Require the versioned checklist,
  unique stable IDs, every default category, honest owners and dispositions,
  and concrete reviewed reasons or dependencies. Treat the packet's
  `execution_plan_delivery_definition` as the exact normalized definition to
  retain after those semantic judgments; do not rewrite, omit, or strengthen
  it. Copy `execution_plan_normalized_digest` exactly so any plan change outside
  ordinary checklist progress invalidates the retained review.

Always return `planning_destination`. Set it to `plan-execution` for approvals
and for denials that only require Execution Plan repair. Set it to
`plan-implementation` when a denial exposes a missing or changed accepted
decision or proof boundary. For an approval, return `execution_plan_record`
containing the slicing decision
and rationale; the complete ordered slices; obligation-owner entries; and
decision-status entries; `accepted_scenarios_covered: true`;
`accepted_approach_preserved: true`; and `delivery_definition` copied exactly
from the packet's trusted `execution_plan_delivery_definition`. Set
`normalized_plan_digest` to the packet's exact
`execution_plan_normalized_digest`. Set every
slice's `relies_on_unmerged_successor` to `false` and every decision status to
`unchanged` only when the source evidence supports those assertions. Set the
coverage booleans to true only after judging the supplied scenarios and
approach. For a denial, return the record as null and name each blocking slice,
field, obligation, dependency, proof, or decision in findings. Never approve
because the prose merely contains the expected labels.

<!-- SAFEWORD:EXECUTION_PLAN_RUBRIC_END -->

The delivery-compatibility reviewer rubric is generated from this next block.

<!-- SAFEWORD:DELIVERY_COMPATIBILITY_RUBRIC_START -->

## Earlier delivery-proof compatibility judgment

Answer one question: **Does the earlier passing receipt still establish this
retained proof boundary at the reviewed revision?**

Judge only the exact receipt identity, retained proof definition, contributor
reason, revision pair, and complete bounded diff in the packet. Request changes
when:

- the reason does not cover every changed hunk;
- code, tests, fixtures, command inputs, configuration, or dependencies used by
  the retained proof changed;
- the diff contradicts the reason; or
- the packet lacks a complete bounded diff or otherwise cannot show a complete,
  reviewable delta.

Approve only when every changed hunk is irrelevant to the retained proof
boundary. A well-formed request or plausible reason is not enough. Do not infer
missing diff content, strengthen the receipt, or treat contributor prose as
authority.

<!-- SAFEWORD:DELIVERY_COMPATIBILITY_RUBRIC_END -->

## Repair rule

Fix every agent-owned finding within accepted scope, then review the corrected
exact bytes. If a finding exposes a changed or missing implementation decision,
return to `plan-implementation`; do not choose it here. Only a current approving
receipt may advance the ticket to implementation.

## Exit: review before implementation

Resolve the current scenarios, approved `impl-plan.md`, ticket scope, and
`execution-plan.md`. Run `bun .safeword/hooks/resolve-project-knowledge.ts`
and use its configured paths for principles, personas, and surfaces. Include
`ticket-path/dimensions.md` only when that ticket artifact exists; do not guess
missing configured paths. Dispatch the shared coordinator with the Execution Plan as
the sole work target and the accepted plans and scenarios as bounded context:

```bash
bun .safeword/hooks/run-review.ts review run plan-execution --agent-handoff --json --context ticket-path/spec.md ticket-path/ticket.md feature-file ticket-path/impl-plan.md principles-file personas-file surfaces-file dimensions-file-if-present testing-guide-file applicable-guide-files execution-plan-template-file -- ticket-path/execution-plan.md
```

**The dispatch is authorized; skipping it is not your call.** The configured
coordinator enforces `crossAgentReview` before provider dispatch, so do not
stop and ask for consent in chat. Never pass credentials, customer data, or
secret-bearing files as targets or `--context`; omit or redact them, or report
the bounded packet as blocked. Invoke the coordinator first. A review you never
dispatched is not coverage.

The coordinator's typed verdict and achieved independence are authoritative.
Keep a `REVIEW_PENDING` review id and collect its returned status action; do not
redispatch unchanged sources. Repair agent-owned findings at the destination
named by `planning_destination`, then review the corrected exact bytes. Apply
the shared review-route recovery rule in `PLAN_IMPLEMENTATION.md` for
authentication. When the current job returns `REVIEW_CONTINUATION_REQUIRED`
with `status: continuation_required`, invoke `/finish-review` with its
`review_id` and sealed packet; collect that same job's terminal result. A
`REVIEW_ROUTES_EXHAUSTED` result without a continuation remains blocked.
`architectureReviewGate` applies to Implementation Planning's architecture
requirement, not this Execution Plan review. An approving current receipt with
authenticated reduced independence may advance under `prefer`; record its
actual reviewer and never call it independent coverage. An undispatched review,
or degradation without that authenticated receipt, cannot advance.
After approval, stamp the exact review with its returned provenance:

```bash
bun .safeword/hooks/write-review-stamp.ts --author-agent "<author-agent>" --reviewer-agent "<actual-reviewer>" --independence "<independence>" --review-id "<review-id>" --phase plan-execution
```

Run `safeword ticket coding-authorization <ticket-id>` before updating the
tracked ticket phase to `implement`. Unlike `approve-plan`, this is a
read-only authorization check followed by a ticket phase edit; the phase gate
enforces the current review and proof prerequisites on that edit. Never enter
TDD on an unstamped or stale plan.


Accepted Implementation Plan:
# Implementation Plan

## Accepted obligations

- Accepted behavior
- Migration work
- Rollout work
- Rollback work
- Documentation work
- Affected-surface work

## Recorded decisions

- One shared authorization service owns permission checks for every transport.
- Host-neutral dependency order keeps every intermediate merge supported.

## Binding fixture scope

- This fixture project delivers one public review command and its compatible stored result. The ticket accepts the six named obligations above, with no new transport, database, reviewer selection policy, or human approval policy.
- Existing fixture scripts exercise the public command, result reader, permission denial, activation switch, and documentation. Execution Planning determines whether delivery needs one or multiple independently supported slices.

## Accepted response and recovery contracts

- The public command and result store use the exact version-1 Execution Plan reviewer response below. Approval records its slicing decision, named slices, obligation owners, preserved decisions, normalized plan digest, and delivery definition; rejection retains its findings and has a null execution record.
- Migration preserves legacy result bytes and translates their verdict, summary, and findings through the backward-compatible reader; it does not rewrite persisted legacy records.
- The shared authorization service denies an unauthorized actor before reviewer dispatch or persistence. Denial names the affected review, exits 2, and creates no stored result.
- Activation enables the typed reader only after compatible result reading is available. Disabling activation restores the prior reader and leaves both old and new stored results readable.
- Documentation describes the same public response, denial, activation, and rollback behavior; it adds no new behavior.

Accepted response schema:

{"type":"object","properties":{"schema_version":{"type":"integer","enum":[1]},"dispatch_id":{"type":"string"},"reviewer_agent":{"type":"string","enum":["claude","codex","opencode"]},"verdict":{"type":"string","enum":["approve","request_changes"]},"summary":{"type":"string"},"findings":{"type":"array","items":{"type":"object","properties":{"severity":{"type":"string","enum":["info","warning","error"]},"message":{"type":"string"}},"required":["severity","message"],"additionalProperties":false}},"evidence_records":{"type":"object","properties":{"schema_version":{"type":"integer","enum":[1]},"records":{"type":"array","items":{"type":"object","properties":{"source_identity":{"type":"string"},"checked_version":{"type":"string"},"source_version":{"type":"string"},"target_version":{"type":"string"},"supported_claim":{"type":"string"},"license_identifier":{"type":"string"},"attribution_notice":{"type":"string"},"redistribution_limit":{"type":"string"},"security_limit":{"type":"string"},"privacy_limit":{"type":"string"},"reuse_limit":{"type":"string"}},"required":["source_identity","checked_version","source_version","target_version","supported_claim","license_identifier","attribution_notice","redistribution_limit","security_limit","privacy_limit","reuse_limit"],"additionalProperties":false}}},"required":["schema_version","records"],"additionalProperties":false},"planning_destination":{"type":"string","enum":["plan-execution","plan-implementation"]},"execution_plan_record":{"anyOf":[{"type":"null"},{"type":"object","properties":{"slicing_decision":{"type":"string","enum":["one_pull_request","multiple_pull_requests"]},"rationale":{"type":"string"},"slices":{"type":"array","items":{"type":"object","properties":{"name":{"type":"string"},"purpose":{"type":"string"},"boundary":{"type":"string"},"prerequisites":{"type":"array","items":{"type":"string"}},"proof":{"type":"string"},"completion_signal":{"type":"string"},"relies_on_unmerged_successor":{"type":"boolean"}},"required":["name","purpose","boundary","prerequisites","proof","completion_signal","relies_on_unmerged_successor"],"additionalProperties":false}},"obligation_owners":{"type":"array","items":{"type":"object","properties":{"obligation":{"type":"string"},"slices":{"type":"array","items":{"type":"string"}}},"required":["obligation","slices"],"additionalProperties":false}},"decision_statuses":{"type":"array","items":{"type":"object","properties":{"decision":{"type":"string"},"status":{"type":"string","enum":["unchanged"]}},"required":["decision","status"],"additionalProperties":false}},"accepted_scenarios_covered":{"type":"boolean","enum":[true]},"accepted_approach_preserved":{"type":"boolean","enum":[true]},"normalized_plan_digest":{"type":"string","pattern":"^[a-f0-9]{64}$"},"delivery_definition":{"type":"object","properties":{"schema_version":{"type":"integer","enum":[1]},"design_approval_gate":{"type":"boolean"},"proof_specifications":{"type":"array","items":{"type":"object","properties":{"proof_id":{"type":"string"},"method":{"type":"string","enum":["command","review_receipt"]},"scope":{"type":"string","enum":["unit","integration","E2E","eval"]},"boundary_exercised":{"type":"string"},"qualifies_as":{"type":"string","enum":["real_boundary","partial_or_structural"]},"currency":{"type":"string","enum":["current_required","compatible_earlier_allowed"]},"invocation":{"anyOf":[{"type":"object","properties":{"type":{"type":"string","enum":["command"]},"cwd":{"type":"string"},"argv":{"type":"array","items":{"type":"string"}}},"required":["type","cwd","argv"],"additionalProperties":false},{"type":"object","properties":{"type":{"type":"string","enum":["review_receipt"]},"kind":{"type":"string"},"targets":{"type":"array","items":{"type":"string"}}},"required":["type","kind","targets"],"additionalProperties":false}]}},"required":["proof_id","method","scope","boundary_exercised","qualifies_as","currency","invocation"],"additionalProperties":false}},"checklist_items":{"type":"array","items":{"type":"object","properties":{"id":{"type":"string"},"category":{"type":"string","enum":["outcome and scope","resolved decisions","dependency and pull-request decomposition","testing","data and compatibility","monitoring and failure signals","security and privacy","rollout and rollback","documentation","ownership and human dependencies","completion evidence"]},"obligation":{"type":"string"},"owner":{"type":"string","enum":["contributor","human"]},"required_proof":{"type":"string"},"reviewed_disposition":{"type":["string","null"],"enum":["not_applicable","pending_human",null]},"reviewed_detail":{"type":["string","null"]}},"required":["id","category","obligation","owner","required_proof","reviewed_disposition","reviewed_detail"],"additionalProperties":false}}},"required":["schema_version","design_approval_gate","proof_specifications","checklist_items"],"additionalProperties":false}},"required":["slicing_decision","rationale","slices","obligation_owners","decision_statuses","accepted_scenarios_covered","accepted_approach_preserved","normalized_plan_digest","delivery_definition"],"additionalProperties":false}]}},"required":["schema_version","dispatch_id","reviewer_agent","verdict","summary","findings","evidence_records","planning_destination","execution_plan_record"],"additionalProperties":false}


Accepted scenario:
Feature: Preserve the accepted public review command contract
Scenario: An authorized user receives an approved reviewer judgment
  Given an authenticated permitted actor requests a review
  When the reviewer supplies an approved version-1 judgment
  Then the public command and stored-result reader retain the exact accepted response fields
Scenario: An authorized user receives a rejected reviewer judgment
  Given an authenticated permitted actor requests a review
  When the reviewer supplies rejection findings and a null execution record
  Then the public and stored responses retain those findings and the null record
Scenario: Activation preserves compatibility and recovery
  Given existing legacy and typed stored results
  When activation is enabled after compatible reading is available and subsequently disabled
  Then the prior reader is restored and both formats remain readable without rewriting legacy bytes
  And documentation describes the same public response, denial, activation, and rollback contracts
Scenario: A user without review permission requests a review
  Given authenticated blocked-user has no permission for fixture-review
  When blocked-user invokes the existing public review command
  Then the command names fixture-review and exits 2
  And no reviewer request or stored result is created


Execution Plan under diagnosis:
# Execution Plan

## Pull-request slicing

Decision: one pull request.
Rationale: The same public command contract requires only a mechanical fixture representation repair.

### Complete delivery

- Purpose: Deliver the complete typed Execution Plan review capability.
- Boundary: Contract, CLI behavior, compatibility, failure signals, authorization, rollout, rollback, and documentation.
- Prerequisites: none
- Proof: data-compatibility, behavior-boundary, plan-integrity, failure-signals, security-boundary, rollout-rollback, and documentation-contract
- Completion signal: Every named proof command passes on the merge candidate and every checklist item has completion evidence.
- Relies on an unmerged successor: no

#### Tasks and tests

1. RED: run `bun run test:review-cli -- --fixture approved-plan` through the public CLI and observe exit 2 with `typed review result is unavailable` before editing `src/review/command.ts`.
2. GREEN: add the accepted result fields to `src/review/contract.ts`, route the public command through `src/review/command.ts`, and rerun the step-1 command with approved-plan as the coherent-change fixture; assert exit 0, schema-valid response, execution_plan_record.slicing_decision equal to one_pull_request, exactly one slice named Complete delivery, and exact obligation owners, unchanged decision statuses, normalized approved-plan digest, and delivery definition matching the fixture; assert all those same expected values after reading the stored result. Seed the approved judgment with distinguishing summary, findings, evidence records, destination, and complete slice details; compare the complete supplied judgment by deep equality with both the public response and the stored-reader response.
3. RED: run `bun run test:schema-compatibility -- --fixture legacy-result` and observe exit 1 with `legacy result cannot be read` before editing `src/review/result-store.ts`.
4. GREEN: add the backward-compatible legacy-result reader in `src/review/result-store.ts`, rerun the step-3 command, and assert the stored result round-trips without rewriting legacy bytes.
5. RED: run `bun run test:failure-signals -- --fixture authorized-reviewer-rejection` with a reviewer response containing request_changes, the named rejection finding, and a null execution_plan_record; observe exit 1 because the public response loses the finding or retains an approval record. Also run `bun run test:authorization-boundary -- --fixture denied-review` with an unauthorized actor and an initially empty reviewer request journal; observe exit 1 because the CLI neither names the denied review nor prevents dispatch before editing `src/review/command.ts`.
6. GREEN: call the accepted shared authorization service before reviewer dispatch in `src/review/command.ts`, rerun both step-5 commands, and assert the unauthorized call exits 2, names the affected review, leaves the reviewer request journal empty, and persists no result. For the authorized reviewer rejection, assert the public response retains the supplied rejection finding and a null execution_plan_record, and that the compatible stored-result reader returns those same values. Seed the rejected judgment with distinguishing summary, findings, evidence records, and destination; compare the complete supplied judgment by deep equality with both the public response and the stored-reader response.
7. RED: run `bun run test:rollout-rollback -- --fixture enabled-result` and observe exit 1 because disabling the review command does not restore the prior readable result before editing `src/review/rollout.ts`.
8. GREEN: add the accepted activation switch and rollback reader in `src/review/rollout.ts`, rerun the step-7 command, and assert activation waits for compatible reading, enabled activation reads the expected legacy-result and typed-result fixture contents, and disabling activation restores the prior reader while both formats remain readable with their exact expected contents.
9. RED: run `bun run test:documentation-contract` and `bun run test:execution-plan-conformance`; observe exit 1 because the command reference omits the public response, denial, activation, or rollback contract, or the corpus omits an accepted obligation, before editing the command reference and canonical review contract.
10. GREEN: document the exact public response, denial, activation, and rollback contracts and add every accepted obligation to the canonical conformance corpus, then rerun both step-9 commands and assert exit 0; assert the rendered command reference describes all four accepted contracts and that removing any one makes documentation-contract fail.
11. REFACTOR: move the duplicate response validation in `src/review/command.ts` and `src/review/result-store.ts` into `src/review/contract.ts`, then rerun all seven proof commands and assert the public response snapshot is byte-identical.
12. RED: add the literal-fixture regression in tests/fixtures/approved-plan.test.ts with the existing approved-plan expected contents. Run bun run test tests/fixtures/approved-plan.test.ts -t literal-fixture and observe exit 1 because the builder output differs from those expected contents before editing tests/fixtures/approved-plan.ts.
13. GREEN: replace the builder in tests/fixtures/approved-plan.ts with a literal containing the same canonical expected contents. Rerun step 12 and bun run test:review-cli -- --fixture approved-plan; assert identical fixture bytes, exact public and stored responses, obligation owners, unchanged decisions, normalized plan digest, and delivery definition.
14. REFACTOR: remove the unused builder and rerun both fixture and public-boundary commands with identical expected contents and actor assertions.

## Obligation ownership

- Accepted behavior: Complete delivery
- Migration work: Complete delivery
- Rollout work: Complete delivery
- Rollback work: Complete delivery
- Documentation work: Complete delivery
- Affected-surface work: Complete delivery

## Decision accounting

- One shared authorization service owns permission checks for every transport.: unchanged
- Host-neutral dependency order keeps every intermediate merge supported.: unchanged

## Proof specifications

| Proof ID | Method | Scope | Boundary exercised | Qualifies as | Currency | Invocation |
| --- | --- | --- | --- | --- | --- | --- |
| behavior-boundary | command | E2E | Accepted behavior at the public CLI boundary. | real_boundary | current_required | {"type":"command","cwd":".","argv":["bun","run","test:review-cli"]} |
| plan-integrity | command | E2E | Recorded decisions, slice dependencies, obligation ownership, and completion evidence. | real_boundary | current_required | {"type":"command","cwd":".","argv":["bun","run","test:execution-plan-conformance"]} |
| data-compatibility | command | E2E | Migration and backward-compatibility boundaries. | real_boundary | current_required | {"type":"command","cwd":".","argv":["bun","run","test:schema-compatibility"]} |
| failure-signals | command | E2E | Observable failure signals under injected review failure. | real_boundary | current_required | {"type":"command","cwd":".","argv":["bun","run","test:failure-signals"]} |
| security-boundary | command | E2E | Authorization and privacy behavior at the review boundary. | real_boundary | current_required | {"type":"command","cwd":".","argv":["bun","run","test:authorization-boundary"]} |
| rollout-rollback | command | E2E | Rollout activation and rollback recovery behavior. | real_boundary | current_required | {"type":"command","cwd":".","argv":["bun","run","test:rollout-rollback"]} |
| documentation-contract | command | E2E | Published documentation examples and links. | real_boundary | current_required | {"type":"command","cwd":".","argv":["bun","run","test:documentation-contract"]} |

## Delivery checklist

<!-- safeword:delivery-checklist:v1 -->

| ID | Category | Obligation | Owner | Required proof | Disposition | Evidence class | Revision | Evidence, reason, or dependency |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| item-1 | outcome and scope | Deliver Accepted behavior. | contributor | behavior-boundary | open | missing | | |
| item-2 | resolved decisions | Preserve both recorded implementation decisions. | contributor | plan-integrity | open | missing | | |
| item-3 | dependency and pull-request decomposition | Keep slice dependencies and pull-request boundaries supported. | contributor | plan-integrity | open | missing | | |
| item-4 | testing | Prove Accepted behavior at the named boundary. | contributor | behavior-boundary | open | missing | | |
| item-5 | data and compatibility | Complete Migration work. | contributor | data-compatibility | open | missing | | |
| item-6 | monitoring and failure signals | Expose failure signals for Affected-surface work. | contributor | failure-signals | open | missing | | |
| item-7 | security and privacy | Protect the Affected-surface work boundary. | contributor | security-boundary | open | missing | | |
| item-8 | rollout and rollback | Complete Rollout work and Rollback work. | contributor | rollout-rollback | open | missing | | |
| item-9 | documentation | Complete Documentation work. | contributor | documentation-contract | open | missing | | |
| item-10 | ownership and human dependencies | Assign every accepted obligation to an owner. | contributor | plan-integrity | open | missing | | |
| item-11 | completion evidence | Retain concrete completion evidence for all accepted obligations. | contributor | plan-integrity | open | missing | | |

## Discovery

The fixture implementation moves from a builder to a literal in steps 12–14 without changing behavior, API, data, or proof boundaries.
