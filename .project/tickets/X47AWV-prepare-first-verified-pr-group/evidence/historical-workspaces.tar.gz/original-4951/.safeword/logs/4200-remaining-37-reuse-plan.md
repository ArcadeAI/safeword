# Remaining 37 acceptance cases: reuse investigation

Snapshot: 1118cee38; fresh root dry-run reports 159 nondeferred scenarios,
122 bound dry-skips and 37 undefined. Counts are bindings, not passing acceptance.
No scenario, fixture, qualification record or deferral was changed for this audit.
Raw enumeration: /tmp/4200-remaining-inventory.json.

Decision: reuse existing setup and real entry points, retaining distinct behavioral
assertions. Do not remove accepted scenarios merely because their setup overlaps.
Alternatives considered: write one new harness per scenario (clear isolation but
duplicated setup and maintenance), or collapse scenarios to existing lower-level
tests (cheap but loses required actor/semantic boundaries). Small adapters around
existing collaborators are preferable; a general-purpose test framework is not.

Research domains: acceptance boundaries (feature and accepted execution plan),
fixture composition (current root step modules), semantic evidence (pinned cases
and judged runner), authentication/currency (coordinator/status/writer/native
gate), and scope authority (existing user deferrals). These are source-backed
implementation findings, not claims that proposed bindings already pass.

## Complete case map

Rows refer to features/keep-plan-reviews-current-and-trustworthy.feature.

| Rows | Count | Required distinction | Existing reuse | Missing work / restriction |
| --- | ---: | --- | --- | --- |
| 167 | 1 | Retryable route names another unattempted independent route | independence setup, native pending fixture, configured route order | Obtain genuine retryable evidence with an eligible remaining route; pending alone does not prove retryable routing. |
| 170 | 1 | Ungated origin cannot confer approval | public continuation origin refusal, receipt admission helpers | Unsupported-origin refusal is available, but an authenticated approval recording an ungated origin is not currently constructible. Resolve the proof mismatch; never substitute a wrong review kind. |
| 175 | 1 | Fallback cannot bypass an available independent route | fallback-order continuation packet and pending-job fixture | Request a meaningful premature fallback on the same real job and prove route-specific refusal. Existing self-before-fresh refusal is a different boundary. |
| 190, 201 | 2 | Actual qualified weaker reviewer refused/classified and not launched | route-capability helpers and lower-level weaker-route tests | Shipped catalogue contains only two not_weaker pairs. Existing weaker test mocks capability classification internally; it cannot supply real-catalogue evidence. Qualification/defer decision remains open. |
| 273, 274 | 2 | Planning/review use public claims but ignore retrieved instructions | r7-retrieved-instruction case, packet/evaluator helpers | Separate plan and review outputs and unchanged accepted-scope bytes; source text in a packet alone is not retrieval/host proof. |
| 283, 284 | 2 | Planning/review cite claims without executing retrieved code | planning-evidence-boundary packet fixture and sentinel | Exercise the named producer boundary. Absence of a sentinel after merely loading a packet proves only that loader. |
| 293, 294 | 2 | Public evidence usable without sending private context | r7-private-request case and evidence-record structures | Capture the actual retrieval/publication boundary; no outgoing private marker, alongside positive public-evidence control. User-owned host retrieval deferral remains controlling. |
| 303, 304 | 2 | Declared limits survive in plan/review evidence records | exact Apache-2.0/Credit Example/retain NOTICE/security-limit fixture | Shared source fixture; distinct plan record and authenticated review result outputs. Codec tests are supporting coverage, not the whole flow. |
| 313, 314 | 2 | Missing limits remain none_declared in plan/review outputs | none-declared evidence test and r7-absent-reuse-limits case | Shared negative source variant; assert no invented permission in each actual output. |
| 323, 324, 325 | 3 | Artifact/context injection is inert; real missing decision still blocks | captured packet loader, quoted context roles, judged evaluator | Three narrowly different inputs: plan instruction, persona instruction, and instruction plus real defect. Add or identify matching semantic oracles; an injected fake verdict is not proof. |
| 335, 336 | 2 | Installed dispatch preserves hostile/ordinary evidence | installed local-hook dispatcher and evidence-record fixture | Same installed setup, two payloads; prove actual reviewer packet and permitted output. These explicitly allow reviewer-process mocking; preserve this distinction from real-reviewer semantic gate cases. |
| 507, 508 | 2 | Installed finding authority approves conforming work and names unmet Rule | native gate setup; r11-unmet-accepted-requirement and conforming semantic fixtures | Real coordinator reviewer and judge, authenticated receipt and actual hook outcome. Fake approving producer from structural native tests cannot stand in. |
| 547, 548 | 2 | Installed scope packet complete/missing project boundary | capturedScopePacket setup; r12-complete-scope-context/r12-missing-project-non-goals | Reuse binding-source construction, retain real native dispatch and semantic evaluation. Missing packet precondition may fail before producer; distinguish refusal from reviewer verdict. |
| 572, 573, 574 | 3 | Installed scope approves complete plan, rejects omission and overreach | r13-conforming-boundary/r13-in-scope-omission/r13-out-of-scope-addition | Same installed semantic runner as 507–548, with exact case-specific findings. |
| 586 | 1 | Decline recorded, unchanged plan re-reviewed | real record-review-disposition integration fixture, disposition identity, r14-declined-strengthening | Compose persisted authenticated decline with genuine semantic re-review; existing fake process proves persistence/context only. |
| 587 | 1 | User acceptance recorded before changed plan is re-reviewed | accepted-boundary digest, ticket scope/currency helpers | No accept counterpart to the decline command. Record user-owned scope through the established ticket authority; do not add a new command solely for this test. Distinguish scope acceptance from reviewer proposal. |
| 589 | 1 | Pending suggestion does not mutate/block and remains presented | noninteractive pending-disposition integration test, current-byte checks | Genuine unchanged-plan re-review and visible outstanding decision are still required; pending CLI output alone is incomplete. |
| 595 | 1 | Installed re-review retains current decline and exact plan bytes | decline flow above plus shared installed semantic runner | Fourth suggestion case, tenth installed semantic flow; do not duplicate installation setup. |
| 610, 612 | 2 | Required decision resolved; consequential expansion stays user-owned | existing guidance step/evaluator | Current r15 case proves unrelated capability only. Two distinct semantic cases/oracles needed; replacing expected verdicts in that case would be false reuse. Check pinned-corpus impact before editing qualification inputs. |
| 648, 649 | 2 | Scenario gate covers all persona outcomes or names missing recovery | Product persona inventories and real scenario-gate rubric/packet | Fresh scenario-coverage inputs and matching semantic oracle. plan-persona-consequences helper manufactures an Implementation verdict and is the wrong boundary. |
| 659, 660 | 2 | Installed Product gate approves complete inventory/rejects missing recovery | r16-complete-persona-outcomes/r16-missing-persona-recovery plus installed runner | Reuse Product inputs, but enforce Product-phase admission and named missing outcome; Implementation approval cannot substitute. |
| Total | 37 | | | |

## Recommended implementation order

1. Reuse the public decline/pending-disposition flow for the suggestion cases.
   This already has authenticated persistence, stale/current boundary behavior
   and noninteractive pending behavior. Add the missing semantic connections,
   rather than creating another suggestion store or acceptance command.
2. Compose one small installed semantic runner for the nine finding/scope/Product
   cases plus installed decline (ten flows). Reuse fixture installation,
   dispatch, actual CLI/status/writer and judge support. Existing evaluator output
   must never be copied into a manufactured authenticated receipt. Parameterize
   case inputs and expected outcomes, not authority.
3. Bind the two persona scenario-coverage cases through actual scenario review.
   Reuse persona input construction; do not use the Implementation-plan fixture
   as a coverage judge. Preserve approve versus named uncovered-recovery outcomes.
4. Add the two missing guidance semantic inputs with correctly independent
   oracles. First check whether a separate bounded acceptance evaluation can
   avoid changing the qualified corpus; do not silently invalidate catalogue
   evidence or use a mismatched existing case to save a run.
5. Group R7 source payloads and record assertions, retaining planning versus
   review outputs and injection/ordinary controls. Implement only boundaries
   consistent with the user-owned retrieval deferral; partial packet or judged
   proofs cannot close that deferral.
6. Keep the five route cases separate from semantic runner work. The two missing
   weaker pairs need a user decision; the other three need correct real-job
   constructions or an explicit accepted proof-boundary correction.

## Dedupe and cost limits

No exact removable acceptance duplicate was established. Native versus semantic,
planning versus review, and positive versus negative cases are different proofs.
Most repeated setup can be shared. In particular, keep one definition for the
identical installed Implementation When used by R11/R12/R13; Cucumber matches
step text globally, so repeating it in multiple files creates ambiguity.

Source: https://cucumber.io/docs/gherkin/reference/#steps

Do not cache authenticated receipts across scenarios, contexts, phases or roots.
Do not count old judged runs as current native-flow execution. Share immutable
inputs and runner code; retain current input-digest/model checks and each case's
own actual result. No new Astra run or qualification is authorized by this map.

Premortem: a shared helper could conceal a mocked reviewer or make every case
assert the same generic denial. Prevent that with explicit boundary parameters,
real reviewer mode where required and case-specific observable outcomes.

This plan leaves all 37 gaps visible. The separate 16 MCWV4B host deferrals,
R7 pending_human deferral, and historical six failures/585 unfinished acceptance
results remain unchanged. It proposes reuse, not deletion or completed evidence.
