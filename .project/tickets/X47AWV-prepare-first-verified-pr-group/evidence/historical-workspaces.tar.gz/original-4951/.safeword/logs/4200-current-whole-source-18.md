Current PR5 complete unique-source review 18/19. Base 854a376861bc034d65cc81ddfa6a85d0ae55821e; head b722f9a27a1815abcfb08e6f6ca09dc7317efa46. Review actual correctness, authenticated approval, rejection findings and test discrimination. Every unique production source, template, test, step and generator changed in PR5 is supplied across these packets. Byte-identical installed mirrors and compiled bundles are omitted; all five generated surfaces passed at this head. Prior historical acceptance failures remain visible; full current run is in progress. Exactly 33 cases are user-deferred and unverified. This is source review, not native-host or merge approval. Flag only concrete in-scope defects; optional hardening does not block.

diff --git a/steps/keep-plan-reviews-route-capability.steps.ts b/steps/keep-plan-reviews-route-capability.steps.ts
new file mode 100644
index 000000000..98af5df67
--- /dev/null
+++ b/steps/keep-plan-reviews-route-capability.steps.ts
@@ -0,0 +1,111 @@
+import { strict as assert } from 'node:assert';
+import { readFileSync, writeFileSync } from 'node:fs';
+import path from 'node:path';
+
+import { Given, Then, When } from '@cucumber/cucumber';
+
+import { reviewerScript } from '../packages/cli/tests/fixtures/planning-reviewers.js';
+import { coordinate, prepare } from './keep-plan-reviews-independence.steps.js';
+import type { SafewordWorld } from './world.js';
+
+type RouteState = Awaited<ReturnType<typeof prepare>> & { modelLog: string; unknown: boolean };
+const states = new WeakMap<SafewordWorld, RouteState>();
+
+Given(
+  /^the real review route registry and project configuration select (a reviewer model at least as capable as the verified author model|a reviewer model with unavailable, stale, or conflicting pair capability)$/,
+  { timeout: 120_000 },
+  async function (this: SafewordWorld, capability: string) {
+    const state = await prepare(this, true);
+    const modelLog = path.join(path.dirname(state.marker), 'requested-models');
+    const unknown = capability.includes('unavailable');
+    states.set(this, Object.assign(state, { modelLog, unknown }));
+    const configPath = path.join(state.root, '.safeword/config.json');
+    const config = JSON.parse(readFileSync(configPath, 'utf8'));
+    writeFileSync(
+      configPath,
+      JSON.stringify({
+        ...config,
+        crossAgentReviewRoutes: {
+          claude: [
+            ...(unknown ? [{ reviewer: 'codex', model: 'gpt-6.1-sol-unqualified' }] : []),
+            { reviewer: 'codex', model: 'gpt-6.1-sol' },
+          ],
+        },
+      }),
+    );
+    const script = reviewerScript(
+      'codex',
+      state.marker,
+      path.join(path.dirname(state.marker), 'packet.json'),
+      false,
+      true,
+    );
+    const launch = `writeFileSync(${JSON.stringify(state.marker)}, 'yes');`;
+    const launched = script.replace(
+      launch,
+      `${launch}\nrequire('node:fs').appendFileSync(${JSON.stringify(`${modelLog}.launches`)}, 'launch\\n');`,
+    );
+    assert.notEqual(launched, script);
+    const observed = launched.replace(
+      'if (message.id === 2) console.log',
+      `if (message.id === 2) require('node:fs').appendFileSync(${JSON.stringify(modelLog)}, message.params.model + '\\n');\n    if (message.id === 2) console.log`,
+    );
+    assert.notEqual(observed, launched);
+    writeFileSync(path.join(path.dirname(state.marker), 'codex'), observed, { mode: 0o755 });
+  },
+);
+
+When(
+  'the coordinator selects an independent route while mocking only the agent invocation',
+  { timeout: 120_000 },
+  async function (this: SafewordWorld) {
+    const state = states.get(this);
+    assert.ok(state);
+    await coordinate(state);
+  },
+);
+
+Then('that route is attempted as an independent review', function (this: SafewordWorld) {
+  const state = states.get(this);
+  assert.ok(state?.result);
+  assert.equal(readFileSync(`${state.modelLog}.launches`, 'utf8'), 'launch\n');
+  assert.deepEqual(readFileSync(state.modelLog, 'utf8').trim().split('\n'), ['gpt-6.1-sol']);
+  assert.equal(state.result.data.independence, 'cross-agent');
+  assert.deepEqual(state.result.data.review_routes, [
+    {
+      reviewer: 'codex',
+      model: 'gpt-6.1-sol',
+      independence: 'cross-agent',
+      status: 'attempted',
+    },
+  ]);
+});
+
+Then(
+  'that route is not attempted as independent and selection continues to the next permitted route',
+  function (this: SafewordWorld) {
+    const state = states.get(this);
+    assert.ok(state?.unknown && state.result);
+    assert.equal(
+      readFileSync(`${state.modelLog}.launches`, 'utf8'),
+      'launch\n',
+      'Unqualified route must not invoke the reviewer process',
+    );
+    assert.deepEqual(
+      readFileSync(state.modelLog, 'utf8').trim().split('\n'),
+      ['gpt-6.1-sol'],
+      'Unqualified route must not invoke the reviewer process',
+    );
+    assert.equal(state.result.data.independence, 'cross-agent');
+    assert.deepEqual(state.result.data.review_routes, [
+      {
+        reviewer: 'codex',
+        model: 'gpt-6.1-sol-unqualified',
+        independence: 'cross-agent',
+        status: 'skipped',
+        failure: 'reviewer_capability_unknown',
+      },
+      { reviewer: 'codex', model: 'gpt-6.1-sol', independence: 'cross-agent', status: 'attempted' },
+    ]);
+  },
+);
diff --git a/steps/keep-plan-reviews-route-denials.steps.ts b/steps/keep-plan-reviews-route-denials.steps.ts
new file mode 100644
index 000000000..cf48f5406
--- /dev/null
+++ b/steps/keep-plan-reviews-route-denials.steps.ts
@@ -0,0 +1,205 @@
+import { strict as assert } from 'node:assert';
+import { spawnSync } from 'node:child_process';
+import { existsSync, readFileSync, writeFileSync } from 'node:fs';
+import path from 'node:path';
+
+import { Given, Then } from '@cucumber/cucumber';
+
+import { installedReviewCli } from '../packages/cli/tests/fixtures/execution-review.js';
+import { reviewerScript } from '../packages/cli/tests/fixtures/planning-reviewers.js';
+import { coordinate, prepare } from './keep-plan-reviews-independence.steps.js';
+import type { SafewordWorld } from './world.js';
+
+const folder = '.project/tickets/CTX123-current-context';
+type DenialState = Awaited<ReturnType<typeof prepare>> & {
+  ledger: string;
+  beforeWriter: string;
+  validLedger: string;
+  fallbackMarker: string;
+};
+const states = new WeakMap<SafewordWorld, DenialState>();
+
+function stamp(state: DenialState) {
+  assert.ok(state.result);
+  return spawnSync(
+    'bun',
+    [
+      path.join(state.root, '.safeword/hooks/write-review-stamp.ts'),
+      '--ticket',
+      path.basename(folder),
+      '--phase',
+      'plan-implementation',
+      '--review-id',
+      state.result.data.review_id,
+      '--author-agent',
+      'claude',
+      '--reviewer-agent',
+      'codex',
+      '--independence',
+      'cross-agent',
+    ],
+    { cwd: state.root, env: { ...process.env, ...state.env }, encoding: 'utf8', timeout: 60_000 },
+  );
+}
+
+Given(
+  'the review coordinator has returned a typed no-independent-route-attempted result',
+  { timeout: 120_000 },
+  async function (this: SafewordWorld) {
+    const base = await prepare(this, true);
+    const state = Object.assign(base, {
+      ledger: path.join(base.root, '.project/skill-invocations.log'),
+      beforeWriter: '',
+      validLedger: '',
+      fallbackMarker: `${base.marker}-headless`,
+    });
+    states.set(this, state);
+    await coordinate(state);
+    const initialId = state.result?.data.review_id;
+    assert.ok(initialId);
+    const written = stamp(state);
+    assert.equal(written.status, 0, written.stdout + written.stderr);
+    const cli = installedReviewCli(state.root);
+    const allowed = await cli(
+      ['ticket', 'approve-plan', 'CTX123', '--json', '--no-input', '--cwd', state.root],
+      { cwd: state.root, env: state.env },
+    );
+    assert.equal(allowed.exitCode, 0, allowed.stdout);
+    const ticket = path.join(state.root, folder, 'ticket.md');
+    const advanced = readFileSync(ticket, 'utf8');
+    assert.match(advanced, /phase: plan-execution/u);
+    writeFileSync(ticket, advanced.replace('phase: plan-execution', 'phase: plan-implementation'));
+    state.evaluateGate = async () => {
+      const manifest = JSON.parse(
+        readFileSync(path.join(state.root, '.cursor/hooks.json'), 'utf8'),
+      );
+      const command = manifest.hooks.preToolUse.find(
+        (hook: { matcher: string }) => hook.matcher === 'Write',
+      ).command;
+      const result = spawnSync('/bin/sh', ['-c', command], {
+        cwd: state.root,
+        env: { ...process.env, ...state.env },
+        encoding: 'utf8',
+        timeout: 60_000,
+        input: JSON.stringify({
+          conversation_id: 'r6-route-denial',
+          workspace_roots: [state.root],
+          cwd: state.root,
+          tool_name: 'Write',
+          tool_input: {
+            file_path: ticket,
+            content: readFileSync(ticket, 'utf8').replace(
+              'phase: plan-implementation',
+              'phase: plan-execution',
+            ),
+          },
+        }),
+      });
+      assert.equal(result.error, undefined, result.error?.message);
+      assert.equal(result.status, 0, result.stderr);
+      return { exitCode: result.status, stdout: result.stdout, stderr: result.stderr };
+    };
+    const nativeAllowed = await state.evaluateGate();
+    assert.equal(JSON.parse(nativeAllowed.stdout).permission, 'allow', nativeAllowed.stdout);
+    {
+      const configPath = path.join(state.root, '.safeword/config.json');
+      const config = JSON.parse(readFileSync(configPath, 'utf8'));
+      writeFileSync(
+        configPath,
+        JSON.stringify({
+          ...config,
+          crossAgentReviewRoutes: {
+            claude: [{ reviewer: 'claude' }],
+          },
+        }),
+      );
+      writeFileSync(
+        path.join(path.dirname(state.marker), 'claude'),
+        reviewerScript(
+          'claude',
+          state.fallbackMarker,
+          `${state.fallbackMarker}.packet`,
+          false,
+          false,
+        ),
+        { mode: 0o755 },
+      );
+    }
+    const result = await cli(
+      [
+        'review',
+        'run',
+        'plan-implementation',
+        `${folder}/impl-plan.md`,
+        '--context',
+        'features/current-context.feature',
+        '--context',
+        `${folder}/spec.md`,
+        '--json',
+        '--no-input',
+        '--cwd',
+        state.root,
+      ],
+      { cwd: state.root, env: state.env },
+    );
+    state.result = JSON.parse(result.stdout);
+    assert.ok(state.result);
+    assert.equal(state.result.data.status, 'blocked', result.stdout);
+    assert.notEqual(state.result.data.review_id, initialId);
+    assert.equal(result.exitCode, 2, result.stdout);
+    const initialLedger = readFileSync(state.ledger, 'utf8');
+    state.validLedger = initialLedger;
+    assert.ok(initialLedger.includes(`review-id:${initialId}`));
+    // A plaintext locator is deliberately forged; the real receipt must still govern admission.
+    state.beforeWriter = initialLedger.replaceAll(initialId, state.result.data.review_id);
+    writeFileSync(state.ledger, state.beforeWriter);
+  },
+);
+
+Then(
+  'the phase remains blocked with reviewer-route reconciliation named',
+  { timeout: 120_000 },
+  async function (this: SafewordWorld) {
+    const state = states.get(this);
+    assert.ok(state?.result && state.gate);
+    assert.equal(state.gate.exitCode, 0, state.gate.stdout);
+    assert.equal(JSON.parse(state.gate.stdout).permission, 'deny');
+    assert.ok(state.gate.stdout.includes(state.result.data.review_id), state.gate.stdout);
+    assert.match(
+      readFileSync(path.join(state.root, folder, 'ticket.md'), 'utf8'),
+      /phase: plan-implementation/u,
+    );
+    const refused = stamp(state);
+    assert.equal(refused.status, 1, refused.stdout + refused.stderr);
+    assert.equal(readFileSync(state.ledger, 'utf8'), state.beforeWriter);
+    writeFileSync(state.ledger, `${state.beforeWriter}\n${state.validLedger}`);
+    assert.ok(state.evaluateGate);
+    const validAfterInvalid = await state.evaluateGate();
+    assert.equal(
+      JSON.parse(validAfterInvalid.stdout).permission,
+      'allow',
+      validAfterInvalid.stdout,
+    );
+    writeFileSync(state.ledger, state.beforeWriter);
+    const current = await installedReviewCli(state.root)(
+      ['review', 'status', state.result.data.review_id, '--json', '--cwd', state.root],
+      { cwd: state.root, env: state.env },
+    );
+    const receipt = JSON.parse(current.stdout).data;
+    assert.equal(receipt.review_id, state.result.data.review_id);
+    assert.equal(receipt.status, 'blocked', current.stdout);
+    {
+      assert.equal(receipt.independence, 'none');
+      assert.deepEqual(receipt.review_routes, [
+        { reviewer: 'claude', independence: 'degraded', status: 'unattempted' },
+      ]);
+      assert.ok(!existsSync(state.fallbackMarker), 'An unearned fallback must never launch');
+      assert.match(
+        JSON.parse(state.gate.stdout).user_message,
+        /Reviewer-route reconciliation is required before leaving "plan-implementation"/u,
+      );
+      assert.match(state.gate.stdout, /did not approve.*blocked/iu);
+      assert.match(refused.stdout, /did not approve.*blocked/iu);
+    }
+  },
+);
diff --git a/steps/keep-plan-reviews-scope-context.steps.ts b/steps/keep-plan-reviews-scope-context.steps.ts
new file mode 100644
index 000000000..936655667
--- /dev/null
+++ b/steps/keep-plan-reviews-scope-context.steps.ts
@@ -0,0 +1,68 @@
+import { strict as assert } from 'node:assert';
+import { rmSync } from 'node:fs';
+
+import { Given, Then, When } from '@cucumber/cucumber';
+
+import { createScopeContextProject } from './support/planning-scope-project.js';
+import {
+  assertPlanningEval,
+  runPlanningEval,
+  selectPlanningEval,
+} from './support/planning-eval.js';
+import type { SafewordWorld } from './world.js';
+
+const cases = {
+  'preserves every binding boundary in those supplied sources': 'r12-complete-scope-context',
+  'the supplied ticket context omits its positive scope': 'r12-missing-ticket-scope',
+  'the supplied ticket context omits its exclusions': 'r12-missing-ticket-exclusions',
+  'the supplied project context omits its non-goals': 'r12-missing-project-non-goals',
+  'the supplied milestone context omits its non-goals': 'r12-missing-milestone-non-goals',
+  'the supplied parent context omits its inherited boundary': 'r12-missing-parent-boundary',
+} as const;
+
+function capturedScopePacket(caseId: string) {
+  const roots: string[] = [];
+  try {
+    return createScopeContextProject(caseId, roots).input;
+  } finally {
+    for (const root of roots) rmSync(root, { recursive: true, force: true });
+  }
+}
+
+Given(
+  /^a child plan is bound by ticket scope, ticket exclusions, project non-goals, milestone non-goals, and inherited parent boundaries and its review packet includes every structurally required role and path but (.+)$/,
+  function (this: SafewordWorld, state: keyof typeof cases) {
+    const caseId = cases[state];
+    assert.ok(caseId, `Unknown scope context: ${state}`);
+    selectPlanningEval(this, caseId, capturedScopePacket(caseId));
+  },
+);
+
+When(
+  'a judged semantic reviewer evaluation applies the canonical accepted-boundary completeness rubric to the packet',
+  { timeout: 240_000 },
+  function (this: SafewordWorld) {
+    runPlanningEval(this);
+  },
+);
+
+Then(
+  'missing boundary context does not block review dispatch or approval',
+  function (this: SafewordWorld) {
+    assertPlanningEval(this, 'approve');
+  },
+);
+
+Then(
+  /^review cannot approve and names the (missing ticket scope|missing ticket boundary|missing project boundary|missing milestone boundary|unchecked inherited boundary)$/,
+  function (this: SafewordWorld, missing: string) {
+    const expected = {
+      'missing ticket scope': /(?=.*ticket)(?=.*scope)/isu,
+      'missing ticket boundary': /(?=.*ticket)(?=.*(?:exclu|boundar))/isu,
+      'missing project boundary': /(?=.*project)(?=.*(?:non.goal|boundar))/isu,
+      'missing milestone boundary': /(?=.*milestone)(?=.*(?:non.goal|boundar))/isu,
+      'unchecked inherited boundary': /(?:parent|inherited)/iu,
+    };
+    assertPlanningEval(this, 'request_changes', expected[missing as keyof typeof expected]);
+  },
+);
diff --git a/steps/keep-plan-reviews-scope-eval.steps.ts b/steps/keep-plan-reviews-scope-eval.steps.ts
new file mode 100644
index 000000000..d08310c23
--- /dev/null
+++ b/steps/keep-plan-reviews-scope-eval.steps.ts
@@ -0,0 +1,47 @@
+import { strict as assert } from 'node:assert';
+
+import { Given, Then, When } from '@cucumber/cucumber';
+
+import {
+  assertPlanningEval,
+  runPlanningEval,
+  selectPlanningEval,
+} from './support/planning-eval.js';
+import type { SafewordWorld } from './world.js';
+
+const cases = {
+  'omits authorization behavior': 'r13-in-scope-omission',
+  'includes automatic account migration': 'r13-out-of-scope-addition',
+  'decides authorization and excludes account migration': 'r13-conforming-boundary',
+} as const;
+
+Given(
+  /^an accepted boundary requires authorization and excludes automatic account migration and the plan (.+)$/,
+  function (this: SafewordWorld, planState: keyof typeof cases) {
+    const caseId = cases[planState];
+    assert.ok(caseId, `Unknown R13 plan state: ${planState}`);
+    const evaluationCase = selectPlanningEval(this, caseId);
+    assert.match(evaluationCase.accepted_boundary, /explicit user authorization/u);
+    assert.match(evaluationCase.accepted_boundary, /no automatic account migration/u);
+  },
+);
+
+When(
+  'a judged semantic reviewer evaluation applies the canonical bidirectional scope-completeness rubric to the plan',
+  { timeout: 240_000 },
+  function (this: SafewordWorld) {
+    runPlanningEval(this);
+  },
+);
+
+Then('approval is blocked with the in-scope omission named', function (this: SafewordWorld) {
+  assertPlanningEval(this, 'request_changes', /authoriz/iu);
+});
+
+Then('approval is blocked with the out-of-scope proposal named', function (this: SafewordWorld) {
+  assertPlanningEval(this, 'request_changes', /automatic.{0,20}migrat/iu);
+});
+
+Then('scope completeness does not block approval', function (this: SafewordWorld) {
+  assertPlanningEval(this, 'approve');
+});
diff --git a/steps/keep-plan-reviews-stale-gates.steps.ts b/steps/keep-plan-reviews-stale-gates.steps.ts
new file mode 100644
index 000000000..208ef4939
--- /dev/null
+++ b/steps/keep-plan-reviews-stale-gates.steps.ts
@@ -0,0 +1,629 @@
+import { strict as assert } from 'node:assert';
+import { spawnSync } from 'node:child_process';
+import {
+  closeSync,
+  constants,
+  existsSync,
+  mkdirSync,
+  openSync,
+  readFileSync,
+  rmSync,
+  writeFileSync,
+  writeSync,
+} from 'node:fs';
+import path from 'node:path';
+
+import { After, Given, Then, When } from '@cucumber/cucumber';
+
+import {
+  admitThroughInstalledCli,
+  featureFixture,
+  installedReviewCli,
+  installFailingReviewers,
+  installReviewer,
+} from '../packages/cli/tests/fixtures/execution-review.js';
+import { cleanupTrustedReviewerDirectories } from '../packages/cli/tests/review-fixtures.js';
+import { SAFEWORD_SCHEMA } from '../packages/cli/src/schema.js';
+import { fixtureProject } from './keep-plan-reviews-installed-context.steps.js';
+import type { SafewordWorld } from './world.js';
+
+const repository = path.resolve(import.meta.dirname, '..');
+const ticketFolder = 'ABC123-feature';
+const states = new WeakMap<SafewordWorld, StaleGateState>();
+
+interface StaleGateState {
+  root: string;
+  host: string;
+  output?: string;
+  pendingReviewId?: string;
+  fallbackReview?: {
+    review_id: string;
+    actual_reviewer: string;
+    independence: string;
+    review_routes: { status: string; failure?: string }[];
+  };
+}
+
+function environment(root: string): NodeJS.ProcessEnv {
+  return {
+    ...process.env,
+    XDG_STATE_HOME: path.join(root, '.review-keys'),
+    CLAUDE_PROJECT_DIR: root,
+    CLAUDE_PLUGIN_ROOT: path.join(repository, 'plugin'),
+    PLUGIN_ROOT: path.join(repository, 'packages/cli/codex-plugin'),
+    NODE_ENV: 'test',
+  };
+}
+
+function dispatch(state: StaleGateState): string {
+  const file = path.join(state.root, '.project/tickets', ticketFolder, 'ticket.md');
+  const edit = {
+    file_path: file,
+    old_string: 'phase: plan-implementation',
+    new_string: 'phase: plan-execution',
+  };
+  let command: string;
+  let input: Record<string, unknown>;
+  if (state.host === 'Cursor') {
+    const manifest = JSON.parse(readFileSync(path.join(state.root, '.cursor/hooks.json'), 'utf8'));
+    command = manifest.hooks.preToolUse.find(
+      (hook: { matcher: string }) => hook.matcher === 'Write',
+    ).command;
+    input = {
+      conversation_id: 'r9-stale',
+      workspace_roots: [state.root],
+      cwd: state.root,
+      tool_name: 'Write',
+      tool_input: {
+        file_path: file,
+        content: readFileSync(file, 'utf8').replace(edit.old_string, edit.new_string),
+      },
+    };
+  } else {
+    if (state.host === 'OpenAI Codex') {
+      const manifest = JSON.parse(
+        readFileSync(path.join(repository, 'packages/cli/codex-plugin/hooks.json'), 'utf8'),
+      );
+      command = manifest.hooks.PreToolUse[0].hooks[0].command;
+    } else {
+      assert.equal(
+        state.host,
+        'Claude Code',
+        'cloud and OpenCode need their own actual host evidence',
+      );
+      const manifest = JSON.parse(
+        readFileSync(path.join(state.root, '.claude/settings.json'), 'utf8'),
+      );
+      command = manifest.hooks.PreToolUse.flatMap(
+        (group: { hooks: { command: string }[] }) => group.hooks,
+      ).find((hook: { command: string }) => hook.command.includes('pre-tool-quality.ts')).command;
+    }
+    input = {
+      cwd: state.root,
+      session_id: 'r9-stale',
+      hook_event_name: 'PreToolUse',
+      tool_name: 'Edit',
+      tool_input: edit,
+    };
+  }
+  const result = spawnSync('/bin/sh', ['-c', command], {
+    cwd: state.root,
+    env: environment(state.root),
+    encoding: 'utf8',
+    timeout: 60_000,
+    input: JSON.stringify(input),
+  });
+  assert.equal(result.error, undefined, result.error?.message);
+  assert.equal(result.status, 0, result.stderr);
+  return result.stdout.trim();
+}
+
+async function prepareApprovedGate(this: SafewordWorld, host: string, invalidate: boolean) {
+  const root = featureFixture();
+  const state = { root, host };
+  states.set(this, state);
+  const owned = fixtureProject();
+  try {
+    for (const file of ['ticket.md', 'spec.md', 'impl-plan.md']) {
+      writeFileSync(
+        path.join(root, '.project/tickets', ticketFolder, file),
+        readFileSync(path.join(owned, '.project/tickets/CTX123-current-context', file), 'utf8')
+          .replaceAll('CTX123', 'ABC123')
+          .replaceAll('features/current-context.feature', 'features/feature.feature'),
+      );
+    }
+    writeFileSync(
+      path.join(root, 'features/feature.feature'),
+      readFileSync(path.join(owned, 'features/current-context.feature'), 'utf8'),
+    );
+  } finally {
+    rmSync(owned, { recursive: true, force: true });
+  }
+  const cli = installedReviewCli(root);
+  const installed = await cli(
+    ['install', '--agents', 'cursor', '--no-input', '--offline', '--json', '--cwd', root],
+    { cwd: root, env: { NODE_ENV: 'test' } },
+  );
+  assert.equal(installed.exitCode, 0, installed.stdout);
+  if (host === 'Claude Code') {
+    // Exercise the supported local-project delivery contract, without enrolling a user profile.
+    mkdirSync(path.join(root, '.claude'), { recursive: true });
+    const settings = SAFEWORD_SCHEMA.jsonMerges['.claude/settings.json'].merge({});
+    writeFileSync(path.join(root, '.claude/settings.json'), JSON.stringify(settings));
+  }
+  await admitThroughInstalledCli(cli, root, ['plan-implementation']);
+  const ledger = path.join(root, '.project/skill-invocations.log');
+  const rows = readFileSync(ledger, 'utf8').trim().split('\n');
+  writeFileSync(ledger, '');
+  // Earn the native ledger stamps through the real receipt-verifying writer.
+  for (const row of rows) {
+    const phase = /:phase@(\S+)/u.exec(row)?.[1];
+    const id = /review-id:(\S+)/u.exec(row)?.[1];
+    assert.ok(phase && id);
+    const stamped = spawnSync(
+      'bun',
+      [
+        path.join(root, '.safeword/hooks/write-review-stamp.ts'),
+        '--ticket',
+        ticketFolder,
+        '--phase',
+        phase,
+        '--review-id',
+        id,
+        '--author-agent',
+        'codex',
+        '--reviewer-agent',
+        'claude',
+        '--independence',
+        'reduced',
+      ],
+      {
+        cwd: root,
+        env: environment(root),
+        encoding: 'utf8',
+        timeout: 60_000,
+      },
+    );
+    assert.equal(stamped.status, 0, stamped.stdout + stamped.stderr);
+  }
+  const allowed = dispatch(state);
+  if (host === 'Cursor') assert.equal(JSON.parse(allowed).permission, 'allow', allowed);
+  else assert.equal(allowed, '', allowed);
+  if (!invalidate) return;
+  const scenarios = path.join(root, 'features/feature.feature');
+  const before = readFileSync(scenarios, 'utf8');
+  const changed = before.replace(
+    'Then the current context reaches review',
+    'Then changed acceptance reaches review',
+  );
+  assert.notEqual(changed, before);
+  writeFileSync(scenarios, changed);
+  const id = /review-id:(\S+)/u.exec(rows[0])?.[1];
+  assert.ok(id);
+  const status = await cli(['review', 'status', id, '--json'], {
+    cwd: root,
+    env: { NODE_ENV: 'test' },
+  });
+  assert.equal(status.exitCode, 2, status.stdout);
+  const stale = JSON.parse(status.stdout);
+  assert.deepEqual(stale.errors, []);
+  assert.equal(stale.data.status, 'stale', status.stdout);
+  assert.ok(stale.findings.some((finding: { code: string }) => finding.code === 'REVIEW_STALE'));
+}
+
+Given(
+  /^a planning phase on (Claude Code|OpenAI Codex|Cursor) has an approving receipt invalidated by a changed accepted scenario$/,
+  { timeout: 120_000 },
+  async function (this: SafewordWorld, host: string) {
+    await prepareApprovedGate.call(this, host, true);
+  },
+);
+
+Given(
+  /^a planning phase on (Claude Code|OpenAI Codex|Cursor) through (installed local project hooks|installed Codex hooks|installed Cursor hooks) has a current approving receipt$/,
+  { timeout: 120_000 },
+  async function (this: SafewordWorld, host: string, boundary: string) {
+    assert.equal(
+      boundary,
+      {
+        'Claude Code': 'installed local project hooks',
+        'OpenAI Codex': 'installed Codex hooks',
+        Cursor: 'installed Cursor hooks',
+      }[host],
+    );
+    await prepareApprovedGate.call(this, host, false);
+  },
+);
+
+async function preparePendingGate(this: SafewordWorld, host: string) {
+  await prepareApprovedGate.call(this, host, false);
+  const state = states.get(this);
+  assert.ok(state);
+  const bin = installReviewer(path.join(state.root, 'reviewer-hold'));
+  const reviewed = await installedReviewCli(state.root)(
+    [
+      'review',
+      'run',
+      'plan-implementation',
+      `.project/tickets/${ticketFolder}/impl-plan.md`,
+      '--context',
+      'features/feature.feature',
+      '--context',
+      `.project/tickets/${ticketFolder}/spec.md`,
+      '--json',
+      '--no-input',
+      '--cwd',
+      state.root,
+    ],
+    {
+      cwd: state.root,
+      env: {
+        NODE_ENV: 'test',
+        PATH: `${bin}:/usr/bin:/bin`,
+        SAFEWORD_AGENT_RUNTIME: 'codex',
+        SAFEWORD_REVIEW_KEY_ROOT: path.join(state.root, '.review-keys'),
+        SAFEWORD_NO_UPDATE_CHECK: '1',
+        SAFEWORD_REVIEW_FOREGROUND_MS: '0',
+        SAFEWORD_REVIEW_TIMEOUT_MS: '30000',
+        SAFEWORD_REVIEW_RUN_BOUND_MS: '60000',
+      },
+    },
+  );
+  const result = JSON.parse(reviewed.stdout);
+  state.pendingReviewId = result.data.review_id;
+  assert.ok(state.pendingReviewId, reviewed.stdout);
+  assert.equal(result.data.status, 'pending', reviewed.stdout);
+  const deadline = Date.now() + 10_000;
+  while (!existsSync(path.join(state.root, 'reviewer-hold')) && Date.now() < deadline) {
+    await new Promise(resolve => setTimeout(resolve, 50));
+  }
+  assert.ok(
+    existsSync(path.join(state.root, 'reviewer-hold')),
+    'The reviewer must actually start and remain pending',
+  );
+  // The ledger only locates a job. Its pending authenticated result must never authorize a gate.
+  const ledger = path.join(state.root, '.project/skill-invocations.log');
+  const approved = readFileSync(ledger, 'utf8');
+  assert.match(approved, /review-id:\S+/u);
+  writeFileSync(ledger, approved.replace(/review-id:\S+/gu, `review-id:${state.pendingReviewId}`));
+}
+
+Given(
+  /^a planning phase on (Claude Code|OpenAI Codex|Cursor) through (installed local project hooks|installed Codex hooks|installed Cursor hooks) has a pending review$/,
+  { timeout: 120_000 },
+  async function (this: SafewordWorld, host: string, boundary: string) {
+    assert.equal(
+      boundary,
+      {
+        'Claude Code': 'installed local project hooks',
+        'OpenAI Codex': 'installed Codex hooks',
+        Cursor: 'installed Cursor hooks',
+      }[host],
+    );
+    await preparePendingGate.call(this, host);
+  },
+);
+
+Given(
+  'the review coordinator has returned a pending review',
+  { timeout: 120_000 },
+  async function (this: SafewordWorld) {
+    await preparePendingGate.call(this, 'Cursor');
+  },
+);
+
+Given(
+  /^a planning phase on (Claude Code|OpenAI Codex|Cursor) through (installed local project hooks|installed Codex hooks|installed Cursor hooks) has a permitted fallback approval after every configured independent route was attempted and returned a typed failure$/,
+  { timeout: 120_000 },
+  async function (this: SafewordWorld, host: string, boundary: string) {
+    assert.equal(
+      boundary,
+      {
+        'Claude Code': 'installed local project hooks',
+        'OpenAI Codex': 'installed Codex hooks',
+        Cursor: 'installed Cursor hooks',
+      }[host],
+    );
+    await prepareApprovedGate.call(this, host, false);
+    const state = states.get(this);
+    assert.ok(state);
+    const author = host === 'Claude Code' ? 'claude' : host === 'Cursor' ? 'cursor' : 'codex';
+    const configPath = path.join(state.root, '.safeword/config.json');
+    const config = JSON.parse(readFileSync(configPath, 'utf8'));
+    writeFileSync(
+      configPath,
+      JSON.stringify({
+        ...config,
+        crossAgentReviewRoutes: {
+          [author]: [{ reviewer: author === 'codex' ? 'claude' : 'codex' }],
+        },
+      }),
+    );
+    const target = `.project/tickets/${ticketFolder}/impl-plan.md`;
+    const planPath = path.join(state.root, target);
+    const before = readFileSync(planPath, 'utf8');
+    const changed = before.replace(
+      '## Approach\n',
+      '## Approach\n\nPreserve authenticated review when independent routes fail.\n',
+    );
+    assert.notEqual(changed, before);
+    writeFileSync(planPath, changed);
+    const cli = installedReviewCli(state.root);
+    const env = {
+      NODE_ENV: 'test',
+      PATH: `${installFailingReviewers()}:/usr/bin:/bin`,
+      SAFEWORD_AGENT_RUNTIME: author,
+      SAFEWORD_NO_UPDATE_CHECK: '1',
+      SAFEWORD_REVIEW_KEY_ROOT: path.join(state.root, '.review-keys'),
+      SAFEWORD_REVIEW_TIMEOUT_MS: '3000',
+      SAFEWORD_REVIEW_RUN_BOUND_MS: '10000',
+    };
+    const exhausted = await cli(
+      [
+        'review',
+        'run',
+        'plan-implementation',
+        target,
+        '--context',
+        'features/feature.feature',
+        '--context',
+        `.project/tickets/${ticketFolder}/spec.md`,
+        '--json',
+        '--no-input',
+        '--cwd',
+        state.root,
+      ],
+      { cwd: state.root, env },
+    );
+    const pending = JSON.parse(exhausted.stdout);
+    assert.equal(pending.data.status, 'continuation_required', exhausted.stdout);
+    assert.equal(pending.data.continuation.tier, 'fresh-context');
+    assert.ok(pending.data.review_routes.length > 0);
+    for (const route of pending.data.review_routes) {
+      assert.equal(route.status, 'attempted', exhausted.stdout);
+      assert.equal(typeof route.failure, 'string', exhausted.stdout);
+    }
+    writeFileSync(
+      path.join(state.root, 'fallback-review.json'),
+      JSON.stringify({
+        schema_version: 1,
+        dispatch_id: pending.data.continuation.packet.dispatch_id,
+        reviewer_agent: author,
+        verdict: 'approve',
+        summary: 'Current plan approved in a fresh host context.',
+        findings: [],
+        evidence_records: { schema_version: 1, records: [] },
+      }),
+    );
+    const continued = await cli(
+      [
+        'review',
+        'continue',
+        pending.data.review_id,
+        '--tier',
+        'fresh-context',
+        '--output',
+        'fallback-review.json',
+        '--offline',
+        '--json',
+        '--no-input',
+        '--cwd',
+        state.root,
+      ],
+      { cwd: state.root, env },
+    );
+    assert.equal(continued.exitCode, 0, continued.stdout);
+    const result = JSON.parse(continued.stdout);
+    assert.equal(result.data.status, 'approved', continued.stdout);
+    assert.equal(result.data.actual_reviewer, author);
+    assert.equal(result.data.independence, 'reduced');
+    assert.ok(
+      !result.findings.some(
+        (finding: { code: string }) => finding.code === 'REVIEW_INDEPENDENCE_DEGRADED',
+      ),
+    );
+    state.fallbackReview = result.data;
+    const denied = JSON.parse(dispatch(state));
+    if (host === 'Cursor') assert.equal(denied.permission, 'deny');
+    else assert.equal(denied.hookSpecificOutput.permissionDecision, 'deny');
+    const stampEnv = {
+      ...environment(state.root),
+      ...env,
+      PATH: process.env.PATH,
+      CLAUDE_SESSION_ID: author === 'claude' ? `r6-${path.basename(state.root)}` : undefined,
+      CLAUDE_CODE_SESSION_ID: undefined,
+      CODEX_THREAD_ID: author === 'codex' ? `r6-${path.basename(state.root)}` : undefined,
+    };
+    if (host === 'Cursor') {
+      const bridge = spawnSync('bun', ['.safeword/hooks/cursor/before-shell-execution.ts'], {
+        cwd: state.root,
+        env: stampEnv,
+        encoding: 'utf8',
+        timeout: 60_000,
+        input: JSON.stringify({
+          workspace_roots: [state.root],
+          conversation_id: `r6-${path.basename(state.root)}`,
+          command: `bun "${state.root}/.safeword/hooks/write-review-stamp.ts" --phase plan-implementation`,
+        }),
+      });
+      assert.equal(bridge.error, undefined, bridge.error?.message);
+      assert.equal(bridge.status, 0, bridge.stderr);
+      assert.equal(JSON.parse(bridge.stdout).permission, 'allow', bridge.stdout);
+    }
+    const stamped = spawnSync(
+      'bun',
+      [
+        path.join(state.root, '.safeword/hooks/write-review-stamp.ts'),
+        '--ticket',
+        ticketFolder,
+        '--phase',
+        'plan-implementation',
+        '--review-id',
+        pending.data.review_id,
+        '--author-agent',
+        author,
+        '--reviewer-agent',
+        author,
+        '--independence',
+        'reduced',
+      ],
+      {
+        cwd: state.root,
+        env: stampEnv,
+        encoding: 'utf8',
+        timeout: 60_000,
+      },
+    );
+    assert.equal(stamped.error, undefined, stamped.error?.message);
+    assert.equal(stamped.status, 0, stamped.stdout + stamped.stderr);
+  },
+);
+
+export function evaluateInstalledPhaseGate(world: SafewordWorld): boolean {
+  const state = states.get(world);
+  if (!state) return false;
+  state.output = dispatch(state);
+  world.nativePlanningGate = { host: state.host, output: state.output };
+  return true;
+}
+
+When(
+  /^actual lifecycle dispatch through (installed local project hooks|installed Codex hooks|installed Cursor hooks) evaluates the phase transition with real configuration and collaborators, mocking only the reviewer process boundary$/,
+  function (this: SafewordWorld, boundary: string) {
+    const state = states.get(this);
+    assert.ok(state);
+    assert.equal(
+      boundary,
+      {
+        'Claude Code': 'installed local project hooks',
+        'OpenAI Codex': 'installed Codex hooks',
+        Cursor: 'installed Cursor hooks',
+      }[state.host],
+    );
+    assert.ok(evaluateInstalledPhaseGate(this));
+  },
+);
+
+Then('the phase remains blocked with re-review named', function (this: SafewordWorld) {
+  const state = states.get(this);
+  assert.ok(state?.output);
+  const result = JSON.parse(state.output);
+  if (state.host === 'Cursor') assert.equal(result.permission, 'deny');
+  else assert.equal(result.hookSpecificOutput.permissionDecision, 'deny');
+  assert.match(state.output, /plan-implementation/u);
+  assert.match(state.output, /review run plan-implementation|fork review of the phase is logged/u);
+});
+
+Then('the phase remains blocked', { timeout: 60_000 }, async function (this: SafewordWorld) {
+  const state = states.get(this);
+  assert.ok(state?.pendingReviewId && state.output);
+  const result = JSON.parse(state.output);
+  if (state.host === 'Cursor') assert.equal(result.permission, 'deny');
+  else assert.equal(result.hookSpecificOutput.permissionDecision, 'deny');
+  assert.match(state.output, /plan-implementation/u);
+  const cli = installedReviewCli(state.root);
+  const status = await cli(['review', 'status', state.pendingReviewId, '--json'], {
+    cwd: state.root,
+    env: { NODE_ENV: 'test' },
+  });
+  assert.equal(JSON.parse(status.stdout).data.status, 'pending', status.stdout);
+  const ledger = path.join(state.root, '.project/skill-invocations.log');
+  const pendingLedger = readFileSync(ledger, 'utf8');
+  const stampArguments = [
+    path.join(state.root, '.safeword/hooks/write-review-stamp.ts'),
+    '--ticket',
+    ticketFolder,
+    '--phase',
+    'plan-implementation',
+    '--review-id',
+    state.pendingReviewId,
+    '--author-agent',
+    'codex',
+    '--reviewer-agent',
+    'claude',
+    '--independence',
+    'reduced',
+  ];
+  const stampOptions = {
+    cwd: state.root,
+    env: environment(state.root),
+    encoding: 'utf8' as const,
+    timeout: 60_000,
+  };
+  const refused = spawnSync('bun', stampArguments, stampOptions);
+  assert.equal(refused.error, undefined, refused.error?.message);
+  assert.notEqual(refused.status, 0);
+  assert.match(refused.stdout + refused.stderr, /did not approve \(status: pending\)/u);
+  assert.equal(readFileSync(ledger, 'utf8'), pendingLedger);
+  // Complete this exact job, changing no stamp or reviewed source. The same
+  // native gate must now allow, distinguishing pending denial from a bad stamp.
+  const hold = openSync(
+    path.join(state.root, 'reviewer-hold'),
+    constants.O_WRONLY | constants.O_NONBLOCK,
+  );
+  try {
+    writeSync(hold, 'complete\n');
+  } finally {
+    closeSync(hold);
+  }
+  const deadline = Date.now() + 15_000;
+  let completed;
+  do {
+    completed = await cli(['review', 'status', state.pendingReviewId, '--json'], {
+      cwd: state.root,
+      env: { NODE_ENV: 'test' },
+    });
+    if (JSON.parse(completed.stdout).data.status !== 'pending') break;
+    await new Promise(resolve => setTimeout(resolve, 50));
+  } while (Date.now() < deadline);
+  assert.equal(JSON.parse(completed.stdout).data.status, 'approved', completed.stdout);
+  assert.equal(readFileSync(ledger, 'utf8'), pendingLedger);
+  const allowed = dispatch(state);
+  if (state.host === 'Cursor') assert.equal(JSON.parse(allowed).permission, 'allow', allowed);
+  else assert.equal(allowed, '', allowed);
+  const stamped = spawnSync('bun', stampArguments, stampOptions);
+  assert.equal(stamped.error, undefined, stamped.error?.message);
+  assert.equal(stamped.status, 0, stamped.stdout + stamped.stderr);
+  state.pendingReviewId = undefined;
+});
+
+Then(
+  'the phase transition proceeds with reduced independence and the actual reviewer recorded without calling the capability degraded',
+  function (this: SafewordWorld) {
+    const state = states.get(this);
+    assert.ok(state?.fallbackReview && state.output !== undefined);
+    assert.equal(state.fallbackReview.independence, 'reduced');
+    assert.equal(
+      state.fallbackReview.actual_reviewer,
+      state.host === 'Claude Code' ? 'claude' : state.host === 'Cursor' ? 'cursor' : 'codex',
+    );
+    const stamp = readFileSync(path.join(state.root, '.project/skill-invocations.log'), 'utf8')
+      .split('\n')
+      .find(row => row.includes(`review-id:${state.fallbackReview?.review_id}`));
+    assert.ok(stamp);
+    assert.ok(stamp.includes(`reviewer:${state.fallbackReview.actual_reviewer}`));
+    assert.match(stamp, /independence:reduced/u);
+    assert.doesNotMatch(state.output, /degrad/iu);
+    if (state.host === 'Cursor')
+      assert.equal(JSON.parse(state.output).permission, 'allow', state.output);
+    else assert.equal(state.output, '', state.output);
+  },
+);
+
+After(async function (this: SafewordWorld) {
+  const state = states.get(this);
+  try {
+    if (!state) return;
+    if (state.pendingReviewId) {
+      const cancelled = await installedReviewCli(state.root)(
+        ['review', 'cancel', state.pendingReviewId, '--json'],
+        { cwd: state.root, env: { NODE_ENV: 'test' } },
+      );
+      assert.equal(JSON.parse(cancelled.stdout).data.status, 'canceled', cancelled.stdout);
+    }
+  } finally {
+    if (state) rmSync(state.root, { recursive: true, force: true });
+    cleanupTrustedReviewerDirectories();
+    states.delete(this);
+  }
+});
diff --git a/steps/keep-plan-reviews-ungated-origin.steps.ts b/steps/keep-plan-reviews-ungated-origin.steps.ts
new file mode 100644
index 000000000..3f6600b55
--- /dev/null
+++ b/steps/keep-plan-reviews-ungated-origin.steps.ts
@@ -0,0 +1,119 @@
+import { strict as assert } from 'node:assert';
+import { readFileSync, writeFileSync } from 'node:fs';
+import path from 'node:path';
+
+import { Given, Then } from '@cucumber/cucumber';
+
+import { installedReviewCli } from '../packages/cli/tests/fixtures/execution-review.js';
+import { reviewerScript } from '../packages/cli/tests/fixtures/planning-reviewers.js';
+import { coordinate, prepare } from './keep-plan-reviews-independence.steps.js';
+import type { SafewordWorld } from './world.js';
+
+type OriginState = Awaited<ReturnType<typeof prepare>> & {
+  refusal: { errors: { code: string; message: string }[] };
+  ticketBefore: string;
+};
+const states = new WeakMap<SafewordWorld, OriginState>();
+const ticket = '.project/tickets/CTX123-current-context/ticket.md';
+
+Given(
+  'the review coordinator has returned an approval submitted from an ungated surface',
+  { timeout: 120_000 },
+  async function (this: SafewordWorld) {
+    const state = await prepare(this, true);
+    writeFileSync(
+      path.join(path.dirname(state.marker), 'codex'),
+      reviewerScript('codex', state.marker, `${state.marker}.packet`, true, true),
+      { mode: 0o755 },
+    );
+    await coordinate(state, 'codex', 'continuation_required');
+    assert.ok(state.result?.data.continuation);
+    const continuation = state.result.data.continuation;
+    assert.equal(continuation.tier, 'fresh-context');
+    writeFileSync(
+      path.join(state.root, 'ungated-approval.json'),
+      JSON.stringify({
+        schema_version: 1,
+        dispatch_id: continuation.packet.dispatch_id,
+        reviewer_agent: 'claude',
+        verdict: 'approve',
+        summary: 'Approve the current bounded plan.',
+        findings: [],
+        evidence_records: { schema_version: 1, records: [] },
+      }),
+    );
+    const before = readFileSync(path.join(state.root, ticket), 'utf8');
+    const rejected = await installedReviewCli(state.root)(
+      [
+        'review',
+        'continue',
+        state.result.data.review_id,
+        '--tier',
+        'fresh-context',
+        '--output',
+        'ungated-approval.json',
+        '--json',
+        '--cwd',
+        state.root,
+      ],
+      {
+        cwd: state.root,
+        // No supported local origin. Only this child's host identity is absent;
+        // the sealed job and supplied output are genuine public-flow fixtures.
+        env: {
+          ...state.env,
+          SAFEWORD_AGENT_RUNTIME: 'unknown',
+          CLAUDE_SESSION_ID: '',
+          CLAUDE_CODE_SESSION_ID: '',
+          CODEX_THREAD_ID: '',
+        },
+      },
+    );
+    assert.equal(rejected.exitCode, 1, rejected.stdout);
+    const refusal = JSON.parse(rejected.stdout);
+    assert.deepEqual(
+      refusal.errors.map((error: { code: string }) => error.code),
+      ['REVIEW_CONTINUATION_ORIGIN_UNVERIFIED'],
+    );
+    states.set(this, Object.assign(state, { refusal, ticketBefore: before }));
+  },
+);
+
+Then(
+  'the phase remains blocked and the unsupported approval origin is named',
+  { timeout: 60_000 },
+  async function (this: SafewordWorld) {
+    const state = states.get(this);
+    assert.ok(state?.result && state.gate);
+    assert.equal(state.gate.exitCode, 2, state.gate.stdout);
+    assert.match(state.refusal.errors[0]!.message, /supported local agent origin/u);
+    assert.equal(readFileSync(path.join(state.root, ticket), 'utf8'), state.ticketBefore);
+    const cli = installedReviewCli(state.root);
+    const current = await cli(
+      ['review', 'status', state.result.data.review_id, '--json', '--cwd', state.root],
+      { cwd: state.root, env: state.env },
+    );
+    assert.equal(JSON.parse(current.stdout).data.status, 'continuation_required');
+    // Positive control: the same output and sealed job are valid from the
+    // supported author origin. Refusing all continuations cannot pass this test.
+    const accepted = await cli(
+      [
+        'review',
+        'continue',
+        state.result.data.review_id,
+        '--tier',
+        'fresh-context',
+        '--output',
+        'ungated-approval.json',
+        '--json',
+        '--cwd',
+        state.root,
+      ],
+      { cwd: state.root, env: state.env },
+    );
+    assert.equal(accepted.exitCode, 0, accepted.stdout);
+    assert.equal(JSON.parse(accepted.stdout).data.status, 'approved');
+    assert.equal(readFileSync(path.join(state.root, ticket), 'utf8'), state.ticketBefore);
+    states.delete(this);
+  },
+);
diff --git a/steps/plan-implementation-phase.steps.ts b/steps/plan-implementation-phase.steps.ts
index b62ac024a..2368250c1 100644
--- a/steps/plan-implementation-phase.steps.ts
+++ b/steps/plan-implementation-phase.steps.ts
@@ -440,7 +440,11 @@ function runPreTool(
 ): HookVerdict {
   const stdout = execFileSync('bun', [PRE_TOOL_HOOK], {
     cwd: PROJECT_ROOT,
-    env: { ...process.env, CLAUDE_PROJECT_DIR: world.projectDirectory },
+    env: {
+      ...process.env,
+      CLAUDE_PROJECT_DIR: world.projectDirectory,
+      SAFEWORD_PLUGIN_CLI: nodePath.join(CODEX_PLUGIN_ROOT, 'runtime', 'cli.js'),
+    },
     input: JSON.stringify({ session_id: sessionId, tool_name: toolName, tool_input: toolInput }),
     encoding: 'utf8',
   });
@@ -507,6 +511,7 @@ function arrangeRepairReviewer(world: PlanWorld, plan: string): void {
   writeFileSync(
     reviewer,
     `#!/bin/sh
+if [ "${'$'}{1:-}" = "--version" ]; then echo 'claude 1.0.0'; exit 0; fi
 if printf '%s' "$*" | /usr/bin/grep -q -- '--help'; then
   echo '${REVIEWER_CAPABILITIES.claude}'
   exit 0
@@ -514,13 +519,13 @@ fi
 payload=$(/bin/cat)
 dispatch_id=$(printf '%s' "$payload" | /usr/bin/sed -n 's/.*"dispatch_id":"\\([^"]*\\)".*/\\1/p')
 if printf '%s' "$payload" | /usr/bin/grep -q 'REPAIR_COMPLETE'; then
-  printf '{"schema_version":1,"dispatch_id":"%s","reviewer_agent":"claude","verdict":"approve","summary":"Current exact bytes are complete.","findings":[]}\\n' "$dispatch_id"
+  printf '{"schema_version":1,"dispatch_id":"%s","reviewer_agent":"claude","verdict":"approve","summary":"Current exact bytes are complete.","findings":[],"evidence_records":{"schema_version":1,"records":[]}}\\n' "$dispatch_id"
 elif printf '%s' "$payload" | /usr/bin/grep -q 'REPAIR_EXTERNAL'; then
-  printf '{"schema_version":1,"dispatch_id":"%s","reviewer_agent":"claude","verdict":"request_changes","summary":"Plan is waiting on its behavior owner.","findings":[{"severity":"error","message":"Pending user decision: choose deny-by-default or cached access. Deny-by-default prevents exposure but reduces availability; cached access preserves availability but can serve stale authority. Resume: ask the user to choose one outcome, record it, then re-run plan review."}]}\\n' "$dispatch_id"
+  printf '{"schema_version":1,"dispatch_id":"%s","reviewer_agent":"claude","verdict":"request_changes","summary":"Plan is waiting on its behavior owner.","findings":[{"severity":"error","message":"Pending user decision: choose deny-by-default or cached access. Deny-by-default prevents exposure but reduces availability; cached access preserves availability but can serve stale authority. Resume: ask the user to choose one outcome, record it, then re-run plan review."}],"evidence_records":{"schema_version":1,"records":[]}}\\n' "$dispatch_id"
 elif printf '%s' "$payload" | /usr/bin/grep -q 'REPAIR_AUTH_MISSING'; then
-  printf '{"schema_version":1,"dispatch_id":"%s","reviewer_agent":"claude","verdict":"request_changes","summary":"Authorization remains unresolved.","findings":[{"severity":"error","message":"Authorization boundary is still missing; return to repair and decide where every request is checked."}]}\\n' "$dispatch_id"
+  printf '{"schema_version":1,"dispatch_id":"%s","reviewer_agent":"claude","verdict":"request_changes","summary":"Authorization remains unresolved.","findings":[{"severity":"error","message":"Authorization boundary is still missing; return to repair and decide where every request is checked."}],"evidence_records":{"schema_version":1,"records":[]}}\\n' "$dispatch_id"
 else
-  printf '{"schema_version":1,"dispatch_id":"%s","reviewer_agent":"claude","verdict":"request_changes","summary":"Three current design defects block approval.","findings":[{"severity":"error","message":"Authorization boundary is missing."},{"severity":"error","message":"Persisted resource owner conflicts with its policy-service source of truth."},{"severity":"error","message":"Rollback behavior is undecided."}]}\\n' "$dispatch_id"
+  printf '{"schema_version":1,"dispatch_id":"%s","reviewer_agent":"claude","verdict":"request_changes","summary":"Three current design defects block approval.","findings":[{"severity":"error","message":"Authorization boundary is missing."},{"severity":"error","message":"Persisted resource owner conflicts with its policy-service source of truth."},{"severity":"error","message":"Rollback behavior is undecided."}],"evidence_records":{"schema_version":1,"records":[]}}\\n' "$dispatch_id"
 fi
 `,
   );
@@ -588,7 +593,7 @@ function arrangeArchitectureReceipt(world: PlanWorld): void {
   const reviewer = nodePath.join(world.reviewerBinDirectory, 'claude');
   writeFileSync(
     reviewer,
-    `#!/bin/sh\nif printf '%s' "$*" | /usr/bin/grep -q -- '--help'; then\n  echo '${REVIEWER_CAPABILITIES.claude}'\n  exit 0\nfi\npayload=$(/bin/cat)\ndispatch_id=$(printf '%s' "$payload" | /usr/bin/sed -n 's/.*"dispatch_id":"\\([^"]*\\)".*/\\1/p')\nprintf '{"schema_version":1,"dispatch_id":"%s","reviewer_agent":"claude","verdict":"request_changes","summary":"The architecture decision needs attention.","findings":[{"severity":"error","message":"The shared-contract choice needs a resolvable durable architecture record; impl-plan.md has no configured architecture link."}]}\\n' "$dispatch_id"\n`,
+    `#!/bin/sh\nif [ "${'$'}{1:-}" = "--version" ]; then echo 'claude 1.0.0'; exit 0; fi\nif printf '%s' "$*" | /usr/bin/grep -q -- '--help'; then\n  echo '${REVIEWER_CAPABILITIES.claude}'\n  exit 0\nfi\npayload=$(/bin/cat)\ndispatch_id=$(printf '%s' "$payload" | /usr/bin/sed -n 's/.*"dispatch_id":"\\([^"]*\\)".*/\\1/p')\nprintf '{"schema_version":1,"dispatch_id":"%s","reviewer_agent":"claude","verdict":"request_changes","summary":"The architecture decision needs attention.","findings":[{"severity":"error","message":"The shared-contract choice needs a resolvable durable architecture record; impl-plan.md has no configured architecture link."}],"evidence_records":{"schema_version":1,"records":[]}}\\n' "$dispatch_id"\n`,
   );
   chmodSync(reviewer, 0o755);
 }
@@ -600,7 +605,11 @@ function assertInstalledPlanGateIsLive(world: PlanWorld): void {
     [world.installedCliPath, 'hook', 'codex', 'pre-tool-use', '--plugin-hook'],
     {
       cwd: world.projectDirectory,
-      env: { ...process.env, CLAUDE_PROJECT_DIR: world.projectDirectory },
+      env: {
+        ...process.env,
+        CLAUDE_PROJECT_DIR: world.projectDirectory,
+        SAFEWORD_PLUGIN_CLI: world.installedCliPath,
+      },
       input: JSON.stringify({
         hook_event_name: 'PreToolUse',
         session_id: SESSION_ID,
@@ -896,7 +905,7 @@ Given(
     const reviewer = nodePath.join(this.reviewerBinDirectory, 'claude');
     writeFileSync(
       reviewer,
-      `#!/bin/sh\nif printf '%s' "$*" | /usr/bin/grep -q -- '--help'; then\n  echo '${REVIEWER_CAPABILITIES.claude}'\n  exit 0\nfi\nprintf 'invoked\\n' >> "$SAFEWORD_REVIEW_LAUNCH_LOG"\npayload=$(/bin/cat)\ndispatch_id=$(printf '%s' "$payload" | /usr/bin/sed -n 's/.*"dispatch_id":"\\([^"]*\\)".*/\\1/p')\nprintf '{"schema_version":1,"dispatch_id":"%s","reviewer_agent":"claude","verdict":"approve","summary":"The plan is otherwise reviewable.","findings":[]}\\n' "$dispatch_id"\n`,
+      `#!/bin/sh\nif [ "${'$'}{1:-}" = "--version" ]; then echo 'claude 1.0.0'; exit 0; fi\nif printf '%s' "$*" | /usr/bin/grep -q -- '--help'; then\n  echo '${REVIEWER_CAPABILITIES.claude}'\n  exit 0\nfi\nprintf 'invoked\\n' >> "$SAFEWORD_REVIEW_LAUNCH_LOG"\npayload=$(/bin/cat)\ndispatch_id=$(printf '%s' "$payload" | /usr/bin/sed -n 's/.*"dispatch_id":"\\([^"]*\\)".*/\\1/p')\nprintf '{"schema_version":1,"dispatch_id":"%s","reviewer_agent":"claude","verdict":"approve","summary":"The plan is otherwise reviewable.","findings":[],"evidence_records":{"schema_version":1,"records":[]}}\\n' "$dispatch_id"\n`,
     );
     chmodSync(reviewer, 0o755);
   },
diff --git a/steps/planning-contract-shape.steps.ts b/steps/planning-contract-shape.steps.ts
new file mode 100644
index 000000000..1599a2d90
--- /dev/null
+++ b/steps/planning-contract-shape.steps.ts
@@ -0,0 +1,104 @@
+import { strict as assert } from 'node:assert';
+
+import { Given, Then, When } from '@cucumber/cucumber';
+
+import { PLANNING_CONTRACTS } from '../packages/cli/src/planning/contracts.generated.js';
+import {
+  assertPlanningEval,
+  runPlanningEval,
+  selectedPlanningEval,
+  selectPlanningEval,
+} from './support/planning-eval.js';
+import type { SafewordWorld } from './world.js';
+
+const phases = {
+  'Product Plan/spec': {
+    phase: 'product-plan',
+    claim: 'the right complete behavior for accepted personas',
+    meaning:
+      /behavior is ready for scenario definition.*not scenario acceptance, design approval, startable delivery, or completion/iu,
+  },
+  'Implementation Plan': {
+    phase: 'plan-implementation',
+    claim: 'the accepted coherent implementation design',
+    meaning:
+      /approach is ready for Execution Planning.*does not approve delivery sequencing, coding, verification, merge, or deployment/iu,
+  },
+  'Execution Plan': {
+    phase: 'plan-execution',
+    claim: 'startable and provable delivery of the accepted design',
+    meaning:
+      /authorizes its bounded coding work when the configured authority permits it.*does not establish implementation, verification, merge, promotion, or deployment completion/iu,
+  },
+} as const;
+const omissions = {
+  'its review question': { field: 'reviewQuestion', finding: /review\s*question/iu },
+  'prohibited content': { field: 'prohibitedContent', finding: /prohibited\s*content/iu },
+  'its return path': { field: 'returnPath', finding: /return\s*path/iu },
+} as const;
+
+Given(
+  /^the canonical (Product Plan\/spec|Implementation Plan|Execution Plan) contract is presented$/,
+  function (this: SafewordWorld, artifact: keyof typeof phases) {
+    const { phase } = phases[artifact];
+    const evaluation = selectPlanningEval(this, `r10-shape-${phase}`);
+    const contract = PLANNING_CONTRACTS[phase];
+    assert.equal(evaluation.reviewed_plan, JSON.stringify(contract));
+    for (const field of [
+      'purpose',
+      'entryCriteria',
+      'requiredContent',
+      'prohibitedContent',
+      'reviewQuestion',
+      'approvalMeaning',
+      'invalidation',
+      'returnPath',
+    ] as const) {
+      assert.ok(Object.hasOwn(contract, field), `Canonical ${phase} lacks ${field}`);
+      assert.ok(contract[field].trim(), `Canonical ${phase} has empty ${field}`);
+    }
+    assert.match(contract.approvalMeaning, phases[artifact].meaning);
+  },
+);
+
+Given(
+  /^a canonical planning contract omits (its review question|prohibited content|its return path)$/,
+  function (this: SafewordWorld, requiredElement: keyof typeof omissions) {
+    const { field } = omissions[requiredElement];
+    assert.ok(Object.hasOwn(PLANNING_CONTRACTS['product-plan'], field));
+    const evaluation = selectPlanningEval(this, `r10-shape-missing-${field}`);
+    const supplied = JSON.parse(evaluation.reviewed_plan) as Record<string, unknown>;
+    const expected: Record<string, unknown> = { ...PLANNING_CONTRACTS['product-plan'] };
+    delete expected[field];
+    assert.deepEqual(supplied, expected);
+    assert.equal(Object.hasOwn(supplied, field), false);
+  },
+);
+
+When(
+  'a judged semantic reviewer evaluation checks its completeness against the canonical contract-shape rubric',
+  { timeout: 240_000 },
+  function (this: SafewordWorld) {
+    runPlanningEval(this);
+  },
+);
+
+Then(
+  /^it declares purpose, entry requirements, required and prohibited content, its review question, approval meaning, invalidating changes, and return path and limits approval to (.+)$/,
+  function (this: SafewordWorld, approvedClaim: string) {
+    const evaluation = selectedPlanningEval(this);
+    const phase = Object.values(phases).find(item => `r10-shape-${item.phase}` === evaluation.id);
+    assert.ok(phase);
+    assert.equal(approvedClaim, phase.claim);
+    assertPlanningEval(this, 'approve');
+  },
+);
+
+Then(
+  /^the contract is rejected with the missing (its review question|prohibited content|its return path) named$/,
+  function (this: SafewordWorld, requiredElement: keyof typeof omissions) {
+    const { field, finding } = omissions[requiredElement];
+    assert.equal(selectedPlanningEval(this).id, `r10-shape-missing-${field}`);
+    assertPlanningEval(this, 'request_changes', finding);
+  },
+);
