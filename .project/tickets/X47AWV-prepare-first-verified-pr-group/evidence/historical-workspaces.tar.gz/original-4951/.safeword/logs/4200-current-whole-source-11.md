Current PR5 complete unique-source review 11/19. Base 854a376861bc034d65cc81ddfa6a85d0ae55821e; head b722f9a27a1815abcfb08e6f6ca09dc7317efa46. Review actual correctness, authenticated approval, rejection findings and test discrimination. Every unique production source, template, test, step and generator changed in PR5 is supplied across these packets. Byte-identical installed mirrors and compiled bundles are omitted; all five generated surfaces passed at this head. Prior historical acceptance failures remain visible; full current run is in progress. Exactly 33 cases are user-deferred and unverified. This is source review, not native-host or merge approval. Flag only concrete in-scope defects; optional hardening does not block.

diff --git a/packages/cli/tests/integration/delivery-execution-prerequisite.test.ts b/packages/cli/tests/integration/delivery-execution-prerequisite.test.ts
index 2fc44b94f..2ea532421 100644
--- a/packages/cli/tests/integration/delivery-execution-prerequisite.test.ts
+++ b/packages/cli/tests/integration/delivery-execution-prerequisite.test.ts
@@ -1,7 +1,7 @@
 import { execFileSync } from 'node:child_process';
 import { createHmac } from 'node:crypto';
 import {
-  chmodSync,
+  cpSync,
   existsSync,
   mkdirSync,
   mkdtempSync,
@@ -17,93 +17,12 @@ import { afterEach, beforeAll, describe, expect, it } from 'vitest';
 
 import { findCommandDefinition } from '../../src/cli-protocol/catalog.js';
 import {
-  createExecutionPlanDeliveryDefinition,
-  normalizedExecutionPlanDigest,
-  parseDeliveryPlanContract,
-} from '../../src/execution-plan/delivery-checklist.js';
+  admitThroughInstalledCli,
+  executionPlan,
+  featureFixture,
+} from '../fixtures/execution-review.js';
 import { assertTestCliFresh, runCli, testCliPath } from '../helpers.js';
-import { writePlanningInventories } from '../planning-fixtures.js';
-import {
-  cleanupTrustedReviewerDirectories,
-  createTrustedReviewerDirectory,
-  REVIEWER_CAPABILITIES,
-} from '../review-fixtures.js';
-
-type PlanningReviewKind = 'scenario-gate' | 'plan-implementation' | 'plan-execution';
-
-const CATEGORIES = [
-  'outcome and scope',
-  'resolved decisions',
-  'dependency and pull-request decomposition',
-  'testing',
-  'data and compatibility',
-  'monitoring and failure signals',
-  'security and privacy',
-  'rollout and rollback',
-  'documentation',
-  'ownership and human dependencies',
-  'completion evidence',
-] as const;
-
-function executionPlan(): string {
-  const rows = CATEGORIES.map(
-    (category, index) =>
-      `| item-${index + 1} | ${category} | Deliver ${category}. | contributor | proof | open | missing |  |  |`,
-  );
-  return [
-    '# Execution Plan',
-    '',
-    '**Status:** planned',
-    '',
-    '## Proof specifications',
-    '',
-    '| Proof ID | Method | Scope | Boundary exercised | Qualifies as | Currency | Invocation |',
-    '| --- | --- | --- | --- | --- | --- | --- |',
-    `| proof | command | integration | public prerequisite | real_boundary | current_required | {"type":"command","cwd":".","argv":[${JSON.stringify(process.execPath)},"--version"]} |`,
-    '',
-    '## Delivery checklist',
-    '',
-    '<!-- safeword:delivery-checklist:v1 -->',
-    '',
-    '| ID | Category | Obligation | Owner | Required proof | Disposition | Evidence class | Revision | Evidence, reason, or dependency |',
-    '| --- | --- | --- | --- | --- | --- | --- | --- | --- |',
-    ...rows,
-    '',
-  ].join('\n');
-}
-
-function featureFixture(designApprovalGate = false, phase = 'plan-execution'): string {
-  const root = mkdtempSync(nodePath.join(tmpdir(), 'safeword-prerequisite-'));
-  const ticketDirectory = nodePath.join(root, '.project', 'tickets', 'ABC123-feature');
-  const featurePath = nodePath.join(root, 'features', 'feature.feature');
-  const implementationPath = nodePath.join(ticketDirectory, 'impl-plan.md');
-  const executionPath = nodePath.join(ticketDirectory, 'execution-plan.md');
-  const plan = executionPlan();
-  mkdirSync(ticketDirectory, { recursive: true });
-  writePlanningInventories(root);
-  mkdirSync(nodePath.dirname(featurePath), { recursive: true });
-  mkdirSync(nodePath.join(root, '.safeword'), { recursive: true });
-  writeFileSync(nodePath.join(root, '.gitignore'), '.safeword/state/\n.review-keys/\n');
-  writeFileSync(
-    nodePath.join(root, '.safeword', 'config.json'),
-    `${JSON.stringify({
-      designApprovalGate,
-      crossAgentReviewRoutes: {
-        codex: [{ reviewer: 'claude', model: 'opus' }],
-      },
-    })}\n`,
-  );
-  writeFileSync(
-    nodePath.join(ticketDirectory, 'ticket.md'),
-    `---\ntype: feature\nphase: ${phase}\n---\n`,
-  );
-  writeFileSync(featurePath, 'Feature: Accepted behavior\n');
-  writeFileSync(nodePath.join(ticketDirectory, 'spec.md'), '# Product Plan\n');
-  writeFileSync(implementationPath, '# Implementation Plan\n');
-  writeFileSync(executionPath, plan);
-  writeFileSync(nodePath.join(root, '.project', 'skill-invocations.log'), '');
-  return root;
-}
+import { cleanupTrustedReviewerDirectories } from '../review-fixtures.js';
 
 function legacyFeatureFixture(phase: 'implement' | 'verify'): string {
   const root = mkdtempSync(nodePath.join(tmpdir(), 'safeword-prerequisite-legacy-'));
@@ -116,39 +35,6 @@ function legacyFeatureFixture(phase: 'implement' | 'verify'): string {
   return root;
 }
 
-function installReviewer(): string {
-  const directory = createTrustedReviewerDirectory('safeword-prerequisite-');
-  const bin = nodePath.join(directory, 'bin');
-  mkdirSync(bin, { recursive: true });
-  const executable = nodePath.join(bin, 'claude');
-  writeFileSync(
-    executable,
-    String.raw`#!/bin/sh
-set -eu
-if [ "${'$'}{1:-}" = "--version" ]; then printf 'claude 1.0.0\n'; exit 0; fi
-if printf '%s' "$*" | /usr/bin/grep -q -- '--help'; then
-  printf '%s\n' '${REVIEWER_CAPABILITIES.claude}'
-  exit 0
-fi
-payload=$(cat)
-dispatch_id=$(printf '%s' "$payload" | sed -n 's/.*"dispatch_id":"\([^"]*\)".*/\1/p')
-record=$(printenv SAFEWORD_REVIEW_FAKE_EXECUTION_PLAN_RECORD || true)
-verdict=$(printenv SAFEWORD_REVIEW_FAKE_VERDICT || true)
-finding=$(printenv SAFEWORD_REVIEW_FAKE_FINDING || true)
-if [ "$verdict" = "request_changes" ]; then
-  printf '{"schema_version":1,"dispatch_id":"%s","reviewer_agent":"claude","verdict":"request_changes","summary":"plan needs repair","findings":[{"severity":"error","message":"%s"}],"planning_destination":"plan-execution","execution_plan_record":null}\n' "$dispatch_id" "$finding"
-elif [ -n "$record" ]; then
-  printf '{"schema_version":1,"dispatch_id":"%s","reviewer_agent":"claude","verdict":"approve","summary":"approved","findings":[],"planning_destination":"plan-execution","execution_plan_record":%s}\n' "$dispatch_id" "$record"
-else
-  printf '{"schema_version":1,"dispatch_id":"%s","reviewer_agent":"claude","verdict":"approve","summary":"approved","findings":[]}\n' "$dispatch_id"
-fi
-`,
-    { mode: 0o755 },
-  );
-  chmodSync(executable, 0o755);
-  return bin;
-}
-
 function rejectAdmittedScenarioReview(root: string): void {
   const ledger = readFileSync(nodePath.join(root, '.project', 'skill-invocations.log'), 'utf8');
   const reviewId = /phase@scenario-gate[^\n]*review-id:(\S+)/.exec(ledger)?.[1];
@@ -182,133 +68,6 @@ function rejectAdmittedScenarioReview(root: string): void {
   writeFileSync(path, `${JSON.stringify({ ...changed, integrity })}\n`);
 }
 
-async function admitThroughInstalledCli(
-  root: string,
-  admitted: readonly PlanningReviewKind[] = [
-    'scenario-gate',
-    'plan-implementation',
-    'plan-execution',
-  ],
-  designApprovalGate = false,
-  slicingDecision: 'one_pull_request' | 'multiple_pull_requests' = 'one_pull_request',
-): Promise<string> {
-  const ticketDirectory = nodePath.join(root, '.project', 'tickets', 'ABC123-feature');
-  const plan = readFileSync(nodePath.join(ticketDirectory, 'execution-plan.md'), 'utf8');
-  const parsed = parseDeliveryPlanContract(plan);
-  if (!parsed.ok) throw new Error(parsed.message);
-  const slices =
-    slicingDecision === 'one_pull_request'
-      ? [
-          {
-            name: 'Contribution',
-            purpose: 'Deliver the contribution.',
-            boundary: 'Public prerequisite.',
-            prerequisites: [] as string[],
-            proof: 'Integration test.',
-            completion_signal: 'The prerequisite is observable.',
-            relies_on_unmerged_successor: false,
-          },
-        ]
-      : [
-          {
-            name: 'Foundation',
-            purpose: 'Deliver the prerequisite.',
-            boundary: 'Shared contract.',
-            prerequisites: [] as string[],
-            proof: 'Contract test.',
-            completion_signal: 'The contract is independently usable.',
-            relies_on_unmerged_successor: false,
-          },
-          {
-            name: 'Contribution',
-            purpose: 'Deliver the contribution.',
-            boundary: 'Public prerequisite.',
-            prerequisites: ['Foundation'],
-            proof: 'Integration test.',
-            completion_signal: 'The prerequisite is observable.',
-            relies_on_unmerged_successor: false,
-          },
-        ];
-  const record = {
-    slicing_decision: slicingDecision,
-    rationale:
-      slicingDecision === 'one_pull_request'
-        ? 'One coherent contribution.'
-        : 'Two independently provable dependency-ordered changes.',
-    slices,
-    obligation_owners: [{ obligation: 'Contribution', slices: slices.map(slice => slice.name) }],
-    decision_statuses: [{ decision: 'Use the accepted plans', status: 'unchanged' }],
-    accepted_scenarios_covered: true,
-    accepted_approach_preserved: true,
-    normalized_plan_digest: normalizedExecutionPlanDigest(plan),
-    delivery_definition: createExecutionPlanDeliveryDefinition(parsed, designApprovalGate),
-  };
-  const bin = installReviewer();
-  const implementationTarget = nodePath.relative(
-    root,
-    nodePath.join(ticketDirectory, 'impl-plan.md'),
-  );
-  const executionTarget = nodePath.relative(
-    root,
-    nodePath.join(ticketDirectory, 'execution-plan.md'),
-  );
-  const specContext = nodePath.relative(root, nodePath.join(ticketDirectory, 'spec.md'));
-  const requests = [
-    ['scenario-gate', 'features/feature.feature', [specContext], undefined],
-    [
-      'plan-implementation',
-      implementationTarget,
-      ['features/feature.feature', specContext],
-      undefined,
-    ],
-    [
-      'plan-execution',
-      executionTarget,
-      [implementationTarget, 'features/feature.feature'],
-      JSON.stringify(record),
-    ],
-  ] as const;
-  const stamps: string[] = [];
-  const reviewKeyRoot = nodePath.join(root, '.review-keys');
-  for (const [reviewKind, target, context, executionRecord] of requests) {
-    if (!admitted.includes(reviewKind)) continue;
-    const reviewed = await runCli(
-      [
-        'review',
-        'run',
-        reviewKind,
-        target,
-        ...context.flatMap(contextPath => ['--context', contextPath]),
-        '--json',
-        '--no-input',
-        '--cwd',
-        root,
-      ],
-      {
-        cwd: root,
-        env: {
-          PATH: `${bin}:/usr/bin:/bin`,
-          NODE_ENV: 'test',
-          SAFEWORD_AGENT_RUNTIME: 'codex',
-          SAFEWORD_NO_UPDATE_CHECK: '1',
-          SAFEWORD_REVIEW_KEY_ROOT: reviewKeyRoot,
-          ...(executionRecord !== undefined && {
-            SAFEWORD_REVIEW_FAKE_EXECUTION_PLAN_RECORD: executionRecord,
-          }),
-        },
-      },
-    );
-    expect(reviewed.exitCode, reviewed.stdout).toBe(0);
-    const id = (JSON.parse(reviewed.stdout) as { data: { review_id: string } }).data.review_id;
-    expect(id).toBeTypeOf('string');
-    stamps.push(
-      `2026-09-13T00:00:00.000Z fixture review:ABC123-feature:phase@${reviewKind} author:codex reviewer:claude independence:reduced review-id:${id}`,
-    );
-  }
-  writeFileSync(nodePath.join(root, '.project', 'skill-invocations.log'), `${stamps.join('\n')}\n`);
-  return bin;
-}
-
 type DeliveryState = 'missing' | 'current' | 'earlier' | 'defect' | 'human';
 
 function prepareDeliveryState(root: string, planPath: string, state: DeliveryState): void {
@@ -391,13 +150,15 @@ describe('delivery execution prerequisite', () => {
       name: 'ticket execution-prerequisite',
       effectClass: 'observe',
       networkPolicy: 'never',
-      registration: expect.objectContaining({ syntax: 'execution-prerequisite <ticketId>' }),
+      registration: expect.objectContaining({
+        syntax: 'execution-prerequisite <ticketId>',
+      }),
     });
   });
 
   it('runs through the installed CLI with integrity-checked admitted reviews', async () => {
     const root = featureFixture();
-    await admitThroughInstalledCli(root);
+    await admitThroughInstalledCli(runCli, root);
 
     const result = await runCli(
       ['ticket', 'execution-prerequisite', 'ABC123', '--json', '--cwd', root],
@@ -433,6 +194,169 @@ describe('delivery execution prerequisite', () => {
     });
   });
 
+  it('names the wrong review kind even when both plan artifacts have identical bytes', async () => {
+    const root = featureFixture();
+    const ticketDirectory = nodePath.join(root, '.project', 'tickets', 'ABC123-feature');
+    writeFileSync(
+      nodePath.join(ticketDirectory, 'impl-plan.md'),
+      readFileSync(nodePath.join(ticketDirectory, 'execution-plan.md'), 'utf8'),
+    );
+    await admitThroughInstalledCli(runCli, root);
+    const invoke = () =>
+      runCli(['ticket', 'execution-prerequisite', 'ABC123', '--json', '--cwd', root], {
+        cwd: root,
+        env: {
+          NODE_ENV: 'test',
+          SAFEWORD_REVIEW_KEY_ROOT: nodePath.join(root, '.review-keys'),
+        },
+      });
+    const matching = await invoke();
+    expect(matching.exitCode, matching.stdout).toBe(0);
+
+    const ledgerPath = nodePath.join(root, '.project', 'skill-invocations.log');
+    const rows = readFileSync(ledgerPath, 'utf8').trim().split('\n');
+    const implementation = rows.find(row => row.includes(':phase@plan-implementation '));
+    expect(implementation).toBeDefined();
+    if (implementation === undefined) throw new Error('Missing Implementation review fixture');
+    const executionAlias = implementation.replace(
+      ':phase@plan-implementation ',
+      ':phase@plan-execution ',
+    );
+    writeFileSync(
+      ledgerPath,
+      `${[...rows.filter(row => !row.includes(':phase@plan-execution ')), executionAlias].join('\n')}\n`,
+    );
+    const mismatched = await invoke();
+    expect(mismatched.exitCode, mismatched.stdout).toBe(2);
+    const output = JSON.parse(mismatched.stdout);
+    expect(output.data.grants_authority).toBe(false);
+    expect(output.findings).toContainEqual(
+      expect.objectContaining({ code: 'missing_admitted_delivery_checklist' }),
+    );
+    const diagnostic = output.findings
+      .map((finding: { message: string }) => finding.message)
+      .join('\n');
+    expect(diagnostic).toMatch(/review kind/iu);
+    expect(diagnostic).toContain('plan-implementation');
+    expect(diagnostic).toContain('plan-execution');
+    const recoveryCommands = output.next_actions.map(
+      (action: { command: string }) => action.command,
+    );
+    expect(recoveryCommands).toContainEqual(expect.stringContaining('review run plan-execution'));
+  });
+
+  it('refuses approval when a signed malformed receipt bypasses current-context validation', async () => {
+    const root = featureFixture();
+    await admitThroughInstalledCli(runCli, root);
+    const options = {
+      cwd: root,
+      env: {
+        NODE_ENV: 'test',
+        SAFEWORD_REVIEW_KEY_ROOT: nodePath.join(root, '.review-keys'),
+      },
+    };
+    const args = ['ticket', 'execution-prerequisite', 'ABC123', '--json', '--cwd', root];
+    const matching = await runCli(args, options);
+    expect(matching.exitCode, matching.stdout).toBe(0);
+
+    const ledgerPath = nodePath.join(root, '.project', 'skill-invocations.log');
+    const rows = readFileSync(ledgerPath, 'utf8').trim().split('\n');
+    const execution = rows.find(row => row.includes(':phase@plan-execution '));
+    const reviewId = /review-id:(\S+)/u.exec(execution ?? '')?.[1];
+    if (reviewId === undefined) throw new Error('Missing Execution review fixture');
+    const jobPath = nodePath.join(root, '.safeword', 'state', 'reviews', `${reviewId}.json`);
+    const job = JSON.parse(readFileSync(jobPath, 'utf8'));
+    const { integrity: _integrity, ...unsigned } = job;
+    // Model an authenticated receipt whose result envelope the strict reader cannot validate.
+    unsigned.result.schemaVersion = 0;
+    const key = Buffer.from(
+      readFileSync(
+        nodePath.join(root, '.review-keys', 'safeword', 'review-integrity.key'),
+        'utf8',
+      ).trim(),
+      'hex',
+    );
+    const integrity = createHmac('sha256', key)
+      .update(realpathSync.native(root))
+      .update('\0')
+      .update(JSON.stringify(unsigned))
+      .digest('hex');
+    writeFileSync(jobPath, `${JSON.stringify({ ...unsigned, integrity })}\n`);
+
+    writeFileSync(
+      nodePath.join(root, '.project', 'tickets', 'ABC123-feature', 'impl-plan.md'),
+      '# Implementation Plan\n\n## Approach\nA changed accepted implementation boundary.\n',
+    );
+    await admitThroughInstalledCli(runCli, root, ['plan-implementation']);
+    const currentImplementation = readFileSync(ledgerPath, 'utf8').trim();
+    writeFileSync(
+      ledgerPath,
+      `${[...rows.filter(row => !row.includes(':phase@plan-implementation ')), currentImplementation].join('\n')}\n`,
+    );
+    const strict = await runCli(['review', 'status', reviewId, '--json', '--cwd', root], options);
+    expect(strict.exitCode, strict.stdout).toBe(1);
+    expect(JSON.parse(strict.stdout).errors).toContainEqual(
+      expect.objectContaining({ code: 'REVIEW_JOB_INVALID' }),
+    );
+    const blocked = await runCli(args, options);
+    expect(blocked.exitCode, blocked.stdout).toBe(2);
+    const output = JSON.parse(blocked.stdout);
+    expect(output.data.grants_authority).toBe(false);
+    expect(output.data.prerequisite_status).not.toBe('satisfied');
+    expect(output.findings).toContainEqual(
+      expect.objectContaining({ code: 'missing_admitted_delivery_checklist' }),
+    );
+  });
+
+  it('names the sibling ticket when its authenticated approval covers identical plan bytes', async () => {
+    const root = featureFixture();
+    const ticketDirectory = nodePath.join(root, '.project', 'tickets', 'ABC123-feature');
+    await admitThroughInstalledCli(runCli, root);
+    const invoke = (ticketId: string) =>
+      runCli(['ticket', 'execution-prerequisite', ticketId, '--json', '--cwd', root], {
+        cwd: root,
+        env: {
+          NODE_ENV: 'test',
+          SAFEWORD_REVIEW_KEY_ROOT: nodePath.join(root, '.review-keys'),
+        },
+      });
+    const matching = await invoke('ABC123');
+    expect(matching.exitCode, matching.stdout).toBe(0);
+    const ledgerPath = nodePath.join(root, '.project', 'skill-invocations.log');
+    const currentRows = readFileSync(ledgerPath, 'utf8').trim().split('\n');
+
+    const siblingDirectory = nodePath.join(root, '.project', 'tickets', 'XYZ789-feature');
+    cpSync(ticketDirectory, siblingDirectory, { recursive: true });
+    await admitThroughInstalledCli(runCli, root, ['plan-execution'], {
+      ticketFolder: 'XYZ789-feature',
+    });
+    expect(readFileSync(nodePath.join(siblingDirectory, 'execution-plan.md'), 'utf8')).toBe(
+      readFileSync(nodePath.join(ticketDirectory, 'execution-plan.md'), 'utf8'),
+    );
+    const siblingReceipt = readFileSync(ledgerPath, 'utf8').trim();
+    const alias = siblingReceipt.replace('review:XYZ789-feature:', 'review:ABC123-feature:');
+    writeFileSync(
+      ledgerPath,
+      `${[...currentRows.filter(row => !row.includes(':phase@plan-execution ')), alias].join('\n')}\n`,
+    );
+    const mismatched = await invoke('ABC123');
+    expect(mismatched.exitCode, mismatched.stdout).toBe(2);
+    const output = JSON.parse(mismatched.stdout);
+    expect(output.data.grants_authority).toBe(false);
+    expect(output.findings).toContainEqual(
+      expect.objectContaining({ code: 'missing_admitted_delivery_checklist' }),
+    );
+    const diagnostic = output.findings
+      .map((finding: { message: string }) => finding.message)
+      .join('\n');
+    expect(diagnostic).toContain('XYZ789-feature');
+    expect(diagnostic).toContain('ABC123-feature');
+    const recoveryCommands = output.next_actions.map(
+      (action: { command: string }) => action.command,
+    );
+    expect(recoveryCommands).toContainEqual(expect.stringContaining('review run plan-execution'));
+  });
+
   it.each([
     {
       label: 'present artifact with planned status and a valid receipt',
@@ -490,7 +414,7 @@ describe('delivery execution prerequisite', () => {
     },
   ])('reports structural facts for a $label without a semantic verdict', async testCase => {
     const root = featureFixture();
-    await admitThroughInstalledCli(root);
+    await admitThroughInstalledCli(runCli, root);
     const executionPath = nodePath.join(
       root,
       '.project',
@@ -520,7 +444,9 @@ describe('delivery execution prerequisite', () => {
     expect(result.data).toEqual({
       command: 'ticket execution-prerequisite',
       grants_authority: false,
-      ...(testCase.expectedExitCode === 0 && { prerequisite_status: 'satisfied' }),
+      ...(testCase.expectedExitCode === 0 && {
+        prerequisite_status: 'satisfied',
+      }),
       execution_plan_artifact: testCase.expectedFacts,
     });
     expect(JSON.stringify(result)).not.toMatch(
@@ -570,7 +496,7 @@ describe('delivery execution prerequisite', () => {
 
   it('denies an authenticated scenario review that requested changes', async () => {
     const root = featureFixture();
-    await admitThroughInstalledCli(root);
+    await admitThroughInstalledCli(runCli, root);
     rejectAdmittedScenarioReview(root);
 
     const invoked = await runCli(
@@ -606,7 +532,9 @@ describe('delivery execution prerequisite', () => {
       ['ticket', 'execution-prerequisite', 'ABC123', '--json', '--cwd', root],
       { cwd: root, env: { NODE_ENV: 'test' } },
     );
-    const result = JSON.parse(invoked.stdout) as { findings: { code: string }[] };
+    const result = JSON.parse(invoked.stdout) as {
+      findings: { code: string }[];
+    };
 
     expect(invoked.exitCode).toBe(2);
     expect(result.findings.map(finding => finding.code)).toEqual([
@@ -642,7 +570,7 @@ describe('delivery execution prerequisite', () => {
     'denies only the missing %s prerequisite with one repair',
     async (_label, admitted, expectedCode, expectedMessage, expectedCommand) => {
       const root = featureFixture();
-      await admitThroughInstalledCli(root, admitted);
+      await admitThroughInstalledCli(runCli, root, admitted);
 
       const invoked = await runCli(
         ['ticket', 'execution-prerequisite', 'ABC123', '--json', '--cwd', root],
@@ -673,9 +601,10 @@ describe('delivery execution prerequisite', () => {
   it('requires configured human design approval as part of the accepted approach', async () => {
     const root = featureFixture(true);
     await admitThroughInstalledCli(
+      runCli,
       root,
       ['scenario-gate', 'plan-implementation', 'plan-execution'],
-      true,
+      { designApprovalGate: true },
     );
 
     const invoked = await runCli(
@@ -718,7 +647,7 @@ describe('delivery execution prerequisite', () => {
     'returns the reviewed %s slicing outcome when its checklist item is completed',
     async (decision, rationale, expectedSlices) => {
       const root = featureFixture();
-      await admitThroughInstalledCli(root, undefined, false, decision);
+      await admitThroughInstalledCli(runCli, root, undefined, { slicingDecision: decision });
       const reviewEnvironment = {
         NODE_ENV: 'test',
         SAFEWORD_REVIEW_KEY_ROOT: nodePath.join(root, '.review-keys'),
@@ -729,16 +658,22 @@ describe('delivery execution prerequisite', () => {
       );
       expect(prerequisite.exitCode, prerequisite.stdout).toBe(0);
       execFileSync('git', ['init', '--quiet'], { cwd: root });
-      execFileSync('git', ['config', 'user.email', 'proof@example.com'], { cwd: root });
+      execFileSync('git', ['config', 'user.email', 'proof@example.com'], {
+        cwd: root,
+      });
       execFileSync('git', ['config', 'user.name', 'Proof Test'], { cwd: root });
       execFileSync('git', ['add', '.'], { cwd: root });
-      execFileSync('git', ['commit', '--quiet', '-m', 'fixture'], { cwd: root });
+      execFileSync('git', ['commit', '--quiet', '-m', 'fixture'], {
+        cwd: root,
+      });
 
       const invoked = await runCli(
         ['ticket', 'record-delivery-proof', 'ABC123', 'item-3', 'proof', '--json', '--cwd', root],
         { cwd: root, env: reviewEnvironment },
       );
-      const result = JSON.parse(invoked.stdout) as { data?: Record<string, unknown> };
+      const result = JSON.parse(invoked.stdout) as {
+        data?: Record<string, unknown>;
+      };
 
       expect(invoked.exitCode, invoked.stdout).toBe(0);
       expect(
@@ -767,7 +702,7 @@ describe('delivery execution prerequisite', () => {
       const root = featureFixture();
       const planPath = nodePath.join(root, '.project/tickets/ABC123-feature/execution-plan.md');
       prepareDeliveryState(root, planPath, state);
-      await admitThroughInstalledCli(root);
+      await admitThroughInstalledCli(runCli, root);
       const git = (args: string[]): void => {
         execFileSync('git', args, { cwd: root });
       };
@@ -820,7 +755,7 @@ describe('delivery execution prerequisite', () => {
         );
       }
       writeFileSync(planPath, plan);
-      const bin = await admitThroughInstalledCli(root);
+      const bin = await admitThroughInstalledCli(runCli, root);
       const git = (args: string[]): void => {
         execFileSync('git', args, { cwd: root });
       };
@@ -879,7 +814,11 @@ describe('delivery execution prerequisite', () => {
       const data = (
         JSON.parse(observed.stdout) as {
           data: {
-            contributor_evidence: { item_id: string; status: string; evidence_class: string }[];
+            contributor_evidence: {
+              item_id: string;
+              status: string;
+              evidence_class: string;
+            }[];
           };
         }
       ).data;
@@ -923,7 +862,10 @@ describe('delivery execution prerequisite', () => {
     expect(invoked.exitCode).toBe(0);
     expect(result).toMatchObject({
       state: 'healthy',
-      data: { prerequisite_status: 'not_applicable', grants_authority: false },
+      data: {
+        prerequisite_status: 'not_applicable',
+        grants_authority: false,
+      },
     });
     expect(result.effects).toEqual({
       files: [],
@@ -950,7 +892,10 @@ describe('delivery execution prerequisite', () => {
       expect(invoked.exitCode).toBe(0);
       expect(result).toMatchObject({
         state: 'healthy',
-        data: { prerequisite_status: 'not_applicable', grants_authority: false },
+        data: {
+          prerequisite_status: 'not_applicable',
+          grants_authority: false,
+        },
       });
     },
   );
diff --git a/packages/cli/tests/integration/execution-product-planning-context.test.ts b/packages/cli/tests/integration/execution-product-planning-context.test.ts
index 82eb44dd5..b6f2ed7f7 100644
--- a/packages/cli/tests/integration/execution-product-planning-context.test.ts
+++ b/packages/cli/tests/integration/execution-product-planning-context.test.ts
@@ -105,7 +105,7 @@ process.stdin.on('end', () => {
   const packet = JSON.parse(input.trim().split('\n').pop());
   writeFileSync(${JSON.stringify(capture)}, JSON.stringify(packet));
   console.log(JSON.stringify({ structured_output: { schema_version: 1, dispatch_id: packet.dispatch_id,
-    reviewer_agent: 'claude', verdict: 'approve', summary: 'Fixture approves the supplied packet.', findings: [], planning_destination: 'plan-execution',
+    reviewer_agent: 'claude', verdict: 'approve', summary: 'Fixture approves the supplied packet.', findings: [], evidence_records: { schema_version: 1, records: [] }, planning_destination: 'plan-execution',
     execution_plan_record: { slicing_decision: 'one_pull_request', rationale: 'One coherent change.',
       slices: [{ name: 'Complete delivery', purpose: 'Deliver the reviewed plan.', boundary: 'The accepted CLI boundary.', prerequisites: [], proof: 'The installed CLI review passes.', completion_signal: 'The review is approved.', relies_on_unmerged_successor: false }],
       obligation_owners: [{ obligation: 'Accepted behavior', slices: ['Complete delivery'] }],
diff --git a/packages/cli/tests/integration/execution-upstream-planning-context.test.ts b/packages/cli/tests/integration/execution-upstream-planning-context.test.ts
index e1d4c3626..63909b069 100644
--- a/packages/cli/tests/integration/execution-upstream-planning-context.test.ts
+++ b/packages/cli/tests/integration/execution-upstream-planning-context.test.ts
@@ -110,7 +110,7 @@ process.stdin.on('end', () => {
   const packet = JSON.parse(input.trim().split('\n').pop());
   writeFileSync(${JSON.stringify(capture)}, JSON.stringify(packet));
   const output = { structured_output: { schema_version: 1, dispatch_id: packet.dispatch_id,
-    reviewer_agent: 'claude', verdict: 'approve', summary: 'Fixture approves the supplied packet.', findings: [], planning_destination: 'plan-execution',
+    reviewer_agent: 'claude', verdict: 'approve', summary: 'Fixture approves the supplied packet.', findings: [], evidence_records: { schema_version: 1, records: [] }, planning_destination: 'plan-execution',
     execution_plan_record: { slicing_decision: 'one_pull_request', rationale: 'One coherent change.',
       slices: [{ name: 'Complete delivery', purpose: 'Deliver the reviewed plan.', boundary: 'The accepted CLI boundary.', prerequisites: [], proof: 'The installed CLI review passes.', completion_signal: 'The review is approved.', relies_on_unmerged_successor: false }],
       obligation_owners: [{ obligation: 'Accepted behavior', slices: ['Complete delivery'] }],
diff --git a/packages/cli/tests/integration/implementation-product-planning-context.test.ts b/packages/cli/tests/integration/implementation-product-planning-context.test.ts
index cc3c81c37..7b7c31bb7 100644
--- a/packages/cli/tests/integration/implementation-product-planning-context.test.ts
+++ b/packages/cli/tests/integration/implementation-product-planning-context.test.ts
@@ -92,7 +92,7 @@ process.stdin.on('end', () => {
   const packet = JSON.parse(input.trim().split('\n').pop());
   writeFileSync(${JSON.stringify(capture)}, JSON.stringify(packet));
   console.log(JSON.stringify({ structured_output: { schema_version: 1, dispatch_id: packet.dispatch_id,
-    reviewer_agent: 'claude', verdict: 'approve', summary: 'Fixture approves the supplied packet.', findings: [] } }));
+    reviewer_agent: 'claude', verdict: 'approve', summary: 'Fixture approves the supplied packet.', findings: [], evidence_records: { schema_version: 1, records: [] } } }));
 });
 `,
     { mode: 0o755 },
diff --git a/packages/cli/tests/integration/implementation-ticket-context-currency.test.ts b/packages/cli/tests/integration/implementation-ticket-context-currency.test.ts
index 43087b38e..f738cdb9a 100644
--- a/packages/cli/tests/integration/implementation-ticket-context-currency.test.ts
+++ b/packages/cli/tests/integration/implementation-ticket-context-currency.test.ts
@@ -92,7 +92,7 @@ process.stdin.on('end', () => {
   const packet = JSON.parse(input.trim().split('\n').pop());
   writeFileSync(${JSON.stringify(capture)}, JSON.stringify(packet));
   console.log(JSON.stringify({ structured_output: { schema_version: 1, dispatch_id: packet.dispatch_id,
-    reviewer_agent: 'claude', verdict: 'approve', summary: 'Fixture approves the supplied packet.', findings: [] } }));
+    reviewer_agent: 'claude', verdict: 'approve', summary: 'Fixture approves the supplied packet.', findings: [], evidence_records: { schema_version: 1, records: [] } } }));
 });
 `,
     { mode: 0o755 },
diff --git a/packages/cli/tests/integration/inspiration-intake-transition.test.ts b/packages/cli/tests/integration/inspiration-intake-transition.test.ts
index b1336732c..ef1d1bcd9 100644
--- a/packages/cli/tests/integration/inspiration-intake-transition.test.ts
+++ b/packages/cli/tests/integration/inspiration-intake-transition.test.ts
@@ -11,7 +11,13 @@ import {
   inspirationActivationLines,
   validProductInspirationLines,
 } from '../fixtures/inspiration.js';
-import { expectHookAllow, expectHookDeny, type HookResult, writeGateConfig } from '../helpers';
+import {
+  createCurrentPlanningCheckerStub,
+  expectHookAllow,
+  expectHookDeny,
+  type HookResult,
+  writeGateConfig,
+} from '../helpers';
 
 const HOOK_PATH = nodePath.resolve(__dirname, '../../templates/hooks/pre-tool-quality.ts');
 const CODEX_HOOK_PATH = nodePath.resolve(
@@ -91,7 +97,12 @@ describe('activated intake inspiration transition wiring', () => {
     return writeThroughCodex(ticketFile, content, 'inspiration-codex-write');
   }
 
-  function writeThroughCodex(filePath: string, content: string, sessionId: string): HookResult {
+  function writeThroughCodex(
+    filePath: string,
+    content: string,
+    sessionId: string,
+    checkerCli?: string,
+  ): HookResult {
     const result = spawnSync('bun', [CODEX_HOOK_PATH], {
       cwd: projectRoot,
       input: JSON.stringify({
@@ -100,7 +111,11 @@ describe('activated intake inspiration transition wiring', () => {
         tool_input: { file_path: filePath, content },
       }),
       encoding: 'utf8',
-      env: { ...process.env, CLAUDE_PROJECT_DIR: projectRoot },
+      env: {
+        ...process.env,
+        CLAUDE_PROJECT_DIR: projectRoot,
+        ...(checkerCli !== undefined && { SAFEWORD_PLUGIN_CLI: checkerCli }),
+      },
     });
     return { status: result.status, stdout: result.stdout ?? '', stderr: result.stderr ?? '' };
   }
@@ -205,10 +220,20 @@ describe('activated intake inspiration transition wiring', () => {
       '<!-- safeword:inspiration-contract:v1 -->\n',
       '',
     );
-    expectHookDeny(
-      writeThroughCodex(specFile, specWithoutSignal, 'inspiration-remove-last-signal'),
-      'last inspiration-contract activation signal',
-    );
+    const checker = createCurrentPlanningCheckerStub();
+    try {
+      expectHookDeny(
+        writeThroughCodex(
+          specFile,
+          specWithoutSignal,
+          'inspiration-remove-last-signal',
+          checker.cli,
+        ),
+        'last inspiration-contract activation signal',
+      );
+    } finally {
+      rmSync(checker.directory, { recursive: true, force: true });
+    }
     expectHookDeny(advanceThroughCodex(), 'all three');
   });
 
diff --git a/packages/cli/tests/integration/installed-planning-copy-admission.test.ts b/packages/cli/tests/integration/installed-planning-copy-admission.test.ts
index a3162e3cf..bc67886a3 100644
--- a/packages/cli/tests/integration/installed-planning-copy-admission.test.ts
+++ b/packages/cli/tests/integration/installed-planning-copy-admission.test.ts
@@ -4,6 +4,7 @@ import {
   existsSync,
   mkdirSync,
   mkdtempSync,
+  readdirSync,
   readFileSync,
   rmSync,
   symlinkSync,
@@ -64,7 +65,8 @@ process.stdin.on('end', () => {
   const packet = JSON.parse(input.slice(input.lastIndexOf('{"schema_version":1')));
   console.log(JSON.stringify({ structured_output: {
     schema_version: 1, dispatch_id: packet.dispatch_id, reviewer_agent: 'claude',
-    verdict: 'approve', summary: 'Fixture approval.', findings: []
+    verdict: 'approve', summary: 'Fixture approval.', findings: [],
+    evidence_records: { schema_version: 1, records: [] }
   }}));
 });
 `,
@@ -172,10 +174,129 @@ process.stdin.on('end', () => {
   return { project, ticketPath, run, advance, root, distribution, environment };
 }
 
+const authoringPhases = [
+  {
+    phase: 'product-plan',
+    artifact: 'spec.md',
+    contract: 'DISCOVERY.md',
+    oldString: 'Product Plan',
+    ticketPhase: 'intake',
+  },
+  {
+    phase: 'plan-implementation',
+    artifact: 'impl-plan.md',
+    contract: 'PLAN_IMPLEMENTATION.md',
+    oldString: 'Preserve accepted behavior through one implementation.',
+    ticketPhase: 'plan-implementation',
+  },
+  {
+    phase: 'plan-execution',
+    artifact: 'execution-plan.md',
+    contract: 'PLAN_EXECUTION.md',
+    oldString: 'One step.',
+    ticketPhase: 'plan-execution',
+  },
+] as const;
+
+function alterAuthorCopy(asset: string, state: 'canonical' | 'comment drift' | 'missing copy') {
+  if (state === 'comment drift')
+    writeFileSync(asset, `<!-- authoring-copy drift -->\n${readFileSync(asset, 'utf8')}`);
+  else if (state === 'missing copy') rmSync(asset);
+}
+
+function alterReviewerCopy(distribution: string) {
+  const files = readdirSync(nodePath.join(distribution, 'dist')).filter(file =>
+    file.endsWith('.js'),
+  );
+  const runtime = files
+    .map(file => nodePath.join(distribution, 'dist', file))
+    .find(file => readFileSync(file, 'utf8').includes('var PLAN_REVIEW_RUBRIC = '));
+  if (runtime === undefined) throw new Error('Copied distribution lacks its reviewer rubric');
+  const source = readFileSync(runtime, 'utf8');
+  const start = source.indexOf('var PLAN_REVIEW_RUBRIC = ');
+  const end = source.indexOf('PLAN_REVIEW_RUBRIC_SHA256', start);
+  const clause = 'Accepted scope and exclusions belong to the user.';
+  const clauseIndex = source.indexOf(clause, start);
+  expect(clauseIndex).toBeGreaterThan(start);
+  expect(clauseIndex).toBeLessThan(end);
+  writeFileSync(runtime, source.slice(0, clauseIndex) + source.slice(clauseIndex + clause.length));
+}
+
 describe('Cursor installed planning copy admission', () => {
+  it.each(
+    authoringPhases.flatMap(phase =>
+      (['canonical', 'comment drift', 'missing copy'] as const).map(state => ({ ...phase, state })),
+    ),
+  )(
+    'checks $phase authoring copy with $state before an installed $artifact edit',
+    { timeout: 90_000 },
+    ({ phase, artifact, contract, oldString, ticketPhase, state }) => {
+      const installed = fixture();
+      if (ticketPhase !== 'plan-implementation') {
+        writeFileSync(
+          installed.ticketPath,
+          readFileSync(installed.ticketPath, 'utf8')
+            .split('phase: plan-implementation')
+            .join(`phase: ${ticketPhase}`),
+        );
+      }
+      const asset = nodePath.join(installed.project, '.safeword/skills/bdd', contract);
+      alterAuthorCopy(asset, state);
+      const planPath = nodePath.join(installed.project, '.project/tickets', folder, artifact);
+      if (artifact === 'execution-plan.md')
+        writeFileSync(planPath, '# Execution Plan\n\nOne step.\n');
+      const edited = spawnSync(
+        'bun',
+        [nodePath.join(installed.project, '.safeword/hooks/pre-tool-quality.ts')],
+        {
+          cwd: installed.project,
+          encoding: 'utf8',
+          timeout: 15_000,
+          env: installed.environment,
+          input: JSON.stringify({
+            tool_name: 'Edit',
+            tool_input: {
+              file_path: planPath,
+              old_string: oldString,
+              new_string: `${oldString} reviewed`,
+            },
+          }),
+        },
+      );
+      expect(edited.status, `${edited.stdout}\n${edited.stderr}`).toBe(0);
+      if (state === 'canonical') {
+        expect(edited.stdout.trim(), 'canonical authoring must remain available').toBe('');
+      } else {
+        const findingCode =
+          state === 'missing copy'
+            ? 'missing_generated_contract_copy'
+            : 'canonical_contract_copy_mismatch';
+        expect(
+          edited.stdout.trim(),
+          'installed plan authoring must refuse a drifted contract copy before the edit',
+        ).not.toBe('');
+        const output = JSON.parse(edited.stdout) as {
+          systemMessage?: string;
+          hookSpecificOutput?: { permissionDecision?: string; permissionDecisionReason?: string };
+        };
+        expect(output.hookSpecificOutput?.permissionDecision).toBe('deny');
+        expect(
+          output.systemMessage,
+          'a blocked author should see the contract mismatch without another command',
+        ).toContain(findingCode);
+        expect(output.hookSpecificOutput?.permissionDecisionReason).toContain(findingCode);
+        expect(output.hookSpecificOutput?.permissionDecisionReason).toContain(phase);
+        expect(output.hookSpecificOutput?.permissionDecisionReason).toContain(
+          `.safeword/skills/bdd/${contract}`,
+        );
+      }
+    },
+  );
+
   it.each([
     { state: 'canonical', permission: 'allow' },
     { state: 'comment drift', permission: 'deny' },
+    { state: 'reviewer rubric drift', permission: 'deny' },
     { state: 'project-writable cached runtime', permission: 'deny' },
   ] as const)(
     'checks $state at the installed Cursor adapter without plugin variables',
@@ -212,7 +333,7 @@ console.log(JSON.stringify({ schema_version: 1, ok: true, state: 'healthy', data
       const asset = nodePath.join(installed.project, '.safeword/skills/bdd/PLAN_IMPLEMENTATION.md');
       if (state === 'comment drift') {
         writeFileSync(asset, `<!-- cached-runtime copy drift -->\n${readFileSync(asset, 'utf8')}`);
-      }
+      } else if (state === 'reviewer rubric drift') alterReviewerCopy(installed.distribution);
       const environment: NodeJS.ProcessEnv = { ...installed.environment, CODEX_HOME: cacheHome };
       delete environment.SAFEWORD_PLUGIN_CLI;
       delete environment.CLAUDE_PLUGIN_ROOT;
@@ -246,15 +367,62 @@ console.log(JSON.stringify({ schema_version: 1, ok: true, state: 'healthy', data
       if (state === 'comment drift') {
         expect(checked.stdout).toContain('canonical_contract_copy_mismatch');
         expect(checked.stdout).toContain('.safeword/skills/bdd/PLAN_IMPLEMENTATION.md');
+      } else if (state === 'reviewer rubric drift') {
+        expect(checked.stdout).toContain('canonical_contract_copy_mismatch');
+        expect(checked.stdout).toContain('src/review/plan-rubric.generated.ts');
       }
       expect(existsSync(marker), 'project-writable authority must never execute').toBe(false);
     },
   );
 
-  it.each(['public approval', 'installed hook'] as const)(
-    'refuses project-copy drift at %s after an authenticated review',
+  it(
+    'refuses public plan approval when the generated reviewer rubric drifts',
+    { timeout: 90_000 },
+    () => {
+      const installed = fixture();
+      alterReviewerCopy(installed.distribution);
+      const approval = installed.run(['ticket', 'approve-plan', 'CPY123']);
+      expect(approval.status).not.toBe(0);
+      expect(approval.stdout).toContain('canonical_contract_copy_mismatch');
+      expect(approval.stdout).toContain('src/review/plan-rubric.generated.ts');
+      expect(readFileSync(installed.ticketPath, 'utf8')).toContain('phase: plan-implementation');
+    },
+  );
+
+  it(
+    'refuses to reuse an approved review after the reviewer copy drifts',
+    { timeout: 90_000 },
+    () => {
+      const installed = fixture();
+      alterReviewerCopy(installed.distribution);
+      const repeated = installed.run([
+        'review',
+        'run',
+        'plan-implementation',
+        `.project/tickets/${folder}/impl-plan.md`,
+        '--context',
+        `.project/tickets/${folder}/spec.md`,
+      ]);
+      expect(repeated.status).not.toBe(0);
+      const output = JSON.parse(repeated.stdout) as { effects?: { network?: unknown[] } };
+      expect(
+        output.effects?.network,
+        'review dispatch must refuse stale reviewer bytes before launch',
+      ).toEqual([]);
+      expect(repeated.stdout).toContain('canonical_contract_copy_mismatch');
+      expect(repeated.stdout).toContain('src/review/plan-rubric.generated.ts');
+    },
+  );
+
+  it.each([
+    ['public approval', 'comment drift'],
+    ['public approval', 'missing copy'],
+    ['installed hook', 'comment drift'],
+    ['installed hook', 'missing copy'],
+  ] as const)(
+    'refuses %s with %s after an authenticated review',
     { timeout: 90_000 },
-    boundary => {
+    (boundary, copyState) => {
       const project = fixture();
       const canonical =
         boundary === 'public approval'
@@ -277,10 +445,12 @@ console.log(JSON.stringify({ schema_version: 1, ok: true, state: 'healthy', data
         driftProject.project,
         '.safeword/skills/bdd/PLAN_IMPLEMENTATION.md',
       );
-      writeFileSync(
-        asset,
-        `<!-- installed-copy drift outside reviewer block -->\n${readFileSync(asset, 'utf8')}`,
-      );
+      if (copyState === 'missing copy') rmSync(asset);
+      else
+        writeFileSync(
+          asset,
+          `<!-- installed-copy drift outside reviewer block -->\n${readFileSync(asset, 'utf8')}`,
+        );
       const drifted =
         boundary === 'public approval'
           ? driftProject.run(['ticket', 'approve-plan', 'CPY123'])
@@ -294,7 +464,11 @@ console.log(JSON.stringify({ schema_version: 1, ok: true, state: 'healthy', data
         refused,
         'installed lifecycle must refuse project author-copy drift after authenticated approval',
       ).toBe(true);
-      expect(`${drifted.stdout}\n${drifted.stderr}`).toContain('canonical_contract_copy_mismatch');
+      expect(`${drifted.stdout}\n${drifted.stderr}`).toContain(
+        copyState === 'missing copy'
+          ? 'missing_generated_contract_copy'
+          : 'canonical_contract_copy_mismatch',
+      );
       expect(`${drifted.stdout}\n${drifted.stderr}`).toContain(
         '.safeword/skills/bdd/PLAN_IMPLEMENTATION.md',
       );
diff --git a/packages/cli/tests/integration/native-planning-copy-dispatch.test.ts b/packages/cli/tests/integration/native-planning-copy-dispatch.test.ts
index 348492cc3..3a721d060 100644
--- a/packages/cli/tests/integration/native-planning-copy-dispatch.test.ts
+++ b/packages/cli/tests/integration/native-planning-copy-dispatch.test.ts
@@ -40,7 +40,8 @@ process.stdin.on('end', () => {
   require('node:fs').appendFileSync(${JSON.stringify(calls)}, 'review' + String.fromCharCode(10));
   process.stdout.write(JSON.stringify({ structured_output: {
     schema_version: 1, dispatch_id: packet.dispatch_id, reviewer_agent: 'claude',
-    verdict: 'approve', summary: 'Native copy fixture approval.', findings: []
+    verdict: 'approve', summary: 'Native copy fixture approval.', findings: [],
+    evidence_records: { schema_version: 1, records: [] }
   }}));
 });
 `,
diff --git a/packages/cli/tests/integration/plan-design-approval.test.ts b/packages/cli/tests/integration/plan-design-approval.test.ts
index f967f3a91..dab3963ba 100644
--- a/packages/cli/tests/integration/plan-design-approval.test.ts
+++ b/packages/cli/tests/integration/plan-design-approval.test.ts
@@ -34,6 +34,7 @@ import {
 import { appendDesignDecision } from '../../src/review/approval-ledger.js';
 import { hashArtifact, reviewScope } from '../../templates/hooks/lib/review-ledger.js';
 import { assertTestCliFresh, runCli, testCliPath } from '../helpers.js';
+import { PLANNING_ROLE_PRODUCT, writeImplementationRoleInputs } from '../planning-role-fixtures.js';
 
 const TICKET_ID = 'PLAN42';
 const TICKET_FOLDER = `${TICKET_ID}-review-the-approach`;
@@ -189,7 +190,24 @@ function projectFiles(directory: string, root = directory): string[] {
   });
 }
 
-function fixture(designApprovalGate: boolean, reviewState: ReviewState = 'approved'): Fixture {
+function supplyCurrentContext(root: string, ticketDirectory: string, enabled: boolean): void {
+  if (!enabled) return;
+  writeFileSync(
+    nodePath.join(ticketDirectory, 'spec.md'),
+    `${PLANNING_ROLE_PRODUCT}\n## Surfaces\n\nAffected:\n- Safeword CLI\n`,
+  );
+  writeImplementationRoleInputs(
+    root,
+    `${nodePath.relative(root, ticketDirectory)}/impl-plan.md`,
+    'review-the-approach.feature',
+  );
+}
+
+function fixture(
+  designApprovalGate: boolean,
+  reviewState: ReviewState = 'approved',
+  currentContext = false,
+): Fixture {
   const root = mkdtempSync(nodePath.join(tmpdir(), 'safeword-plan-approval-'));
   fixtures.push(root);
   const ticketDirectory = nodePath.join(root, '.project', 'tickets', TICKET_FOLDER);
@@ -222,6 +240,13 @@ function fixture(designApprovalGate: boolean, reviewState: ReviewState = 'approv
       'type: feature',
       'phase: plan-implementation',
       'status: in_progress',
+      ...(currentContext
+        ? [
+            'product_plan_contract: v1',
+            'phase_anchors:',
+            '  - scenario-gate: features/review-the-approach.feature',
+          ]
+        : []),
       'scope: review one approach',
       'out_of_scope: unrelated work',
       'done_when: execution planning begins safely',
@@ -237,6 +262,7 @@ function fixture(designApprovalGate: boolean, reviewState: ReviewState = 'approv
     nodePath.join(root, 'features', 'review-the-approach.feature'),
     'Feature: Review the approach\n',
   );
+  supplyCurrentContext(root, ticketDirectory, currentContext);
   writeFileSync(
     nodePath.join(root, '.safeword', 'templates', 'execution-plan-template.md'),
     EXECUTION_PLAN_TEMPLATE,
@@ -283,7 +309,8 @@ function fixture(designApprovalGate: boolean, reviewState: ReviewState = 'approv
   const reviewId = payload.data?.review_id;
   if (reviewId === undefined)
     throw new Error(`Implementation Plan review failed: ${reviewed.stdout}`);
-  const scope = reviewScope(TICKET_FOLDER, 'impl-plan', hashArtifact(PLAN));
+  const currentPlan = readFileSync(nodePath.join(ticketDirectory, 'impl-plan.md'), 'utf8');
+  const scope = reviewScope(TICKET_FOLDER, 'impl-plan', hashArtifact(currentPlan));
   const existingLedger = readFileSync(ledgerPath, 'utf8');
   writeFileSync(
     ledgerPath,
@@ -533,7 +560,7 @@ dispatch_id=$(printf '%s' "$payload" | /usr/bin/sed -n 's/.*"dispatch_id":"\([^"
 if printf '%s' "$payload" | /usr/bin/grep -Fq '"kind":"plan-execution"'; then
   review_record=$(printenv SAFEWORD_REVIEW_FAKE_EXECUTION_PLAN_RECORD || true)
   if [ -n "$review_record" ]; then
-    printf '{"schema_version":1,"dispatch_id":"%s","reviewer_agent":"claude","verdict":"approve","summary":"replan approved","findings":[],"planning_destination":"plan-execution","execution_plan_record":%s}\n' "$dispatch_id" "$review_record"
+    printf '{"schema_version":1,"dispatch_id":"%s","reviewer_agent":"claude","verdict":"approve","summary":"replan approved","findings":[],"evidence_records":{"schema_version":1,"records":[]},"planning_destination":"plan-execution","execution_plan_record":%s}\n' "$dispatch_id" "$review_record"
     exit 0
   fi
   if printf '%s' "$payload" | /usr/bin/grep -Fq 'Accepted authorization approach changed'; then
@@ -541,15 +568,15 @@ if printf '%s' "$payload" | /usr/bin/grep -Fq '"kind":"plan-execution"'; then
   else
     destination=plan-execution
   fi
-  printf '{"schema_version":1,"dispatch_id":"%s","reviewer_agent":"claude","verdict":"request_changes","summary":"implementation discovery","findings":[{"severity":"error","message":"Repair the affected plan."}],"planning_destination":"%s","execution_plan_record":null}\n' "$dispatch_id" "$destination"
+  printf '{"schema_version":1,"dispatch_id":"%s","reviewer_agent":"claude","verdict":"request_changes","summary":"implementation discovery","findings":[{"severity":"error","message":"Repair the affected plan."}],"evidence_records":{"schema_version":1,"records":[]},"planning_destination":"%s","execution_plan_record":null}\n' "$dispatch_id" "$destination"
   exit 0
 fi
 if [ "${'$'}{SAFEWORD_REVIEW_FAKE_VERDICT:-approve}" = "request_changes" ]; then
-  printf '{"schema_version":1,"dispatch_id":"%s","reviewer_agent":"claude","verdict":"request_changes","summary":"plan is blocked","findings":[{"severity":"error","message":"Authorization boundary is missing."}]}\n' "$dispatch_id"
+  printf '{"schema_version":1,"dispatch_id":"%s","reviewer_agent":"claude","verdict":"request_changes","summary":"plan is blocked","findings":[{"severity":"error","message":"Authorization boundary is missing."}],"evidence_records":{"schema_version":1,"records":[]}}\n' "$dispatch_id"
 elif [ "${'$'}{SAFEWORD_REVIEW_FAKE_FINDING:-}" = "1" ]; then
-  printf '{"schema_version":1,"dispatch_id":"%s","reviewer_agent":"claude","verdict":"approve","summary":"plan is approved with advice","findings":[{"severity":"warning","message":"Consider documenting the optional recovery example."}]}\n' "$dispatch_id"
+  printf '{"schema_version":1,"dispatch_id":"%s","reviewer_agent":"claude","verdict":"approve","summary":"plan is approved with advice","findings":[{"severity":"warning","message":"Consider documenting the optional recovery example."}],"evidence_records":{"schema_version":1,"records":[]}}\n' "$dispatch_id"
 else
-  printf '{"schema_version":1,"dispatch_id":"%s","reviewer_agent":"claude","verdict":"approve","summary":"plan is approved","findings":[]}\n' "$dispatch_id"
+  printf '{"schema_version":1,"dispatch_id":"%s","reviewer_agent":"claude","verdict":"approve","summary":"plan is approved","findings":[],"evidence_records":{"schema_version":1,"records":[]}}\n' "$dispatch_id"
 fi
 `,
     { mode: 0o755 },
@@ -679,7 +706,7 @@ describe('implementation-time discoveries return to the affected planning phase'
   ] as const)(
     'routes %s repair from implementation through the installed CLI',
     async (discovery, planningDestination, expectedPhase) => {
-      const project = fixture(false);
+      const project = fixture(false, 'approved', true);
       writeFileSync(
         project.ticketPath,
         readFileSync(project.ticketPath, 'utf8').replace(
@@ -733,7 +760,14 @@ describe('implementation-time discoveries return to the affected planning phase'
       expect(result.stdout).toContain(`"planning_destination":"${planningDestination}"`);
 
       if (planningDestination === 'plan-implementation') {
-        const revisedImplementationPlan = `${PLAN}\nAccepted authorization uses the revised boundary.\n`;
+        const currentImplementationPlan = readFileSync(
+          nodePath.join(project.ticketDirectory, 'impl-plan.md'),
+          'utf8',
+        );
+        const revisedImplementationPlan = currentImplementationPlan.replace(
+          '## Decisions\n',
+          '## Decisions\n\nAccepted authorization uses the revised boundary.\n',
+        );
         writeFileSync(
           nodePath.join(project.ticketDirectory, 'impl-plan.md'),
           revisedImplementationPlan,
@@ -799,6 +833,92 @@ describe('implementation-time discoveries return to the affected planning phase'
   );
 });
 
+describe('repair must precede renewed planning approval', () => {
+  it('refuses reuse of the old current-context approval after an execution discovery', async () => {
+    const project = fixture(false, 'approved', true);
+    const args = ['--json', '--no-input', 'ticket', 'approve-plan', TICKET_ID];
+    const accepted = await runCli(args, { cwd: project.root, env: reviewEnvironment(project) });
+    expect(accepted.exitCode, accepted.stdout).toBe(0);
+    expect(phase(project.ticketPath)).toBe('plan-execution');
+    writeFileSync(
+      project.ticketPath,
+      readFileSync(project.ticketPath, 'utf8').replace('phase: plan-execution', 'phase: implement'),
+    );
+    const executionPlanPath = nodePath.join(project.ticketDirectory, 'execution-plan.md');
+    writeFileSync(
+      executionPlanPath,
+      replanExecutionPlan('Accepted authorization approach changed'),
+    );
+    const reviewerBin = installBlockingReviewer();
+    const reviewed = await runCli(
+      [
+        '--json',
+        '--no-input',
+        'review',
+        'run',
+        'plan-execution',
+        nodePath.relative(project.root, executionPlanPath),
+        '--context',
+        nodePath.relative(project.root, nodePath.join(project.ticketDirectory, 'impl-plan.md')),
+        '--context',
+        'features/review-the-approach.feature',
+        '--cwd',
+        project.root,
+      ],
+      {
+        cwd: project.root,
+        env: {
+          PATH: `${reviewerBin}:/usr/bin:/bin`,
+          SAFEWORD_AGENT_RUNTIME: 'codex',
+          SAFEWORD_NO_UPDATE_CHECK: '1',
+          SAFEWORD_REVIEW_FOREGROUND_MS: '5000',
+          ...reviewEnvironment(project),
+        },
+      },
+    );
+    expect(reviewed.exitCode, reviewed.stdout).toBe(2);
+    expect(reviewed.stdout).toContain('"planning_destination":"plan-implementation"');
+    const returned = await runCli(args, { cwd: project.root, env: reviewEnvironment(project) });
+    expect(returned.exitCode, returned.stdout).toBe(2);
+    expect(phase(project.ticketPath)).toBe('plan-implementation');
+    const unrepaired = await runCli(args, { cwd: project.root, env: reviewEnvironment(project) });
+    expect(unrepaired.exitCode, unrepaired.stdout).toBe(2);
+    expect(unrepaired.stdout).toContain(
+      'no current authenticated Implementation Plan review receipt',
+    );
+    expect(phase(project.ticketPath)).toBe('plan-implementation');
+  });
+});
+
+describe('legacy review reuse after a planning return', () => {
+  it('preserves an untouched legacy review but refuses it after a recorded discovery', async () => {
+    const project = fixture(false);
+    const legacyId = 'PLAN43';
+    addReviewedTicket(project, legacyId, 'The retained legacy approach.');
+    const legacyPath = nodePath.join(
+      project.root,
+      '.project',
+      'tickets',
+      `${legacyId}-review-the-approach`,
+      'ticket.md',
+    );
+    const args = ['--json', '--no-input', 'ticket', 'approve-plan', legacyId];
+    const untouched = await runCli(args, { cwd: project.root, env: reviewEnvironment(project) });
+    expect(untouched.exitCode, untouched.stdout).toBe(0);
+    writeFileSync(
+      legacyPath,
+      `${readFileSync(legacyPath, 'utf8').replace(
+        'phase: plan-execution',
+        'phase: plan-implementation',
+      )}\n### Execution discovery requiring fresh planning review\n\n> Repair the accepted authorization boundary.\n`,
+    );
+    const returned = await runCli(args, { cwd: project.root, env: reviewEnvironment(project) });
+    expect(returned.exitCode, returned.stdout).toBe(2);
+    expect(phase(legacyPath)).toBe('plan-implementation');
+    expect(returned.stdout).toContain('Convert its retained plan and design decisions');
+  });
+});
+
 describe('an accepted design enters Execution Planning', () => {
   it('binds the approval to the exact approach bytes before advancing', () => {
     const project = fixture(true);
diff --git a/packages/cli/tests/integration/plan-execution-journey.test.ts b/packages/cli/tests/integration/plan-execution-journey.test.ts
index 187c39fd8..9b788649d 100644
--- a/packages/cli/tests/integration/plan-execution-journey.test.ts
+++ b/packages/cli/tests/integration/plan-execution-journey.test.ts
@@ -202,29 +202,29 @@ fi
 payload=$(cat)
 dispatch_id=$(printf '%s' "$payload" | sed -n 's/.*"dispatch_id":"\([^"]*\)".*/\1/p')
 if ! printf '%s' "$payload" | /usr/bin/grep -Fq '"kind":"plan-execution"'; then
-  printf '{"schema_version":1,"dispatch_id":"%s","reviewer_agent":"claude","verdict":"approve","summary":"approved","findings":[]}\n' "$dispatch_id"
+  printf '{"schema_version":1,"dispatch_id":"%s","reviewer_agent":"claude","verdict":"approve","summary":"approved","findings":[],"evidence_records":{"schema_version":1,"records":[]}}\n' "$dispatch_id"
   exit 0
 fi
 if printf '%s' "$payload" | /usr/bin/grep -Fq '${CONCRETE_PROOF_CONTRACT_SIGNAL}'; then
   if printf '%s' "$payload" | /usr/bin/grep -Fq 'TBD CLI boundary'; then
-    printf '{"schema_version":1,"dispatch_id":"%s","reviewer_agent":"claude","verdict":"request_changes","summary":"missing subprocess boundary","findings":[{"severity":"error","message":"The test step must name the installed CLI subprocess boundary."}],"planning_destination":"plan-execution","execution_plan_record":null}\n' "$dispatch_id"
+    printf '{"schema_version":1,"dispatch_id":"%s","reviewer_agent":"claude","verdict":"request_changes","summary":"missing subprocess boundary","findings":[{"severity":"error","message":"The test step must name the installed CLI subprocess boundary."}],"evidence_records":{"schema_version":1,"records":[]},"planning_destination":"plan-execution","execution_plan_record":null}\n' "$dispatch_id"
     exit 0
   fi
   if printf '%s' "$payload" | /usr/bin/grep -Fq 'TBD denied-exit result'; then
-    printf '{"schema_version":1,"dispatch_id":"%s","reviewer_agent":"claude","verdict":"request_changes","summary":"missing exit-code assertion","findings":[{"severity":"error","message":"The test step must name the denied exit-code assertion."}],"planning_destination":"plan-execution","execution_plan_record":null}\n' "$dispatch_id"
+    printf '{"schema_version":1,"dispatch_id":"%s","reviewer_agent":"claude","verdict":"request_changes","summary":"missing exit-code assertion","findings":[{"severity":"error","message":"The test step must name the denied exit-code assertion."}],"evidence_records":{"schema_version":1,"records":[]},"planning_destination":"plan-execution","execution_plan_record":null}\n' "$dispatch_id"
     exit 0
   fi
 fi
 if printf '%s' "$payload" | /usr/bin/grep -Fq '4. TODO: decide whether denied authorization returns an error or an empty result'; then
-  printf '{"schema_version":1,"dispatch_id":"%s","reviewer_agent":"claude","verdict":"request_changes","summary":"task 4 requires a behavior decision","findings":[{"severity":"error","message":"Task 4 requires a behavior decision before implementation."}],"planning_destination":"plan-implementation","execution_plan_record":null}\n' "$dispatch_id"
+  printf '{"schema_version":1,"dispatch_id":"%s","reviewer_agent":"claude","verdict":"request_changes","summary":"task 4 requires a behavior decision","findings":[{"severity":"error","message":"Task 4 requires a behavior decision before implementation."}],"evidence_records":{"schema_version":1,"records":[]},"planning_destination":"plan-implementation","execution_plan_record":null}\n' "$dispatch_id"
   exit 0
 fi
 if ! printf '%s' "$payload" | /usr/bin/grep -Fq '${REVIEW_CONTRACT_SIGNAL}'; then
-  printf '{"schema_version":1,"dispatch_id":"%s","reviewer_agent":"claude","verdict":"request_changes","summary":"the first step is not startable","findings":[{"severity":"error","message":"Execution Planning does not require a named first RED."}],"planning_destination":"plan-execution","execution_plan_record":null}\n' "$dispatch_id"
+  printf '{"schema_version":1,"dispatch_id":"%s","reviewer_agent":"claude","verdict":"request_changes","summary":"the first step is not startable","findings":[{"severity":"error","message":"Execution Planning does not require a named first RED."}],"evidence_records":{"schema_version":1,"records":[]},"planning_destination":"plan-execution","execution_plan_record":null}\n' "$dispatch_id"
   exit 0
 fi
 review_record=$(printenv SAFEWORD_REVIEW_FAKE_EXECUTION_PLAN_RECORD || true)
-printf '{"schema_version":1,"dispatch_id":"%s","reviewer_agent":"claude","verdict":"approve","summary":"the named RED is startable","findings":[],"planning_destination":"plan-execution","execution_plan_record":%s}\n' "$dispatch_id" "$review_record"
+printf '{"schema_version":1,"dispatch_id":"%s","reviewer_agent":"claude","verdict":"approve","summary":"the named RED is startable","findings":[],"evidence_records":{"schema_version":1,"records":[]},"planning_destination":"plan-execution","execution_plan_record":%s}\n' "$dispatch_id" "$review_record"
 `,
     { mode: 0o755 },
   );
@@ -280,7 +280,7 @@ describe('Execution Plan cold-start journey', () => {
       mkdirSync(nodePath.join(root, 'src'), { recursive: true });
       writeFileSync(
         nodePath.join(root, '.safeword', 'config.json'),
-        `${JSON.stringify({ designApprovalGate: false, crossAgentReviewRoutes: { codex: [{ reviewer: 'claude', model: 'opus' }] } })}\n`,
+        `${JSON.stringify({ designApprovalGate: false, crossAgentReviewRoutes: { codex: [{ reviewer: 'claude', model: 'claude-opus-5' }] } })}\n`,
       );
       writeFileSync(nodePath.join(root, '.safeword', 'SAFEWORD.md'), '# Safeword\n');
       writeFileSync(
@@ -538,7 +538,7 @@ describe('Execution Plan cold-start journey', () => {
             '--phase',
             request.kind,
             '--model',
-            'opus',
+            'claude-opus-5',
             '--author-agent',
             'codex',
             '--reviewer-agent',
@@ -773,7 +773,7 @@ describe('Execution Plan cold-start journey', () => {
       mkdirSync(nodePath.join(root, 'tests'), { recursive: true });
       writeFileSync(
         nodePath.join(root, '.safeword', 'config.json'),
-        `${JSON.stringify({ designApprovalGate: false, crossAgentReviewRoutes: { codex: [{ reviewer: 'claude', model: 'opus' }] } })}\n`,
+        `${JSON.stringify({ designApprovalGate: false, crossAgentReviewRoutes: { codex: [{ reviewer: 'claude', model: 'claude-opus-5' }] } })}\n`,
       );
       writeFileSync(nodePath.join(root, '.safeword', 'SAFEWORD.md'), '# Safeword\n');
       writeFileSync(
