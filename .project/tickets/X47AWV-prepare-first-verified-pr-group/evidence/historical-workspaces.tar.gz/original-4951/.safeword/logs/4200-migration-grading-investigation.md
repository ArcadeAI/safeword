Decision: stop repeated literal-phrase false negatives while preserving proof that the reviewer detected missing migration completion evidence.
Options: (1) append another phrase; (2) require the concepts migration + proof + completion using the existing AND matcher; (3) rebuild the negative into an isolated minimal pair or introduce semantic LLM grading.
Research plan before choosing:
- Grader validity: what deterministic checks can establish, what their word-level boundary cannot; current authoritative eval guidance.
- Fixture and contract semantics: compare the two observed outputs with accepted migration, proof, and completion obligations; test misleading dependency-only wording.
- Implementation and scope cost: use existing matcher, keep all IDs/verdicts/destinations and admission/authentication unchanged; avoid new schema, model, or broad corpus changes.

Evidence and decision:
- Anthropic's current eval guidance identifies deterministic string checks as fast and reproducible but brittle to valid wording, while model graders require calibration: https://www.anthropic.com/engineering/demystifying-evals-for-ai-agents
- OpenAI documents exact and substring string checks as specific operations, not semantic entailment: https://developers.openai.com/api/docs/guides/graders
- Both authenticated Astra outputs correctly reject with plan-execution and demand all migration proofs as a prerequisite to completion. One says "for slice completion", the next "for completion". The approved phrase extension remained a lexical false negative.
- Adding "for completion" is smallest today but preserves the same recurring failure. A semantic judge is more flexible but introduces model, route, calibration and qualification obligations. Rebuilding the fixture has broader behavior and proof-definition changes.
- Recommend the existing AND matcher with three required concepts: migration, proof, completion. No new parser, schema, judge, production rubric, route, or identity policy. Add discriminating checks for the two observed valid rejections, dependency-only wording, missing completion, and missing migration.
- Premortem: a finding can contain all three concepts without entailing the defect. This is the existing coarse grader limit, not a semantic guarantee; preserve this limitation and exact required verdict/destination/null-record checks. The dependency-only false positive identified by Claude is excluded because it lacks proof.

The prepared patch is unapplied pending human test-change approval. Review its correctness and scope; distinguish actual blockers from optional precision hardening.
