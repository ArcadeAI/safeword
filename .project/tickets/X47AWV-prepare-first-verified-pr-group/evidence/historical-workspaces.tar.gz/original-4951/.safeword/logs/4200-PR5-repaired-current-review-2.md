Review PR #5139 complete committed non-bundled own-slice diff, part 2/10. Parent 854a376861bc034d65cc81ddfa6a85d0ae55821e; head 95c264f1282884bc803f0ba0db7537380c66bcff. Every non-bundled changed file is supplied across all parts. Compiled CLI bundle diffs excluded; source and generators included and all five generated surface checks passed. Review concrete correctness, authenticated approval, actual rejection findings, semantic scope, currency and test discrimination within accepted plans. Qualified Execution default is gpt-6.1-sol paired with Claude Opus 5; six canonical proof surfaces still byte-identical to qualified candidate. Full package 11415 pass, zero fail, 14 skip; release 82 pass. Actual root acceptance running; 110 undefined previously, historical six failures/585 unfinished retained. Do not infer complete acceptance or merge readiness from package tests. Already approved fixture corrections and release identities preserve rejections. Optional hardening is non-blocking; do not expand accepted scope. Review supplied complete source and generation rather than claiming raw compiled-byte inspection. No PR merge or Ready authority.

diff --git a/.project/tickets/5F5ZZA-keep-plan-reviews-current-and-trustworthy/execution-plan.md b/.project/tickets/5F5ZZA-keep-plan-reviews-current-and-trustworthy/execution-plan.md
index 516c9f85f..075d9f50f 100644
--- a/.project/tickets/5F5ZZA-keep-plan-reviews-current-and-trustworthy/execution-plan.md
+++ b/.project/tickets/5F5ZZA-keep-plan-reviews-current-and-trustworthy/execution-plan.md
@@ -24,9 +24,16 @@ integrates with those contracts without redefining them.
 
 The repository already has phase-specific reviewers, an authenticated review
 coordinator and job store, an append-only review ledger, and phase admission.
-It does not yet have one complete planning-context resolver, semantic review
-identity, generated shared contract source, or authenticated reduced-
-independence receipt path.
+The stacked branches now implement the planning-context resolver, semantic
+review identity, generated shared contracts, and authenticated reduced-
+independence receipt path. Implementation does not establish current acceptance:
+R4 exact-contract and R8 guidance corrections are uncommitted and need fresh
+RED evidence after fixture changes before GREEN can be claimed. R9's
+unsupported-direction rejection and semantic upstream correction are committed
+at bf758b53f52d40f3d7288f285937dcb717554a26, with current-main verification and
+owning-slice placement pending. R9's upstream canonical-contract dependency
+correction is not implemented. The checklist stays open until current proof is
+recorded.
 
 During this ticket's Implementation Plan approval, an approved cross-agent
 review with warnings still failed `ticket approve-plan`. Phase admission
@@ -37,6 +44,51 @@ reported findings from the latest approved review because it did not restrict
 stamp allowed the transition, confirming both defects. PR 1 fixes them before
 the broader provenance changes.
 
+### Resume execution status
+
+The tasks below preserve the original build sequence; they are not instructions
+to manufacture fresh REDs for implemented behavior. Their current status is:
+
+| Slice | Implemented behavior to characterize and verify | Open corrective work |
+| --- | --- | --- |
+| PR 1 | Both approval/rejection tasks and their production fix | Exact-head final review and current validation |
+| PR 2 | Shared generation and installed-copy integrity; unsupported-direction rejection committed on the stack | Task 2: place the correction in its owning slice and verify current main |
+| PR 3 | Context resolution, semantic currency, disposition recording; semantic upstream correction committed on the stack | Tasks 2–3: place existing corrections, refresh exact-contract proof, and implement upstream canonical-contract dependency |
+| PR 4 | Fallback routing, installed gates, capability corpus | Task 3: installed advisory guidance; live model confirmation and release proof |
+| PR 5 | Evidence records and scope judgment | Current nondeferred acceptance, evals, and exact-head review; R7 host retrieval remains deferred |
+
+For implemented tasks, run the named command as characterization; passing is
+the expected outcome. Historical RED/GREEN evidence stays in the ledger. A new
+failure is investigated rather than relabeled as the original RED. Only the
+corrective partitions above enter a new RED/GREEN/REFACTOR loop. Characterize
+PR 2's implemented R9 rejection: `scripts/dev bun run --cwd packages/cli test
+ tests/integration/planning-contract-generation.test.ts -t "unsupported own-review-only"`
+must reject the invalid contract. PR 3's implemented semantic upstream correction
+must change identity after a semantic upstream edit in
+`tests/review/execution-role-context.test.ts`. These are characterization runs,
+not new RED claims. The unimplemented upstream contract-byte dependency enters
+the new paired R9 RED loop.
+
+R4's primary corrective RED runs from the root:
+
+```bash
+scripts/dev node --import tsx node_modules/.bin/cucumber-js features/keep-plan-reviews-current-and-trustworthy.feature --name '^Context identity ignores cosmetic and unrelated edits$' --tags 'not @wip and not @proof.vitest and not @manual and not @live'
+```
+
+Its missing behavior is the cosmetic bounded-contract example retaining approval;
+the semantic mutation is the passing control. R8's primary corrective RED runs:
+
+```bash
+scripts/dev node --import tsx node_modules/.bin/cucumber-js features/keep-plan-reviews-current-and-trustworthy.feature --name '^(Generated Codex Cloud instructions cannot claim a gated approval|OpenCode Desktop guidance cannot claim a gated approval|Generated guidance identifies gated surfaces as enforced)$' --tags 'not @wip and not @proof.vitest and not @manual and not @live'
+```
+
+Its missing behavior is installed guidance omitting the supported/advisory
+boundary and supported redirect. These commands are the first corrective proofs,
+not a claim that the existing lower-level documentation tests currently fail.
+PR 3 context characterization includes an Execution Plan with no data declaration
+whose accepted Implementation Plan triggers current data guidance; installed
+Claude dispatch must enforce the same completeness boundary.
+
 ## PR 1 — Make approved planning receipts advance truthfully
 
 - **Purpose:** Ensure the canonical planning gate accepts one authenticated
@@ -58,15 +110,18 @@ the broader provenance changes.
 
 ### Tasks and tests
 
-1. RED: Extend
+1. Proof: Extend
    `packages/cli/tests/integration/plan-design-approval.test.ts` with the exact
    reproduced case: a current coordinator approval with warning findings and a
    phase review stamp, but no redundant artifact self-stamp. Run
-   `bun run test tests/integration/plan-design-approval.test.ts`; before GREEN
+   `bun run test tests/integration/plan-design-approval.test.ts`; in the original RED
    it must fail because approval still requires the second stamp.
-2. RED: In the same real CLI harness, prove `changes_requested` returns only
+2. Proof: In the same real CLI harness, prove `changes_requested` returns only
    its rejection findings, while missing or stale evidence returns the typed
    admission failure and never concatenates findings from an approved review.
+   Run `bun run test tests/integration/plan-design-approval.test.ts` through `scripts/dev`; in the original RED, assert the
+   new case fails because approved warning findings appear in a refusal or actual rejection findings are omitted.
+
 3. GREEN: Make `phaseReviewAdmission` the sole authenticated current-review
    decision used by plan approval. Remove the duplicate content-bound
    `currentReview` check rather than teaching users to mint a second weaker
@@ -98,23 +153,25 @@ the broader provenance changes.
 - **Completion signal:** There is one source for shared lifecycle, scope-
   authority, trust, and contract-shape clauses; every installed copy is exact;
   and each approval still claims only behavior, design, or startable delivery.
+  Do not cut a release between PR 2 and PR 4; the merged intermediate slices
+  are development states, not supported published packages.
   No later slice depends on semantic review identity until PR 3 proves that
   identity through the real coordinator and admission path.
 - **Relies on an unmerged successor:** no
 
 ### Tasks and tests
 
-1. RED: Add
+1. Proof: Add
    `packages/cli/tests/integration/planning-contract-generation.test.ts` for R1,
    R5, and R10. Through real generators and a fresh installed project, assert a
    shared-clause edit changes every marked copy, phase-only clauses stay local,
    a missing or altered block fails reconciliation, and no phase approval can
    claim a downstream state. Run
    `bun run test tests/integration/planning-contract-generation.test.ts`;
-   Initial RED established the missing shared-clause source. Subsequent bounded
-   loops attest the missing generator output or lifecycle gate named in their
-   ledger proof row; completed source generation is not relabeled RED.
-2. RED: Add exact-byte partitions for authoring, review dispatch, and phase
+   in the original RED, the new shared-source propagation assertion must fail because
+   no single source updates every marked contract. Historical passing source
+   generation remains checked; corrective missing-copy cases have their own RED.
+2. Proof: Add exact-byte partitions for authoring, review dispatch, and phase
    admission. Each rejects an installed-copy mismatch and accepts canonical
    generated bytes; a missing marked clause returns
    `missing_generated_shared_clause` with its clause ID and affected planning
@@ -127,6 +184,9 @@ the broader provenance changes.
    change. Keep missing, unknown, unknown-suffix, duplicate, and contradictory
    values in `planning-contract-generation.test.ts` as variations of that one
    outcome.
+   Run `bun run test tests/integration/planning-contract-generation.test.ts tests/integration/installed-planning-copy-admission.test.ts` through `scripts/dev`; in the original RED, assert the
+   new case fails because an altered or missing installed contract advances, or an undecidable invalidation declaration writes installed bytes.
+
 3. GREEN: Add the smallest typed shared-clause source and generator. Generate
    the three author contracts and three reviewer-rubric blocks, register every
    canonical/generated asset, and wire one exact-copy conformance check into
@@ -180,7 +240,7 @@ reopening its authority.
 
 ### Tasks and tests
 
-1. RED: Add `packages/cli/tests/review/planning-context.test.ts` for the closed
+1. Proof: Add `packages/cli/tests/review/planning-context.test.ts` for the closed
    `PlanningContextRole` model. Cover each phase's required-role matrix,
    including principles, personas, and affected surfaces for Execution review,
    justified absence, defaults versus stale/blank/unreadable overrides,
@@ -194,7 +254,10 @@ reopening its authority.
    unrelated parent-job edits retain approval. A child Product Plan review must
    receive inherited epistemic fields through the real resolver. A declared
    missing parent or required blank/missing/ambiguous framing fails closed.
-2. RED: Add
+   Run `bun run test tests/review/planning-context.test.ts` through `scripts/dev`; in the original RED, assert the
+   new case fails because required context is absent from the packet or an invalid override resolves permissively.
+
+2. Proof: Add
    `packages/cli/tests/integration/planning-review-identity.test.ts`. Through
    packet preparation, coordinator persistence, status, stamp, and admission,
    mutate whitespace/comments and unrelated inventory, then every decision-
@@ -207,22 +270,41 @@ reopening its authority.
    and unreferenced persona edits retain approval. No fourth planning contract
    or new inventory authority is introduced.
    Exercise the canonical R9 dependency direction with the same mechanics.
-   Generate/reconcile the canonical contract, then review both plans.
-   A semantic upstream Implementation change stales both reviews under
-   `both_plan_reviews`. The upstream role remains required and currency-bearing
-   in the packet and admission validation; missing or invalid input blocks.
-   Reconciliation rejects `implementation_review_only` before changing installed
-   contract bytes. Assert that changing the
-   declaration itself stales old receipts, and malformed/unknown/missing modes
-   fail closed. Do not use a mocked status or a separate per-mode code path.
-3. RED: Change corrected Product/Implementation plan bytes, every stable
-   Execution Plan field, canonical semantic contract bytes, ticket identity,
+   Add paired canonical-contract mutations through the real coordinator,
+   status, stamp, and admission entry points: changing Implementation contract
+   bytes stales both receipts; changing only Execution contract bytes stales
+   only Execution. Capture an authentic failing RED before adding the upstream
+   canonical contract to the existing accepted-upstream dependency projection.
+   Packet-level paired mutation checks in
+   `tests/review/execution-role-context.test.ts` support this integration proof;
+   they do not replace it. Retain outside-marker cosmetic stability and reject
+   missing upstream canonical identity. This correction belongs to PR 3's
+   existing context/currency task, with no new approval store or schema version.
+   A semantic upstream Implementation change must stale both reviews under
+   `both_plan_reviews`; the upstream role remains required and currency-bearing.
+   Reconciliation must reject `implementation_review_only` before changing
+   installed contract bytes. Missing, unknown, duplicate, and contradictory
+   declarations also fail closed. Do not use mocked status or a separate
+   configurable dependency path.
+   Run `bun run test tests/integration/planning-review-identity.test.ts` through `scripts/dev`; in the original RED, assert the
+   new case fails because a changed required dependency retains approval or a cosmetic dependency loses it.
+
+3. Proof: Change corrected Product/Implementation plan bytes, every stable
+   Execution Plan field, exact bounded canonical contract bytes, ticket identity,
    and review kind. None may inherit the prior verdict; a fresh matching verdict
    restores admission. Then change only ordinary contributor-row Disposition,
    Evidence class, Revision, and final evidence cells and prove the accepted
    Execution review remains current. This deterministic proof remains required
    in addition to the later judged eval.
-4. RED: In the same integration harness, authenticate a nonblocking optional
+   Run `bun run test tests/integration/planning-review-identity.test.ts tests/integration/planning-context-currency.test.ts` through `scripts/dev`; in the original RED, assert the
+   new case fails because changed bounded canonical bytes or stable plan definition retains approval.
+   In the authenticated job fixture, retain a pre-feature receipt with no
+   review identity and sealed records with malformed or unsupported-version
+   identities. Real status/stamp/admission must deny them without rewriting
+   history. An older-schema reader must ignore unknown identity fields rather
+   than grant authority; a fresh supported receipt restores admission.
+
+4. Proof: In the same integration harness, authenticate a nonblocking optional
    finding, record the user's decline through a real pseudo-terminal, and assert
    `--no-input`, redirected input, and refusal record nothing. Assert the
    command serializes cooperating writers with an exclusive sibling lock,
@@ -231,11 +313,17 @@ reopening its authority.
    of unchanged plan bytes retain the decline. Prove the accepted-boundary
    digest excludes dispositions, covers ticket/project/parent/milestone
    boundaries, and supplies the matching decline to the fresh reviewer rubric
-   without coordinator filtering. Do not claim protection from an out-of-band
+   without coordinator filtering. The public
+   `tests/integration/planning-review-disposition.test.ts` harness must also
+   recover a dead writer's lock on retry and record the complete disposition;
+   a live owner must return `REVIEW_DISPOSITION_WRITE_UNAVAILABLE`, preserve
+   both ticket bytes and the owner's lock, and never force removal.
+   Do not claim protection from an out-of-band
    writer that ignores the lock.
    Run
-   `bun run test tests/integration/planning-review-identity.test.ts`; before
-   GREEN it must fail because no disposition command or ticket field exists.
+   `scripts/dev bun run --cwd packages/cli test tests/integration/planning-review-identity.test.ts tests/integration/planning-review-disposition.test.ts`.
+   Existing command behavior is characterization and must pass; a missing
+   lock partition is added as a characterization proof, not a fabricated RED.
 5. GREEN: Implement the closed resolver and role-specific canonical projector.
    Callers provide ticket identity and review kind only. Fail closed on missing,
    duplicate, unknown, ambiguous, blank, unreadable, or stale required input.
@@ -278,7 +366,7 @@ reopening its authority.
 
 ### Tasks and tests
 
-1. RED: Add
+1. Proof: Add
    `packages/cli/tests/integration/planning-review-fallback.test.ts` and
    `packages/cli/tests/integration/planning-review-zero-independent.test.ts`, and
    `packages/cli/tests/integration/planning-review-route-order.test.ts` for R6.
@@ -299,7 +387,10 @@ reopening its authority.
    the public coordinator, status, stamp, and admission path, crossing `prefer`
    and `require`. The representative capability-outline rows do not replace
    these required partitions; unknown comparison must never mean “not weaker.”
-2. RED: Add
+   Run `bun run test tests/integration/planning-review-fallback.test.ts tests/integration/planning-review-zero-independent.test.ts tests/integration/planning-review-route-order.test.ts` through `scripts/dev`; in the original RED, assert the
+   new case fails because an unattempted stronger route or unqualified comparison authorizes a fallback.
+
+2. Proof: Add
    `packages/cli/tests/integration/planning-review-host-gates.test.ts` with
    installed lifecycle fixtures for Claude Code, OpenAI Codex, Cursor,
    OpenCode CLI/TUI, Claude Code Cloud, and Cursor Cloud Agents. Mock only the
@@ -318,12 +409,18 @@ reopening its authority.
    a qualified weaker pair is refused even after project/user rank overlays.
    Reversing a pair or changing its evidence/corpus/rubric/settings revision
    cannot inherit qualification. Exercise public routing, stamp, and admission.
-3. RED: Add
+   Run `bun run test tests/integration/planning-review-host-gates.test.ts` through `scripts/dev`; in the original RED, assert the
+   new case fails because unverified model metadata grants independence or a stale receipt advances.
+
+3. Proof: Add
    `packages/cli/tests/integration/planning-documentation.test.ts`. Assert the
    older coordinator ADR carries the reciprocal supersession marker, generated
    Codex Cloud and OpenCode Desktop guidance is advisory only, and every gated
    surface names its actual enforcement boundary.
-4. RED: Add the pinned reviewer-capability manifest and human-labelled Product,
+   Run `bun run test tests/integration/planning-documentation.test.ts` through `scripts/dev`; in the original RED, assert the
+   new case fails because installed advisory guidance claims authoritative approval or omits its supported redirect.
+
+4. Proof: Add the pinned reviewer-capability manifest and human-labelled Product,
    Implementation, and Execution Plan corpus. Add
    `bun run test:eval:reviewer-capability` for three deterministic runs per
    exact model. A run passes only with the expected verdict, every required
@@ -339,6 +436,26 @@ reopening its authority.
    fails when a shipped default cross-vendor pair lacks
    supported ordering or the live adapter confirmation proof required for its
    claimed independence.
+   Run `bun run test:eval:reviewer-capability` through `scripts/dev`; in the original RED, assert the
+   new case fails because an unsupported ordered pair qualifies or a pinned required finding is absent.
+
+   Add `tests/smoke/planning-review-model-confirmation.live.test.ts` before
+   changing adapter behavior. Install the packaged runtime in a fresh project;
+   invoke real Claude and Codex through the public coordinator with each exact
+   packaged default selector. Assert the recorded provider/model equals the
+   launched exact selector, with a completed matching Codex thread/turn and
+   Claude assistant/result agreement. A reroute, unavailable selector, missing
+   metadata, timeout, or skipped route cannot pass. Run
+   `../../scripts/dev env SAFEWORD_RUN_PLANNING_MODEL_LIVE=1 bun run test:smoke:live tests/smoke/planning-review-model-confirmation.live.test.ts`
+   from `packages/cli`; before GREEN, a missing or mismatched confirmed model
+   must fail its exact identity assertion. Process-boundary fixtures retain the
+   adversarial wrong-thread/turn and reroute cases; a live success proves the
+   actual supported protocol, not the absence of every possible reroute.
+   Run `../../scripts/dev bun run test:release` from `packages/cli`; packaged
+   capability and plugin release cases must fail a missing comparison, stale
+   corpus/rubric/settings digest, or unsupported default pair. No skipped live
+   route or historic model confirmation satisfies the current live proof.
+
 5. GREEN: Generate packaged ordered-pair comparisons only from admitted evidence; retain exact
    model, corpus/rubric/settings digests, evidence date, and results digest.
    Provider-documented within-family order may supplement the catalogue, but
@@ -398,25 +515,34 @@ reopening its authority.
   versioned fixed-rubric eval runs three deterministic repetitions and requires
   at least two agreeing correct verdicts per fixture; below threshold is
   inconclusive, never passing. The complete feature runs through Cucumber.
-- **Completion signal:** All accepted scenarios are GREEN/REFACTOR, the pinned eval
-  passes 2-of-3, customer docs explain the bounded planning approvals and host
-  matrix, and the contributor checklist has current evidence.
+- **Completion signal:** The nondeferred scenario boundaries have current
+  GREEN/REFACTOR evidence, the pinned eval passes 2-of-3, and customer docs and
+  contributor proofs are current. R7's planning-agent retrieval boundary remains
+  unproved under the user's deferral; packet or judged proof cannot close it.
+  The open human deferral item prevents claiming complete R7, feature, or epic
+  acceptance. This bounded code-delivery signal grants no merge authority.
 - **Relies on an unmerged successor:** no
 
 ### Tasks and tests
 
-1. RED: Add
+1. Proof: Add
    `packages/cli/tests/integration/planning-evidence-boundary.test.ts`. Through
    real planning/review packet preparation, prove retrieved instructions cannot
    alter scope, code snippets are not run, public evidence remains usable
    without sending private context, and absent reuse limits are not invented.
    Cover both `PlanEvidenceRecordV1` in Implementation Inspiration and the
    reviewer verdict's durable evidence record.
-2. RED: Add a versioned `evidence_records` collection to new job-result fixtures with
+   Run `bun run test tests/integration/planning-evidence-boundary.test.ts` through `scripts/dev`; in the original RED, assert the
+   new case fails because untrusted packet evidence changes accepted authority or loses its reuse limits.
+
+2. Proof: Add a versioned `evidence_records` collection to new job-result fixtures with
    source identity, claims, license, attribution, redistribution, security,
    privacy, and reuse limits. Prove persistence in the existing job record,
    integrity coverage, authority-inert older-schema reading, and no backfill.
-3. RED: Add
+   Run `bun run test tests/review/job.test.ts tests/integration/planning-evidence-boundary.test.ts` through `scripts/dev`; in the original RED, assert the
+   new case fails because an evidence record is dropped, accepted despite broken integrity, or gains authority under an unsupported schema.
+
+3. Proof: Add
    `packages/cli/tests/integration/planning-scope-review.test.ts`. Through the
    installed three phase entry points, cover all binding ticket/project/
    milestone/parent boundaries, omission and overreach, optional strengthening,
@@ -430,11 +556,14 @@ reopening its authority.
    editing customer docs; its new cases must fail until README and website
    content state exact plan/context currency, bounded phase authority, fallback
    assurance, recovery, and the enforced/advisory host split.
-4. RED: Add a versioned judged-eval manifest/corpus for R7 and R10–R16. Pin
+   Run `bun run test tests/integration/planning-scope-review.test.ts tests/integration/planning-documentation.test.ts tests/hooks/product-plan-contract.test.ts` through `scripts/dev`; in the original RED, assert the
+   new case fails because omission or overreach advances, or the customer guidance omits an accepted authority boundary.
+
+4. Proof: Add a versioned judged-eval manifest/corpus for R7 and R10–R16. Pin
    judge identity, rubric digest, deterministic settings, repetitions `3`,
    agreement threshold `2`, expected verdict, allowed finding authority, and
    forbidden scope expansion. Run `bun run test:eval:planning-contracts`;
-   before GREEN it must fail adversarial omissions, overreach, instruction
+   in the original RED it must fail adversarial omissions, overreach, instruction
    injection, and corrected-byte cases.
 5. GREEN: Reuse the existing quarantine/parser, emit `PlanEvidenceRecordV1` in
    Implementation Inspiration entries, and persist reviewer evidence records in
@@ -449,7 +578,7 @@ reopening its authority.
 8. REFACTOR: Remove redundant rubric prose after parity. Keep deterministic
    boundary tests separate from model evals and evals out of default fast tests.
 9. Run:
-   `bun run test tests/integration/planning-evidence-boundary.test.ts tests/integration/planning-scope-review.test.ts tests/integration/planning-documentation.test.ts tests/hooks/product-plan-contract.test.ts tests/review/plan-state-truthfulness.test.ts`.
+   `bun run test tests/integration/planning-evidence-boundary.test.ts tests/integration/planning-scope-review.test.ts tests/integration/planning-documentation.test.ts tests/hooks/product-plan-contract.test.ts tests/integration/plan-state-truthfulness.test.ts`.
 10. Add the aggregate `test:eval:planning-reviews` script, then run it to prove
     both the reviewer-capability catalogue and semantic planning contracts.
 11. Run:
@@ -491,8 +620,13 @@ reopening its authority.
   or backfill and keeps older records authority-inert.
 - G1C9PP owns 30–60 minute focused reviewability and its receipt judgment; this
   ticket preserves the bounded contract that judgment consumes.
-- `skip: no other behavior, design, proof, rollout, or documentation obligation
-is deferred outside the five PRs above.`
+- User-accepted 2026-09-30 deferral: host-level hostile-content injection at the
+  planning agent's retrieval boundary. The user owns reopening or changing that
+  deferral; the contributor owns producing its boundary evidence once reopened.
+  Packet quarantine and the judged corpus do not prove host instruction refusal,
+  nonexecution, or nondisclosure. R7, feature, and epic acceptance remain open.
+  The Delivery Checklist's `retrieval-proof-deferral` item retains this gap even
+  if every narrower command passes; the risk acceptance grants no merge authority.
 
 ## Decision accounting
 
@@ -502,8 +636,8 @@ is deferred outside the five PRs above.`
   `changes_requested` reviewer rejection findings. Human design approval remains
   separate. PR 1 and `phase-approval-proof` carry this decision.
 
-- Bind each verdict to exact plan bytes plus semantic canonical-contract and
-  context projections, while gating generated copies by exact bytes separately:
+- Bind each verdict to exact plan bytes plus exact bounded canonical-contract
+  bytes and semantic context projections, while gating generated copies by exact bytes separately:
   unchanged.
 - Extend the existing coordinator and review ledger instead of creating a
   second planning-review subsystem: unchanged.
@@ -512,6 +646,9 @@ is deferred outside the five PRs above.`
 - Treat semantic projection as a closed domain model, not generic Markdown
   normalization: unchanged.
 - Record a user-declined optional strengthening in ticket context: unchanged.
+- Confirm reviewer identity through Codex acknowledged, turn-correlated model
+  metadata and Claude assistant/result usage agreement; never accept argv, a
+  banner, or a selector probe: `unchanged` — PR 4 and `fallback-proof`.
 - Classify reviewer capability from qualified exact ordered pairs and fail closed
   when comparison is unavailable: unchanged.
 - Admit authenticated reduced-independence receipts without discarding stronger
@@ -524,15 +661,20 @@ remains required for structure, wiring, receipt identity, and corrected bytes.
 
 | Proof ID             | Method  | Scope       | Boundary exercised                                                                                                                        | Qualifies as  | Currency         | Invocation                                                                                                                                                                                                                                                                       |
 | -------------------- | ------- | ----------- | ----------------------------------------------------------------------------------------------------------------------------------------- | ------------- | ---------------- | -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
-| phase-approval-proof | command | integration | Installed CLI plan approval through authenticated phase admission and typed rejection rendering                                           | real_boundary | current_required | {"type":"command","cwd":"packages/cli","argv":["bun","run","test","tests/integration/plan-design-approval.test.ts","tests/integration/plan-transition-gate.test.ts","tests/integration/review-receipt-wiring.test.ts"]}                                                          |
-| contract-proof       | command | integration | Canonical generator through schema reconciliation, installed copies, and lifecycle copy checks                                            | real_boundary | current_required | {"type":"command","cwd":"packages/cli","argv":["bun","run","test","tests/integration/planning-contract-generation.test.ts","tests/integration/installed-planning-copy-admission.test.ts","tests/review/plan-rubric-generation.test.ts","tests/review/execution-plan-rubric-generation.test.ts","tests/schema.test.ts","tests/parity.test.ts"]} |
-| identity-proof       | command | integration | Filesystem context resolution through coordinator job, ledger stamp, and phase admission                                                  | real_boundary | current_required | {"type":"command","cwd":"packages/cli","argv":["bun","run","test","tests/review/planning-context.test.ts","tests/integration/planning-review-identity.test.ts","tests/integration/phase-review-gate.test.ts"]}                                                                   |
-| fallback-proof       | command | integration | Coordinator exhaustion through authenticated fallback receipt and installed host gates                                                    | real_boundary | current_required | {"type":"command","cwd":"packages/cli","argv":["bun","run","test","tests/integration/planning-review-fallback.test.ts","tests/integration/planning-review-zero-independent.test.ts","tests/integration/planning-review-route-order.test.ts","tests/integration/planning-review-host-gates.test.ts","tests/review/policy.test.ts","tests/review/surface-parity.test.ts"]}                              |
-| evidence-proof       | command | integration | Retrieval quarantine through durable evidence record and installed planning/review entry points                                           | real_boundary | current_required | {"type":"command","cwd":"packages/cli","argv":["bun","run","test","tests/integration/planning-evidence-boundary.test.ts","tests/integration/planning-scope-review.test.ts","tests/hooks/product-plan-contract.test.ts"]}                                                         |
-| documentation-proof  | command | integration | ADR supersession, customer-facing README/website content, and generated host guidance through exact assertions                            | real_boundary | current_required | {"type":"command","cwd":"packages/cli","argv":["bun","run","test","tests/integration/planning-documentation.test.ts"]}                                                                                                                                                           |
-| planning-evals-proof | command | eval        | Pinned repeated capability-catalogue and semantic-contract corpora exercise exact planning rubrics and default cross-provider comparisons | real_boundary | current_required | {"type":"command","cwd":"packages/cli","argv":["bun","run","test:eval:planning-reviews"]}                                                                                                                                                                                        |
-| feature-proof        | command | E2E         | Complete feature through real Cucumber entry point and step wiring                                                                        | real_boundary | current_required | {"type":"command","cwd":".","argv":["bun","run","test:bdd:acceptance","--","features/keep-plan-reviews-current-and-trustworthy.feature"]}                                                                                                                                        |
-| release-proof        | command | E2E         | Repository smoke boundary after integrated feature changes                                                                                | real_boundary | current_required | {"type":"command","cwd":".","argv":["bun","run","test:smoke"]}                                                                                                                                                                                                                   |
+| phase-approval-proof | command | integration | Installed CLI plan approval through authenticated phase admission and typed rejection rendering | real_boundary | current_required | {"type":"command","cwd":"packages/cli","argv":["../../scripts/dev","bun","run","test","tests/integration/plan-design-approval.test.ts","tests/integration/plan-transition-gate.test.ts","tests/integration/review-receipt-wiring.test.ts"]} |
+| contract-proof | command | integration | Canonical generator through schema reconciliation, installed copies, and lifecycle copy checks | real_boundary | current_required | {"type":"command","cwd":"packages/cli","argv":["../../scripts/dev","bun","run","test","tests/integration/planning-contract-generation.test.ts","tests/integration/installed-planning-copy-admission.test.ts","tests/review/plan-rubric-generation.test.ts","tests/review/execution-plan-rubric-generation.test.ts","tests/schema.test.ts","tests/parity.test.ts"]} |
+| identity-proof | command | integration | Filesystem context resolution through coordinator job, ledger stamp, and phase admission | real_boundary | current_required | {"type":"command","cwd":"packages/cli","argv":["../../scripts/dev","bun","run","test","tests/review/planning-context.test.ts","tests/integration/planning-review-identity.test.ts","tests/integration/planning-review-disposition.test.ts","tests/integration/phase-review-gate.test.ts","tests/integration/planning-context-currency.test.ts","tests/review/job.test.ts"]} |
+| fallback-proof | command | integration | Coordinator exhaustion through authenticated fallback receipt and installed host gates | real_boundary | current_required | {"type":"command","cwd":"packages/cli","argv":["../../scripts/dev","bun","run","test","tests/integration/planning-review-fallback.test.ts","tests/integration/planning-review-zero-independent.test.ts","tests/integration/planning-review-route-order.test.ts","tests/integration/planning-review-host-gates.test.ts","tests/review/policy.test.ts","tests/review/surface-parity.test.ts"]} |
+| evidence-proof | command | integration | Retrieval quarantine through durable evidence record and installed planning/review entry points | real_boundary | current_required | {"type":"command","cwd":"packages/cli","argv":["../../scripts/dev","bun","run","test","tests/integration/planning-evidence-boundary.test.ts","tests/integration/planning-scope-review.test.ts","tests/hooks/product-plan-contract.test.ts"]} |
+| documentation-proof | command | integration | ADR supersession, customer-facing README/website content, and generated host guidance through exact assertions | real_boundary | current_required | {"type":"command","cwd":"packages/cli","argv":["../../scripts/dev","bun","run","test","tests/integration/planning-documentation.test.ts"]} |
+| planning-evals-proof | command | eval | Pinned repeated capability-catalogue and semantic-contract corpora exercise exact planning rubrics and default cross-provider comparisons | real_boundary | current_required | {"type":"command","cwd":"packages/cli","argv":["../../scripts/dev","bun","run","test:eval:planning-reviews"]} |
+| feature-proof | command | E2E | Complete feature through real Cucumber entry point and step wiring | real_boundary | current_required | {"type":"command","cwd":".","argv":["scripts/dev","bun","run","test:bdd:acceptance","--","features/keep-plan-reviews-current-and-trustworthy.feature"]} |
+| release-proof | command | E2E | Repository smoke boundary after integrated feature changes | real_boundary | current_required | {"type":"command","cwd":".","argv":["scripts/dev","bun","run","test:smoke"]} |
+| failure-proof | command | integration | Context, copy, route, identity and origin refusal through their public integration paths | real_boundary | current_required | {"type":"command","cwd":"packages/cli","argv":["../../scripts/dev","sh","-c","bun run test tests/integration/planning-contract-generation.test.ts tests/integration/installed-planning-copy-admission.test.ts tests/review/plan-rubric-generation.test.ts tests/review/execution-plan-rubric-generation.test.ts tests/schema.test.ts tests/parity.test.ts tests/review/planning-context.test.ts tests/integration/planning-review-identity.test.ts tests/integration/planning-review-disposition.test.ts tests/integration/phase-review-gate.test.ts tests/integration/planning-context-currency.test.ts tests/review/job.test.ts tests/integration/planning-review-fallback.test.ts tests/integration/planning-review-zero-independent.test.ts tests/integration/planning-review-route-order.test.ts tests/integration/planning-review-host-gates.test.ts tests/review/policy.test.ts tests/review/surface-parity.test.ts tests/integration/planning-evidence-boundary.test.ts tests/integration/planning-scope-review.test.ts tests/hooks/product-plan-contract.test.ts"]} |
+| complete-testing-proof | command | integration | All named deterministic integration boundaries plus pinned planning evals | real_boundary | current_required | {"type":"command","cwd":"packages/cli","argv":["../../scripts/dev","sh","-c","bun run test tests/integration/plan-design-approval.test.ts tests/integration/plan-transition-gate.test.ts tests/integration/review-receipt-wiring.test.ts tests/integration/planning-contract-generation.test.ts tests/integration/installed-planning-copy-admission.test.ts tests/review/plan-rubric-generation.test.ts tests/review/execution-plan-rubric-generation.test.ts tests/schema.test.ts tests/parity.test.ts tests/review/planning-context.test.ts tests/integration/planning-review-identity.test.ts tests/integration/planning-review-disposition.test.ts tests/integration/phase-review-gate.test.ts tests/integration/planning-context-currency.test.ts tests/review/job.test.ts tests/integration/planning-review-fallback.test.ts tests/integration/planning-review-zero-independent.test.ts tests/integration/planning-review-route-order.test.ts tests/integration/planning-review-host-gates.test.ts tests/review/policy.test.ts tests/review/surface-parity.test.ts tests/integration/planning-evidence-boundary.test.ts tests/integration/planning-scope-review.test.ts tests/hooks/product-plan-contract.test.ts tests/integration/planning-documentation.test.ts && bun run test:eval:planning-reviews"]} |
+| slice-review-proof | review_receipt | integration | Current reviewed slice boundaries, dependencies, and safe intermediate development states; final code review remains required | real_boundary | current_required | {"type":"review_receipt","kind":"plan-execution","targets":[".project/tickets/5F5ZZA-keep-plan-reviews-current-and-trustworthy/execution-plan.md"]} |
+| live-model-proof | command | E2E | Fresh installed coordinator through real Claude/Codex exact-selector model confirmation | real_boundary | current_required | {"type":"command","cwd":"packages/cli","argv":["../../scripts/dev","env","SAFEWORD_RUN_PLANNING_MODEL_LIVE=1","bun","run","test:smoke:live","tests/smoke/planning-review-model-confirmation.live.test.ts"]} |
+| packaged-release-proof | command | integration | Packaged default ordered-pair qualification, current generated runtimes, and release conformance | real_boundary | current_required | {"type":"command","cwd":"packages/cli","argv":["../../scripts/dev","bun","run","test:release"]} |
 
 ## Delivery checklist
 
@@ -540,15 +682,18 @@ remains required for structure, wiring, receipt identity, and corrected bytes.
 
 | ID                     | Category                                  | Obligation                                                                                                                                           | Owner       | Required proof       | Disposition    | Evidence class | Revision | Evidence, reason, or dependency                                                |
 | ---------------------- | ----------------------------------------- | ---------------------------------------------------------------------------------------------------------------------------------------------------- | ----------- | -------------------- | -------------- | -------------- | -------- | ------------------------------------------------------------------------------ |
-| outcome-scope          | outcome and scope                         | Deliver R1–R16 without redefining sibling-owned plan content, migration, recovery copy, or release authority                                         | contributor | feature-proof        | open           | missing        |          |                                                                                |
-| resolved-decisions     | resolved decisions                        | Preserve all eight recorded decisions and exact/fallback/capability/user-authority boundaries                                                        | contributor | feature-proof        | open           | missing        |          |                                                                                |
-| pr-decomposition       | dependency and pull-request decomposition | Land five ordered independently reviewable slices, each safe without a successor                                                                     | contributor | phase-approval-proof | open           | missing        |          |                                                                                |
-| testing                | testing                                   | Complete deterministic boundary proof, all accepted scenario ledgers, the capability-catalogue eval, and the pinned 2-of-3 semantic contract eval    | contributor | planning-evals-proof | open           | missing        |          |                                                                                |
+| outcome-scope          | outcome and scope                         | Deliver the nondeferred R1–R16 boundaries without redefining sibling scope; R7 host acceptance remains open under retrieval-proof-deferral                                         | contributor | feature-proof        | open           | missing        |          |                                                                                |
+| resolved-decisions     | resolved decisions                        | Preserve all nine recorded decisions and exact/fallback/capability/user-authority boundaries                                                        | contributor | feature-proof        | open           | missing        |          |                                                                                |
+| pr-decomposition | dependency and pull-request decomposition | Deliver five ordered slices safe without successors; obtain current review of their boundaries | contributor | slice-review-proof | open | missing |  |  |
+| testing                | testing                                   | Complete nondeferred boundary/ledger proof and pinned evals; preserve unfinished R7 host acceptance regardless of narrower scenario passes          | contributor | complete-testing-proof | open           | missing        |          |                                                                                |
 | data-compatibility     | data and compatibility                    | Add versioned identity/evidence to existing job results and user dispositions to tickets; preserve history with no new store, migration, or backfill | contributor | identity-proof       | open           | missing        |          |                                                                                |
-| monitoring             | monitoring and failure signals            | Expose typed context, copy, route, identity, and origin failures with one recovery action                                                            | contributor | fallback-proof       | open           | missing        |          |                                                                                |
+| monitoring             | monitoring and failure signals            | Expose typed context, copy, route, identity, and origin failures with one recovery action                                                            | contributor | failure-proof       | open           | missing        |          |                                                                                |
 | security-privacy       | security and privacy                      | Preserve credential/privacy boundaries and deny execution or instruction authority to evidence                                                       | contributor | evidence-proof       | open           | missing        |          |                                                                                |
-| rollout-rollback       | rollout and rollback                      | Activate coherent slices; rollback preserves inert records and ledger history                                                                        | contributor | identity-proof       | open           | missing        |          |                                                                                |
+| rollout-rollback       | rollout and rollback                      | Release PR 2–4 together after integration; rollback preserves inert records and ledger history                                                                        | contributor | identity-proof       | open           | missing        |          |                                                                                |
 | documentation          | documentation                             | Update guidance, README, website, ADR marker, and generated host copies                                                                              | contributor | documentation-proof  | open           | missing        |          |                                                                                |
 | ownership-dependencies | ownership and human dependencies          | Keep sibling obligations deferred to named owners and invent no human authority                                                                      | contributor | feature-proof        | open           | missing        |          |                                                                                |
+| live-model-confirmation | testing | Prove current exact packaged reviewer selectors through actual installed Claude and Codex protocols; no skipped route qualifies | contributor | live-model-proof | open | missing | | |
+| packaged-release | rollout and rollback | Verify current packaged default comparisons and coherent generated runtimes before any release | contributor | packaged-release-proof | open | missing | | |
 | design-approval        | ownership and human dependencies          | Obtain configured human design approval                                                                                                              | human       |                      | not_applicable | missing        |          | Project `designApprovalGate` is disabled; review is not human design approval. |
-| completion-evidence    | completion evidence                       | Produce current receipts for all boundaries, complete feature, eval, and verification                                                                | contributor | release-proof        | open           | missing        |          |                                                                                |
+| retrieval-proof-deferral | ownership and human dependencies | Resolve the user-owned R7 host-retrieval proof deferral and establish its boundary evidence before claiming complete R7, feature, or epic acceptance | human | | pending_human | missing | | User deferred this proof on 2026-09-30; narrower packet or judged evidence cannot close this item. |
+| completion-evidence    | completion evidence                       | Produce current receipts for delivered boundaries and evals; do not claim complete feature or epic acceptance while retrieval-proof-deferral is open                                                                | contributor | release-proof        | open           | missing        |          |                                                                                |
diff --git a/.project/tickets/5F5ZZA-keep-plan-reviews-current-and-trustworthy/impl-plan.md b/.project/tickets/5F5ZZA-keep-plan-reviews-current-and-trustworthy/impl-plan.md
index aa5bc0fd5..6a17f08f3 100644
--- a/.project/tickets/5F5ZZA-keep-plan-reviews-current-and-trustworthy/impl-plan.md
+++ b/.project/tickets/5F5ZZA-keep-plan-reviews-current-and-trustworthy/impl-plan.md
@@ -7,7 +7,7 @@
 
 **Riskiest assumption:** Safeword can ignore cosmetic and unrelated context edits without also ignoring a decision that changes what the reviewer was required to judge. The cheapest discriminating proof is R4's paired context-identity outline: whitespace/comment and unrelated-inventory edits must retain approval, while a changed Rule, referenced persona, affected surface, principle, scope boundary, or plan decision must stale it.
 
-**Architecture at a glance:** one phase-aware context resolver constructs the complete review dependency set from the ticket and project configuration. One identity projector turns those inputs into a canonical record containing the target-plan identity, semantic contract digest, ticket and review kind, and a semantic digest per load-bearing context role. Product and Implementation Plans use exact target bytes. Execution Plans retain the accepted normalized identity that excludes only ordinary progress in the four trusted Delivery Checklist progress cells; every stable obligation field and every other plan byte remains identity-bearing. The existing review coordinator snapshots that resolved packet and stores the identity with its authenticated receipt; every phase gate asks the same admission service whether the current identity still matches. A separate exact-byte copy-integrity check requires every installed authoring contract and generated reviewer rubric to match the canonical generated bytes at authoring, dispatch, and admission. Product, Implementation, and Execution Planning keep different rubrics and approval meanings, while generated shared clauses keep their lifecycle, scope-authority, and trust language identical.
+**Architecture at a glance:** one phase-aware context resolver constructs the complete review dependency set from the ticket and project configuration. One identity projector turns those inputs into a canonical record containing the target-plan identity, exact bounded canonical contract digest, ticket and review kind, and a semantic digest per load-bearing context role. Product and Implementation Plans use exact target bytes. Execution Plans retain the accepted normalized identity that excludes only ordinary progress in the four trusted Delivery Checklist progress cells; every stable obligation field and every other plan byte remains identity-bearing. The existing review coordinator snapshots that resolved packet and stores the identity with its authenticated receipt; every phase gate asks the same admission service whether the current identity still matches. A separate exact-byte copy-integrity check requires every installed authoring contract and generated reviewer rubric to match the canonical generated bytes at authoring, dispatch, and admission. Product, Implementation, and Execution Planning keep different rubrics and approval meanings, while generated shared clauses keep their lifecycle, scope-authority, and trust language identical.
 
 The closed `PlanningContextRole` model covers ticket, project, parent, milestone, rules,
 scenarios, dimensions, principles, personas, surfaces, architecture records,
@@ -18,9 +18,9 @@ returns either the complete role-labeled dependency set, a typed
 record, an untriggered data guide, or a dimensions artifact that does not exist,
 or a typed missing-role error. The projector produces a
 versioned `PlanningReviewIdentity` containing ticket and review kind, target-plan
-identity, semantic canonical-contract digest, and an ordered role/path/semantic-
-digest entry for every dependency. The ticket projection explicitly retains
-scope, exclusions, and versioned user-owned review dispositions matching the
+identity, exact bounded canonical-contract digest, and an ordered role/path/semantic-
+digest entry for every dependency. The ticket projection retains all nonadministrative frontmatter, including
+`scope`, `out_of_scope`, `done_when`, and `type`, plus versioned user-owned review dispositions matching the
 current review kind. The parent/spec
 projection retains the selected parent job's persona, job-to-be-done, outcome,
 constraints, and milestone boundaries. The project projection retains the owning
@@ -59,11 +59,10 @@ including Approach, proof scope and confidence limits, affected surfaces,
 contracts and failure behavior, rollout and rollback, Measurement applicability,
 Persona consequences, Recorded Decisions, Data applicability, Design alignment,
 Known deviations, Doc impact, and Assessment triggers. The
-canonical-contract projection retains the phase, purpose, entry, required and
-prohibited content, review question, approval meaning, invalidation, return
-path, and marked shared clauses while ignoring layout and comments. Meaningful
-order is preserved, declared sets are sorted, and missing, duplicate, unknown,
-or ambiguous required shapes fail closed.
+canonical-contract identity retains the exact bytes between the contract markers,
+including layout and comments. Semantic normalization applies only to other
+context inputs: meaningful order is preserved, declared sets are sorted, and
+missing, duplicate, unknown, or ambiguous required shapes fail closed.
 
 The parent role and rules role have separate ownership even when both resolve
 from one declared parent spec: parent retains the complete selected parent job
@@ -91,29 +90,21 @@ representation of those inputs as a replacement for reading their current source
 The accepted Implementation Plan is always required and currency-bearing in an
 Execution review. The canonical Execution Planning contract, owned by 7CAMAD,
 must declare `upstreamImplementationInvalidation: both_plan_reviews`, as required
-by parent TBU2.R11/TBU4.R9. Missing, unsupported, duplicate, or ambiguous values
-return `invalid_invalidation_contract` rather than selecting a permissive default.
-The typed field is generated from the canonical owner's decided invalidation
-clause and is a prerequisite for its runtime consumption. If that clause has no decidable direction,
-contract reconciliation blocks and returns the decision to 7CAMAD. This child
-consumes the owner's declaration and does not choose another dependency policy.
-
-The deterministic representative scenario is **An undecidable Execution
-invalidation contract blocks reconciliation**. Its boundary is a real installed
-project's upgrade, not an upstream-plan mutation: reject the canonical source's
-undecidable declaration before any installed contract bytes change, naming
-`invalid_invalidation_contract`, the Execution phase, and the source path.
-Missing, unknown, unknown-suffix, duplicate, and contradictory declarations are
-lower-level variations of that rejection. Existing R9 receipt-invalidation
-scenarios prove the separate runtime consequence. This names the proof of the already accepted declaration rule, not a new
-dependency policy or a substitute for those runtime scenarios.
-
-An own-review-only declaration is unsupported: it cannot make a superseded
-design admissible. Semantic Implementation Plan changes stale both plan reviews.
-The user authorized this parent alignment on 2026-10-04 PDT by delegating the
-stated choice; the former snapshot-only design is historical, not an accepted
-exception. Its runtime removal belongs to PR3. All applicable roles retain their
-defined semantic binding. No generic configurable dependency graph is introduced.
+by parent TBU2.R11/TBU4.R9. Missing, unsupported, duplicate, or ambiguous
+declarations return `invalid_invalidation_contract`; an own-review-only
+declaration cannot make a superseded design admissible. This child consumes and
+validates the owner's declaration without adding a configurable dependency policy.
+
+The real reconciliation rejection proof covers both undecidable declarations
+and the unsupported own-review-only declaration before any installed contract
+bytes change. It names the Execution phase and canonical source path. A semantic
+accepted Implementation Plan change invalidates its own approval and the
+dependent Execution approval. The historical snapshot-only defect was removed
+in bf758b53f52d40f3d7288f285937dcb717554a26; it is not an accepted exception.
+The user authorized parent alignment on
+2026-10-04 PDT by delegating the stated choice. No general dependency graph is
+introduced.
+
 Scenario-gate is an additional consumer of this identity path, not a fourth
 planning contract. Its exact target is the accepted scenario source; required
 context is ticket, project (including the accepted persona-outcome inventory),
@@ -146,11 +137,16 @@ role error. For `product-plan`, the target spec's own Rules are already covered
 by the exact target bytes; the separate rules role contains only inherited
 parent Rules when a child declares a parent.
 
-The resolver derives data-guidance applicability from the reviewed plan's own
-`Data applicability` declaration: a justified `skip: <reason>` produces the
-typed absent data role with that reviewed plan as authority; every non-skip data
-decision requires current configured data guidance. The plan cannot silently
-remove that context: the skip stays in exact reviewed target bytes and the
+For Implementation review, the resolver derives data-guidance applicability
+from the reviewed Implementation Plan's `Data applicability` declaration. For
+Execution review, it uses the accepted Implementation Plan's declaration, never
+a duplicate decision in the Execution Plan. That declaration remains bound in
+the upstream semantic projection. In either case: a justified `skip: <reason>` produces the
+typed absent data role with the declaring Implementation Plan as authority; every non-skip data
+decision requires current configured data guidance. The Execution packet must include current data guidance when the upstream
+Implementation Plan triggers it, even without a declaration in the Execution
+Plan; the R2/R3 resolver proof covers this. The plan cannot silently remove
+that context: the skip remains bound to its declaring Implementation Plan and the
 Implementation Plan rubric independently accepts or rejects its reason.
 Architecture applicability is deliberately stricter: only when no durable architecture record is configured may the
 reviewed plan's justified `Architecture applicability: skip: <reason>` produce
@@ -198,11 +194,22 @@ boundary. An undecided optional suggestion creates no disposition, cannot
 change plan bytes, and remains nonblocking.
 
 Accepting an optional expansion does not create an `accepted` disposition. The
-user first changes the authoritative ticket scope/exclusions—or the owning
-parent Product Plan when authority lives there—and only then may the plan be
-corrected. That semantic boundary change stales dependent approval and requires
-fresh review, making user authority visible before agent-authored plan bytes
-change.
+contributor first receives explicit human direction and records that decision,
+its authenticated suggestion reference, and the authorized scope change in the
+existing ticket work log. The authoritative ticket scope/exclusions—or owning
+parent Product Plan—change before plan bytes. Without that human direction,
+the contributor must not make the boundary edit or report acceptance. The
+semantic boundary change stales dependent approval and requires fresh review.
+
+This is the existing human-directed authoring workflow, not authenticated human
+identity or protection against an agent forging editable project artifacts.
+R14 proves that reviewer output alone cannot expand scope, and that a recorded
+user decision precedes the boundary and plan changes. Its confidence limit does
+not claim that the package can identify who edited every namespace file. Adding
+an identity-authenticated scope-writing command would change this accepted
+boundary and introduce another authority mechanism; neither a reviewer verdict
+nor this plan grants that expansion. The deferred R7 host-adherence proof cannot
+be replaced by an interactive terminal confirmation.
 
 Planning-side evidence uses a versioned `PlanEvidenceRecordV1` embedded in the
 Implementation Inspiration decision entry, not the review job's output record.
@@ -221,10 +228,10 @@ evidence cannot rewrite the plan under review.
 | D1BKYA: authenticated current phase admission alone permits approach approval; a missing, stale, or invalid phase receipt still blocks | public `ticket approve-plan` through real CLI, coordinator receipt and interactive design approval | integration | real approving-warning review plus authenticated phase stamp succeeds after removing only the redundant artifact-stamp event; paired missing/stale/invalid receipt cases refuse admission; rejection rendering retains only actual reviewer findings | approval is bound to exact plan bytes and current receipt; it grants no release or merge authority |
 | R1: one shared source generates the common clauses and preserves phase-only clauses                                                                   | real Safeword reconciliation from packaged source through installed copies                                             | integration               | proves the authoring source, generator, schema, and reconciliation cooperate                                                                                                                                                                                        | generation tests cannot judge prose quality; the semantic phase reviewers cover that                                                                     |
 | R2-R3: every required current input resolves or dispatch fails closed                                                                                 | real review-packet preparation with project configuration and filesystem inputs                                        | integration               | omissions, defaults, stale overrides, and unreadable files cross modules and I/O                                                                                                                                                                                    | exhaustive malformed-file partitions stay in lower-level table tests                                                                                     |
-| R4-R5: target-plan identity and semantic contract/context determine currency while exact generated-copy bytes gate use                                | identity projector, copy-integrity gate, and real job-status recomputation                                             | integration               | proves exact Product/Implementation identity and normalized Execution progress separately from semantic context and installed-copy conformance                                                                                                                      | SHA-256 detects changes but does not prove the selected semantic fields are complete; mutation partitions support it                                     |
+| R4-R5: target-plan identity, exact bounded canonical contract bytes, and semantic context determine currency while exact generated-copy bytes gate use                                | identity projector, copy-integrity gate, and real job-status recomputation                                             | integration               | proves exact Product/Implementation identity and normalized Execution progress separately from semantic context and installed-copy conformance                                                                                                                      | SHA-256 detects changes but does not prove the selected semantic fields are complete; mutation partitions support it                                     |
 | R6: independent-first routing and the ordered fallback ladder record achieved assurance honestly                                                      | real coordinator and phase admission with only reviewer subprocesses mocked, plus real host lifecycle payload fixtures | integration               | route selection, typed exhaustion, author/reviewer process identity, reviewer capability, authenticated receipts, and gate admission must cooperate; host fixtures prove exact Claude author identity and fail-closed Codex/Cursor/OpenCode absence                 | provider authentication itself remains covered by existing live verification, not deterministic CI                                                       |
 | R6 capability catalogue: every packaged cross-provider ordering is earned and every default independence claim is executable                          | pinned human-labelled planning-review corpus, Claude/Codex live model-confirmation proofs, and release verification      | eval + integration + live | repeated semantic review distinguishes model capability; release checks bind admitted results and adapter-specific confirmation to shipped catalogue/default routes                                                                                                 | a small corpus can establish only its declared planning-review boundary and live proofs must be refreshed when CLIs, models, rubrics, or defaults change |
-| R7: retrieved and reviewed material stays evidence, not instructions                                                                                  | quarantine/parser integration plus judged reviewer evaluation                                                          | integration + eval        | deterministic code proves no execution or disclosure path; an eval proves semantic instruction resistance                                                                                                                                                           | eval confidence is bounded by the pinned judge/rubric and repeated-run agreement                                                                         |
+| R7: retrieved and reviewed material stays evidence, not instructions                                                                                  | quarantine/parser integration plus judged reviewer evaluation                                                          | integration + eval        | deterministic code proves no execution or disclosure path; an eval proves semantic instruction resistance                                                                                                                                                           | eval confidence is bounded by the pinned judge/rubric and repeated-run agreement; the user-deferred planning-agent retrieval boundary is unproved                                                                         |
 | R8: ungated hosts receive advisory guidance while gated hosts retain enforcement claims                                                               | real CLI reconciliation of host guidance                                                                               | integration               | proves generated content on the installed surface                                                                                                                                                                                                                   | cannot prove a cloud vendor executes repository prose; the contract deliberately claims advisory only                                                    |
 | R9: only dependent reviews stale and receipts cannot cross ticket or kind                                                                             | current identity recomputation through the real phase gate                                                             | integration               | a semantic upstream change stales both receipts through the real resolver/status/admission machinery; reconciliation rejects an unsupported own-review-only declaration before changing installed bytes | concurrent filesystem mutation is covered by the coordinator snapshot checks, not this matrix                                                            |
 | R10-R11: each phase contract asks and approves only its own decision, with bounded findings and fresh-byte repair                                     | fixed-rubric judged review plus real phase-gate corrected-byte/fresh-verdict integration                               | integration + eval        | semantic finding authority needs judgment while receipt currency is deterministic                                                                                                                                                                                   | the eval remains model-dependent; exact-byte integration cannot judge finding quality                                                                    |
@@ -249,21 +256,16 @@ Every new public or lifecycle entry point receives a real wiring proof: CLI conf
 - **OpenCode CLI/TUI:** the profile plugin boundary is covered by exact-version real-process conformance; **OpenCode Desktop** is explicitly advisory and covered by generated-copy assertions.
 - **OpenAI Codex Cloud and Claude Code on the Web:** `skip:` the accepted feature marks them unaffected or advisory; no approval is claimed there.
 
-### Build order
-
-1. Establish the load-bearing identity slice: exact Product/Implementation identity, normalized Execution progress identity, semantic contract and context projections, separate exact-copy integrity, and paired retain/stale proofs.
-2. Make the context resolver produce the complete phase dependency set and fail closed on missing or stale configured sources.
-3. Carry the resolved identity through the existing coordinator job record, status response, stamp verification, and phase admission without creating a parallel receipt store.
-4. Generate shared planning clauses from one source and retain phase-specific author/reviewer rubrics and bounded approval meanings.
-5. Carry the existing untrusted-evidence quarantine into planning review packets and add the R7 evidence-record fields and disclosure/execution refusals before judged evaluation.
-6. Add the user-owned ticket disposition command and bind dispositions to the ticket projection before enforcing optional-strengthening behavior.
-7. Enforce finding authority, accepted-boundary completeness, Product Plan persona/epistemic completeness, and separate persona-outcome-to-scenario coverage in the judged rubrics and installed entry points.
-8. Run the pinned reviewer-capability corpus, generate only qualified ordered comparisons with full provenance, and make release verification reject an unsupported default cross-vendor pair.
-9. Reconcile all host guidance and update the configured customer documentation surfaces.
+### Runtime boundaries
 
 API contracts are internal typed CLI contracts: callers supply a ticket and review kind, not an arbitrary claim of completeness; the resolver returns either a complete, role-labeled dependency set or a typed blocking error. Authorization stays split: the coordinator authenticates review provenance, phase admission accepts only a current matching receipt, and neither grants Product approval, design approval, merge authority, or release authority it did not receive.
 
-Failure behavior is fail closed at authoring, dispatch, and admission. Typed
+Failure behavior is fail closed at authoring, dispatch, admission, and packaged
+release validation. The existing release-gate lane checks the generated
+catalogue's exact asset hashes and dogfood/native-copy parity before packing;
+missing or mismatched authoring, reviewer, or host copies refuse release, name
+the failed copy, and require the owning generator plus parity checks. This reuses
+the release path rather than introducing another approval or waiver. Typed
 failures distinguish `missing_review_target` for an absent plan under review,
 `missing_canonical_contract` for an absent canonical phase contract,
 `missing_generated_shared_clause` carrying the missing clause identifier and
@@ -341,22 +343,14 @@ admitting receipt. A failed route still follows the ordinary ladder. Real host
 lifecycle fixtures must prove both the supported Claude value and the absence
 cases before an adapter may advertise capability.
 
-Reviewer confirmation is adapter-specific and coordinator-owned. Claude must
-return a canonical model in its trusted JSON `modelUsage` envelope that matches
-the requested exact non-alias selector. The Codex independent route uses the
-existing CLI's app-server stdio protocol rather than `exec` JSONL: the trusted
-`thread/start` response identifies its effective model and provider, and the
-correlated `model/rerouted` notification exposes service substitution. The
-coordinator compares configured, requested and acknowledged identities, starts
-one turn on that exact ephemeral thread without a model override, and binds
-its terminal response and metadata to that thread and turn. A missing or
-mismatched identity, unsupported protocol, failed or incomplete turn, or any
-reroute cannot grant independent approval. Preserve the actual reviewer and
-findings and use the accepted reduced/fail-closed policy; do not relabel a
-mixed-model turn as a qualified exact-model review. The legacy `exec` route
-remains readable for configured best-available review, but exact argv, a startup
-banner and unsupported-selector refusal alone never establish independent model
-confirmation.
+Reviewer confirmation is adapter-specific and coordinator-owned. Claude binds
+the assistant event's model to matching canonical first-party usage metadata.
+Codex uses app-server stdio to bind the acknowledged model/provider and any
+reroute to one completed review turn; `exec` argv or a startup banner cannot prove
+the effective model. Missing confirmation, substitution, or incomplete execution
+cannot grant independent approval. The exact protocol mechanics and trust limits
+live in [model-identity authority](../../../ARCHITECTURE.md#authenticated-reduced-independence-planning-review-fallback);
+the evidence and rejected alternatives are recorded below.
 
 This makes Claude-author/Codex-reviewer independence reachable without widening
 author identity claims: non-Claude authors still follow the declared unknown-
@@ -396,9 +390,9 @@ longer offers returns its typed route failure and creates no receipt. A verified
 exact model absent from the active catalogue and overlays returns
 `reviewer_capability_unknown`; runtime code never reinterprets dated provider
 evidence to invent a rank. The next Safeword release refreshes the packaged
-catalogue or changes the default route. This operational duty sits outside the
-accepted builder persona set; builders retain the explicit project/user overlay
-recovery below.
+catalogue or changes the default route. This is the accepted Safeword Maintainer
+persona's release responsibility; builders retain the explicit project/user
+overlay recovery below.
 An `off` coordinator policy cannot satisfy a planning phase review gate and
 therefore reports a blocking configuration error until cross-agent review is
 enabled.
@@ -448,19 +442,90 @@ required. Its refusal renderer also selected findings from the latest approved
 review and presented them as rejection reasons. This diagnosed baseline is the
 state to repair, not a second review authority to preserve. The Recorded
 Decision below owns the correction; Execution Planning owns only its sequencing
-and proof. Implementation status and verification remain in the ledger.
+and proof. Its durable rationale and narrow ownership are recorded in
+[Digest-Bound Planning Decisions](../../../ARCHITECTURE.md#digest-bound-planning-decisions-in-the-shared-review-ledger).
+G1C9PP retains the broader approval-consumer model. Implementation status and
+verification remain in the ledger.
+
+### Known corrective gaps in the stacked implementation
+
+Execution review must also bind the exact canonical Implementation reviewer
+contract on which its accepted upstream plan depends. Capture that upstream
+contract during packet preparation, using the same canonical-copy validation
+and fingerprint path as the existing own-phase contract. Include its reviewer
+digest in the existing accepted-upstream-plan dependency projection alongside
+the upstream plan's semantic identity. Keep the own-phase contract digest
+unchanged. Missing upstream contract identity cannot become Execution approval.
+No new persisted dependency graph, receipt field, or approval authority is
+needed. Extending the receipt schema would make this dependency more explicit
+but adds validation and migration without improving the accepted outcome;
+hashing the whole Implementation authoring file would unnecessarily invalidate
+reviews after edits outside its canonical markers. SHA-256 retains the existing
+byte hashing primitive documented at https://nodejs.org/api/crypto.html.
+
+The riskiest assumption is that dispatch and current-status reconstruction
+capture the same upstream canonical contract. R9's two canonical-contract rows
+must prove the real coordinator-to-status-to-admission boundary: an
+Implementation contract-byte change invalidates both reviews, while an
+Execution-only contract-byte change invalidates only Execution. Mock only the
+reviewer process; a packet-only assertion is supporting proof, not acceptance.
+
+The exact bounded canonical-contract identity decision (R4) has an uncommitted
+production correction in the current worktree. Its earlier RED receipt became
+stale after fixture changes; refresh authentic RED before claiming GREEN.
+R8's explicit advisory-only guidance correction is also present but uncommitted,
+with the same proof-refresh obligation. Neither correction is completed delivery.
+
+R9's rejection of unsupported invalidation directions and removal of the
+snapshot-only upstream exception are committed at
+bf758b53f52d40f3d7288f285937dcb717554a26. Current-main verification and placement
+in the owning PR slices remain pending. The upstream canonical-contract
+dependency correction described above is still proposed and has no production
+implementation or passing proof. The ledger owns detailed proof state.
+The Execution Plan retains current live model-confirmation and package-release
+proof obligations; historical confirmed models and deterministic fixtures cannot
+claim those current boundaries. These gaps are unfinished delivery, not accepted
+design exceptions. The separately user-deferred R7 host proof remains open.
 
 ### Persona consequences
 
-| Persona               | Consequential needs                                                                                                                                                                                                                                                                               | Design consequence                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                               | Confidence limit                                                                                                                                                                         |
-| --------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
-| Technical Builder     | Inspect what was reviewed, understand why a receipt is current or stale, retain user authority over scope and optional strengthening, and route design acceptance through the configured human gate when enabled.                                                                                 | Typed identity exposes the target identity, semantic contract, dependency role, reviewer route, and bounded authority; typed failures name the reconciliation action. Reviewer findings cannot expand scope, and review approval remains distinct from configured human design approval. An unranked reviewer returns `reviewer_capability_unknown` with one action: pin a supported exact selector, select a qualified exact-model pair or refresh its qualification evidence, or update Safeword. An unknown author returns `author_capability_unknown` with one action: use a host with verified author metadata or change `require` to `prefer` for honest reduced fallback. | Deterministic integration proves identity, gate result, and preserved authority, not whether every explanation is optimally phrased for a particular developer.                          |
-| Non-Technical Builder | Trust that the agent cannot reuse stale approval, understand a refusal in plain language, and receive one concrete recovery action. Approval authority is not applicable merely because this persona is non-technical; the same user-owned scope and configured design-approval boundaries apply. | Phase admission fails closed on missing, stale, or unauthenticated evidence and carries a typed recovery value through the shared result contract. K3EBHB R7 and R10 own the final installed plain-language wording and its acceptance proof.                                                                                                                                                                                                                                                                                                                                                                                                                                    | This ticket proves the typed reason, recovery value, and lack of invented authority, but cannot claim the NTB wording is understandable until K3EBHB's installed-surface scenarios pass. |
+<!-- prettier-ignore -->
+| Persona | Consequential needs | Design consequence | Confidence limit |
+| --- | --- | --- | --- |
+| Technical Builder | Inspect the reviewed basis, understand currency, retain user-owned scope, and use configured human design authority. | Typed identity exposes the target, exact canonical digest, context roles, reviewer route, and bounded authority. Admission and the capability policies above preserve authentication and provide one recovery action without inventing user authority. | Integration proves emitted identity and admission; final explanation quality remains bounded by installed-surface proof. |
+| Non-Technical Builder | Trust that the agent cannot reuse stale approval, understand a refusal in plain language, and receive one concrete recovery action. Approval authority is not applicable merely because this persona is non-technical; the same user-owned scope and configured design-approval boundaries apply. | Phase admission fails closed on missing, stale, or unauthenticated evidence and carries a typed recovery value through the shared result contract. K3EBHB R7 and R10 own the final installed plain-language wording and its acceptance proof. | This ticket proves the typed reason, recovery value, and lack of invented authority, but cannot claim the NTB wording is understandable until K3EBHB's installed-surface scenarios pass. |
+| Safeword Maintainer | Keep canonical author/reviewer/host copies aligned, refuse an unsafe release, identify regeneration recovery, and gain no approval authority from maintenance. | Schema-owned identities, generated-surface checks, and the existing release catalogue/dogfood checks reject missing or mismatched copies. The refusal names the copy and regeneration command. The maintainer refreshes qualified defaults and regenerates assets; release and merge authority stay separate. | Release checks prove packaged-byte conformance, not semantic decision quality or a vendor's execution of its hooks. |
 
 ## Decisions
 
 ### Implementation Inspiration — review identity
 
+Reviewer-confirmation decision evidence, checked 2026-10-05:
+
+- **Codex transport:** [official app-server protocol](https://learn.chatgpt.com/docs/app-server),
+  retrieval snapshot 2026-10-05, applied to installed CLI **0.153.4**. Its generated
+  `ThreadStartResponse` requires `model` and `modelProvider`; its reroute schema
+  requires thread/turn IDs and source/destination models. Schema SHA-256 values:
+  `656f8fd0fe91f533126cbfdb9369cfab550927a229e48dd46460f6f015d2b186` and
+  `37cd3c1b3a3560b85b01d4061a07d830fc9ed93b80e4663f975f9197cdb501ef`.
+  Choose acknowledged, turn-bound metadata over `exec` argv/banner/selector
+  probing because the latter cannot distinguish service substitution. The
+  provider declaration is trusted; model weights are not audited. Public docs
+  are linked, no source copied; no private context or credentials belong in this
+  evidence. Recheck protocol fit when the supported CLI changes.
+- **Claude confirmation:** [official programmatic CLI guidance](https://code.claude.com/docs/en/headless),
+  retrieval snapshot 2026-10-05, applied to installed CLI **2.1.289**. The docs
+  establish streamed assistant/result messages and metadata. Exact
+  `modelUsage.canonicalModel` and `provider` fields are version-scoped observations,
+  not a portable documented guarantee: authenticated review
+  `dff59e7a-ca96-4564-a4ae-49cd51a61fca` confirmed first-party
+  `claude-opus-5-5`, with honest reduced independence because the author model is
+  unknown. Adapter tests bind assistant model to matching usage metadata and
+  reject missing/conflicting observations. Choose that envelope over reviewer
+  prose or selector alone; missing supported metadata cannot earn independence.
+  Public docs are linked, no source copied; provider identity is trusted without
+  weight verification, and no secret-bearing payload is retained here.
+
 <!-- prettier-ignore -->
 | Reference | Checked on | Source version | Target version | Evidence of fit | Principle to borrow | Mismatch / license / security boundary |
 | --- | --- | --- | --- | --- | --- | --- |
@@ -473,12 +538,12 @@ and proof. Implementation status and verification remain in the ledger.
 | [Anthropic success criteria](https://docs.anthropic.com/en/docs/test-and-evaluate/define-success) | 2026-09-20 | current documentation | Reviewer capability eval | Evaluation criteria should be specific, measurable, achievable, and relevant, with explicit benchmarks | Predeclare a measurable absolute floor and fixture-level comparison before observing candidate results | Provider guidance does not choose Safeword's threshold or prove cross-provider capability; no source or model output reused |
 
 **Decision impact:** changed: review currency uses exact Product/Implementation
-target bytes and the accepted normalized Execution identity plus semantic
-canonical-contract and context projections; installed contract copies remain
+target bytes and the accepted normalized Execution identity plus exact bounded
+canonical-contract bytes and semantic context projections; installed contract copies remain
 subject to a separate exact-byte integrity gate.
 **Decision informed:** Bind each verdict to the phase's target-plan identity plus
-canonical semantic projections of the contract and every load-bearing context
-role, without weakening exact generated-copy conformance.
+the exact bounded canonical-contract digest and semantic projections of every
+load-bearing context role, without weakening exact generated-copy conformance.
 
 ### Supporting decision detail — capability catalogue qualification
 
@@ -528,13 +593,21 @@ the absolute floor; no integer rank or transitive closure grants eligibility.
 
 ### Recorded Decisions
 
+Reviewer-identity transport decision: use Codex app-server's acknowledged,
+turn-correlated metadata and Claude's assistant/result usage agreement, with
+the versioned evidence above. Reject argv/banner probes, selector names alone,
+and reviewer-authored identity claims because they cannot establish the effective
+model. Unsupported or substituted metadata follows the existing honest
+reduced/fail-closed policy. The linked durable model-identity record owns the
+protocol detail; this adds no new transport or authority.
+
 | Decision                                                                                                                                                                 | Choice                                                                                                                                                                                                                                                                                                                                                                      | Alternatives considered                                                                                                                                                                           | Rejected because                                                                                                                                                                                                                                                                                                             |
 | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------ | --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
 | Consolidate authenticated planning approval authority and truthful refusals | `phaseReviewAdmission` is the sole current-review prerequisite for `approve-plan`: authenticate the cited job, target, current identity, and achieved assurance; remove the redundant content-bound artifact-stamp prerequisite. Render reviewer rejection findings only from an actual `changes_requested` verdict and its `REVIEWER_FINDING` entries. Keep copy/conformance/configuration failures typed separately and human design approval distinct. | Retain both authenticated phase admission and a second artifact stamp; render findings from the latest review regardless of verdict. | The second stamp duplicates currency already established by authenticated admission and can block an approved plan. Approved-review warnings are not rejection findings; mixing them invents a refusal. Authenticated approval advances without an extra planning stamp; neither review approval nor this repair grants merge authority. |
-| Bind each verdict to its phase's target-plan identity plus semantic canonical-contract and context projections, while gating generated copies by exact bytes separately. | Use exact Product/Implementation target bytes and the accepted normalized Execution identity that excludes only ordinary checklist progress; use a versioned typed context projection and an exact canonical-copy digest for authoring, dispatch, and admission conformance; reject unknown required shapes.                                                                | Hash every packet byte into review currency; normalize stable Execution Plan fields; persist a general Merkle dependency graph.                                                                   | Whole-packet hashing would rereview already-approved work after each checklist tick. Normalizing stable obligations could hide design changes. A general graph adds storage, migration, and traversal machinery without improving this fixed three-phase dependency model.                                                   |
+| Bind each verdict to its phase's target-plan identity plus exact bounded canonical-contract bytes and semantic context projections, while gating generated copies by exact bytes separately. | Use exact Product/Implementation target bytes and the accepted normalized Execution identity that excludes only ordinary checklist progress; use a versioned typed context projection and an exact canonical-copy digest for authoring, dispatch, and admission conformance; reject unknown required shapes.                                                                | Hash every packet byte into review currency; normalize stable Execution Plan fields; persist a general Merkle dependency graph.                                                                   | Whole-packet hashing would rereview already-approved work after each checklist tick. Normalizing stable obligations could hide design changes. A general graph adds storage, migration, and traversal machinery without improving this fixed three-phase dependency model.                                                   |
 | Extend the existing coordinator and review ledger instead of creating a second planning-review subsystem.                                                                | One resolver feeds packet construction, job fingerprinting, status, stamps, and phase admission.                                                                                                                                                                                                                                                                            | Validate only in hooks; add a new planning receipt store.                                                                                                                                         | Hook-only checks drift by host. A second store would split authority and duplicate integrity, concurrency, and fallback behavior already present.                                                                                                                                                                            |
 | Author shared planning clauses once and generate exact marked copies while keeping phase-only judgment separate.                                                         | One canonical shared-clause source generates Product, Implementation, and Execution contract mirrors; each phase owns its distinct rubric.                                                                                                                                                                                                                                  | Duplicate prose with parity tests; collapse all phases into one rubric.                                                                                                                           | Duplicate prose remains two authorities even if tested. One rubric would erase the different behavior/design/delivery approval meanings.                                                                                                                                                                                     |
-| Treat semantic projection as a closed domain model, not generic Markdown normalization.                                                                                  | Parse named contract fields and role-specific sections into typed values; sort only unordered sets and preserve meaningful order.                                                                                                                                                                                                                                           | Strip comments and whitespace from every file generically.                                                                                                                                        | Generic normalization can erase meaningful Gherkin/doc structure or preserve unrelated inventory, creating false-current or false-stale receipts.                                                                                                                                                                            |
+| Treat semantic projection as a closed domain model, not generic Markdown normalization.                                                                                  | Parse role-specific context sections into typed values; sort only unordered sets and preserve meaningful order.                                                                                                                                                                                                                                           | Strip comments and whitespace from every file generically.                                                                                                                                        | Generic normalization can erase meaningful Gherkin/doc structure or preserve unrelated inventory, creating false-current or false-stale receipts.                                                                                                                                                                            |
 | Record a user-declined optional strengthening in ticket context.                                                                                                         | Add a versioned `review_dispositions` ticket field written from an authenticated nonblocking finding after explicit user direction; include only matching-review-kind dispositions in that phase's semantic ticket projection so the unchanged plan receives fresh same-kind review without staling unrelated phase receipts.                                               | Append a new review-ledger event; create a separate disposition store; project every disposition into every review kind; keep the decline only in session/reviewer output.                        | The ledger would gain authority beyond phase-admission claims; another store adds integrity and concurrency machinery; whole-field projection creates unrelated rereviews; ephemeral output cannot preserve the accepted decline across sessions.                                                                            |
 | Classify reviewer capability from qualified exact ordered pairs and fail closed when comparison is unavailable.                                                          | Require a current qualified not-weaker record for the verified exact author/reviewer pair, supported by provider ordering or predeclared pinned-corpus evidence. Project/user rank overlays order routes only and cannot qualify a pair.                                                                                                                                    | Infer capability from vendor/agent identity; treat unknown models as equivalent; require users to configure every comparison; assign undocumented maintainer integers; use aggregate score alone. | Agent identity does not establish model strength; permissive unknowns overstate assurance; configuration-only ranking breaks the fire-and-forget default for known supported models; undocumented integers are not auditable; an aggregate-only bar can hide a regression on a planning failure the author reliably catches. |
 | Admit authenticated reduced-independence receipts without discarding stronger completed evidence.                                                                        | Under `prefer`, admit a successful different-agent, separate-process review immediately as `reduced` when author capability is unknown; only route failures descend through same-agent fallback after every stronger configured route is exhausted. Seal the actual reviewer, route, reason, and tier in the existing job store; no reduced receipt is labeled cross-agent. | Discard successful different-agent evidence and force fallback; preserve non-stamping host fallback; call fallback independent; let hosts write ledger stamps directly.                           | Discarding a stronger completed review wastes evidence and work; non-stamping fallback cannot satisfy accepted R6 recovery; calling it independent fabricates assurance; direct host stamps bypass coordinator authentication and packet identity.                                                                           |
@@ -547,10 +620,10 @@ Data applicability: review provenance and user-owned review dispositions are dur
 
 - **Purpose:** prove which phase-specific target identity and semantically identified canonical contract and accepted context, ticket, review kind, reviewer route, and independence level produced a verdict, while separately proving installed copies match the canonical generated bytes.
 - **Store and model:** retain the ticket file, existing integrity-protected review job JSON, and append-only review ledger. Add a versioned `review_identity` and versioned `evidence_records` collection to new job results; add versioned `review_dispositions` to ticket frontmatter; stamps continue to cite the coordinator review ID rather than copy identity data.
-- **Schema and relationships:** one review identity belongs to one review job and contains one phase-specific target-plan identity, one semantic contract digest, and ordered role/path/semantic-digest dependencies. Each evidence record belongs to the verdict that produced it. Each ticket disposition cites one authenticated review kind and finding fingerprint plus the accepted-boundary digest it was judged against. A stamp references one job by ID and phase scope; generated-copy digests are recomputed conformance inputs, not currency fields.
+- **Schema and relationships:** one review identity belongs to one review job and contains one phase-specific target-plan identity, one exact canonical contract digest, and ordered role/path/semantic-digest dependencies. Each evidence record belongs to the verdict that produced it. Each ticket disposition cites one authenticated review kind and finding fingerprint plus the accepted-boundary digest it was judged against. A stamp references one job by ID and phase scope; whole authoring-file digests are recomputed conformance inputs, distinct from the exact bounded contract digest that determines currency.
 - **Source of truth:** captured plan and resolved project files are review inputs; the coordinator job record is the source of provenance and reviewer-produced evidence records; the ticket is the source of user-owned decline dispositions; the ledger is the source of phase-admission claims. No host-authored duplicate becomes authority.
 - **Ownership and access:** the coordinator writes job identity and evidence records; the stamp helper writes admission claims after authenticating that job; the user is the change authority for ticket dispositions and the typed CLI records one only after explicit user direction against an authenticated nonblocking finding. External reviewers receive bounded snapshots but never write authority files.
-- **Identity and integrity:** SHA-256 covers exact Product/Implementation bytes or the trusted normalized Execution identity, plus canonical semantic contract and context projections including only ticket dispositions matching the current review kind. Existing job integrity covers identity, verdict, and evidence records. Evidence records are outputs and do not affect the identity of the review that produced them; if reused later, their semantic projection becomes an input dependency. A separate SHA-256 comparison requires every generated copy to match canonical bytes. Review kind and ticket identity prevent cross-kind and cross-ticket reuse.
+- **Identity and integrity:** SHA-256 covers exact Product/Implementation bytes or the trusted normalized Execution identity, plus the exact bounded canonical contract bytes and semantic context projections including only ticket dispositions matching the current review kind. Existing job integrity covers identity, verdict, and evidence records. Evidence records are outputs and do not affect the identity of the review that produced them; if reused later, their semantic projection becomes an input dependency. A separate SHA-256 comparison requires every generated copy to match canonical bytes. Review kind and ticket identity prevent cross-kind and cross-ticket reuse.
 - **Cross-system flow:** project sources and prior reusable evidence → resolver/projector → neutral packet → external verdict and evidence records → authenticated job → ledger stamp → phase admission. A user decline flows from an authenticated nonblocking finding → typed ticket disposition command → atomic ticket update → stale matching-kind receipt → fresh same-kind review of the unchanged plan.
 - **Lifecycle and retention:** use existing ticket, review-job, and ledger retention. Source changes stale their declared dependents; disposition changes recompute only matching-kind identity and make that receipt non-current. Evidence records remain with their verdict and declare reuse limits before later use. No automatic deletion or compaction is added.
 - **Migration and backfill:** skip: the ticket excludes migration policy and adds no backfill. Existing receipts are preserved; they authorize only when the active admission reader can authenticate them and recompute the current required identity.
@@ -573,7 +646,19 @@ authority.
 
 Ticket disposition writes use an exclusive `O_CREAT | O_EXCL` sibling lock, an
 expected SHA-256 digest of the exact ticket bytes, an adjacent temporary file,
-and same-filesystem rename. Under that lock the command rereads `ticket.md` and
+and same-filesystem rename. They reuse the existing review-job `withFileLock`
+protocol, not the ledger's lease protocol: the lock records the writer PID,
+waits up to two seconds for a live owner, and recovers a dead owner's lock only
+after checking that its device/inode still matches the inspected file. A
+malformed owner becomes recoverable after the existing two-second age threshold.
+Normal release also checks device/inode identity before unlinking. A live or
+unrecoverable lock returns `REVIEW_DISPOSITION_WRITE_UNAVAILABLE`; leave the
+ticket unchanged, check its current contents, and retry after the active writer
+finishes. Never remove a live owner's lock to force progress. A crashed writer's
+dead-owner lock is recovered on retry; no new lease, fencing token, or recovery
+command is introduced. The public disposition proof covers dead-owner retry
+and live-owner refusal through this shared helper.
+Under that lock the command rereads `ticket.md` and
 rejects a digest mismatch, so cooperating Safeword disposition writers serialize
 and any earlier ticket edit returns the current digest for retry. This is not a
 universal filesystem compare-and-swap: an out-of-band writer that ignores the
@@ -601,7 +686,14 @@ Architecture applicability: this changes the shared `review` component's packet,
 
 ## Known deviations
 
-No unresolved deviations. If this plan is approved, the proposed fallback
+User-accepted proof deferral (2026-09-30): host-level hostile-content injection
+at the planning agent's retrieval boundary is deferred. Packet quarantine tests
+and the judged corpus do not prove the host never follows retrieved instructions,
+executes retrieved code, or discloses private context. R7 and epic acceptance stay
+unfinished until that boundary is proved; this deferral grants neither completion
+nor merge authority.
+
+If this plan is approved, the proposed fallback
 record linked above will supersede the older coordinator record's clauses that
 called every same-agent result `degraded`, prohibited host-owned fallback
 receipts from creating a stamp, and allowed host tiers to read live worktree
diff --git a/.project/tickets/5F5ZZA-keep-plan-reviews-current-and-trustworthy/planning-contracts-eval-history.md b/.project/tickets/5F5ZZA-keep-plan-reviews-current-and-trustworthy/planning-contracts-eval-history.md
new file mode 100644
index 000000000..f97430859
--- /dev/null
+++ b/.project/tickets/5F5ZZA-keep-plan-reviews-current-and-trustworthy/planning-contracts-eval-history.md
@@ -0,0 +1,23 @@
+# Planning-contract eval history
+
+The fixed judged corpus uses three reviewer runs per case and requires at least
+two correct judgments. Each run's exact manifest, reviewer outputs, judge
+reasons, and per-case status are in `planning-contracts-eval.json`.
+
+During harness development, complete runs scored 8/11, 9/11, 9/11, and 10/11
+before an 11/11 run. None of the incomplete runs was treated as passing. The
+inconclusive cases exposed ambiguous or incomplete synthetic packets (corrected
+plan bytes, persona failure outcomes, and the missing-boundary case), an
+ambiguous `scope_expanded` projection, and a judge that lacked the canonical
+phase contract. The fixtures now isolate the intended rule, the judge receives
+the actual phase contract, and both are pinned by manifest digests. Focused
+three-run checks of the disputed cases preceded that full run. Two further R7
+cases were then added for a public source requesting private project material
+and a source declaring no reuse limits. Each passed a focused three-run check;
+the expanded fixed corpus then passed **13/13** cases with three runs each.
+The current raw report and manifest retain every reviewer verdict and judge
+reason for that final run.
+
+The semantic eval is distinct from deterministic installed-boundary tests and
+from the reviewer-capability catalogue. It does not prove that every real-world
+planning packet will be judged correctly.
