Current PR5 complete unique-source review 15/19. Base 854a376861bc034d65cc81ddfa6a85d0ae55821e; head b722f9a27a1815abcfb08e6f6ca09dc7317efa46. Review actual correctness, authenticated approval, rejection findings and test discrimination. Every unique production source, template, test, step and generator changed in PR5 is supplied across these packets. Byte-identical installed mirrors and compiled bundles are omitted; all five generated surfaces passed at this head. Prior historical acceptance failures remain visible; full current run is in progress. Exactly 33 cases are user-deferred and unverified. This is source review, not native-host or merge approval. Flag only concrete in-scope defects; optional hardening does not block.

diff --git a/steps/keep-plan-reviews-dependencies.steps.ts b/steps/keep-plan-reviews-dependencies.steps.ts
new file mode 100644
index 000000000..e4d3797bf
--- /dev/null
+++ b/steps/keep-plan-reviews-dependencies.steps.ts
@@ -0,0 +1,313 @@
+import { strict as assert } from 'node:assert';
+import { spawnSync } from 'node:child_process';
+import { cpSync, mkdtempSync, readFileSync, rmSync, writeFileSync } from 'node:fs';
+import { tmpdir } from 'node:os';
+import path from 'node:path';
+
+import { After, Given, Then, When } from '@cucumber/cucumber';
+
+import { parsePlanningContract } from '../packages/cli/src/planning/phase-contract.js';
+import { parseDeliveryPlanContract } from '../packages/cli/src/execution-plan/delivery-checklist.js';
+import { extractExecutionPlanReviewRubric } from '../packages/cli/src/review/execution-plan-rubric.js';
+import { extractPlanReviewRubric } from '../packages/cli/src/review/plan-rubric.js';
+import {
+  admitThroughInstalledCli,
+  featureFixture,
+} from '../packages/cli/tests/fixtures/execution-review.js';
+import { cleanupTrustedReviewerDirectories } from '../packages/cli/tests/review-fixtures.js';
+import type { SafewordWorld } from './world.js';
+import { fixtureProject } from './keep-plan-reviews-installed-context.steps.js';
+
+const ticketDirectory = '.project/tickets/ABC123-feature';
+const states = new WeakMap<SafewordWorld, DependencyState>();
+
+interface DependencyState {
+  root: string;
+  runtime: string;
+  implementation: string;
+  execution: string;
+  observed?: readonly string[];
+  canonicalChanged?: boolean;
+}
+
+function executionAdmission(state: DependencyState): string {
+  const result = spawnSync('bun', [path.join(state.runtime, 'runtime/hooks/pre-tool-quality.ts')], {
+    cwd: state.root,
+    encoding: 'utf8',
+    timeout: 30_000,
+    input: JSON.stringify({
+      session_id: 'r9-dependency',
+      tool_name: 'Edit',
+      tool_input: {
+        file_path: path.join(state.root, ticketDirectory, 'ticket.md'),
+        old_string: 'phase: plan-execution',
+        new_string: 'phase: implement',
+      },
+    }),
+    env: {
+      ...process.env,
+      XDG_STATE_HOME: path.join(state.root, '.review-keys'),
+      CLAUDE_PROJECT_DIR: state.root,
+      CLAUDE_PLUGIN_ROOT: state.runtime,
+    },
+  });
+  assert.equal(result.error, undefined, result.error?.message);
+  assert.equal(result.status, 0, `${result.stdout}\n${result.stderr}`);
+  return result.stdout.trim();
+}
+
+function reviewStatuses(state: DependencyState): readonly string[] {
+  return [state.implementation, state.execution].map(id => {
+    const result = spawnSync(
+      'bun',
+      [path.join(state.runtime, 'runtime/cli.js'), 'review', 'status', id, '--json'],
+      {
+        cwd: state.root,
+        encoding: 'utf8',
+        timeout: 30_000,
+        env: {
+          ...process.env,
+          XDG_STATE_HOME: path.join(state.root, '.review-keys'),
+          CLAUDE_PLUGIN_ROOT: state.runtime,
+        },
+      },
+    );
+    assert.equal(result.error, undefined, result.error?.message);
+    const output = JSON.parse(result.stdout);
+    assert.deepEqual(output.errors, [], `${result.stdout}\n${result.stderr}`);
+    assert.ok(output.data.review_identity, 'the receipts must carry owned planning identities');
+    assert.ok(['approved', 'stale'].includes(output.data.status), result.stdout);
+    return output.data.status;
+  });
+}
+
+async function currentReceipts(world: SafewordWorld): Promise<void> {
+  const root = featureFixture();
+  const runtime = mkdtempSync(path.join(tmpdir(), 'safeword-r9-dependency-'));
+  const state = { root, runtime, implementation: '', execution: '' };
+  states.set(world, state);
+  // Semantic dependencies belong to an owned v1 planning ticket, not a legacy plan.
+  const owned = fixtureProject();
+  try {
+    for (const file of ['ticket.md', 'spec.md', 'impl-plan.md']) {
+      const content = readFileSync(
+        path.join(owned, '.project/tickets/CTX123-current-context', file),
+        'utf8',
+      )
+        .replaceAll('CTX123', 'ABC123')
+        .replaceAll('features/current-context.feature', 'features/feature.feature')
+        .replace('phase: plan-implementation', 'phase: plan-execution');
+      writeFileSync(path.join(root, ticketDirectory, file), content);
+    }
+    writeFileSync(
+      path.join(root, 'features/feature.feature'),
+      readFileSync(path.join(owned, 'features/current-context.feature'), 'utf8'),
+    );
+  } finally {
+    rmSync(owned, { recursive: true, force: true });
+  }
+  cpSync(path.resolve(import.meta.dirname, '../plugin'), runtime, { recursive: true });
+  // Dispatch and currency reconstruction use the same installed distribution.
+  await admitThroughInstalledCli(async (args, options) => {
+    const reviewed = spawnSync('bun', [path.join(runtime, 'runtime/cli.js'), ...args], {
+      cwd: options.cwd,
+      encoding: 'utf8',
+      timeout: 60_000,
+      env: {
+        ...process.env,
+        ...options.env,
+        PATH: `${options.env.PATH}:${process.env.PATH ?? ''}`,
+        XDG_STATE_HOME: path.join(root, '.review-keys'),
+        CLAUDE_PLUGIN_ROOT: runtime,
+      },
+    });
+    assert.equal(reviewed.error, undefined, reviewed.error?.message);
+    return {
+      exitCode: reviewed.status ?? 1,
+      stdout: reviewed.stdout,
+      stderr: reviewed.stderr,
+    };
+  }, root);
+  const ledger = readFileSync(path.join(root, '.project/skill-invocations.log'), 'utf8');
+  for (const [field, kind] of [
+    ['implementation', 'plan-implementation'],
+    ['execution', 'plan-execution'],
+  ] as const) {
+    const row = ledger.split('\n').find(line => line.includes(`:phase@${kind} `));
+    assert.ok(row);
+    const id = /review-id:(\S+)/u.exec(row)?.[1];
+    assert.ok(id);
+    state[field] = id;
+  }
+  assert.deepEqual(
+    reviewStatuses(state),
+    ['approved', 'approved'],
+    'both authentic receipts must start current',
+  );
+  assert.equal(
+    executionAdmission(state),
+    '',
+    'the current authenticated receipts must admit coding',
+  );
+}
+
+Given(
+  'both plans have current review receipts',
+  { timeout: 60_000 },
+  async function (this: SafewordWorld) {
+    await currentReceipts(this);
+  },
+);
+
+Given(
+  'current plan-review receipts and a canonical Execution Planning contract that declares accepted Implementation Plan changes invalidate both plan reviews',
+  { timeout: 60_000 },
+  async function (this: SafewordWorld) {
+    await currentReceipts(this);
+    const state = states.get(this);
+    assert.ok(state);
+    const contract = readFileSync(
+      path.join(state.runtime, 'templates/skills/bdd/PLAN_EXECUTION.md'),
+      'utf8',
+    );
+    const parsed = parsePlanningContract('plan-execution', contract);
+    assert.equal(parsed.phase, 'plan-execution');
+    assert.ok('upstreamImplementationInvalidation' in parsed);
+    assert.equal(parsed.upstreamImplementationInvalidation, 'both_plan_reviews');
+  },
+);
+
+function changeCanonicalContract(state: DependencyState, implementation: boolean): void {
+  const file = implementation ? 'PLAN_IMPLEMENTATION.md' : 'PLAN_EXECUTION.md';
+  const before = '- **Purpose:**';
+  const after = '- **Purpose:**   ';
+  const extract = implementation ? extractPlanReviewRubric : extractExecutionPlanReviewRubric;
+  // Change the actual canonical and installed authoring files, leaving the
+  // previously approved runtime and reviewer copy untouched.
+  for (const directory of ['templates/skills/bdd', 'skills/bdd']) {
+    const contract = path.join(state.runtime, directory, file);
+    const content = readFileSync(contract, 'utf8');
+    assert.ok(content.includes(before), `the ${file} contract must declare its purpose`);
+    const changed = content.replace(before, () => after);
+    assert.notEqual(extract(changed), extract(content), 'the exact bounded contract must change');
+    writeFileSync(contract, changed);
+  }
+  state.canonicalChanged = true;
+}
+
+function changeFile(
+  state: DependencyState,
+  file: string,
+  change: (content: string) => string,
+): void {
+  const absolute = path.join(state.root, file);
+  const before = readFileSync(absolute, 'utf8');
+  const after = change(before);
+  assert.notEqual(after, before, `the ${file} mutation must actually change bytes`);
+  writeFileSync(absolute, after);
+}
+
+const mutations: Record<string, (state: DependencyState) => void> = {
+  'accepted behavior': state =>
+    changeFile(state, 'features/feature.feature', content =>
+      content.replace(
+        'Then the current context reaches review',
+        'Then changed acceptance reaches review',
+      ),
+    ),
+  'accepted scope': state =>
+    changeFile(state, `${ticketDirectory}/ticket.md`, content =>
+      content.replace(
+        'scope: preserve authenticated approval',
+        'scope: change accepted approval boundary',
+      ),
+    ),
+  'canonical Implementation Planning contract bytes change': state =>
+    changeCanonicalContract(state, true),
+  'only canonical Execution Planning contract bytes change': state =>
+    changeCanonicalContract(state, false),
+  "only the accepted Implementation Plan's formatting bytes": state =>
+    changeFile(state, `${ticketDirectory}/impl-plan.md`, content => `${content}\n`),
+  'only the Execution Plan bytes, including formatting-only bytes outside normalized checklist progress cells':
+    state => changeFile(state, `${ticketDirectory}/execution-plan.md`, content => `${content}\n`),
+  "only whitespace inside a reviewed Execution Plan checklist row's normalized progress cells":
+    state =>
+      changeFile(state, `${ticketDirectory}/execution-plan.md`, content =>
+        content.replace('| open | missing |  |  |', '|   open   |   missing   |   |   |'),
+      ),
+  "only ordinary progress in a reviewed Execution Plan checklist row's Disposition, Evidence class, Revision, or final evidence cell":
+    state =>
+      changeFile(state, `${ticketDirectory}/execution-plan.md`, content =>
+        content.replace(
+          '| open | missing |  |  |',
+          '| complete | current_revision_real_boundary | fixture-revision | receipt:fixture-progress |',
+        ),
+      ),
+};
+
+for (const [description, mutate] of Object.entries(mutations)) {
+  When(`${description} occurs`, function (this: SafewordWorld) {
+    const state = states.get(this);
+    assert.ok(state);
+    mutate(state);
+    // A progress locator is fixture input, not a claim of authenticated delivery proof.
+    const parsed = parseDeliveryPlanContract(
+      readFileSync(path.join(state.root, ticketDirectory, 'execution-plan.md'), 'utf8'),
+    );
+    assert.ok(parsed.ok, 'each mutation must preserve a structurally valid Delivery Checklist');
+    state.observed = reviewStatuses(state);
+  });
+}
+
+When('the accepted Implementation Plan changes semantically', function (this: SafewordWorld) {
+  const state = states.get(this);
+  assert.ok(state);
+  changeFile(state, `${ticketDirectory}/impl-plan.md`, content =>
+    content.replace(
+      'Use the current review receipt to guard the transition.',
+      'Use a different authenticated review receipt to guard the transition.',
+    ),
+  );
+  state.observed = reviewStatuses(state);
+});
+
+const expectedStatuses: Record<string, readonly string[]> = {
+  'both plan reviews are invalidated': ['stale', 'stale'],
+  'only the Execution Plan review is invalidated': ['approved', 'stale'],
+  'only the Implementation Plan review is invalidated and the Execution Plan review remains current':
+    ['stale', 'approved'],
+  'neither plan review is invalidated': ['approved', 'approved'],
+};
+
+Then(
+  /^(both plan reviews are invalidated|only the Execution Plan review is invalidated|only the Implementation Plan review is invalidated and the Execution Plan review remains current|neither plan review is invalidated)$/,
+  function (this: SafewordWorld, result: string) {
+    const state = states.get(this);
+    assert.ok(state?.observed);
+    assert.deepEqual(state.observed, expectedStatuses[result], result);
+    if (state.canonicalChanged) {
+      const output = executionAdmission(state);
+      assert.notEqual(output, '', 'a changed canonical contract must not admit coding');
+      const denied = JSON.parse(output);
+      assert.equal(denied.hookSpecificOutput?.permissionDecision, 'deny', output);
+      const requiredApproval =
+        state.observed[0] === 'stale'
+          ? 'An accepted implementation approach is required before execution.'
+          : 'An admitted Delivery Checklist is required before execution.';
+      assert.ok(
+        denied.hookSpecificOutput?.permissionDecisionReason?.startsWith(requiredApproval),
+        output,
+      );
+    }
+  },
+);
+
+After(function (this: SafewordWorld) {
+  const state = states.get(this);
+  if (state) {
+    rmSync(state.root, { recursive: true, force: true });
+    rmSync(state.runtime, { recursive: true, force: true });
+    cleanupTrustedReviewerDirectories();
+  }
+  states.delete(this);
+});
diff --git a/steps/keep-plan-reviews-disposition.steps.ts b/steps/keep-plan-reviews-disposition.steps.ts
new file mode 100644
index 000000000..c65f9a9e7
--- /dev/null
+++ b/steps/keep-plan-reviews-disposition.steps.ts
@@ -0,0 +1,270 @@
+import { strict as assert } from 'node:assert';
+import { mkdirSync, readFileSync, rmSync, writeFileSync } from 'node:fs';
+import path from 'node:path';
+
+import { After, Given, Status, Then, When } from '@cucumber/cucumber';
+
+import { prepareReviewPacket } from '../packages/cli/src/review/packet.js';
+import { acceptedBoundaryDigest } from '../packages/cli/src/review/planning-accepted-boundary.js';
+import { planningContractCases } from '../packages/cli/tests/fixtures/planning-contracts-eval.js';
+import {
+  createReviewedDispositionProject,
+  target,
+} from '../packages/cli/tests/fixtures/planning-disposition.js';
+import {
+  assertPlanningEval,
+  runPlanningEval,
+  selectPlanningEval,
+} from './support/planning-eval.js';
+import type { SafewordWorld } from './world.js';
+
+const suggestion = 'Consider adding optional multi-region failover.';
+const planTarget = target.replace('spec.md', 'impl-plan.md');
+interface DispositionState {
+  project: Awaited<ReturnType<typeof createReviewedDispositionProject>>;
+  plan: string;
+  reviewId: string;
+  acceptance?: { ticket: string; boundaryDigest: string };
+}
+const states = new WeakMap<SafewordWorld, DispositionState>();
+const roots = new WeakMap<SafewordWorld, string[]>();
+
+export async function prepareRecordedSuggestion(world: SafewordWorld): Promise<void> {
+  const owned: string[] = [];
+  roots.set(world, owned);
+  const project = await createReviewedDispositionProject(owned, suggestion);
+  const complete = planningContractCases.find(item => item.id === 'r12-complete-scope-context');
+  assert.ok(complete);
+  writeFileSync(
+    project.ticketPath,
+    `---
+id: DIS123
+type: feature
+phase: plan-implementation
+status: in_progress
+product_plan_contract: v1
+scope:
+- require explicit user authorization before account changes
+out_of_scope:
+- automatic account migration
+- multi-region failover
+done_when: authorized changes succeed and denied changes do not mutate
+phase_anchors:
+- scenario-gate: features/manual-change.feature
+---
+`,
+  );
+  writeFileSync(
+    path.join(project.root, target),
+    `# Product Plan
+
+<!-- safeword:product-plan-contract:v1 -->
+
+## Product Bet
+- **Expected outcome:** Builders authorize one manual account change.
+- **Persona outcome inventory:** Builder sees success as an authorized change; refusal as no mutation; failure as a named error with no mutation; approval as explicit consent; trust as an owner-named receipt; recovery as obtaining fresh consent and retrying the same target.
+- **Known facts:** Account changes require explicit user authorization.
+- **Assumptions:** The existing consent-token API can enforce it.
+- **Unresolved product decisions:** none
+- **Success threshold:** Authorized changes succeed; denied changes leave the account intact.
+- **Project non-goals:** No background account mutation or multi-region failover.
+
+## Jobs To Be Done
+### approval.BU1 — Authorize a manual change
+**Persona:** Builder (BU)
+#### approval.BU1.R1 — Preserve consent
+An owner-authorized token permits one target account change. Absent, expired or mismatched consent permits no mutation. A transient failure permits retry without mutation.
+
+## Shape
+### M1 — Safe manual approval
+- **Outcome:** One owner-authorized target account changes.
+- **Non-goals:** Batched account changes and multi-region failover.
+
+## Surfaces
+Affected:
+- Safeword CLI
+`,
+  );
+  mkdirSync(path.join(project.root, 'features'), { recursive: true });
+  writeFileSync(
+    path.join(project.root, 'features/manual-change.feature'),
+    `@approval.BU1.R1 @surface.safeword-cli
+Feature: Manual authorized account changes
+Scenario: Authorized change
+  Given valid consent for the requesting owner and target account
+  When a manual account change is requested
+  Then one authorized account changes
+Scenario: Denied change
+  Given absent expired or mismatched consent
+  When a manual account change is requested
+  Then no account mutation occurs
+Scenario: Retry a transient failure
+  Given a transient endpoint failure
+  When the same manual change is retried with valid consent
+  Then the retry succeeds without an earlier mutation
+`,
+  );
+  const plan = `# Implementation Plan
+
+## Approach
+${complete.reviewed_plan}
+
+## Architecture applicability
+skip: No durable architecture record applies to this existing endpoint.
+
+## Data applicability
+skip: Existing account schema and consent-token contract stay unchanged; no new data shape or migration is introduced.
+
+## Measurement applicability
+skip: The Product Plan makes no quantitative promise.
+`;
+  writeFileSync(path.join(project.root, planTarget), plan);
+  const reviewed = await project.run(['review', 'run', 'plan-implementation', planTarget]);
+  assert.equal(reviewed.exitCode, 0, `${reviewed.stdout}\n${reviewed.stderr}`);
+  const data = JSON.parse(reviewed.stdout).data;
+  assert.equal(data.status, 'approved');
+  assert.deepEqual(data.reviewer_output.findings, [{ severity: 'warning', message: suggestion }]);
+  states.set(world, { project, plan, reviewId: data.review_id });
+}
+
+export function recordedSuggestion(world: SafewordWorld): DispositionState {
+  const state = states.get(world);
+  assert.ok(state);
+  return state;
+}
+
+Given(
+  'a nonblocking reviewer suggestion for a useful capability outside the accepted boundary is recorded',
+  { timeout: 60_000 },
+  async function (this: SafewordWorld) {
+    await prepareRecordedSuggestion(this);
+  },
+);
+
+When('the user declines it', function (this: SafewordWorld) {
+  const state = states.get(this);
+  assert.ok(state);
+  const result = state.project.terminal('y', state.reviewId);
+  assert.equal(result.status, 0, `${result.stdout}\n${result.stderr}`);
+  assert.match(result.stdout, /"status":"recorded"/u);
+});
+
+When('the user accepts it', function (this: SafewordWorld) {
+  const state = recordedSuggestion(this);
+  const { project } = state;
+  const specPath = path.join(project.root, target);
+  const before = acceptedBoundaryDigest(
+    readFileSync(project.ticketPath, 'utf8'),
+    readFileSync(specPath, 'utf8'),
+  );
+  // Synthetic explicit user direction, recorded through the existing authoring
+  // workflow. This is not an identity-authenticated scope-writing command.
+  const ticket =
+    readFileSync(project.ticketPath, 'utf8')
+      .replace(
+        '- require explicit user authorization before account changes\n',
+        '- require explicit user authorization before account changes\n- allow owner-requested manual multi-region failover using the existing consent guard\n',
+      )
+      .replace('- multi-region failover\n', '') +
+    `\n## User-accepted expansion\n\nThe user explicitly accepts the optional manual multi-region failover suggested in authenticated review ${state.reviewId}, finding 1: ${suggestion} Automatic failover and background mutation remain excluded. Record this boundary before correcting the Implementation Plan.\n`;
+  writeFileSync(project.ticketPath, ticket);
+  const spec =
+    readFileSync(specPath, 'utf8')
+      .replace(
+        'No background account mutation or multi-region failover.',
+        'No background account mutation or automatic failover.',
+      )
+      .replace(
+        'Batched account changes and multi-region failover.',
+        'Batched account changes and automatic failover.',
+      ) +
+    `\n## Accepted manual recovery boundary\n\nThe user may explicitly retry a pre-commit failure against a secondary region using the same owner/target consent guard. A successful retry produces one mutation and an owner-named receipt. Denial or another pre-commit failure produces no mutation. An uncertain post-commit result permits no automatic retry. This is user-requested manual multi-region failover; automatic failover stays excluded.\n`;
+  writeFileSync(specPath, spec);
+  const boundaryDigest = acceptedBoundaryDigest(ticket, spec);
+  assert.notEqual(boundaryDigest, before);
+  assert.equal(
+    readFileSync(path.join(project.root, planTarget), 'utf8'),
+    state.plan,
+    'Record acceptance and change the boundary before plan bytes.',
+  );
+  state.acceptance = { ticket, boundaryDigest };
+});
+
+Then(
+  'the expansion is recorded as user-accepted before the plan is corrected and re-reviewed',
+  { timeout: 240_000 },
+  async function (this: SafewordWorld) {
+    const state = recordedSuggestion(this);
+    assert.ok(state.acceptance);
+    const previous = await state.project.run(['review', 'status', state.reviewId]);
+    assert.equal(
+      JSON.parse(previous.stdout).data.status,
+      'stale',
+      'The boundary edit invalidates the previous approval before plan correction.',
+    );
+    const plan = `${state.plan}\n## User-accepted manual regional recovery\n\nUse the existing manual endpoint and authoritative account/consent store for both regions; regional routing does not create an independent consent authority or a second account copy. The caller explicitly selects primary or secondary through the CLI region option. Both routes enforce the same owner/target/expiry guard before the single atomic account mutation. The trusted session owner label supplies the receipt; no credential or caller-supplied owner label is printed.\n\nA pre-commit failure leaves the account and consent unconsumed so the owner can explicitly retry the same target through the secondary region. A successful retry consumes consent and changes one account once. An uncertain post-commit outcome must not claim no mutation or confirmed success, and permits no automatic retry or failover.\n\nProof invokes the real CLI against primary pre-commit failure, verifies unchanged authoritative state, explicitly retries the same target in secondary with valid consent, and verifies one mutation plus the owner-named receipt. Both region routes also prove denied, expired and mismatched consent leaves state unchanged and returns a nonzero CLI exit. Rollout keeps regional routing off until those proofs pass; rollback disables the new region option while retaining the consent guard. Automatic failover, background mutation and account migration remain excluded.\n`;
+    writeFileSync(path.join(state.project.root, planTarget), plan);
+    const packet = prepareReviewPacket(state.project.root, 'plan-implementation', [
+      planTarget,
+    ]).packet;
+    assert.equal(
+      packet.review_disposition_context,
+      undefined,
+      'Acceptance is the authoritative scope edit, not a fabricated disposition.',
+    );
+    selectPlanningEval(this, 'r14-user-accepted-expansion', {
+      context: JSON.stringify(packet),
+      reviewed_plan: plan,
+    });
+    runPlanningEval(this);
+    assertPlanningEval(this, 'approve');
+    assert.equal(readFileSync(state.project.ticketPath, 'utf8'), state.acceptance.ticket);
+    assert.equal(readFileSync(path.join(state.project.root, planTarget), 'utf8'), plan);
+    assert.equal(
+      acceptedBoundaryDigest(
+        state.acceptance.ticket,
+        readFileSync(path.join(state.project.root, target), 'utf8'),
+      ),
+      state.acceptance.boundaryDigest,
+    );
+  },
+);
+
+Then(
+  'the unchanged plan is re-reviewed against the accepted boundary and the decline remains recorded',
+  { timeout: 240_000 },
+  async function (this: SafewordWorld) {
+    const state = states.get(this);
+    assert.ok(state);
+    const { project, plan, reviewId } = state;
+    const ticket = readFileSync(project.ticketPath, 'utf8');
+    const status = await project.run(['review', 'status', reviewId]);
+    assert.equal(JSON.parse(status.stdout).data.status, 'stale');
+    const packet = prepareReviewPacket(project.root, 'plan-implementation', [planTarget]).packet;
+    const record = packet.review_disposition_context?.records[0];
+    assert.ok(record);
+    assert.equal(record.review_id, reviewId);
+    assert.equal(record.message, suggestion);
+    assert.equal(record.disposition, 'declined');
+    assert.equal(record.boundary_status, 'current');
+    assert.equal(readFileSync(path.join(project.root, planTarget), 'utf8'), plan);
+    selectPlanningEval(this, 'r14-declined-strengthening', {
+      context: JSON.stringify(packet),
+      reviewed_plan: plan,
+    });
+    runPlanningEval(this);
+    assertPlanningEval(this, 'approve', undefined, /declin|failover/iu);
+    assert.equal(readFileSync(path.join(project.root, planTarget), 'utf8'), plan);
+    assert.equal(readFileSync(project.ticketPath, 'utf8'), ticket);
+  },
+);
+
+After(function (this: SafewordWorld, scenario) {
+  if (scenario.result?.status === Status.FAILED) {
+    console.error(`Retained disposition fixture: ${(roots.get(this) ?? []).join(', ')}`);
+    return;
+  }
+  for (const root of roots.get(this) ?? []) rmSync(root, { recursive: true, force: true });
+  roots.delete(this);
+  states.delete(this);
+});
diff --git a/steps/keep-plan-reviews-fallback-order.steps.ts b/steps/keep-plan-reviews-fallback-order.steps.ts
new file mode 100644
index 000000000..61194b519
--- /dev/null
+++ b/steps/keep-plan-reviews-fallback-order.steps.ts
@@ -0,0 +1,233 @@
+import { strict as assert } from 'node:assert';
+import { readFileSync, writeFileSync } from 'node:fs';
+import path from 'node:path';
+
+import { Given, Then, When } from '@cucumber/cucumber';
+
+import { installedReviewCli } from '../packages/cli/tests/fixtures/execution-review.js';
+import { reviewerScript } from '../packages/cli/tests/fixtures/planning-reviewers.js';
+import { coordinate, prepare } from './keep-plan-reviews-independence.steps.js';
+import type { SafewordWorld } from './world.js';
+
+type Tier =
+  'same-agent headless review' | 'host-reported fresh-context review' | 'bounded self-review';
+type OrderState = Awaited<ReturnType<typeof prepare>> & {
+  nextTier: Tier;
+  launchLog: string;
+  reviewId?: string;
+  dispatchId?: string;
+};
+const states = new WeakMap<SafewordWorld, OrderState>();
+
+Given(
+  /^every route before (same-agent headless review|host-reported fresh-context review|bounded self-review) is configured to return a typed failure when attempted$/,
+  { timeout: 120_000 },
+  async function (this: SafewordWorld, nextTier: Tier) {
+    const state = await prepare(this, true);
+    const directory = path.dirname(state.marker);
+    const launchLog = path.join(directory, 'launch-order');
+    states.set(this, Object.assign(state, { nextTier, launchLog }));
+    const configPath = path.join(state.root, '.safeword/config.json');
+    const config = JSON.parse(readFileSync(configPath, 'utf8'));
+    writeFileSync(
+      configPath,
+      JSON.stringify({
+        ...config,
+        crossAgentReviewRoutes: {
+          claude: [{ reviewer: 'codex', model: 'gpt-6.1-sol' }, { reviewer: 'claude' }],
+        },
+      }),
+    );
+    for (const agent of ['codex', 'claude'] as const) {
+      const marker = agent === 'codex' ? state.marker : path.join(directory, 'headless-invoked');
+      const script = reviewerScript(
+        agent,
+        marker,
+        path.join(directory, `${agent}-packet.json`),
+        agent === 'codex',
+        true,
+      );
+      const launch = `writeFileSync(${JSON.stringify(marker)}, 'yes');`;
+      const observed = script.replace(
+        launch,
+        `${launch}\nrequire('node:fs').appendFileSync(${JSON.stringify(launchLog)}, '${agent}\\n');`,
+      );
+      assert.notEqual(observed, script);
+      const producer =
+        agent === 'claude' && nextTier !== 'same-agent headless review'
+          ? observed.replace(
+              'function reviewOutput(packet)',
+              'process.exit(7);\nfunction reviewOutput(packet)',
+            )
+          : observed;
+      writeFileSync(path.join(directory, agent), producer, { mode: 0o755 });
+    }
+  },
+);
+
+async function continueHost(
+  state: OrderState,
+  tier: 'fresh-context' | 'self-review',
+  failure: boolean,
+) {
+  assert.ok(state.result?.data.continuation);
+  const reviewId = state.result.data.review_id;
+  const dispatchId = state.result.data.continuation.packet.dispatch_id;
+  assert.equal(state.result.data.continuation.tier, tier);
+  if (!failure)
+    writeFileSync(
+      path.join(state.root, 'host-review.json'),
+      JSON.stringify({
+        schema_version: 1,
+        dispatch_id: dispatchId,
+        reviewer_agent: 'claude',
+        verdict: 'approve',
+        summary: `Approved by host-reported ${tier}.`,
+        findings: [],
+        evidence_records: { schema_version: 1, records: [] },
+      }),
+    );
+  const result = await installedReviewCli(state.root)(
+    [
+      'review',
+      'continue',
+      reviewId,
+      '--tier',
+      tier,
+      ...(failure ? ['--failure', 'process_failed'] : ['--output', 'host-review.json']),
+      '--offline',
+      '--json',
+      '--cwd',
+      state.root,
+    ],
+    { cwd: state.root, env: state.env },
+  );
+  assert.equal(result.exitCode, failure ? 2 : 0, result.stdout);
+  state.result = JSON.parse(result.stdout);
+  assert.ok(state.result?.data.continuation);
+  assert.equal(state.result.data.review_id, reviewId);
+  assert.equal(state.result.data.continuation.packet.dispatch_id, dispatchId);
+  state.reviewId = reviewId;
+  state.dispatchId = dispatchId;
+}
+
+async function refusePrematureSelfReview(state: OrderState) {
+  assert.ok(state.result?.data.continuation);
+  const reviewId = state.result.data.review_id;
+  const dispatchId = state.result.data.continuation.packet.dispatch_id;
+  writeFileSync(
+    path.join(state.root, 'premature-review.json'),
+    JSON.stringify({
+      schema_version: 1,
+      dispatch_id: dispatchId,
+      reviewer_agent: 'claude',
+      verdict: 'approve',
+      summary: 'A valid output cannot bypass the pending fresh-context tier.',
+      findings: [],
+      evidence_records: { schema_version: 1, records: [] },
+    }),
+  );
+  const cli = installedReviewCli(state.root);
+  const refused = await cli(
+    [
+      'review',
+      'continue',
+      reviewId,
+      '--tier',
+      'self-review',
+      '--output',
+      'premature-review.json',
+      '--offline',
+      '--json',
+      '--cwd',
+      state.root,
+    ],
+    { cwd: state.root, env: state.env },
+  );
+  assert.equal(refused.exitCode, 1, refused.stdout);
+  const result = JSON.parse(refused.stdout);
+  assert.ok(
+    result.errors.some(
+      (error: { code: string }) => error.code === 'REVIEW_CONTINUATION_TIER_INVALID',
+    ),
+  );
+  const current = await cli(['review', 'status', reviewId, '--json', '--cwd', state.root], {
+    cwd: state.root,
+    env: state.env,
+  });
+  const data = JSON.parse(current.stdout).data;
+  assert.equal(data.status, 'continuation_required');
+  assert.equal(data.continuation.tier, 'fresh-context');
+  assert.equal(data.continuation.packet.dispatch_id, dispatchId);
+  assert.deepEqual(data.continuation_attempts ?? [], []);
+}
+
+When(
+  'review recovery selects the next permitted route',
+  { timeout: 120_000 },
+  async function (this: SafewordWorld) {
+    const state = states.get(this);
+    assert.ok(state);
+    const headless = state.nextTier === 'same-agent headless review';
+    await coordinate(state, 'claude', headless ? 'approved' : 'continuation_required');
+    if (headless) return;
+    await refusePrematureSelfReview(state);
+    if (state.nextTier === 'bounded self-review') await continueHost(state, 'fresh-context', true);
+    await continueHost(
+      state,
+      state.nextTier === 'bounded self-review' ? 'self-review' : 'fresh-context',
+      false,
+    );
+  },
+);
+
+Then(
+  /^review recovery selects and attempts (same-agent headless review|host-reported fresh-context review|bounded self-review), and no later tier is attempted first$/,
+  async function (this: SafewordWorld, nextTier: Tier) {
+    const state = states.get(this);
+    assert.ok(state?.result);
+    assert.equal(state.nextTier, nextTier);
+    const self = nextTier === 'bounded self-review';
+    const headless = nextTier === 'same-agent headless review';
+    const launches = readFileSync(state.launchLog, 'utf8').trim().split('\n');
+    // Trusted candidate retries belong to the same tier; interleaving tiers still fails.
+    const tiers = launches.filter((launch, index) => launch !== launches[index - 1]);
+    assert.deepEqual(tiers, ['codex', 'claude']);
+    assert.deepEqual(state.result.data.review_routes, [
+      {
+        reviewer: 'codex',
+        model: 'gpt-6.1-sol',
+        independence: 'cross-agent',
+        status: 'attempted',
+        failure: 'process_failed',
+      },
+      {
+        reviewer: 'claude',
+        independence: 'degraded',
+        status: 'attempted',
+        ...(headless ? {} : { failure: 'process_failed' }),
+      },
+    ]);
+    assert.equal(state.result.data.status, 'approved');
+    assert.equal(state.result.data.actual_reviewer, 'claude');
+    assert.equal(state.result.data.independence, 'reduced');
+    assert.deepEqual(
+      state.result.data.continuation_attempts ?? [],
+      self ? [{ tier: 'fresh-context', failure: 'process_failed' }] : [],
+    );
+    if (headless) assert.equal(state.result.data.continuation, undefined);
+    else {
+      assert.equal(state.result.data.continuation?.tier, self ? 'self-review' : 'fresh-context');
+      assert.equal(state.result.data.continuation?.packet.dispatch_id, state.dispatchId);
+    }
+    const receipt = await installedReviewCli(state.root)(
+      ['review', 'status', state.result.data.review_id, '--json', '--cwd', state.root],
+      { cwd: state.root, env: state.env },
+    );
+    assert.equal(receipt.exitCode, 0, receipt.stdout);
+    const current = JSON.parse(receipt.stdout).data;
+    assert.equal(current.status, 'approved');
+    assert.equal(current.review_id, state.result.data.review_id);
+    assert.deepEqual(current.review_routes, state.result.data.review_routes);
+  },
+);
diff --git a/steps/keep-plan-reviews-finding-authority.steps.ts b/steps/keep-plan-reviews-finding-authority.steps.ts
new file mode 100644
index 000000000..166f5d678
--- /dev/null
+++ b/steps/keep-plan-reviews-finding-authority.steps.ts
@@ -0,0 +1,93 @@
+import { strict as assert } from 'node:assert';
+
+import { Given, Then, When } from '@cucumber/cucumber';
+
+import {
+  assertPlanningEval,
+  runPlanningEval,
+  selectPlanningEval,
+} from './support/planning-eval.js';
+import type { SafewordWorld } from './world.js';
+
+const cases = {
+  'a requirement accepted upstream is unmet': 'r11-unmet-accepted-requirement',
+  'an optional resilience improvement outside accepted scope': 'r11-optional-architecture',
+  'a replacement architecture selected only by the reviewer': 'r11-optional-architecture',
+  'a uniquely determined correction under an accepted decision':
+    'r11-uniquely-determined-correction',
+} as const;
+
+Given(
+  /^a recorded planning-review finding of (.+)$/,
+  function (this: SafewordWorld, finding: keyof typeof cases) {
+    const caseId = cases[finding];
+    assert.ok(caseId, `Unknown finding authority case: ${finding}`);
+    const evaluationCase = selectPlanningEval(this, caseId);
+    if (caseId !== 'r11-optional-architecture') {
+      assert.match(evaluationCase.accepted_boundary, /manual\.BU1\.R1/u);
+      assert.equal(evaluationCase.expected_verdict, 'request_changes');
+      assert.match(
+        evaluationCase.reviewed_plan,
+        caseId === 'r11-unmet-accepted-requirement'
+          ? /without checking consent/u
+          : /after the account write/u,
+      );
+      assert.doesNotMatch(
+        evaluationCase.reviewed_plan,
+        /checks a consent token linked to the requesting user and target account before any write/u,
+      );
+      return;
+    }
+    assert.match(
+      evaluationCase.context,
+      /Reviewer preference: replace the consent-token API with a new event bus for resilience/u,
+    );
+    assert.match(evaluationCase.reviewed_plan, /consent-token API/u);
+    assert.match(evaluationCase.accepted_boundary, /explicit user authorization/u);
+    assert.equal(evaluationCase.expected_verdict, 'approve');
+  },
+);
+
+When(
+  'a judged semantic reviewer evaluation applies the canonical finding-authority rubric against the accepted contract and scope',
+  { timeout: 240_000 },
+  function (this: SafewordWorld) {
+    runPlanningEval(this);
+  },
+);
+
+Then(
+  'the suggestion remains nonblocking until the user accepts it',
+  function (this: SafewordWorld) {
+    assertPlanningEval(this, 'approve', undefined, /event[ -]?bus/iu);
+  },
+);
+
+Then(
+  'the review blocks with the violated Rule, defect, unresolved choice, and constraints named',
+  function (this: SafewordWorld) {
+    assertPlanningEval(
+      this,
+      'request_changes',
+      /(?=.*manual\.BU1\.R1)(?=.*(?:authoriz|consent|token))(?=.*(?:before|unchecked|without))(?=.*(?:user|owner))(?=.*account)(?=.*(?:unresolved|undecided|binding|bound|tie|link))(?=.*(?:migration|background|existing.{0,20}(?:token|API)))/isu,
+    );
+  },
+);
+
+Then(
+  'the review blocks with the uniquely determined correction named',
+  function (this: SafewordWorld) {
+    assertPlanningEval(
+      this,
+      'request_changes',
+      /(?=.*(?:consent|token|authoriz))(?=.*after)(?=.*before)(?=.*(?:write|mutation))/isu,
+    );
+  },
+);
+
+Then(
+  'the reviewer-authored decision is recorded as a nonblocking suggestion and the review does not block on it',
+  function (this: SafewordWorld) {
+    assertPlanningEval(this, 'approve', undefined, /event[ -]?bus/iu);
+  },
+);
diff --git a/steps/keep-plan-reviews-guidance.steps.ts b/steps/keep-plan-reviews-guidance.steps.ts
new file mode 100644
index 000000000..57e848e21
--- /dev/null
+++ b/steps/keep-plan-reviews-guidance.steps.ts
@@ -0,0 +1,103 @@
+import { strict as assert } from 'node:assert';
+
+import { Given, Then, When } from '@cucumber/cucumber';
+
+import {
+  assertPlanningEval,
+  runPlanningEval,
+  selectPlanningEval,
+} from './support/planning-eval.js';
+import type { SafewordWorld } from './world.js';
+
+Given(
+  'a recorded architecture, data, testing, domain, or research suggestion proposes a decision required by accepted behavior',
+  function (this: SafewordWorld) {
+    const selected = selectPlanningEval(this, 'r15-required-proof-decision');
+    assert.equal(selected.kind, 'plan-execution');
+    assert.match(selected.accepted_boundary, /CLI denial must return a nonzero exit code/u);
+    assert.match(selected.reviewed_plan, /Execution-owned proof decision/u);
+    assert.match(selected.reviewed_plan, /invoke the actual CLI against the real endpoint/u);
+  },
+);
+
+Given(
+  'a recorded architecture, data, testing, domain, or research suggestion proposes a capability outside accepted behavior whose exclusion would change the accepted outcome',
+  function (this: SafewordWorld) {
+    const selected = selectPlanningEval(this, 'r15-consequential-scope-choice');
+    assert.equal(selected.kind, 'plan-implementation');
+    assert.match(
+      selected.accepted_boundary,
+      /excluded a new target-owner authorization capability/u,
+    );
+    assert.match(selected.context, /never the target owner/u);
+    assert.match(selected.reviewed_plan, /User-owned scope choice remains pending/u);
+    assert.match(selected.reviewed_plan, /not selected as architecture, a delivery task/u);
+  },
+);
+
+Given(
+  'a recorded architecture, data, testing, domain, or research suggestion proposes an unrelated capability whose exclusion does not change the accepted outcome',
+  function (this: SafewordWorld) {
+    const selected = selectPlanningEval(this, 'r15-guidance-candidate');
+    assert.match(selected.context, /Architecture guide suggests automatic migration/u);
+    assert.match(
+      selected.context,
+      /Excluding it does not change the accepted manual-authorization outcome/u,
+    );
+    assert.match(
+      selected.accepted_boundary,
+      /require explicit user authorization before account changes/u,
+    );
+    assert.doesNotMatch(selected.reviewed_plan, /automatic migration/u);
+  },
+);
+
+When(
+  'a judged semantic reviewer evaluation applies the canonical accepted-boundary guidance rubric to the suggestion',
+  { timeout: 240_000 },
+  function (this: SafewordWorld) {
+    runPlanningEval(this);
+  },
+);
+
+Then('the capability is dropped', function (this: SafewordWorld) {
+  assertPlanningEval(this, 'approve', undefined, /migration/iu);
+});
+
+Then(
+  'the decision is surfaced and resolved in its owning plan',
+  { timeout: 240_000 },
+  function (this: SafewordWorld) {
+    assertPlanningEval(this, 'approve');
+    selectPlanningEval(this, 'r15-missing-required-proof-decision');
+    runPlanningEval(this);
+    const runs = assertPlanningEval(this, 'request_changes');
+    assert.ok(
+      runs.filter(run =>
+        run.reviewer.findings.some(
+          finding => /CLI/iu.test(finding) && /denial|refusal|exit.code/iu.test(finding),
+        ),
+      ).length >= 2,
+      'Two correct judged findings must reject endpoint-only proof for the accepted CLI denial.',
+    );
+  },
+);
+
+Then(
+  'the capability is surfaced as a user-owned scope choice and does not enter the plan',
+  function (this: SafewordWorld) {
+    const runs = assertPlanningEval(this, 'request_changes');
+    assert.ok(
+      runs.filter(run =>
+        run.reviewer.findings.some(
+          finding =>
+            /target.owner|owner consent/iu.test(finding) &&
+            /user.owned|user (?:must )?(?:decide|choose|authorize)|scope choice|decision owner:\s*(?:the )?user/iu.test(
+              finding,
+            ),
+        ),
+      ).length >= 2,
+      'Two correct judged findings must name the consent conflict and its user-owned scope boundary.',
+    );
+  },
+);
diff --git a/steps/keep-plan-reviews-host-guidance.steps.ts b/steps/keep-plan-reviews-host-guidance.steps.ts
new file mode 100644
index 000000000..8ac08d875
--- /dev/null
+++ b/steps/keep-plan-reviews-host-guidance.steps.ts
@@ -0,0 +1,185 @@
+import { strict as assert } from 'node:assert';
+import { spawnSync } from 'node:child_process';
+import { mkdirSync, mkdtempSync, readFileSync, rmSync, writeFileSync } from 'node:fs';
+import { tmpdir } from 'node:os';
+import path from 'node:path';
+
+import { After, Given, Then, When } from '@cucumber/cucumber';
+
+import type { SafewordWorld } from './world.js';
+
+const packageRoot = path.resolve(import.meta.dirname, '../packages/cli');
+interface HostGuidanceState {
+  root: string;
+  agent: 'codex' | 'claude' | 'opencode';
+  surface: string;
+  guidance?: string;
+}
+const states = new WeakMap<SafewordWorld, HostGuidanceState>();
+
+function assertAdvisory(guidance: string, surface: string): void {
+  assert.ok(
+    guidance
+      .split(/[.!?]\s/u)
+      .some(sentence => sentence.includes(surface) && /\badvisory\b/u.test(sentence)),
+    guidance,
+  );
+  assert.match(guidance, /Do not claim[^.]{0,100}planning review or approval[^.]{0,80}there/su);
+  for (const sentence of guidance.split(/[.!?]\s/u)) {
+    if (sentence.includes(surface)) {
+      if (!/Do not claim/u.test(sentence)) {
+        assert.doesNotMatch(
+          sentence,
+          /\b(?:enforc\w*|authoritativ\w*|approv\w*|gated|review(?:s|ed)?)\b/iu,
+        );
+      }
+    }
+  }
+}
+
+function setup(world: SafewordWorld, surface: string, agent: HostGuidanceState['agent']): void {
+  const root = mkdtempSync(path.join(tmpdir(), 'safeword-planning-host-guidance-'));
+  mkdirSync(path.join(root, 'project'));
+  writeFileSync(
+    path.join(root, 'project/package.json'),
+    '{"name":"host-guidance","private":true}\n',
+  );
+  states.set(world, { root, agent, surface });
+}
+
+After(function (this: SafewordWorld) {
+  const state = states.get(this);
+  if (state) rmSync(state.root, { recursive: true, force: true });
+  states.delete(this);
+});
+
+Given(
+  'repository instructions are generated for use by local Codex and may be read by Codex Cloud',
+  function (this: SafewordWorld) {
+    setup(this, 'Codex Cloud', 'codex');
+  },
+);
+
+Given(
+  'the OpenCode profile plugin is read from Desktop where native lifecycle hooks are unavailable',
+  function (this: SafewordWorld) {
+    setup(this, 'OpenCode Desktop', 'opencode');
+  },
+);
+
+Given(
+  /^planning guidance is generated for (local Claude Code|OpenCode CLI)$/,
+  function (this: SafewordWorld, surface: string) {
+    setup(this, surface, surface === 'local Claude Code' ? 'claude' : 'opencode');
+  },
+);
+
+When(
+  /^the Safeword CLI reconciles (?:the installed repository guidance|the installed OpenCode profile guidance|that installed guidance) through real project configuration$/,
+  function (this: SafewordWorld) {
+    const state = states.get(this);
+    assert.ok(state);
+    const project = path.join(state.root, 'project');
+    const environment = {
+      ...process.env,
+      CODEX_HOME: path.join(state.root, 'codex'),
+      CLAUDE_CONFIG_DIR: path.join(state.root, 'claude'),
+      OPENCODE_CONFIG_DIR: path.join(state.root, 'opencode'),
+      SAFEWORD_SKIP_INSTALL: '1',
+      SAFEWORD_SKIP_SKILLS: '1',
+    };
+    if (state.agent === 'codex') {
+      mkdirSync(environment.CODEX_HOME);
+      for (const args of [
+        ['plugin', 'marketplace', 'add', path.resolve(packageRoot, '../..'), '--json'],
+        ['plugin', 'add', 'safeword@safeword', '--json'],
+      ]) {
+        const enrolled = spawnSync('codex', args, {
+          encoding: 'utf8',
+          timeout: 60_000,
+          env: environment,
+        });
+        assert.equal(enrolled.status, 0, `${enrolled.stdout}\n${enrolled.stderr}`);
+      }
+    }
+    const result = spawnSync(
+      'bun',
+      [
+        path.join(packageRoot, 'src/cli.ts'),
+        'install',
+        `--agents=${state.agent}`,
+        '--no-input',
+        '--no-modify',
+        ...(state.agent === 'opencode' ? ['--offline'] : []),
+        '--json',
+        '--cwd',
+        project,
+      ],
+      {
+        cwd: project,
+        encoding: 'utf8',
+        timeout: 60_000,
+        env: environment,
+      },
+    );
+    const output = JSON.parse(result.stdout) as { errors: unknown[]; changed: boolean };
+    assert.deepEqual(output.errors, [], `${result.stdout}\n${result.stderr}`);
+    assert.equal(output.changed, true);
+    const entry =
+      state.agent === 'opencode'
+        ? path.join(state.root, 'opencode/skills/safeword-bdd/SKILL.md')
+        : path.join(project, '.safeword/SAFEWORD.md');
+    state.guidance = readFileSync(entry, 'utf8');
+  },
+);
+
+Then(
+  'it labels Codex Cloud execution advisory, claims neither review nor approval there, and directs authoritative planning to a supported gated surface',
+  function (this: SafewordWorld) {
+    const guidance = states.get(this)?.guidance ?? '';
+    assertAdvisory(guidance, 'Codex Cloud');
+    assert.throws(() =>
+      assertAdvisory(
+        `${guidance}\nCodex Cloud approves plans through the planning review gate.`,
+        'Codex Cloud',
+      ),
+    );
+    assert.match(guidance, /authoritative planning[^.]{0,100}supported gated surface/su);
+  },
+);
+
+Then(
+  'it labels Desktop execution advisory, claims neither review nor approval there, and names both OpenCode CLI and TUI as authoritative planning entry points',
+  function (this: SafewordWorld) {
+    const guidance = states.get(this)?.guidance ?? '';
+    assertAdvisory(guidance, 'OpenCode Desktop');
+    assert.throws(() =>
+      assertAdvisory(
+        `${guidance}\nPlanning approval is granted in OpenCode Desktop.`,
+        'OpenCode Desktop',
+      ),
+    );
+    assert.match(
+      guidance,
+      /planning review and approval are enforced[^.]{0,150}OpenCode CLI and TUI/su,
+    );
+  },
+);
+
+Then(
+  'it states that planning review and approval are enforced there and does not label that surface advisory',
+  function (this: SafewordWorld) {
+    const state = states.get(this);
+    assert.ok(state?.guidance);
+    const surface =
+      state.surface === 'local Claude Code' ? 'local Claude Code' : 'OpenCode CLI and TUI';
+    const enforced = /planning review and approval are enforced[^.]{0,200}/su.exec(
+      state.guidance,
+    )?.[0];
+    assert.ok(enforced?.includes(surface), state.guidance);
+    assert.doesNotMatch(enforced, /advisory/u);
+    for (const sentence of state.guidance.split(/[.!?]\s/u)) {
+      if (sentence.includes(surface)) assert.doesNotMatch(sentence, /\badvisory\b/u);
+    }
+  },
+);
