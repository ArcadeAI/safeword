# Decision: close out already-implemented work without false proof history

Investigation plan: determine (1) what current completion accepts, (2) what corrections the installed guard permits, (3) whether existing retrospective authority applies to 5F5ZZA, and (4) whether resolving this requires changing delivery scope. Evidence domains: proof fidelity, history/authorization, delivery gates, and scope/maintenance cost.

Current primary evidence:
- TDD.md in the installed 1.1.0 skill documents REFACTOR skip reasons when no change is warranted. It also requires distinct commit annotations and preserves genuine RED history.
- The observed pre-push boundary warning identifies my same-SHA GREEN/REFACTOR annotation as invalid. The correction attempt was rejected before mutation.
- packages/cli/templates/hooks/pre-tool-quality.ts lines 1376–1381 unconditionally reject removing or rewriting checked historical evidence. Current installed ticket commands expose no repair or amendment command.
- packages/cli/src/review/retrospective-gate.ts binds claims to the fixed RETROSPECTIVE_TICKET/LEDGER/FEATURE/CUTOFF. retrospective-close.ts refuses another ticket; current authority is CKWE2D. Its receipts cannot be reused for 5F5ZZA.
- The done gate requires all scenario entries complete. This ledger has 137 unchecked entries, plus my invalid checked refactor annotation. Current passing tests cannot establish an earlier failing test or certify explicitly deferred cases.

Options:
1. Keep #4200 open and retain the delivered, reviewed changes in Draft. Strongest argument: no new trust-policy surface and no invented history. Cost: current technical progress does not settle formal completion, and merge-readiness evidence remains incomplete.
2. Authorize a separate bounded ledger-recovery follow-on. Strongest argument: it can reconcile valid current behavior, explicit deferrals and correctable annotation mistakes while preserving the original history. Cost: this is additional trust-policy scope, requiring its own accepted contract, discriminating tests and independent review before the installed workflow may use it. It must not become a general waiver or be smuggled into this epic.

Recommend option 2 as separate work because the current installed authority cannot issue the needed certification or correction. Until that scope is accepted and a trusted recovery route exists, keep the epic open and preserve both the incomplete and incorrect entries. Broad test-edit approval already exists; asking for it again would not unblock this guard.

Premortem: a permissive recovery lane could erase failures; any future design must preserve the original entry, identify exactly what is corrected, and distinguish present verification from historical RED and unverified deferrals. No recovery mechanism or policy override is implemented here.
