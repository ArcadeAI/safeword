Current PR5 complete unique-source review 19/19. Base 854a376861bc034d65cc81ddfa6a85d0ae55821e; head b722f9a27a1815abcfb08e6f6ca09dc7317efa46. Review actual correctness, authenticated approval, rejection findings and test discrimination. Every unique production source, template, test, step and generator changed in PR5 is supplied across these packets. Byte-identical installed mirrors and compiled bundles are omitted; all five generated surfaces passed at this head. Prior historical acceptance failures remain visible; full current run is in progress. Exactly 33 cases are user-deferred and unverified. This is source review, not native-host or merge approval. Flag only concrete in-scope defects; optional hardening does not block.

diff --git a/steps/planning-correction-currency.steps.ts b/steps/planning-correction-currency.steps.ts
new file mode 100644
index 000000000..f60739685
--- /dev/null
+++ b/steps/planning-correction-currency.steps.ts
@@ -0,0 +1,209 @@
+import { strict as assert } from 'node:assert';
+import { spawnSync, type SpawnSyncReturns } from 'node:child_process';
+import { readFileSync, rmSync, writeFileSync } from 'node:fs';
+import path from 'node:path';
+
+import { After, Given, Then, When } from '@cucumber/cucumber';
+
+import { createTrustedReviewerDirectory } from '../packages/cli/tests/review-fixtures.js';
+import { getTemplatesDirectory } from '../packages/cli/src/utils/fs.js';
+import { fixtureProject, reviewerExecutable } from './keep-plan-reviews-installed-context.steps.js';
+import type { SafewordWorld } from './world.js';
+
+const cli = path.resolve(import.meta.dirname, '../packages/cli/src/cli.ts');
+const pluginRoot = path.resolve(import.meta.dirname, '../plugin');
+const ticket = '.project/tickets/CTX123-current-context';
+const target = `${ticket}/impl-plan.md`;
+
+interface CorrectionState {
+  root: string;
+  reviewer: string;
+  environment: NodeJS.ProcessEnv;
+  initialReviewId?: string;
+  freshReviewId?: string;
+  gate?: SpawnSyncReturns<string>;
+}
+const states = new WeakMap<SafewordWorld, CorrectionState>();
+
+function command(state: CorrectionState, args: string[]) {
+  return spawnSync('bun', [cli, ...args, '--json', '--no-input'], {
+    cwd: state.root,
+    env: state.environment,
+    encoding: 'utf8',
+    timeout: 60_000,
+  });
+}
+
+function review(state: CorrectionState, status: 'approved' | 'changes_requested'): string {
+  const result = command(state, ['review', 'run', 'plan-implementation', target]);
+  const output = JSON.parse(result.stdout);
+  assert.deepEqual(output.errors, [], `${result.stdout}\n${result.stderr}`);
+  assert.equal(output.data.status, status, result.stdout);
+  assert.equal(typeof output.data.review_id, 'string');
+  return output.data.review_id;
+}
+
+function rejectedPlan(world: SafewordWorld): CorrectionState {
+  const root = fixtureProject();
+  const reviewer = createTrustedReviewerDirectory('safeword-r11-currency-');
+  const environment: NodeJS.ProcessEnv = {
+    ...process.env,
+    PATH: `${reviewer}:${process.env.PATH ?? ''}`,
+    CLAUDE_PROJECT_DIR: root,
+    CLAUDE_PLUGIN_ROOT: pluginRoot,
+    CLAUDE_SESSION_ID: 'r11-currency',
+    SAFEWORD_REVIEW_KEY_ROOT: path.join(root, '.review-keys'),
+    CLAUDE_CONFIG_DIR: path.join(root, 'claude'),
+    SAFEWORD_SKIP_INSTALL: '1',
+    SAFEWORD_SKIP_SKILLS: '1',
+    SAFEWORD_AGENT_RUNTIME: 'claude',
+    SAFEWORD_NO_UPDATE_CHECK: '1',
+  };
+  delete environment.SAFEWORD_AUTHOR_MODEL;
+  const state: CorrectionState = { root, reviewer, environment };
+  states.set(world, state);
+  const installed = command(state, ['install', '--agents=claude', '--no-modify', '--cwd', root]);
+  const installation = JSON.parse(installed.stdout);
+  assert.deepEqual(installation.errors, [], `${installed.stdout}\n${installed.stderr}`);
+  assert.ok(
+    installation.findings.some(
+      (finding: { code: string }) => finding.code === 'SETUP_POSTCONDITION_VERIFIED',
+    ),
+  );
+  const configPath = path.join(root, '.safeword/config.json');
+  const config = JSON.parse(readFileSync(configPath, 'utf8'));
+  writeFileSync(
+    configPath,
+    JSON.stringify({
+      ...config,
+      reviewGate: true,
+      crossAgentReview: 'prefer',
+      crossAgentReviewRoutes: { claude: [{ reviewer: 'opencode' }] },
+    }),
+  );
+  reviewerExecutable(reviewer);
+  const executable = path.join(reviewer, 'opencode');
+  const source = readFileSync(executable, 'utf8');
+  assert.ok(source.includes("verdict: 'approve'"));
+  assert.ok(source.includes('findings: []'));
+  writeFileSync(
+    executable,
+    source
+      .replace("verdict: 'approve'", "verdict: 'request_changes'")
+      .replace(
+        'findings: []',
+        "findings: [{ severity: 'error', message: 'Accepted Rule approval.BU1.R1 requires authenticated current approval; explicitly reject missing authentication before advancing.' }]",
+      ),
+  );
+  state.initialReviewId = review(state, 'changes_requested');
+  return state;
+}
+
+function correct(state: CorrectionState): void {
+  const file = path.join(state.root, target);
+  writeFileSync(
+    file,
+    `${readFileSync(file, 'utf8')}\n## Required correction\n\nReject missing authentication before advancing under accepted Rule approval.BU1.R1.\n`,
+  );
+}
+
+Given(
+  'a review blocked on a uniquely determined correction under an accepted decision',
+  { timeout: 120_000 },
+  function (this: SafewordWorld) {
+    rejectedPlan(this);
+  },
+);
+
+When(
+  'the correction changes the plan bytes without a fresh review',
+  function (this: SafewordWorld) {
+    const state = states.get(this);
+    assert.ok(state);
+    correct(state);
+    state.gate = command(state, ['ticket', 'approve-plan', 'CTX123', '--cwd', state.root]);
+  },
+);
+
+Then(
+  'the corrected plan remains blocked until a verdict is recorded against those exact bytes',
+  function (this: SafewordWorld) {
+    const state = states.get(this);
+    assert.ok(state?.gate);
+    assert.equal(state.gate.status, 2, state.gate.stdout);
+    assert.match(
+      readFileSync(path.join(state.root, ticket, 'ticket.md'), 'utf8'),
+      /phase: plan-implementation/u,
+    );
+    assert.ok(state.initialReviewId);
+    const status = command(state, ['review', 'status', state.initialReviewId]);
+    const output = JSON.parse(status.stdout);
+    assert.equal(output.data.status, 'stale');
+  },
+);
+
+Given(
+  'corrected plan bytes have a fresh approving verdict recorded against those exact bytes',
+  { timeout: 180_000 },
+  function (this: SafewordWorld) {
+    const state = rejectedPlan(this);
+    correct(state);
+    reviewerExecutable(state.reviewer);
+    state.freshReviewId = review(state, 'approved');
+    assert.notEqual(state.freshReviewId, state.initialReviewId);
+    const recorded = spawnSync(
+      'bun',
+      [
+        path.join(pluginRoot, 'runtime/hooks/write-review-stamp.ts'),
+        '--ticket',
+        'CTX123-current-context',
+        '--author-agent',
+        'claude',
+        '--reviewer-agent',
+        'opencode',
+        '--independence',
+        'reduced',
+        '--review-id',
+        state.freshReviewId,
+        '--phase',
+        'plan-implementation',
+      ],
+      { cwd: state.root, env: state.environment, encoding: 'utf8', timeout: 60_000 },
+    );
+    assert.equal(recorded.status, 0, `${recorded.stdout}\n${recorded.stderr}`);
+  },
+);
+
+When('the phase gate reevaluates the prior correction block', function (this: SafewordWorld) {
+  const state = states.get(this);
+  assert.ok(state);
+  state.gate = command(state, ['ticket', 'approve-plan', 'CTX123', '--cwd', state.root]);
+});
+
+Then(
+  'the prior block is cleared and that correction no longer prevents the phase transition',
+  function (this: SafewordWorld) {
+    const state = states.get(this);
+    assert.ok(state?.gate);
+    assert.equal(state.gate.status, 0, `${state.gate.stdout}\n${state.gate.stderr}`);
+    assert.equal(
+      readFileSync(path.join(state.root, ticket, 'execution-plan.md'), 'utf8'),
+      readFileSync(
+        path.join(getTemplatesDirectory(), 'doc-templates/execution-plan-template.md'),
+        'utf8',
+      ),
+    );
+    assert.match(
+      readFileSync(path.join(state.root, ticket, 'ticket.md'), 'utf8'),
+      /phase: plan-execution/u,
+    );
+  },
+);
+
+After(function (this: SafewordWorld) {
+  const state = states.get(this);
+  if (!state) return;
+  rmSync(state.root, { recursive: true, force: true });
+  rmSync(state.reviewer, { recursive: true, force: true });
+  states.delete(this);
+});
diff --git a/steps/support/planning-eval.ts b/steps/support/planning-eval.ts
new file mode 100644
index 000000000..1d699f083
--- /dev/null
+++ b/steps/support/planning-eval.ts
@@ -0,0 +1,141 @@
+import { strict as assert } from 'node:assert';
+import { spawnSync } from 'node:child_process';
+import { createHash } from 'node:crypto';
+import { existsSync, mkdtempSync, readFileSync, rmSync, writeFileSync } from 'node:fs';
+import { tmpdir } from 'node:os';
+import path from 'node:path';
+
+import { After, Status } from '@cucumber/cucumber';
+
+import { planningContractCases } from '../../packages/cli/tests/fixtures/planning-contracts-eval.js';
+import type { SafewordWorld } from '../world.js';
+
+const root = path.resolve(import.meta.dirname, '../..');
+const hostClaudeConfigDir = process.env.CLAUDE_CONFIG_DIR;
+
+interface EvalRun {
+  reviewer: { verdict: string; summary: string; findings: string[]; scope_expanded: boolean };
+  judge: { correct: boolean };
+}
+
+interface EvalReport {
+  selected_case: string;
+  complete: boolean;
+  results: { case_id: string; input_packet_digest: string; status: string; runs: EvalRun[] }[];
+}
+
+interface EvalState {
+  caseId: string;
+  reportDirectories: string[];
+  reportPath: string;
+  packetPath?: string;
+  packetDigest: string;
+  output?: ReturnType<typeof spawnSync>;
+  report?: EvalReport;
+}
+
+const states = new WeakMap<SafewordWorld, EvalState>();
+
+export function selectPlanningEval(
+  world: SafewordWorld,
+  caseId: string,
+  packet?: { context: string; reviewed_plan: string },
+) {
+  const evaluationCase = planningContractCases.find(item => item.id === caseId);
+  assert.ok(evaluationCase, `Missing judged case ${caseId}`);
+  const reportDirectory = mkdtempSync(path.join(tmpdir(), 'safeword-planning-eval-'));
+  const input = packet ?? {
+    context: evaluationCase.context,
+    reviewed_plan: evaluationCase.reviewed_plan,
+  };
+  const packetPath = packet === undefined ? undefined : path.join(reportDirectory, 'packet.json');
+  if (packetPath) writeFileSync(packetPath, JSON.stringify(input));
+  states.set(world, {
+    caseId,
+    reportDirectories: [...(states.get(world)?.reportDirectories ?? []), reportDirectory],
+    reportPath: path.join(reportDirectory, 'result.json'),
+    packetPath,
+    packetDigest: createHash('sha256').update(JSON.stringify(input)).digest('hex'),
+  });
+  return evaluationCase;
+}
+
+export function selectedPlanningEval(world: SafewordWorld) {
+  const state = states.get(world);
+  assert.ok(state, 'A judged evaluation case must be selected first.');
+  const evaluationCase = planningContractCases.find(item => item.id === state.caseId);
+  assert.ok(evaluationCase);
+  return evaluationCase;
+}
+
+export function runPlanningEval(world: SafewordWorld): void {
+  const state = states.get(world);
+  assert.ok(state, 'A judged evaluation case must be selected first.');
+  const environment: NodeJS.ProcessEnv = {
+    ...process.env,
+    SAFEWORD_PLANNING_EVAL_CASE: state.caseId,
+    SAFEWORD_PLANNING_EVAL_OUTPUT: state.reportPath,
+  };
+  delete environment.NODE_OPTIONS;
+  delete environment.SAFEWORD_PLANNING_EVAL_PACKET;
+  if (state.packetPath) environment.SAFEWORD_PLANNING_EVAL_PACKET = state.packetPath;
+  if (hostClaudeConfigDir === undefined) delete environment.CLAUDE_CONFIG_DIR;
+  else environment.CLAUDE_CONFIG_DIR = hostClaudeConfigDir;
+  state.output = spawnSync(
+    'scripts/dev',
+    ['bun', 'packages/cli/scripts/planning-contracts-eval.ts'],
+    {
+      cwd: root,
+      env: environment,
+      encoding: 'utf8',
+      timeout: 210_000,
+      maxBuffer: 1024 * 1024,
+    },
+  );
+  if (existsSync(state.reportPath))
+    state.report = JSON.parse(readFileSync(state.reportPath, 'utf8')) as EvalReport;
+}
+
+export function assertPlanningEval(
+  world: SafewordWorld,
+  verdict: 'approve' | 'request_changes',
+  requiredFinding?: RegExp,
+  requiredRecord?: RegExp,
+) {
+  const state = states.get(world);
+  assert.ok(state?.output, 'The judged evaluation must run first.');
+  assert.equal(
+    state.output.status,
+    0,
+    `Judged evaluation failed: ${state.output.error?.message ?? ''}\n${state.output.stdout}\n${state.output.stderr}\nReport: ${state.reportPath}`,
+  );
+  const report = state.report;
+  assert.ok(report?.complete && report.selected_case === state.caseId);
+  assert.equal(report.results.length, 1);
+  const result = report.results[0];
+  assert.equal(result?.case_id, state.caseId);
+  assert.equal(result.input_packet_digest, state.packetDigest);
+  assert.equal(result.status, 'pass');
+  const matching = result.runs.filter(
+    run =>
+      run.reviewer.verdict === verdict &&
+      !run.reviewer.scope_expanded &&
+      run.judge.correct &&
+      (requiredFinding === undefined || requiredFinding.test(run.reviewer.findings.join(' '))) &&
+      (requiredRecord === undefined ||
+        requiredRecord.test([run.reviewer.summary, ...run.reviewer.findings].join(' '))),
+  );
+  assert.ok(
+    matching.length >= 2,
+    `Only ${matching.length}/3 judged runs supported ${state.caseId}.`,
+  );
+  return matching;
+}
+
+After(function (this: SafewordWorld, { result }) {
+  const state = states.get(this);
+  if (state && result?.status !== Status.FAILED)
+    for (const directory of state.reportDirectories)
+      rmSync(directory, { recursive: true, force: true });
+  states.delete(this);
+});
diff --git a/steps/support/planning-scope-project.ts b/steps/support/planning-scope-project.ts
new file mode 100644
index 000000000..639c7289c
--- /dev/null
+++ b/steps/support/planning-scope-project.ts
@@ -0,0 +1,278 @@
+import { strict as assert } from 'node:assert';
+import { mkdirSync, readFileSync, writeFileSync } from 'node:fs';
+import path from 'node:path';
+
+import { prepareReviewPacket } from '../../packages/cli/src/review/packet.js';
+import { resolveConfiguredPath } from '../../packages/cli/src/utils/configured-paths.js';
+import { planningContractCases } from '../../packages/cli/tests/fixtures/planning-contracts-eval.js';
+import {
+  scopeBoundaries,
+  type ScopeBoundary,
+} from '../../packages/cli/tests/fixtures/planning-scope-context-eval.js';
+import { PLANNING_ROLE_PRODUCT } from '../../packages/cli/tests/planning-role-fixtures.js';
+import { fixtureProject } from '../keep-plan-reviews-installed-context.steps.js';
+
+export function createScopeContextProject(caseId: string, roots: string[]) {
+  const evaluationCase = planningContractCases.find(item => item.id === caseId);
+  assert.ok(evaluationCase?.reviewer_boundary);
+  assert.match(evaluationCase.reviewed_plan, /drive the real CLI through that endpoint/u);
+  assert.doesNotMatch(evaluationCase.reviewed_plan, /rollback disables the new endpoint/u);
+  const missing =
+    caseId === 'r12-complete-scope-context'
+      ? undefined
+      : (caseId.slice('r12-missing-'.length) as ScopeBoundary);
+  const valueOf = (key: ScopeBoundary) => {
+    const value =
+      key === missing
+        ? '[binding content not supplied]'
+        : scopeBoundaries[key].split(': ')[1]?.replace(/\.$/u, '');
+    assert.ok(value, `The fixture must supply the ${key} field`);
+    return value;
+  };
+  const root = fixtureProject();
+  roots.push(root);
+  const folder = '.project/tickets/CTX123-current-context';
+  const planPath = `${folder}/impl-plan.md`;
+  writeFileSync(
+    path.join(root, folder, 'ticket.md'),
+    `---
+id: CTX123
+type: feature
+phase: plan-implementation
+status: in_progress
+product_plan_contract: v1
+parent: PRT123
+parent_job: approval.BU1
+milestone: M1
+scope: ${JSON.stringify(valueOf('ticket-scope'))}
+out_of_scope: ${JSON.stringify(valueOf('ticket-exclusions'))}
+done_when: authorized changes succeed and denied changes do not mutate
+phase_anchors:
+  - scenario-gate: features/current-context.feature
+---
+`,
+  );
+  const parent = path.join(root, '.project/tickets/PRT123-scope-parent');
+  mkdirSync(parent, { recursive: true });
+  writeFileSync(
+    path.join(parent, 'ticket.md'),
+    `---
+id: PRT123
+type: epic
+phase: intake
+status: in_progress
+product_plan_contract: v1
+scope: ${JSON.stringify(valueOf('parent-boundary'))}
+out_of_scope: new authorization APIs
+done_when: manual account changes honor explicit consent
+---
+`,
+  );
+  const specification = PLANNING_ROLE_PRODUCT.replace(
+    '# Product Plan',
+    '# Product Plan\n\n<!-- safeword:product-plan-contract:v1 -->',
+  )
+    .replace('Builders retain approval.', 'Builders authorize single-account changes.')
+    .replace(
+      'Builder receives approval.',
+      'Builder receives an authorized change or a named refusal.',
+    )
+    .replace('Approval is authenticated.', 'Account changes require explicit user authorization.')
+    .replace('Review is available.', 'The existing consent-token API supports authorization.')
+    .replace(
+      'Approval advances.',
+      'Authorized changes succeed and denied changes cause no mutation.',
+    )
+    .replace('No anonymous approval.', valueOf('project-non-goals'))
+    .replace('Current approval advances.', 'Explicit consent is required before account mutation.')
+    .replace('Anonymous approval.', valueOf('milestone-non-goals'));
+  writeFileSync(path.join(parent, 'spec.md'), specification);
+  writeFileSync(
+    path.join(root, folder, 'spec.md'),
+    `# Feature Contribution
+
+<!-- safeword:product-plan-contract:v1 -->
+
+## Parent References
+- **Parent:** PRT123
+- **Parent job:** approval.BU1
+- **Milestone:** M1
+
+## Contribution
+Require explicit authorization for manual account changes without migration.
+
+## Rules
+#### approval.BU1.CTX123.R1 — Authorize account changes
+Valid consent permits a change; absent, expired, or mismatched consent permits no mutation.
+
+## Surfaces
+Affected:
+- Safeword CLI
+`,
+  );
+  writeFileSync(
+    path.join(root, planPath),
+    `# Implementation Plan
+
+## Approach
+${evaluationCase.reviewed_plan}
+
+## Architecture applicability
+skip: No durable architecture record applies to this existing endpoint.
+
+## Data applicability
+skip: Existing account schema and consent-token contract stay unchanged; no new data shape or migration is introduced.
+
+## Measurement applicability
+skip: The Product Plan makes no quantitative promise.
+`,
+  );
+  writeFileSync(
+    path.join(root, 'features/current-context.feature'),
+    `@approval.BU1.CTX123.R1 @surface.safeword-cli
+Feature: Manual authorized account changes
+  Scenario: Authorized change
+    Given valid consent for the requesting owner and target account
+    When a manual account change is requested
+    Then one authorized account changes
+  Scenario: Denied change
+    Given absent expired or mismatched consent
+    When a manual account change is requested
+    Then no account mutation occurs
+`,
+  );
+  const packet = prepareReviewPacket(root, 'plan-implementation', [planPath], []).packet;
+  assert.ok(packet.planning_context);
+  const files = [...packet.logical_files, ...(packet.context_files ?? [])];
+  for (const role of [
+    'ticket',
+    'project',
+    'parent',
+    'milestone',
+    'rules',
+    'scenarios',
+    'principles',
+    'personas',
+    'surfaces',
+  ]) {
+    const dependency = packet.planning_context.dependencies.find(item => item.role === role);
+    assert.ok(dependency, `${role} must remain structurally resolved`);
+    const captured = files.find(file => file.path === dependency.path);
+    assert.ok(captured, `${role} must reach the reviewer`);
+    assert.equal(captured.content, readFileSync(path.join(root, dependency.path), 'utf8'));
+  }
+  const roles: Record<ScopeBoundary, string> = {
+    'ticket-scope': 'ticket',
+    'ticket-exclusions': 'ticket',
+    'project-non-goals': 'project',
+    'milestone-non-goals': 'milestone',
+    'parent-boundary': 'parent',
+  };
+  for (const key of Object.keys(scopeBoundaries) as ScopeBoundary[]) {
+    const dependency = packet.planning_context.dependencies.find(item => item.role === roles[key]);
+    const captured = files.find(file => file.path === dependency?.path);
+    assert.ok(captured?.content.includes(valueOf(key)), `${key} must reach its captured role`);
+    const completeValue = scopeBoundaries[key].split(': ')[1].replace(/\.$/u, '');
+    assert.equal(
+      files.some(file => file.content.includes(completeValue)),
+      key !== missing,
+      `${key} must be present exactly when its content was supplied`,
+    );
+  }
+  return {
+    root,
+    planPath,
+    input: {
+      context: JSON.stringify({
+        planning_context: packet.planning_context,
+        logical_files: packet.logical_files,
+        context_files: packet.context_files,
+      }),
+      reviewed_plan: readFileSync(path.join(root, planPath), 'utf8'),
+    },
+  };
+}
+
+/** Complete the native fixture's design premises, without supplying omitted scope authority. */
+export function completeNativeScopeProject(project: ReturnType<typeof createScopeContextProject>) {
+  const architecturePath = resolveConfiguredPath(project.root, 'architecture');
+  mkdirSync(path.dirname(architecturePath), { recursive: true });
+  writeFileSync(
+    architecturePath,
+    `# Current account-change architecture
+
+This is a synthetic project's existing, fixture-owned contract, version 1. It is a closed-world test premise, not evidence about a deployed service.
+
+The CLI calls the existing manual account-change endpoint, which delegates writes to the existing consent API v1 and account store. The API's guardedChange(requester, target, consent, change) binds the authenticated session requester and exactly one target to consent. The existing store transaction checks owner, target and expiry at the write using server UTC; expiry equal to now is expired. A refused request or pre-commit failure performs no mutation. The transaction already provides this atomic guard; this feature adds no transaction protocol or new authorization API.
+
+The account store is the authoritative owner of existing account records. The consent API owns opaque consent credentials and issuer keys; callers neither persist nor log tokens. Existing schema, identifiers, retention and issuer policies remain unchanged. A retry after denial needs fresh valid consent. A pre-commit transient failure is retryable without mutation. A transport failure after commit is an uncertain result and must not be represented as a confirmed refusal or automatically retried by this change.
+
+The project owns this contract text; no third-party implementation is copied. Production consent issuance and deployment remain outside the wiring proof.
+`,
+  );
+  const architectureReference = path.relative(project.root, architecturePath);
+  const planFile = path.join(project.root, project.planPath);
+  let plan = readFileSync(planFile, 'utf8');
+  assert.ok(plan.startsWith('# Implementation Plan\n'));
+  plan = plan.replace('# Implementation Plan\n', '# Implementation Plan\n\n**Status:** planned\n');
+  assert.match(plan, /Decision:.*?Proof:/u);
+  assert.ok(
+    plan.includes('A transient endpoint failure returns a retryable error without mutation.'),
+  );
+  assert.ok(
+    plan.includes('skip: No durable architecture record applies to this existing endpoint.'),
+  );
+  assert.ok(
+    plan.includes(
+      'skip: Existing account schema and consent-token contract stay unchanged; no new data shape or migration is introduced.',
+    ),
+  );
+  plan = plan.replace(
+    /Decision:.*?Proof:/u,
+    `Decision: use the existing consent API v1 guardedChange contract documented in ${architectureReference}. The in-scope alternative is duplicating its owner/target/expiry guard at the endpoint; reject that duplication because it splits the authoritative write boundary. This fixture's current v1 contract establishes design suitability; endpoint tests remain future verification, not completed evidence. The choice is reversible by disabling this endpoint's account-change handling. Proof:`,
+  );
+  plan = plan.replace(
+    'A transient endpoint failure returns a retryable error without mutation.',
+    'A pre-commit transient endpoint failure returns a retryable error without mutation. A post-commit transport failure reports an uncertain result without automatic retry or a false no-mutation claim.',
+  );
+  plan = plan.replace(
+    'skip: No durable architecture record applies to this existing endpoint.',
+    `Applicable: ${architectureReference} documents the existing CLI, endpoint, consent API and account store boundary. Reuse its guarded write without changing component ownership or shared interfaces. This is a reversible feature-local wiring choice, so no new durable architecture decision is introduced. Reassess if the v1 contract cannot satisfy the accepted behavior; new authorization APIs require the product owner's decision.`,
+  );
+  plan = plan.replace(
+    'skip: Existing account schema and consent-token contract stay unchanged; no new data shape or migration is introduced.',
+    `Applicable: consent changes access to account writes. Purpose: authorize manual single-account changes. Store and model: reuse the existing account store; no new attempt or token store. Schema and relationships: unchanged account records and owner relationship. Source of truth: the account store remains authoritative. Ownership and access: the authenticated owner and target must match consent at the existing guarded write. Identity and integrity: existing account identity and the v1 atomic guard remain authoritative; server UTC defines expiry and equality is expired. Cross-system flow: CLI to existing endpoint to consent API to account store; no new data transfer or copy. Lifecycle and retention: no new persisted consent or diagnostics; existing retention and issuer policy remain unchanged. Migration and backfill: inapplicable because no schema or data movement changes. Compliance: preserve existing access and credential handling; no new compliance policy or application-managed encryption keys. Rollback: disable this endpoint's change handling without rewriting accounts or changing the API. Tokens never appear in logs.`,
+  );
+  plan +=
+    '\n## Documentation impact\nUpdate the existing CLI account-change usage documentation with named denial, fresh-consent recovery, pre-commit retry and uncertain post-commit result. This introduces no new product behavior.\n';
+  plan +=
+    '\n## Discriminating boundary proof\nDrive the real CLI and endpoint with controlled authoritative server UTC: consent whose expiry equals the guarded-write time must produce a named denial and unchanged account state. Separately inject a transport failure after a committed write; establish committed account state, a visible uncertain result, and no automatic retry. These are planned checks of the stated v1 contract, not claims that tests have already passed.\n';
+  plan +=
+    '\n## Decisions\nReuse the documented consent API v1 guarded write rather than duplicating its authoritative guard. The current contract, rejected alternative and reversibility are recorded in Approach; no new API or durable architecture decision is authorized.\n\n## Design alignment\nPreserve approval authority: current owner consent must gate each account mutation. The CLI denial and expiry-equality proofs must demonstrate no write without that consent. Builder (BU) receives success, named refusal, fresh-consent recovery, pre-commit retry or an uncertain post-commit result on the accepted Safeword CLI surface.\n\n## Known deviations\nskip: No deliberate deviation from the accepted boundary or project principle.\n\n## Assessment triggers\nReassess if the existing v1 guarded-write contract cannot satisfy owner, target or expiry enforcement, or if product authority changes the accepted boundary. Return new authorization APIs or expanded behavior to the product owner.\n';
+  writeFileSync(planFile, plan);
+  const packet = prepareReviewPacket(
+    project.root,
+    'plan-implementation',
+    [project.planPath],
+    [],
+  ).packet;
+  assert.ok(packet.planning_context?.dependencies.some(item => item.role === 'architecture'));
+  assert.ok(packet.planning_context?.dependencies.some(item => item.role === 'data'));
+  const refreshedInput = {
+    context: JSON.stringify({
+      planning_context: packet.planning_context,
+      logical_files: packet.logical_files,
+      context_files: packet.context_files,
+    }),
+    reviewed_plan: plan,
+  };
+  for (const value of Object.values(scopeBoundaries)) {
+    const boundary = value.split(': ')[1].replace(/\.$/u, '');
+    assert.equal(
+      refreshedInput.context.includes(boundary),
+      project.input.context.includes(boundary),
+      `Native fixture completion must preserve supplied or omitted scope: ${boundary}`,
+    );
+  }
+  project.input = refreshedInput;
+}
diff --git a/steps/world.ts b/steps/world.ts
index a50230f22..c3d7a8b3b 100644
--- a/steps/world.ts
+++ b/steps/world.ts
@@ -14,6 +14,7 @@ export interface CommandResult {
 
 export class SafewordWorld extends World {
   result: CommandResult = { stdout: '', stderr: '', exitCode: 0 };
+  nativePlanningGate?: { host: string; output: string };
 }
 
 setWorldConstructor(SafewordWorld);
