# Independent reviewer characterization

Review three new root R6 bindings and the extraction of the existing reviewer
process script into a shared fixture. Production behavior is unchanged. The
actual public coordinator confirms the Codex app-server model and provider,
uses the real packaged qualified model-pair catalogue, and classifies verified
Opus-5 author/Sol reviewer as cross-agent. An unknown author model is reduced
and reports AUTHOR_CAPABILITY_UNKNOWN. The third case earns an authenticated
stamp through the installed writer and advances the real approve-plan gate.

/tmp/4200-r6-independent-matching-runtime.json records three passing scenarios
and twelve undefined scenarios in the selected outline group. The shared
extraction regression passes seven package tests. Prior fixture failures
(missing stamp, ticket argument, identity, child PATH, and runtime mismatch)
remain in their logs; they are not production defects or passing proof.

Challenge causal discrimination, authenticated authority, real route selection,
model evidence, cleanup, and scope. Only reviewer processes are mocked. These
private installed project fixtures do not prove a live host installation.
OpenCode/cloud remain deferred; no feature-completion or Ready claim is made.

Review 2fadd5b1-86b1-4154-bee8-1b4b90dc73c3 requested a stored-independence
assertion. The repaired Then reads the exact persisted review-ID row, requires
author:claude/reviewer:codex/independence:cross-agent, and re-reads this receipt
through actual public review status after gate admission. It checks current
approved status, reviewer, independence, and review ID. The app-server mock
supports the happy-path model evidence, not a model-mismatch characterization;
the absent-author variant is not claimed. Reduced approval is intentionally
permitted by the accepted fallback contract; 'independent approval refused'
means refused cross-agent classification, not rejection of all reduced reviews.
No new model qualification or live-host installation claim is made.
