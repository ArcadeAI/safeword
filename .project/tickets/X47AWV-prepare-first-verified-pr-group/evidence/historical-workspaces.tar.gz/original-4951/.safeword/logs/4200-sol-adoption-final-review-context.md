# Approved qualified Sol adoption

Scope: switch only the Execution Planning Codex default from Astra to Sol,
adopt the four qualified Execution prompt clarifications, and package fresh
admission and capability evidence. Keep authenticated approval, configured model
overrides, route order, and the existing qualification thresholds unchanged.

Human approved the complete ten-file adoption patch and separately approved the
current-contract discovery fixture correction. That correction keeps routing,
rejection, approval, retained proof assertions and separate legacy coverage.

Both real native task matrices passed all 63 cases, with no unfinished cases.
Both capability cohorts completed 18 calls and passed 17; both failures remain
in their evidence files. The existing official comparison reports not_weaker
in both directions. Do not add resilience machinery or modify fixtures to erase
the measured false positive or invalid-output failure.

Contract revision: 8451a6cb6e036335f9ae9457858b053bebf62d8c3faef88188cfb14f41396bfe
Corpus revision: b906f3cb783bdf2a4f749f97de0bade2883e66b4966330eee37a7bc0a170aac9
Current contract, rubric and prompt are byte-identical to the frozen qualified
candidate. Existing Astra evidence is retained. Qualification used native Codex
0.160.0; the user's global 0.153.4 cannot run Sol. No global profile edits or
tool-version manager are part of this work.

All five generated surfaces verified successfully. Typecheck and source lint
pass. The pre-correction targeted suite was 78 passed and one legacy-fixture
failure; the approved correction is being checked. Broad acceptance remains
incomplete, including 110 undefined root scenarios. This review is not authority
to claim epic completion, merge, or promote a Draft PR.
