# Sol capability qualification investigation

Decision: qualify the requested cheaper reviewer without weakening exact-model capability ordering or spending on unnecessary Astra reruns.

Investigation plan:
- Evidence validity: compare current corpus, rubric and settings digests with archived results; establish whether old Claude results can be reused honestly.
- Evaluation scope: inspect the accepted repetition and scoring floor, and distinguish task qualification from directional author/reviewer capability.
- Change scope: compare replacing the two pinned models with introducing a multi-model catalogue; preserve the existing approval gate.
- Cost and reproducibility: count required native calls, freeze inputs, retain every failure, and avoid launching another Vitest process.

Options: replace the pinned OpenAI model with Sol after fresh evidence; add a general multi-model catalogue; retain Astra and defer the requested saving.

Verified: commit 5dc6f2b3a (September 28) introduced sealed Astra/Claude capability evidence. This predates the October 6 Sol CLI access error; availability alone was an incomplete explanation of the original selection. Current root rubric digest f2fe2b547cf3f8ba886fa05326a4602b9f5d152cf865bf8db741ff4898a754ec differs from archived f7a11ed5b1bca5f46e527892f2bfd2cefc77521e0bcede7974c5c6ea5e7aeb66. The comparator returns unknown for the archived pair. The accepted corpus has six cases and three runs each: 18 native calls per model, 36 for Claude and Sol. No Astra call is necessary to evaluate the proposed replacement.

The general catalogue option preserves more reviewer identities but adds model-selection/generation complexity beyond this requested replacement. Retaining Astra avoids changes but does not deliver the authorized cost reduction. Prefer the existing two-model mechanism, with fresh Claude/Sol evidence collected against an in-memory derived manifest on the frozen candidate. Do not mutate tracked fixtures or settings, reuse stale Claude evidence, or publish a new catalogue before passing evidence and approved source adoption.

Premortem: Sol may pass the 63 Execution cases but fail broader planning capability; retain Astra as the unchanged production default unless both checks qualify the replacement.

Current authoritative evaluation guidance: packaged llm-evals-guide.md requires full task evaluation for model changes, deterministic scoring where possible, and explicit cost controls. Anthropic's current engineering guidance (https://www.anthropic.com/engineering/demystifying-evals-for-ai-agents) likewise distinguishes outcomes from infrastructure noise and recommends calibrated graders.

Prepared /tmp/4200-sol-capability-collect.ts derives a Sol manifest in memory, uses existing collection/scoring/sealing functions, records both identities and all failures, and leaves repository fixtures untouched. Its syntax transpiles. The sequential queue /tmp/4200-sol-capability-queue.py waits for complete passing 63-case Claude AND Sol matrices before dispatching 36 calls; otherwise it writes a nondispatch reason. No evidence has been collected or admitted yet. Result locations: /tmp/4200-sol-capability-{codex,claude}-results.json and comparison.json; binding in /tmp/4200-sol-capability-binding.json. Existing archived Astra evidence remains intact.

Next: finish the running task matrices before deciding whether any source model or catalogue change is justified.
