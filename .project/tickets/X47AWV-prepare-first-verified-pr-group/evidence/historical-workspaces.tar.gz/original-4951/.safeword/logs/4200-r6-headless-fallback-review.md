# Typed headless fallback characterization

Review the two additional R6 route-result bindings in the existing private
independence fixture. Production code is unchanged. The actual project config
supplies an independent Codex route and a permitted same-agent Claude route.
Only those reviewer processes are mocked. The Codex producer exits with failure;
the real coordinator records attempted independent route failure and invokes
the Claude producer, which approves or returns an error-level rejection.

The approving case earns a stamp through the real installed writer, observes
its exact persisted author/reviewer/reduced label and ID, re-reads the current
authenticated receipt, and advances actual ticket approve-plan. The declining
case re-reads current authenticated changes_requested status, refuses actual
admission, preserves Implementation Planning, and has no approval stamp. Its
Then additionally requires the actual reviewer rejection in gate output so a
mere missing locator cannot satisfy the intended negative.

/tmp/4200-r6-recorded-fallback-complete.json records five passing scenarios and
285 steps (the two new rows plus all three earlier independence rows). The
extra causal rejection assertion has a focused run in progress. The first
two-row run failed because the fixture omitted the headless route; the actual
coordinator correctly returned continuation_required. That failure is retained.
No live-host, semantic reviewer, model mismatch, weaker-model, or remaining
fresh-context/self-review proof is claimed. The historical acceptance aggregate
and all remaining undefined/deferred cases stay open.

Challenge whether configured-route exhaustion, persisted authentic outcomes,
actual reviewer labels, rejection causality, and no false approval are observed.
Review for unnecessary fixture abstractions or scope expansion. The shared
reviewer process helper and its seven-test extraction regression are unchanged.

Review 107b1737-5269-4530-b36e-a5cb3e887f08 approves. The causal rejection
row completed 1/1 (57 steps) in /tmp/4200-r6-decline-causal.json. Its advisory
about vague failure strings is addressed: the configured Codex route must have
the exact typed process_failed outcome. The approving gate output also must not
emit REVIEW_INDEPENDENCE_DEGRADED, and the current authenticated receipt's label
must be reduced. The final two-row assertion follow-up is running with frozen
sources. The ledger is observed persistence, not independent evidence of the
classification. This fixture does not establish exact producer launch ordering;
the separate fallback-ladder ordering rows remain unbound. No refusal-to-stamp
claim is made for the negative; its current rejection and actual gate/rejection
message are the discriminating evidence. Stop expanding this scoped review once
these actual assertions are correct; other typed-route rows remain separate work.
