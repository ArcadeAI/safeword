# Qualification runner interruption

Verified October 7, 10:09 PM PDT: write_stdin for former session 12254 returns Unknown process id. Process inventory finds no Vitest, original matrix runner, Sol queue, or capability queue. Claude log ends at RUN, without final census; no Claude or repaired-Sol results file exists. The prior Sol process-error matrix still records 0/63 passing. Earlier statements that the Claude runner remained active were based on old session state and were incorrect.

Hypotheses: an ordinary completed matrix (ruled out by absent census and final output); a still-running but detached runner (ruled out by scoped process inventory); interruption or session cleanup (consistent, exact cause not confirmed). Do not infer successful judgments from quiet logs or elapsed time. The interrupted Claude matrix has zero confirmed passes and all 63 cases unproven; repaired Sol and capability collection never dispatched.

Decision plan: compare holding the foreground session open, a detached single sequential supervisor with closed inherited descriptors, and an OS-managed job. Verify process continuity after its launcher exits before calling a runner durable. Prefer the single detached supervisor: no OS service configuration, recurring automation, repository runtime changes or new testing policy. It must use existing frozen inputs and trusted CLI, one Vitest at a time, fresh artifact names, visible per-case reporting, and fail closed on incomplete results. No retry loop or repeated paid execution after a failure.

Premortem: a host-level cleanup may terminate even the detached process; check the recorded PID and actual result files across turn boundaries, and report interruption rather than a running state if either disappears.

Next: launch one fresh supervised Claude/Sol sequence only after confirming no Vitest process remains, and verify its PID from a separate tool invocation.
