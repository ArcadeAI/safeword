Current PR5 complete unique-source review 1/19. Base 854a376861bc034d65cc81ddfa6a85d0ae55821e; head b722f9a27a1815abcfb08e6f6ca09dc7317efa46. Review actual correctness, authenticated approval, rejection findings and test discrimination. Every unique production source, template, test, step and generator changed in PR5 is supplied across these packets. Byte-identical installed mirrors and compiled bundles are omitted; all five generated surfaces passed at this head. Prior historical acceptance failures remain visible; full current run is in progress. Exactly 33 cases are user-deferred and unverified. This is source review, not native-host or merge approval. Flag only concrete in-scope defects; optional hardening does not block.

diff --git a/ARCHITECTURE.md b/ARCHITECTURE.md
index 28a913c53..9890f9ca8 100644
--- a/ARCHITECTURE.md
+++ b/ARCHITECTURE.md
@@ -821,14 +821,24 @@ authority, and content-hash review history.
 **Status:** Accepted
 **Date:** 2026-09-10
 
-| Field          | Value                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                         |
-| -------------- | --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
-| What           | Human Implementation Plan approvals and declines are append-only, digest-bound events in the existing project-local review ledger. Each event identifies the ticket, planning phase, exact plan digest, decision, user-authority reference, timestamp, and idempotency key. The same ledger may retain derived `delivery-proof:v1` events that bind an executed reviewed proof to its ticket, checklist item, Proof ID, producing revision, invocation, and outcome; those events are evidence only and grant neither human approval nor merge authority. Delivery proof requires a clean contribution subject outside the ticket's Execution Plan before and after execution. It remains current across the plan-only commit that persists its receipt only while the producing revision is an ancestor and Git reports no other committed or working-tree change; the separately authenticated normalized plan identity prevents that exclusion from hiding stable plan edits. Writers serialize appends with an exclusive lease-bearing lock and monotonically increasing fencing token, reread inside the lock, and atomically replace the ledger only while still owning the current token. Unknown event kinds remain authority-inert and are preserved byte-for-byte when a known event is appended; known receipts remain readable. Events are retained for audit, while a changed plan digest makes an earlier decision non-current. |
-| Why            | Approval is authority over exact reviewed bytes, not mutable ticket state. Append-only history preserves the audit trail; digest binding prevents stale approval; serialization and fencing prevent concurrent writers or stale lock holders from losing an event; compatibility rules let independently released hosts share the ledger without an unfamiliar event invalidating unrelated review evidence.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                  |
-| Trade-off      | Every supported writer must honor the same locking, compatibility, and clean-subject protocol, and retained events can increase read cost. Excluding the exact Execution Plan avoids an impossible self-referential commit but requires its normalized identity and stable definition to be checked independently. Unrelated repository changes conservatively stale proof. Local filesystems lacking exclusive creation and atomic same-directory rename fail closed. Contention, stale-lease recovery, and ledger growth must remain observable assessment triggers.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        |
-| Alternatives   | Mutable ticket frontmatter (rejected: conflates workflow state and authority); overwrite one current receipt (rejected: destroys history); host-local memory (rejected: breaks project handoff); reject a ledger containing an unknown event (rejected: one extension can erase otherwise valid authority); append without fencing (rejected: a stale writer can overwrite a newer append).                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   |
-| Migration      | Existing ledgers remain valid. Tickets with approval enabled but no current digest-bound decision read as pending; no backfill invents authority. During rollback, new decision events remain readable but are non-authoritative under the old phase sequence. `YCFFNC` owns coordinated activation and rollback across installed hosts.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                      |
-| Implementation | Ticket `G1C9PP` owns the consumer model, local writer protocol, current-digest lookup, and fail-closed behavior. Ticket `5F5ZZA` owns authenticated host-user-event provenance and transport. Ticket `YCFFNC` owns cross-host deployment compatibility.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       |
+<!-- prettier-ignore -->
+| Field | Value |
+| --- | --- |
+| What | Human Implementation Plan approvals and declines are append-only, digest-bound events in the existing project-local review ledger. Each event identifies the ticket, planning phase, exact plan digest, decision, user-authority reference, timestamp, and idempotency key. The same ledger may retain derived `delivery-proof:v1` events that bind an executed reviewed proof to its ticket, checklist item, Proof ID, producing revision, invocation, and outcome; those events are evidence only and grant neither human approval nor merge authority. Delivery proof requires a clean contribution subject outside the ticket's Execution Plan before and after execution. It remains current across the plan-only commit that persists its receipt only while the producing revision is an ancestor and Git reports no other committed or working-tree change; the separately authenticated normalized plan identity prevents that exclusion from hiding stable plan edits. Writers serialize appends with an exclusive lease-bearing lock and monotonically increasing fencing token, reread inside the lock, and atomically replace the ledger only while still owning the current token. Unknown event kinds remain authority-inert and are preserved byte-for-byte when a known event is appended; known receipts remain readable. Events are retained for audit, while a changed plan digest makes an earlier decision non-current. |
+| Why | Approval is authority over exact reviewed bytes, not mutable ticket state. Append-only history preserves the audit trail; digest binding prevents stale approval; serialization and fencing prevent concurrent writers or stale lock holders from losing an event; compatibility rules let independently released hosts share the ledger without an unfamiliar event invalidating unrelated review evidence. |
+| Trade-off | Every supported writer must honor the same locking, compatibility, and clean-subject protocol, and retained events can increase read cost. Excluding the exact Execution Plan avoids an impossible self-referential commit but requires its normalized identity and stable definition to be checked independently. Unrelated repository changes conservatively stale proof. Local filesystems lacking exclusive creation and atomic same-directory rename fail closed. Contention, stale-lease recovery, and ledger growth must remain observable assessment triggers. |
+| Alternatives | Mutable ticket frontmatter (rejected: conflates workflow state and authority); overwrite one current receipt (rejected: destroys history); host-local memory (rejected: breaks project handoff); reject a ledger containing an unknown event (rejected: one extension can erase otherwise valid authority); append without fencing (rejected: a stale writer can overwrite a newer append). |
+| Migration | Existing ledgers remain valid. Tickets with approval enabled but no current digest-bound decision read as pending; no backfill invents authority. During rollback, new decision events remain readable but are non-authoritative under the old phase sequence. `YCFFNC` owns coordinated activation and rollback across installed hosts. |
+| Implementation | Ticket `G1C9PP` owns the consumer model, local writer protocol, current-digest lookup, and fail-closed behavior. Ticket `5F5ZZA` owns authenticated host-user-event provenance and transport. Ticket `YCFFNC` owns cross-host deployment compatibility. |
+
+**D1BKYA approval-consumer correction:** D1BKYA owns removing the redundant
+content-bound `impl-plan` stamp from `ticket approve-plan`, as explicitly
+requested for epic #4200. The command still requires authenticated current
+`phaseReviewAdmission` for the exact Implementation Plan and still records
+human design authority separately when configured. Rejection rendering uses
+only the actual rejected receipt's findings. G1C9PP retains the broader approval
+consumer and ledger protocol; this correction changes neither its user-authority
+model nor any merge or release permission.
 
 **A639WN extension:** The ledger also retains `delivery-compatibility:v1`
 events. Each event binds an independent compatibility judgment to the exact
@@ -846,15 +856,16 @@ Compatibility evidence grants neither human approval nor merge authority.
 **Status:** Proposed
 **Date:** 2026-09-20
 
-| Field                  | Value                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     |
-| ---------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
-| Context                | Product, Implementation, and Execution Planning reviews depend on their target-plan identity and a larger accepted context. Product and Implementation use exact work-product bytes; Execution retains its accepted normalized identity so ordinary checklist progress does not force review of an unchanged delivery design. Raw whole-packet hashing safely catches every edit but makes formatting, comments, progress, and unrelated persona or surface inventory invalidate approval. Looser caller-selected packets can omit a load-bearing boundary and still appear current.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                      |
-| Decision               | One phase-aware resolver derives the complete role-labeled dependency set from ticket and project configuration. One projector binds exact Product/Implementation target bytes or the trusted normalized Execution identity, plus semantically normalized canonical-contract clauses and ticket-relevant slices of each context role, into a deterministic SHA-256 review-currency identity. Execution normalization excludes only ordinary progress in contributor-row Disposition, Evidence class, Revision, and final evidence cells; every stable obligation and every other plan byte remains identity-bearing. Separately, an exact-byte copy-integrity check requires every installed authoring contract and generated reviewer rubric to match the canonical generated bytes at authoring, dispatch, and admission. The existing coordinator stores the currency identity with the authenticated receipt, and the existing phase-admission path recomputes it before accepting a ledger stamp. Shared scope, lifecycle, trust, and authority clauses are authored once and generated into the three planning contracts; phase-specific judgment remains separate. |
-| Consequences           | Cosmetic contract, context, and unrelated inventory edits remain review-current, while changed scope, Rules, scenarios, referenced personas, affected surfaces, applicable principles, accepted decisions, or semantic contract clauses stale the dependent review. A generated copy that differs by even whitespace fails its separate integrity gate until canonical bytes are restored. Missing, unreadable, stale, duplicate, unknown, or ambiguous required structures fail closed. Product, Implementation, and Execution approvals remain limited to behavior, design, and startable delivery respectively.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        |
-| Alternatives           | Hash every packet byte: rejected because it violates the accepted semantic-stability contract. Persist a general Merkle dependency graph: rejected because a fixed three-phase dependency model does not justify another store, migration surface, or graph evaluator. Let each host assemble and validate context: rejected because authority and behavior would drift by surface.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       |
-| Data and compatibility | The integrity-protected review job remains the provenance store and the append-only review ledger remains the admission-claim store. New jobs carry a versioned review identity; no backfill or history rewrite occurs. Existing records remain preserved and authorize only when the active reader can authenticate them and recompute the current required identity. Existing Execution Plan normalized-digest and delivery-proof semantics remain unchanged.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                           |
-| Reassess when          | A false-current approval exposes an omitted semantic field; cosmetic edits repeatedly cause false staleness; a fourth planning artifact requires non-linear dependencies; a host's lifecycle authority changes; or SHA-256 is withdrawn for this use.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     |
-| Implementation         | Ticket `5F5ZZA`; the shared review packet/job/admission path, generated planning contracts, Product Plan review contract, and installed host adapters.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    |
+<!-- prettier-ignore -->
+| Field | Value |
+| --- | --- |
+| Context | Product, Implementation, and Execution Planning reviews depend on their target-plan identity and a larger accepted context. Product and Implementation use exact work-product bytes; Execution retains its accepted normalized identity so ordinary checklist progress does not force review of an unchanged delivery design. Raw whole-packet hashing safely catches every edit but makes formatting, comments, progress, and unrelated persona or surface inventory invalidate approval. Looser caller-selected packets can omit a load-bearing boundary and still appear current. |
+| Decision | One phase-aware resolver derives the complete role-labeled dependency set from ticket and project configuration. One projector binds exact Product/Implementation target bytes or the trusted normalized Execution identity, plus the exact bounded canonical-contract digest and semantically normalized ticket-relevant slices of each context role, into a deterministic SHA-256 review-currency identity. Execution normalization excludes only ordinary progress in contributor-row Disposition, Evidence class, Revision, and final evidence cells; every stable obligation and every other plan byte remains identity-bearing. Separately, an exact-byte copy-integrity check requires every installed authoring contract and generated reviewer rubric to match the canonical generated bytes at authoring, dispatch, and admission. The existing coordinator stores the currency identity with the authenticated receipt, and the existing phase-admission path recomputes it before accepting a ledger stamp. Shared scope, lifecycle, trust, and authority clauses are authored once and generated into the three planning contracts; phase-specific judgment remains separate. |
+| Consequences | Cosmetic context and unrelated inventory edits remain review-current, while changed scope, Rules, scenarios, referenced personas, affected surfaces, applicable principles, accepted decisions, or any bounded canonical contract bytes stale the dependent review. A generated copy that differs by even whitespace fails its separate integrity gate until canonical bytes are restored. Missing, unreadable, stale, duplicate, unknown, or ambiguous required structures fail closed. Product, Implementation, and Execution approvals remain limited to behavior, design, and startable delivery respectively. |
+| Alternatives | Hash every packet byte: rejected because it violates the accepted semantic-stability contract. Persist a general Merkle dependency graph: rejected because a fixed three-phase dependency model does not justify another store, migration surface, or graph evaluator. Let each host assemble and validate context: rejected because authority and behavior would drift by surface. |
+| Data and compatibility | The integrity-protected review job remains the provenance store and the append-only review ledger remains the admission-claim store. New jobs carry a versioned review identity; no backfill or history rewrite occurs. Existing records remain preserved and authorize only when the active reader can authenticate them and recompute the current required identity. Existing Execution Plan normalized-digest and delivery-proof semantics remain unchanged. |
+| Reassess when | A false-current approval exposes an omitted semantic field; cosmetic edits repeatedly cause false staleness; a fourth planning artifact requires non-linear dependencies; a host's lifecycle authority changes; or SHA-256 is withdrawn for this use. |
+| Implementation | Ticket `5F5ZZA`; the shared review packet/job/admission path, generated planning contracts, Product Plan review contract, and installed host adapters. |
 
 **5F5ZZA Product Plan gate placement:** Product Plan review runs at the exit
 from `intake`, before `define-behavior` and scenario-quality review. Its
@@ -883,16 +894,13 @@ review output is evidence of the authoritative inventory, never a replacement
 source or fourth planning contract.
 
 **5F5ZZA contract-directed upstream edge:** Required Execution review context
-always includes the accepted Implementation Plan. Its currency edge is read
-from the canonical Execution Planning contract owned by 7CAMAD: the closed
-`upstreamImplementationInvalidation` field declares `both_plan_reviews` or
-`implementation_review_only`. Only that upstream role may be snapshot-only in
-the latter mode; immutable packet integrity and required-source validation still
-apply, while later upstream content changes do not stale the Execution receipt.
-The contract mode remains semantic currency, and missing/invalid modes fail
-closed. The former mode binds the upstream semantic digest. All other applicable
-role bindings remain fixed; no general dependency graph is added. R9 proves both
-modes through the same real resolver, coordinator status, and admission path.
+always includes the accepted Implementation Plan as a currency-bearing dependency.
+The canonical Execution Planning contract owned by 7CAMAD declares
+`upstreamImplementationInvalidation: both_plan_reviews`, matching parent
+TBU2.R11/TBU4.R9. Reconciliation rejects unsupported own-review-only, missing,
+or ambiguous declarations before installed bytes change. A semantic upstream
+change stales both approvals. All applicable role bindings remain fixed; no
+snapshot-only exception or general dependency graph is added.
 
 **5F5ZZA user-disposition extension:** A user-declined optional strengthening
 is stored as versioned ticket context, not as reviewer authority or a new
@@ -914,15 +922,16 @@ preserve the unknown ticket field but derive no authority from it.
 **Status:** Proposed
 **Date:** 2026-09-20
 
-| Field          | Value                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     |
-| -------------- | --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
-| Context        | The independent-review coordinator already has a bounded fallback ladder, but its 2026-08-02 record says host-reported fresh-context and bounded self-review can never create a stamp and calls same-agent completion degraded. The accepted planning contract instead permits those tiers to advance with honestly reduced independence only after every stronger configured route was attempted and failed.                                                                                                                                                                                                                                                                                                                                             |
-| Decision       | Keep one ordered ladder: independent routes, same-agent headless review, host-reported fresh-context review, then bounded self-review. Fallback is unavailable while a stronger route remains available or before at least one configured independent route was attempted. When policy permits it, the coordinator binds every tier to the same immutable packet; host-owned tiers complete a tier-bound continuation whose typed result is integrity-sealed in the existing job store. An approval may produce a stamp-eligible receipt with the actual reviewer/tier and `reduced` independence. It never claims cross-agent independence, human approval, merge authority, or release authority. `require` policy and ungated origins remain blocking. |
-| Consequences   | Planning can finish honestly when external review infrastructure is exhausted without misrepresenting assurance or creating a parallel receipt store. Phase admission authenticates and currency-checks fallback receipts exactly like independent receipts, while policy and ordered-route evidence determine whether reduced independence is admissible. Zero configured/reachable independent routes before any attempt remains a configuration block rather than an automatic fallback.                                                                                                                                                                                                                                                               |
-| Supersedes     | The 2026-08-02 coordinator clauses that label all same-agent fallback `degraded`, say foreground fresh-context/self-review never create a review stamp, require host tiers to read live worktree paths without revalidated source integrity, allow `off` to coexist with a required planning review, and treat agent/process separation as sufficient under `require` when author capability is unverifiable. Every tier now reviews the same immutable coordinator packet through a tier-bound continuation. `off` blocks a required planning review; `require` blocks rather than weakening independence. The older record's route preference, typed failures, authentication, containment, and actual-provenance decisions remain in force.            |
-| Alternatives   | Preserve non-stamping host fallback: rejected because accepted R6 phase transitions could never advance. Treat fallback as independent: rejected because it fabricates assurance. Let hosts write ledger stamps directly: rejected because it bypasses coordinator authentication and packet identity.                                                                                                                                                                                                                                                                                                                                                                                                                                                    |
-| Reassess when  | A host provides cryptographically attestable fresh-context identity, reduced-independence reviews show materially different defect-catch rates, or policy needs to distinguish which fallback tiers may advance.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                          |
-| Implementation | Ticket `5F5ZZA`; coordinator recovery jobs, authenticated result persistence, review stamps, phase admission, and installed host recovery guidance.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       |
+<!-- prettier-ignore -->
+| Field | Value |
+| --- | --- |
+| Context | The independent-review coordinator already has a bounded fallback ladder, but its 2026-08-02 record says host-reported fresh-context and bounded self-review can never create a stamp and calls same-agent completion degraded. The accepted planning contract instead permits those tiers to advance with honestly reduced independence only after every stronger configured route was attempted and failed. |
+| Decision | Keep one ordered ladder: independent routes, same-agent headless review, host-reported fresh-context review, then bounded self-review. Fallback is unavailable while a stronger route remains available or before at least one configured independent route was attempted. When policy permits it, the coordinator binds every tier to the same immutable packet; host-owned tiers complete a tier-bound continuation whose typed result is integrity-sealed in the existing job store. An approval may produce a stamp-eligible receipt with the actual reviewer/tier and `reduced` independence. It never claims cross-agent independence, human approval, merge authority, or release authority. `require` policy and ungated origins remain blocking. |
+| Consequences | Planning can finish honestly when external review infrastructure is exhausted without misrepresenting assurance or creating a parallel receipt store. Phase admission authenticates and currency-checks fallback receipts exactly like independent receipts, while policy and ordered-route evidence determine whether reduced independence is admissible. Zero configured/reachable independent routes before any attempt remains a configuration block rather than an automatic fallback. |
+| Supersedes | The 2026-08-02 coordinator clauses that label all same-agent fallback `degraded`, say foreground fresh-context/self-review never create a review stamp, require host tiers to read live worktree paths without revalidated source integrity, allow `off` to coexist with a required planning review, and treat agent/process separation as sufficient under `require` when author capability is unverifiable. Every tier now reviews the same immutable coordinator packet through a tier-bound continuation. `off` blocks a required planning review; `require` blocks rather than weakening independence. The older record's route preference, typed failures, authentication, containment, and actual-provenance decisions remain in force. |
+| Alternatives | Preserve non-stamping host fallback: rejected because accepted R6 phase transitions could never advance. Treat fallback as independent: rejected because it fabricates assurance. Let hosts write ledger stamps directly: rejected because it bypasses coordinator authentication and packet identity. |
+| Reassess when | A host provides cryptographically attestable fresh-context identity, reduced-independence reviews show materially different defect-catch rates, or policy needs to distinguish which fallback tiers may advance. |
+| Implementation | Ticket `5F5ZZA`; coordinator recovery jobs, authenticated result persistence, review stamps, phase admission, and installed host recovery guidance. |
 
 **5F5ZZA capability-classification extension:** Cross-agent independence also
 requires verified exact author/reviewer model IDs and a current qualified
diff --git a/README.md b/README.md
index 54723a24b..6a0c58700 100644
--- a/README.md
+++ b/README.md
@@ -440,6 +440,21 @@ not clear it. Hosts without trusted exact author-model metadata cannot
 automatically satisfy that claim today; the existing reasoned skip remains an
 auditable escape hatch, without relabeling fallback as independent.
 
+Product Plan approval means the accepted behavior is ready for scenarios;
+Implementation Plan approval means its design is coherent enough for delivery
+planning; Execution Plan approval means the sequence is startable and provable.
+Each approval covers its own phase and semantic dependencies such as accepted
+scope and prior decisions. Product and Implementation receipts bind exact plan bytes;
+Execution review binds normalized decision bytes, so ordinary Delivery Checklist
+progress does not stale it. A changed reviewed decision calls for re-review before
+the affected phase advances. When independent routes fail,
+`prefer` can admit a completed fallback with its actual reviewer and **reduced
+independence**; `require` cannot. Repair the cause or configure a qualified
+route, then re-review for independent assurance. Local Claude Code, local Codex,
+local Cursor, OpenCode CLI/TUI, Claude Code Cloud, and Cursor Cloud Agents have
+enforced planning entry points. Codex Cloud and OpenCode Desktop are advisory;
+use an enforced host for an authoritative planning approval.
+
 **Codex plugin skills**: Codex gets Safeword workflow skills from the Safeword Codex plugin, with scoped names such as `safeword:bdd`, `safeword:verify`, and `safeword:explain`. Safeword no longer installs Safeword-owned workflow aliases into `.agents/skills/`.
 
 **Language coding-skills** (auto-installed per language): when safeword detects a Go, Python, TypeScript, or Rust project, `install` installs a small third-party coding-skill for that language (via `npx skills`, into `.claude/skills/` and, where supported by the agent, `.agents/skills/`). These are third-party language helpers, not Safeword Codex workflow files. The Claude Code on-edit nudge points the agent at the matching skill the first time you edit that language in a scenario; Cursor's adapter is dormant pending platform bug #534. Best-effort — a missing network or installer error degrades to a warning, never blocks install. Note: frontier models already write most core idioms unaided, so this is a light nudge, not a transformation.
diff --git a/features/keep-plan-reviews-current-and-trustworthy.feature b/features/keep-plan-reviews-current-and-trustworthy.feature
index 06a9b2dc9..5361f0a36 100644
--- a/features/keep-plan-reviews-current-and-trustworthy.feature
+++ b/features/keep-plan-reviews-current-and-trustworthy.feature
@@ -59,7 +59,7 @@ Feature: Keep plan reviews current and trustworthy
     @surface.claude-code @rejection
     Scenario Outline: Installed dispatch cannot bypass packet completeness
       Given a <phase> review packet <packet_state>
-      When actual lifecycle dispatch from installed local project hooks prepares the review with real configuration and collaborators, mocking only the reviewer process boundary
+      When the native plugin review hook dispatches from an installed local project with real configuration and collaborators, mocking only the reviewer process boundary
       Then <dispatch_result>
 
       Examples:
@@ -110,7 +110,7 @@ Feature: Keep plan reviews current and trustworthy
       Examples:
         | context_change | review_state |
         | a bound context artifact changes only in whitespace or comments | the review remains current |
-        | the canonical phase contract changes only in whitespace or comments | the review remains current |
+        | the canonical phase contract changes only in whitespace or comments | the review becomes stale |
         | an unrelated persona or surface entry is added | the review remains current |
         | the reviewed plan changes only in whitespace or comments outside normalized Execution Plan checklist progress cells | that plan's review becomes stale because its exact bytes changed |
         | the canonical phase contract changes semantically | the review becomes stale |
@@ -130,6 +130,7 @@ Feature: Keep plan reviews current and trustworthy
         | the installed authoring contract differs from the canonical source only in whitespace or comments | authoring and approval are blocked until the exact canonical contract bytes are restored |
         | the installed authoring contract is absent | authoring and approval are blocked until the canonical contract is restored |
         | the generated reviewer rubric deletes one clause but retains the canonical version label | review dispatch and approval are blocked until the exact canonical contract bytes are restored |
+        | the generated reviewer rubric is absent | review dispatch and approval are blocked until the canonical contract is restored |
         | the authoring contract and reviewer rubric both match the exact canonical bytes | both copies recompute to the same identity and contract identity does not block authoring, dispatch, or approval |
 
     @surface.claude-code
@@ -145,7 +146,7 @@ Feature: Keep plan reviews current and trustworthy
 
     @surface.claude-code @rejection
     Scenario: Cosmetic canonical changes preserve review currency but require copy reconciliation
-      Given a plan review is current and its canonical phase contract changed only in whitespace or comments after installed copies were generated
+      Given a plan review is current and its authoring guidance changed only in comments outside the canonical contract after installed copies were generated
       When actual lifecycle dispatch from installed local project hooks evaluates the phase transition with real configuration and collaborators, mocking only the reviewer process boundary
       Then the review receipt remains current and the phase remains blocked with canonical contract reconciliation named
 
@@ -163,13 +164,18 @@ Feature: Keep plan reviews current and trustworthy
         | every configured independent route was attempted and returned a typed failure, then the permitted fallback approves | the review passes with reduced independence and actual reviewer recorded without calling the capability degraded |
         | every independent route and same-agent headless review returned typed failures, then host-reported fresh-context review approves | the review passes with reduced independence and the host-reported fresh-context reviewer recorded |
         | every earlier route through host-reported fresh-context review returned typed failures, then bounded self-review approves | the review passes with reduced independence and the bounded self-reviewer recorded |
-        | a typed retryable-route result naming another unattempted independent route | the phase remains blocked |
         | a pending review | the phase remains blocked |
         | an unrecognized or unparseable reviewer result | the phase remains blocked with no approval recorded |
-        | an approval whose recorded origin is an ungated surface | the phase remains blocked with reviewer-route reconciliation named |
+        | an approval submitted from an ungated surface | the phase remains blocked and the unsupported approval origin is named |
         | every configured independent route was attempted and returned a typed failure, then the permitted fallback declines | the phase remains blocked with no approval recorded |
         | a typed no-independent-route-attempted result | the phase remains blocked with reviewer-route reconciliation named |
 
+    @manual @deferred.DRD65E @rejection
+    Scenario: An unattempted independent route prevents exhausted-route approval
+      Given the review coordinator has returned a typed retryable-route result naming another unattempted independent route
+      When the phase gate evaluates the receipt
+      Then the phase remains blocked
+
     @rejection
     Scenario: Fallback cannot bypass an available independent route
       Given at least one independent reviewer route remains available and unattempted
@@ -186,7 +192,7 @@ Feature: Keep plan reviews current and trustworthy
         | a different agent in a separate process using a model at least as capable as the author | cross-agent independence is accepted |
         | a different agent in the same process using a model at least as capable as the author | independent approval is refused |
         | the authoring agent in the same process | independent approval is refused |
-        | a different agent using a weaker model than the author | independent approval is refused |
+        | a different agent when the author model cannot be verified | independent approval is refused |
 
     Scenario Outline: Route selection derives independence from configured model capability
       Given the real review route registry and project configuration select <reviewer_capability>
@@ -196,10 +202,22 @@ Feature: Keep plan reviews current and trustworthy
       Examples:
         | reviewer_capability | selection_result |
         | a reviewer model at least as capable as the verified author model | that route is attempted as an independent review |
-        | a reviewer model weaker than the verified author model | that route is not attempted as independent and selection continues to the next permitted route |
+        | a reviewer model with unavailable, stale, or conflicting pair capability | that route is not attempted as independent and selection continues to the next permitted route |
+
+    @manual @deferred.KKP2R3 @rejection
+    Scenario: A genuinely weaker reviewer cannot provide independent approval
+      Given an approval is returned by a different agent using a weaker model than the author
+      When the coordinator classifies its independence
+      Then independent approval is refused
+
+    @manual @deferred.KKP2R3 @rejection
+    Scenario: A genuinely weaker reviewer is excluded before independent launch
+      Given the real review route registry and project configuration select a reviewer model weaker than the verified author model
+      When the coordinator selects an independent route while mocking only the agent invocation
+      Then that route is not attempted as independent and selection continues to the next permitted route
 
     Scenario Outline: Exhausted routes advance through the fallback ladder in order
-      Given every route before <next_tier> was attempted and returned a typed failure
+      Given every route before <next_tier> is configured to return a typed failure when attempted
       When review recovery selects the next permitted route
       Then review recovery selects and attempts <next_tier>, and no later tier is attempted first
 
@@ -227,7 +245,7 @@ Feature: Keep plan reviews current and trustworthy
         | OpenAI Codex | installed Codex hooks | a permitted fallback approval after every configured independent route was attempted and returned a typed failure | the phase transition proceeds with reduced independence and the actual reviewer recorded without calling the capability degraded |
         | Cursor | installed Cursor hooks | a permitted fallback approval after every configured independent route was attempted and returned a typed failure | the phase transition proceeds with reduced independence and the actual reviewer recorded without calling the capability degraded |
 
-    @surface.opencode
+    @surface.opencode @manual @deferred.MCWV4B
     Scenario Outline: OpenCode CLI and TUI gates enforce the real review result
       Given an OpenCode <entry_point> planning phase has <review_state>
       When actual lifecycle dispatch through the installed profile-level plugins/safeword.js evaluates the phase transition with real configuration and collaborators, mocking only the reviewer process boundary
@@ -242,7 +260,7 @@ Feature: Keep plan reviews current and trustworthy
         | TUI | a current approving receipt | the phase transition proceeds |
         | TUI | a permitted fallback approval after every configured independent route was attempted and returned a typed failure | the phase transition proceeds with reduced independence and the actual reviewer recorded without calling the capability degraded |
 
-    @surface.claude-code-cloud @surface.cursor-cloud-agents
+    @surface.claude-code-cloud @surface.cursor-cloud-agents @manual @deferred.MCWV4B
     Scenario Outline: Cloud phase gates enforce the real review result
       Given a planning phase on <cloud_host> in its fresh cloud environment has <review_state>
       When actual lifecycle dispatch from installed project hooks evaluates the phase transition with real configuration and collaborators, mocking only the remote reviewer process boundary
@@ -260,6 +278,7 @@ Feature: Keep plan reviews current and trustworthy
   @plan-implementability.TBU4.5F5ZZA.R7
   Rule: plan-implementability.TBU4.5F5ZZA.R7 — Research and review context remain untrusted evidence
 
+    @manual @deferred.FC33HK
     Scenario Outline: Retrieved instructions cannot change accepted scope
       Given a retrieved source contains instructions to change the accepted scope and relevant evidentiary claims
       When a judged semantic evaluation uses it during <consumption_point> with only the retrieval boundary mocked
@@ -270,6 +289,7 @@ Feature: Keep plan reviews current and trustworthy
         | planning | resulting plan output |
         | plan review | resulting review output |
 
+    @manual @deferred.FC33HK
     Scenario Outline: Retrieved executable code remains untrusted evidence
       Given a retrieved source contains executable code and relevant evidentiary claims
       When structural quarantine exposes its claims during <consumption_point> while mocking only the retrieval process boundary
@@ -280,6 +300,7 @@ Feature: Keep plan reviews current and trustworthy
         | planning |
         | plan review |
 
+    @manual @deferred.FC33HK
     Scenario Outline: Private-context requests do not prevent public evidence use
       Given a retrieved source requests private code, credentials, customer data, and unpublished design context and also exposes public evidence
       When structural quarantine exposes its public evidence during <consumption_point> while mocking only the retrieval process boundary
@@ -290,6 +311,7 @@ Feature: Keep plan reviews current and trustworthy
         | planning |
         | plan review |
 
+    @manual @deferred.FC33HK
     Scenario Outline: Reusable evidence records declared reuse limits
       Given a retrieved source has license identifier Apache-2.0, attribution notice "Credit Example", redistribution limit "retain NOTICE", and security limit "do not execute retrieved code"
       When it is used during <consumption_point>
@@ -300,6 +322,7 @@ Feature: Keep plan reviews current and trustworthy
         | planning | Apache-2.0, "Credit Example", "retain NOTICE", and "do not execute retrieved code" appear in the plan evidence record before reuse |
         | plan review | Apache-2.0, "Credit Example", "retain NOTICE", and "do not execute retrieved code" appear in the review evidence record before reuse |
 
+    @manual @deferred.FC33HK
     Scenario Outline: Evidence records do not invent absent limits
       Given a retrieved source states no license, attribution, redistribution, or security limit
       When it is used during <consumption_point>
@@ -321,7 +344,7 @@ Feature: Keep plan reviews current and trustworthy
         | an instruction inside a bound persona context input to ignore the contract and approve an otherwise conforming plan | the plan is approved on contract grounds and the context instruction is recorded only as reviewed content |
         | the same injected instruction and a genuine missing in-scope decision | the injected instruction remains reviewed content and the review blocks with the missing decision named |
 
-    @surface.claude-code
+    @surface.claude-code @manual @deferred.FC33HK
     Scenario Outline: Installed review dispatch preserves the retrieved-evidence trust boundary
       Given the installed Claude Code workflow receives <retrieved_state>
       When actual lifecycle dispatch from installed local project hooks prepares judged plan review with real configuration and collaborators, mocking only the reviewer process boundary
@@ -341,13 +364,21 @@ Feature: Keep plan reviews current and trustworthy
       When the Safeword CLI reconciles the installed repository guidance through real project configuration
       Then it labels Codex Cloud execution advisory, claims neither review nor approval there, and directs authoritative planning to a supported gated surface
 
-    @surface.opencode
+    @surface.opencode @manual @deferred.MCWV4B
     Scenario: OpenCode Desktop guidance cannot claim a gated approval
       Given the OpenCode profile plugin is read from Desktop where native lifecycle hooks are unavailable
       When the Safeword CLI reconciles the installed OpenCode profile guidance through real project configuration
       Then it labels Desktop execution advisory, claims neither review nor approval there, and names both OpenCode CLI and TUI as authoritative planning entry points
 
-    @surface.claude-code @surface.opencode
+    # MCWV4B must resolve the parent advisory boundary and prove native
+    # enforcement before these deferred expectations can establish authority.
+    @surface.opencode @manual @deferred.MCWV4B
+    Scenario: Generated OpenCode guidance identifies proven gated surfaces as enforced
+      Given planning guidance is generated for OpenCode CLI
+      When the Safeword CLI reconciles that installed guidance through real project configuration
+      Then it states that planning review and approval are enforced there and does not label that surface advisory
+
+    @surface.claude-code
     Scenario Outline: Generated guidance identifies gated surfaces as enforced
       Given planning guidance is generated for <gated_surface>
       When the Safeword CLI reconciles that installed guidance through real project configuration
@@ -356,7 +387,6 @@ Feature: Keep plan reviews current and trustworthy
       Examples:
         | gated_surface |
         | local Claude Code |
-        | OpenCode CLI |
 
   @plan-implementability.TBU4.5F5ZZA.R9
   Rule: plan-implementability.TBU4.5F5ZZA.R9 — Review invalidation follows the dependency direction specified by the Execution Planning contract; this child implements the shared provenance and invalidation mechanics rather than defining a second dependency matrix
@@ -370,6 +400,8 @@ Feature: Keep plan reviews current and trustworthy
         | change_description | invalidated_reviews |
         | accepted behavior | both plan reviews are invalidated |
         | accepted scope | both plan reviews are invalidated |
+        | canonical Implementation Planning contract bytes change | both plan reviews are invalidated |
+        | only canonical Execution Planning contract bytes change | only the Execution Plan review is invalidated |
         | only the accepted Implementation Plan's formatting bytes | only the Implementation Plan review is invalidated and the Execution Plan review remains current |
         | only the Execution Plan bytes, including formatting-only bytes outside normalized checklist progress cells | only the Execution Plan review is invalidated |
         | only whitespace inside a reviewed Execution Plan checklist row's normalized progress cells | neither plan review is invalidated |
@@ -421,6 +453,12 @@ Feature: Keep plan reviews current and trustworthy
         | Claude Code | installed local project hooks |
         | OpenAI Codex | installed Codex hooks |
         | Cursor | installed Cursor hooks |
+
+      # User deferred these host checks on 2026-10-09; MCWV4B owns their proof.
+      # They remain unproven, and are excluded from the default automated lane.
+      @manual @deferred.MCWV4B
+      Examples: OpenCode and cloud verification deferred to MCWV4B
+        | host_entry | installed_boundary |
         | OpenCode CLI | installed profile-level plugins/safeword.js |
         | OpenCode TUI | installed profile-level plugins/safeword.js |
         | Claude Code Cloud | installed project hooks in its fresh cloud environment |
@@ -465,7 +503,7 @@ Feature: Keep plan reviews current and trustworthy
         | Execution Plan | passed verification and merge authority |
 
     Scenario: A planning approval may claim its own bounded state
-      Given an Implementation Plan has passed its own review
+      Given a coherent Implementation Plan has passed its own design review
       When a judged semantic reviewer evaluation checks a receipt claiming only the accepted coherent implementation design
       Then the receipt is accepted as a bounded Implementation Plan approval
 
diff --git a/packages/cli/package.json b/packages/cli/package.json
index dbb3d7b02..315586590 100644
--- a/packages/cli/package.json
+++ b/packages/cli/package.json
@@ -48,6 +48,8 @@
     "test:smoke:live": "node scripts/run-vitest-with-build-lock.mjs --config vitest.live.config.ts",
     "test:smoke:live:github": "node scripts/run-github-live-smokes.mjs",
     "test:eval:reviewer-capability": "bun scripts/reviewer-capability-eval.ts",
+    "test:eval:planning-contracts": "bun scripts/planning-contracts-eval.ts",
+    "test:eval:planning-reviews": "bun run test:eval:reviewer-capability && bun run test:eval:planning-contracts",
     "test:release": "node scripts/run-vitest-with-build-lock.mjs --config vitest.release.config.ts",
     "test:slow": "node scripts/run-vitest-with-build-lock.mjs --config vitest.slow.config.ts",
     "test:slow:install-proof": "node scripts/run-vitest-with-build-lock.mjs --config vitest.slow.config.ts tests/integration/non-git-install-proof.slow.test.ts",
