# Current qualification triage

Decision: repair demonstrably incomplete clean-case fixtures, change the reviewer contract, or reject the model candidate. A wrong choice hides true rejection findings or spends money repeating invalid evaluations.

Investigation plan and domains:
1. Accepted behavior and fixture construction: do the two rejected positive fixtures actually provide current final proof and startable conformance assertions? Compare their concrete tasks against the accepted contract, not just expected verdicts.
2. Evaluation methods: check primary-source guidance on inspecting failed trajectories and distinguishing infrastructure failure from semantic quality. Preserve complete census and exact input identities.
3. Runtime and host execution: compare timeout durations and observed sleep events; identify whether a bounded retry can establish an awake-run result without changing timeouts or authentication.
4. Scope and cost: determine the smallest correction and affected-case diagnostic before paying for another full qualification. No scorer, verdict, threshold, model default or catalogue admission changes.

Current sealed candidate results: Claude 25/63 pass, 38 fail, zero unfinished; Sol 58/63 pass, five fail, zero unfinished. Sol has two request_changes-versus-approve disagreements, two test timeouts, and one process failure. Capability collection correctly did not dispatch. Overnight sleep events materially confound runtime outcomes; they do not erase or excuse semantic findings. Prior interrupted runners remain unqualified.

Options: (A) surgical fixture proof corrections after human approval, then affected diagnostic before a fresh full qualification; (B) weaken final-proof/startability requirements to accept the existing fixtures; (C) abandon Sol based on these two verdicts. Steelman B: keeps dataset bytes fixed and finishes faster, but contradicts accepted current-proof behavior. Steelman C: conservatively retains the existing default, but a model that identifies actual fixture defects has not thereby failed the intended behavior. A preserves both the acceptance contract and model scrutiny, at the cost of resetting the corpus identity and fresh full-run evidence.

Primary-source evidence: https://www.anthropic.com/engineering/demystifying-evals-for-ai-agents describes reading transcripts and auditing tasks and graders; https://www.anthropic.com/engineering/infrastructure-noise treats infrastructure setup as a source of evaluation noise. Local exact reviewer outputs are in /tmp/4200-supervised-sol-live.log, with original complete censuses retained unchanged.

Premortem: repeated fixture repair could become tuning the corpus to a model. Require contract-based independent review, preserve rejection expectations and all negative cases, and do not admit affected diagnostics as full qualification.

Next: prepare and independently review only the two concrete fixture-proof corrections; do not apply them without the testing guide's explicit approval.
