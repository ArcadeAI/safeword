# Sol CLI access recovery — October 7, 2026

The plain PATH command resolves /Users/alex/.local/bin/codex to the standalone 0.153.4 installation. A fresh gpt-6.1-sol probe through that executable returned HTTP 400, matching the October 6 failure.

The repository already pins @openai/codex 0.160.0 and its node_modules/.bin/codex reports that version. With exactly the same authenticated temporary CODEX_HOME, an explicit 0.160.0 invocation returned availability-check and exit 0. Evidence: /tmp/4200-sol-current-access.log and /tmp/4200-sol-pinned-cli-access.log. No credentials were read or replaced; no global configuration or installation was changed.

Earlier claims that the account itself cannot use Sol were too broad: the failure depends on the old standalone client. Sol qualification is now queued behind the corrected Claude matrix using explicit repo-local CLI precedence. Script /tmp/4200-sol-pinned-qualification-queue.py; log /tmp/4200-sol-pinned-qualification-queue.log. Qualification remains unearned and the default remains unchanged until a complete passing matrix and admission refresh.
