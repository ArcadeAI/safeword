# Mechanical binding refresh; no expected behavior changed

Full root acceptance at e7dcf6d52 completed 175 cases: 50 pass,7 fail,118
undefined. All7 failures stopped in readManifest before reviewer judgment.
Only rubric_digest differs from current canonical prompts. Corpus digest,
judge rubric, reviewer/judge models,3 repetitions,2 agreement threshold and
all expected verdicts are unchanged. Refresh the derived canonical-rubric
hash after the previously authorized contract correction. This is metadata,
not a new model pass. Every old failed/stale result remains recorded; new
judged root runs are still required. Validate no bypass or verdict change.

diff --git a/packages/cli/tests/fixtures/planning-contracts-eval/manifest.json b/packages/cli/tests/fixtures/planning-contracts-eval/manifest.json
index 5f99257fd..a72cd49e5 100644
--- a/packages/cli/tests/fixtures/planning-contracts-eval/manifest.json
+++ b/packages/cli/tests/fixtures/planning-contracts-eval/manifest.json
@@ -1,6 +1,6 @@
 {
   "version": 1,
-  "rubric_digest": "2b86e288fac6ee06d61db02c73b886499a3dff4c37d5cf45578ed9ee24e7ff7a",
+  "rubric_digest": "d079e1fb9262edb2ca67b9f350c7676afb5577debf2fe1f908c3a4067c087214",
   "corpus_digest": "34f998706fa38801c050b6f3f989ab7bca39ad9e570f6f455321505799d0e716",
   "reviewer_model": "claude-opus-5",
   "judge_model": "claude-sonnet-5",
