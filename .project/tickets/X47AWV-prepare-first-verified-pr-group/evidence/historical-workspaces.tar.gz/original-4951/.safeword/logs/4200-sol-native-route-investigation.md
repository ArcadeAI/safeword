# Sol native route decision

- [x] Frame: reach Sol through the actual trusted reviewer route without weakening executable trust or spending on another broken full matrix.
- [x] Options: use a separately installed trusted copy of the already pinned 0.160.0 native CLI; repair project-package permissions; keep the old global CLI.
- [x] Domains: executable ancestry and project trust; CLI/app-server model availability; exact model provenance and qualification validity; local installation scope and maintenance.
- [x] Verify one real reviewer packet through the repaired route, then decide whether full qualification is warranted.

Evidence: direct 0.160.0 exec returned availability-check, but the full Sol matrix returned 63 process failures and no judgments. The package JavaScript launcher has mode 0777; runtime executable selection rejects group/world-writable ancestry and prefers a directly trusted global executable over staging. Global CLI is 0.153.4 and rejects Sol. The already installed native 0.160.0 binary has mode 0755. Do not weaken the trust filter or change global shell configuration. Test a versioned native copy outside the repository using only a scoped runner PATH.

Decision: retain existing executable trust checks and use a versioned native installation outside the repository. Changing project-package permissions would still couple trust to the editable source tree; keeping the old global CLI cannot reach Sol. The native copy at /Users/alex/.local/share/safeword-reviewers/codex/0.160.0/codex is installed from the already pinned package with mode 0755, reports 0.160.0, and is selected through runner-local PATH only. No global shell profile, authentication, or production trust rule changed.

One real Execution Plan packet through runHeadlessReviewerWithProvenance completed successfully and confirmed provider openai/model gpt-6.1-sol; it approved one-coherent-change. Raw result /tmp/4200-sol-native-pilot.log. This is a route diagnostic, not full qualification. Full 63-case qualification is queued after the active corrected Claude run with /tmp/4200-sol-native-full-queue.py and log /tmp/4200-sol-native-full-queue.log. Fresh results use /tmp/4200-qualified-sol-native-{live.log,results.json}; the failed 63-process-error run remains /tmp/4200-sol-final-codex-{live.log,results.json}.

Premortem: a future launcher update could silently select the old executable again; keep explicit versioned native PATH for qualification and confirm the requested model on every case. Production default remains unchanged until complete fresh matrix evidence qualifies Sol and the current candidate is approved for adoption.
