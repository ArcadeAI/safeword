# Qualification failure audit

Independently adjudicate the supplied cases against their exact accepted
Implementation Plans, accepted scenarios, and PLAN_EXECUTION contract. The
fixture expectations are disputed oracles, not authority. Actual reviewer
outputs are included to identify the failed behavior, not to dictate verdicts.

For each case: say whether the plan should approve or reject, whether the actual
reviewer correctly identifies an accepted-contract violation, and which layer
is at fault (fixture, expectation matcher, reviewer instruction/judgment).
Identify the smallest correction that isolates the intended behavior without
changing accepted scope, weakening required rejection, or demanding incidental
words. Distinguish concrete defects from optional advice. Do not rewrite the
production contract or demand label duplication when the required meaning is
present elsewhere. For positive cases, challenge both independently valuable
outcomes and the possibility that accepted data/measurement work is one part of
the same delivery. Do not assume either interpretation without the actual plan.

The run completed all 63 cases: 54 passed and nine failed. No qualification or
admission is claimed. No patch is applied for these nine cases. The sole goal
of this audit is root-cause classification and a surgical corrective proposal.
