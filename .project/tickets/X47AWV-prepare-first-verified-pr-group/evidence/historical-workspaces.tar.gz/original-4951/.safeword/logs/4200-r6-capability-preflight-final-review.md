# R6 explicit-selector qualification before launch

Review this bounded corrective implementation against accepted R6. It checks
known explicit selectors before invoking the reviewer, using the existing exact
ordered-pair comparison and current packaged evidence. Runtime-default routes,
unverified author hosts, same-agent fallback, nonplanning reviews and unverified
OpenCode provider routing retain their prior behavior. Actual runtime-confirmed
provider/model remains required after an eligible launch; the predictive namespace
does not grant approval. No model default, corpus, qualification threshold or
authority policy changed. Skipped route independence is its nominal route class;
public achieved independence remains the separate final result field.

The versioned catalogue already owns weaker/unknown/exact-pair decisions. The
existing skip decision now includes that preflight result; the main coordinator
loop stays within the existing complexity limit without another exception.
Private actor-facing tests prepare real project configuration, use the installed
public CLI and mock only reviewer processes. A non-probe launch log and exact
requested-model log prove the unqualified route never launches. The qualified
route is the passing control; actual typed skipped/attempted evidence is checked.
The unavailable comparison is representative; stale/conflicting records remain
covered by lower-level catalogue tests, and the weaker root row remains unbound.

Executable RED review de810605-97d7-448e-aae4-52fb8aaafa2a approves the exact
attested positive/negative command: one pass, one intended launch-count failure,
no timeout. RED commit 77b816af3 preserves that test. GREEN root cases pass 2/2;
after refactoring, eleven related root cases pass 11/11 (627 steps) in
/tmp/4200-r6-preflight-refactor-root.json. Five targeted package files pass 33/33
both before and after refactoring. Lint and all three package typechecks pass.
All five generated surfaces were refreshed and verified. The two generated
plugin CLI bundles and identity/inventory carriers changed by deterministic
generation; raw complete bundle inspection is not claimed in this source packet.
The full normal suite is running against frozen sources in
/tmp/4200-r6-preflight-full-normal.log. Historical acceptance failures, unbound
scenarios, RGR and deferrals remain open; no Ready or merge authority is inferred.

Review angles: refute preflight eligibility/source authority; check that runtime
identity cannot be replaced by requested identity; preserve default, fallback,
unknown-author and nonplanning behavior; verify actual launch discrimination and
scope. Apply current PRINCIPLES.md and persona/surface guidance: authoritative
structure should gate eligibility, preserve user controls, and avoid extra work.
Report actual defects, not optional new qualification or host mechanisms.
