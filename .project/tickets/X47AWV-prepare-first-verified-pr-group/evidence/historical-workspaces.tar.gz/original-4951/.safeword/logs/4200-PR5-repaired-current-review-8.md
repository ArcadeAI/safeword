Review PR #5139 complete committed non-bundled own-slice diff, part 8/10. Parent 854a376861bc034d65cc81ddfa6a85d0ae55821e; head 95c264f1282884bc803f0ba0db7537380c66bcff. Every non-bundled changed file is supplied across all parts. Compiled CLI bundle diffs excluded; source and generators included and all five generated surface checks passed. Review concrete correctness, authenticated approval, actual rejection findings, semantic scope, currency and test discrimination within accepted plans. Qualified Execution default is gpt-6.1-sol paired with Claude Opus 5; six canonical proof surfaces still byte-identical to qualified candidate. Full package 11415 pass, zero fail, 14 skip; release 82 pass. Actual root acceptance running; 110 undefined previously, historical six failures/585 unfinished retained. Do not infer complete acceptance or merge readiness from package tests. Already approved fixture corrections and release identities preserve rejections. Optional hardening is non-blocking; do not expand accepted scope. Review supplied complete source and generation rather than claiming raw compiled-byte inspection. No PR merge or Ready authority.

diff --git a/packages/cli/tests/fixtures/reviewer-capability-evidence/claude-opus-5.json b/packages/cli/tests/fixtures/reviewer-capability-evidence/claude-opus-5.json
index 12a470176..a3c7b22a0 100644
--- a/packages/cli/tests/fixtures/reviewer-capability-evidence/claude-opus-5.json
+++ b/packages/cli/tests/fixtures/reviewer-capability-evidence/claude-opus-5.json
@@ -1,27 +1,31 @@
 {
   "provider": "anthropic",
   "model": "claude-opus-5",
-  "corpus_digest": "f76edddd71868835e161d06987bce170fb395a71849412dd96c2b6d18c698b24",
-  "rubric_digest": "b9d97005601dcaaa38caefb84716497d792170da6d5d4a0076b039691df9594f",
-  "settings_digest": "acd5a69993710ae8483c78771a67a6d61e061707f39f450a24a9a10511f7bf4d",
-  "evidence_date": "2026-09-29",
+  "corpus_digest": "9625362c688a1eb641c0a504cd75d1977c0f9ee05980c0e233a57a76bd99ba92",
+  "rubric_digest": "a4662a8bb68e00b1da37f622ba88f2f0d8f9f3a502edea3777776ebb1d51cdc1",
+  "settings_digest": "5e89801fc75ed7f7e0a477a6ba32deca73cbe3896e6a640419aa7637f27c0e34",
+  "evidence_date": "2026-10-08",
   "runs": [
     {
       "fixture_id": "product-approve",
       "run": 1,
-      "verdict": "request_changes",
+      "verdict": "approve",
       "findings": [
         {
-          "severity": "error",
-          "message": "Undefined display for a concluded review with no blocking findings and no valid authenticated receipt. The plan defines Pending as \"the current review has not finished\", Approved as requiring \"an authenticated approval receipt\", and Rejected as \"concluded with blocking findings\". The done state explicitly contemplates that a receipt may be \"missing or stale\", so the state of a finished review whose receipt is absent or fails authentication is reachable within accepted scope, yet it matches none of the three definitions. Triggering condition: the review job completes producing no blocking findings while no authenticated receipt is available. Two reasonable implementations follow — display Pending, or display Rejected — and both falsely report the accepted claim. Pending tells the builder the review has not finished when it has, so the builder waits indefinitely instead of exercising the accepted repair-and-retry path; Rejected promises \"those actual findings\" when none exist, breaking the accepted done-state requirement that a rejected review shows the actual blocking findings. Define the product behavior for this state (for example, an explicit fourth outcome, or an accepted mapping onto one existing status with its definition widened to match) so the display cannot claim a status whose own accepted definition is false."
+          "severity": "warning",
+          "message": "Epistemic status is inconsistent between sections. 'Evidence and decisions' records 'Assumption: the existing CLI command adds no new viewer-permission gate', but the Refusal outcome asserts it as settled behavior: 'no new viewer-permission refusal applies to this existing CLI command.' An unsupported assumption restated as an accepted outcome can be read downstream as a known fact. Recommend marking the Refusal line as assumption-dependent so scenario definition inherits the open condition rather than a false certainty."
         },
         {
           "severity": "warning",
-          "message": "The staleness boundary is stated but not bounded as a product decision. \"A stale approval is a receipt for a different review job or different plan bytes\" leaves what counts as different plan bytes to the implementation. Byte-exact comparison and any normalization (trailing whitespace, line endings, formatting-only edits) are both reasonable readings, and they differ in whether a builder who makes a cosmetic edit after approval sees Approved or must re-review. This does not permit a missing or stale receipt to appear as approval, so it does not violate the accepted invariant, but the user-visible consequence of a trivial edit is currently an unresolved product choice presented as settled by \"no product choice remains open\"."
+          "message": "The failure outcome is framed around review-side conditions (interruption, missing/invalid receipt) but does not name the case where the status itself cannot be read — for example, the receipt or job record is unreadable or the status lookup fails. Under the current wording an implementation could render that as a bare Pending with no error text while still satisfying every stated outcome. This is a resilience gap rather than a violated accepted claim, since the ticket scopes the three review outcomes; naming it in intake would close the ambiguity before scenario definition."
         },
         {
-          "severity": "warning",
-          "message": "The Rejected display promises \"those actual findings\" with no accepted boundary on volume or truncation. For a review with a large number of blocking findings, showing all of them and showing a truncated set with an indication of the remainder are both consistent with the current wording, and they differ in what the builder can act on in the CLI surface. Naming the accepted expectation (complete findings, or truncation with an explicit remainder indicator) would close this without adding implementation design."
+          "severity": "info",
+          "message": "The plan excludes the never-requested state ('The display begins only after a review is requested; a never-requested state is outside this ticket'). The CAP100 ticket is silent on that state, so this is a reviewer-visible scope narrowing rather than a ticket-backed exclusion. It reads as a reasonable boundary — a never-requested review is not a review — but it is a user-owned scope call and should be confirmed in the ticket if builders can reach the status surface before requesting a review."
+        },
+        {
+          "severity": "info",
+          "message": "Scope, exclusions, persona, surface, and observable done state align with .project/non-goals.md, .project/personas.md, .project/surfaces.md, and .project/principles.md: no new approval authority, storage, or notification channel is introduced, and the existing authenticated receipt remains the sole approval authority. .project/tickets/CAP100/boundaries.md confirms no parent or milestone boundaries are inherited, so no binding context is missing for this review."
         }
       ]
     },
@@ -32,19 +36,19 @@
       "findings": [
         {
           "severity": "warning",
-          "message": "Abnormal termination has no named status. The plan defines Pending as \"the current review has not finished\" and Rejected as a review that \"concluded with blocking findings\". A review that ends without concluding — crash, timeout, or cancellation — satisfies neither definition cleanly and would display as Pending indefinitely, leaving the builder with no stated repair or retry path (the retry path is attached only to Rejected). This does not let a stale or missing receipt appear as approval, and none of the four accepted scenarios cover it, so it is non-blocking. Naming the intended outcome for a review that ends without a conclusion would close the ambiguity before scenario definition."
+          "message": "Staleness is defined only for approval receipts (\"A stale approval is a receipt for a different review job or different plan bytes\"), not for blocking verdicts. After the builder repairs a Rejected plan but before a new review is requested, the plan does not state whether the display shows Rejected with the prior review's findings or returns to Pending. The \"current review\" framing in the Rejected definition and the done state's \"all three current outcomes\" make the Rejected-until-new-review reading the natural one, and either reading still shows findings that a real review actually emitted, so the accepted claim \"see only actual blocking findings after rejection\" is not falsifiable by this gap. Naming the intended state for repaired-but-not-resubmitted plan bytes would remove the ambiguity before scenario definition."
         },
         {
           "severity": "warning",
-          "message": "The exclusion of the never-requested state (\"The display begins only after a review is requested; a never-requested state is outside this ticket\") is asserted by the plan, not traceable to the ticket or the accepted scenarios, which are silent on it. Accepted scope and exclusions belong to the user, so an exclusion originating in the plan should be confirmed as a user decision rather than recorded as settled; the plan's claim that \"no product choice remains open\" currently absorbs it without that confirmation."
+          "message": "The plan declares \"a never-requested state is outside this ticket.\" The ticket (.project/tickets/CAP100/ticket.md) states the goal as distinguishing Pending, Approved, and Rejected reviews and does not name this exclusion, and .project/tickets/CAP100/boundaries.md records no parent or milestone boundary supplying it. Accepted scope and exclusions belong to the user, so this is a plan-authored boundary rather than an inherited one. It is defensible on its face — a never-requested review is not a review — and the plan states it openly instead of silently assuming it, so it is a scope confirmation to obtain from the user rather than a defect."
         },
         {
           "severity": "info",
-          "message": "Scenario 4's stale-approval case is fully covered by the plan's definition of stale (\"a receipt for a different review job or different plan bytes\"): such a receipt is by construction not the current review's, so the current review is either unfinished (Pending) or concluded with blocking findings (Rejected). There is no unmapped concluded-but-unapproved state arising from staleness."
+          "message": "The refusal outcome asserts flatly that \"no new viewer-permission refusal applies to this existing CLI command,\" while Evidence and decisions correctly labels the same statement an assumption. The epistemic status is preserved where it is required, but the outcome inventory reads as a known fact. Marking it as assumed at the point of assertion would keep facts and assumptions distinct throughout."
         },
         {
           "severity": "info",
-          "message": "Prohibited content check is clean: the plan names no storage schema, display component, delivery task order, or ordering of implementation work, and it does not claim that scenarios, downstream plans, or implementation are approved. Existing approval authority and storage are correctly framed as untouched constraints rather than as work being accepted here."
+          "message": "Outcome inventory is complete for the one accepted persona in .project/personas.md: success, refusal, failure, approval, trust, and recovery are each present, and none are dismissed as inapplicable without reason. Scope matches .project/non-goals.md (no new approval authority, status store, or notification channel) and .project/surfaces.md (the existing CLI review-status command only). Scenario coverage, including scenarios.md items 5 and 6, is deliberately not assessed here; that verdict belongs to scenario review after Product approval."
         }
       ]
     },
@@ -55,15 +59,19 @@
       "findings": [
         {
           "severity": "warning",
-          "message": "The plan enumerates exactly three current outcomes but does not say how a review that terminates without a decision (for example, a review that fails or aborts and produces no blocking findings) is presented. Two reasonable readings exist: such a review stays Pending indefinitely, or it is shown as Rejected with an empty findings list. The second reading would violate the plan's own statement that Rejected means 'concluded with blocking findings' and would show a builder an empty findings view. This is a warning rather than an error because the accepted scope names three statuses and the ticket does not claim coverage of abnormal termination; naming the intended outcome (or explicitly excluding it) in the plan would remove the ambiguity before scenario definition."
+          "message": "spec.md, Accepted behavior: \"A running review shows its running state\" sits beside a Pending definition that already covers an unfinished review, and the ticket accepts three statuses (Pending, Approved, Rejected). Two reasonable readings survive: a running review displays Pending (matching accepted scenario 1), or it displays a distinct fourth label. The ambiguity does not let Approved or Rejected be shown falsely, so it is non-blocking, but the status vocabulary should be stated explicitly before scenario definition so the display contract is unambiguous."
         },
         {
           "severity": "warning",
-          "message": "'Evidence and decisions' mixes a supported project constraint (the existing authenticated receipt), a non-promise ('No quantitative target is promised'), and a closure claim ('no product choice remains open') in three sentences without separating supported facts from assumptions. The contract asks that supported facts, assumptions, and unresolved decisions be kept distinct. Nothing here appears mislabeled, but the section carries no assumption list at all, which makes the closure claim unverifiable from the plan alone."
+          "message": "spec.md, Accepted behavior: \"The display begins only after a review is requested; a never-requested state is outside this ticket\" is an author-declared exclusion. The ticket goal, the scenarios, and .project/non-goals.md are silent on the never-requested case; the ticket's stated exclusions cover only new approval authority, storage, and notification channels. Accepted scope and exclusions are user-owned, so this boundary should be confirmed in the authoritative ticket rather than established by the plan."
         },
         {
           "severity": "info",
-          "message": "The exclusion of the never-requested state is scoped narrowly and consistently ('the display begins only after a review is requested'), which matches the ticket goal of distinguishing review outcomes rather than describing pre-review UI. Worth confirming during scenario definition that no accepted scenario implicitly starts from a never-requested state, since scenario 4's 'request a new review' step brushes against that edge."
+          "message": "spec.md, Builder outcomes: the refusal outcome is marked inapplicable for a new viewer-permission gate with a specific reason (no new gate on the existing CLI command), and that reason is carried as an explicit assumption in the Evidence and decisions section rather than asserted as a known fact. This is the correct epistemic handling; if the assumption is later contradicted by the command's actual permission model, the Product Plan bytes change and require a fresh product review."
+        },
+        {
+          "severity": "info",
+          "message": "Scenario coverage was not assessed. The packet's scenarios.md is untrusted supporting context, not work under review, and scenario coverage belongs to scenario review after Product approval."
         }
       ]
     },
@@ -74,19 +82,31 @@
       "findings": [
         {
           "severity": "error",
-          "message": "spec.md omits the Rejected status entirely. The ticket goal states a builder must distinguish Pending, Approved, and Rejected, and that rejected reviews show the actual blocking findings and permit repair and retry; accepted scenario 3 requires a completed review with blocking findings to display Rejected with those findings. With only 'Pending means the review has not finished' and 'Approved means ... approval receipt' accepted, a completed-and-rejected review is not covered: an implementation may display it as Pending (it never reached approval) and still satisfy every accepted statement in the plan. Observable consequence: a builder sees a blocked review as still in progress, with no findings to repair, while the implementation reports the accepted behavior as satisfied. The plan must accept the Rejected state, the display of the actual blocking findings, and the repair-and-retry outcome, or explicitly exclude them from user-owned scope — which the ticket does not permit."
+          "message": "spec.md omits the Rejected outcome entirely. The accepted ticket goal (.project/tickets/CAP100/ticket.md) requires a builder to distinguish Pending, Approved, and Rejected, and requires Rejected to show the actual blocking findings. Rejected is neither defined in Accepted behavior nor listed under exclusions, so this is an in-scope omission, not a user-owned descope. Observable consequence: an implementation that renders only Pending and Approved satisfies every claim in this Product Plan while leaving a blocked builder with no rejection state and no findings."
+        },
+        {
+          "severity": "error",
+          "message": "The definition \"Pending means the review has not finished\" does not cover a review that has finished without a valid authenticated approval receipt, and \"Approved means the review has an authenticated approval receipt\" excludes it too. The accepted ticket requires that condition to stay Pending with its actual receipt error and no invented rejection findings. The omitted contract permits two reasonable implementations — one that shows Pending with the actual error, and one that shows Rejected with fabricated blocking findings — and the second violates the accepted behavior while still conforming to this plan."
         },
         {
           "severity": "error",
-          "message": "The Approved definition has no currency requirement: 'Approved means the review has an authenticated approval receipt.' Accepted scenario 2 requires a *current* authenticated approval, and scenario 4 requires that after a plan is repaired a stale approval cannot approve it. As written, two reasonable implementations are permitted — one that checks receipt currency against the reviewed plan and one that checks only that some authenticated receipt exists. The second displays Approved for a plan that has been changed since the receipt was issued, falsely reporting the accepted user-facing claim. The plan must state that Approved requires the authenticated approval receipt to correspond to the current plan state, and that a superseded receipt does not display Approved."
+          "message": "No failure or recovery outcome is inventoried for the accepted Builder persona. The ticket and .project/personas.md both require a retry action for an interrupted review and a repair-and-retry path after rejection, with retry not altering plan bytes. spec.md states no retry, no error surfacing, and no byte-stability constraint, so an implementation can report the accepted done state while leaving a builder permanently stuck on a Pending display with no actionable error and no way to request a new review."
+        },
+        {
+          "severity": "error",
+          "message": "The Observable done state — \"A builder can distinguish Pending from Approved\" — is non-discriminating proof for the accepted goal. Every behavior required by the ticket beyond the two-state distinction (actual findings on rejection, actual error on interruption, absence of invented findings, retry) can be broken while this done state still passes, so the plan supplies no check that would detect the failures above."
+        },
+        {
+          "severity": "warning",
+          "message": "spec.md does not keep known facts, assumptions, and unresolved product decisions visibly distinct. The two status definitions are asserted as facts with no cited support; the authenticated-receipt rule is supported by .project/principles.md, but the Pending definition has no stated basis and reads as an unmarked assumption."
         },
         {
           "severity": "warning",
-          "message": "The observable done state, 'A builder can distinguish Pending from Approved', is non-discriminating with respect to the accepted goal: it can be demonstrated in full while the Rejected status and stale-approval behavior are entirely broken or absent. Once the states above are accepted, restate the done state so it fails when a rejected review, its blocking findings, or a superseded approval is displayed incorrectly."
+          "message": "Approval, trust, and refusal outcomes are not inventoried or marked inapplicable with a specific reason. The plan references an authenticated approval receipt but never states the builder-visible outcome when receipt authentication is stale or invalid, which .project/tickets/CAP100/scenarios.md item 4 treats as consequential."
         },
         {
           "severity": "info",
-          "message": "Required Product Plan content is otherwise present (persona, surface, scope and exclusions), and the plan correctly avoids implementation design, task sequencing, and claims of scenario or design approval. The plan also does not separate supported facts from assumptions and unresolved decisions; if the currency semantics of the approval receipt are an open product question rather than settled, record it explicitly as unresolved rather than leaving it implied."
+          "message": "The stated exclusions (no new approval authority, no notifications) are consistent with .project/non-goals.md and .project/principles.md, and the plan correctly refrains from implementation design, task sequencing, and any claim that scenarios or delivery are approved. The single affected surface matches .project/surfaces.md. No scenario-coverage verdict is issued here, since the Product Plan is incomplete."
         }
       ]
     },
@@ -97,23 +117,35 @@
       "findings": [
         {
           "severity": "error",
-          "message": "spec.md omits the Rejected review state entirely. The ticket goal is that a builder can distinguish Pending, Approved, and Rejected, and accepted scenario 3 requires a completed review with blocking findings to display Rejected with those actual findings. Because the plan names no Rejected behavior, two reasonable implementations exist: one that renders a third Rejected state with its findings, and one that renders only Pending/Approved and shows a completed-with-findings review as Pending or as nothing. The second implementation passes every condition stated in the plan while the accepted user-facing behavior is false. Add Rejected as accepted behavior, including that the display shows the actual blocking findings rather than a generic failure label."
+          "message": "spec.md omits the Rejected outcome entirely. The accepted goal in .project/tickets/CAP100/ticket.md requires a builder to distinguish Pending, Approved, AND Rejected, with rejected reviews showing the actual blocking findings and permitting repair and retry. The plan's Accepted behavior section defines Pending and Approved only, and Scope and exclusions excludes only new approval authority and notifications, so Rejected is neither in-scope-defined nor excluded. Triggering condition: a completed review carrying blocking findings. Observable consequence: two reasonable implementations are permitted — one that renders a blocking-findings review as Rejected with its findings, and one that renders it as Pending (not finished approving) — and the second violates the accepted goal while satisfying every statement in this plan."
+        },
+        {
+          "severity": "error",
+          "message": "spec.md defines Approved as \"the review has an authenticated approval receipt\" with no currency binding to the current plan bytes. The accepted behavior in .project/tickets/CAP100/scenarios.md item 4 requires that after a plan is repaired a stale approval cannot approve it, and .project/principles.md makes the authenticated receipt the only approval authority. Triggering condition: a builder repairs a rejected plan whose prior revision carried a valid receipt. Observable consequence: an implementation honoring this plan's literal definition displays Approved for the edited plan, which falsely reports approval authority over bytes that were never approved — a trust-boundary failure against the sole accepted approval invariant."
         },
         {
           "severity": "error",
-          "message": "The observable done state — 'A builder can distinguish Pending from Approved' — is narrower than the accepted behavior it is supposed to make observable. It cannot detect the missing Rejected state, the required display of actual blocking findings (scenario 3), or the repair-and-retry path (scenario 4). This done state is non-discriminating proof: the claimed behavior can be entirely broken for rejected reviews while the stated done condition still holds. Restate the done state so it fails when any of the three statuses, the findings display, or retry after repair is absent."
+          "message": "spec.md states no contract for an interrupted review or for a finished nonblocking review that lacks a valid approval receipt. The ticket accepts that both conditions stay Pending, surface their actual error (the run error and the receipt error respectively), permit retry without changing plan bytes, and invent no rejection findings. Triggering condition: a review run that terminates early, or one that completes without blocking findings but produces no valid receipt. Observable consequence: because the plan constrains neither the displayed state, the error text, nor the prohibition on fabricated findings, an implementation may render either condition as Rejected with synthesized blocking findings — directly contradicting the accepted behavior — and still conform to this plan."
         },
         {
           "severity": "error",
-          "message": "'Approved means the review has an authenticated approval receipt' states no currency boundary, but accepted scenario 4 requires that after a plan is repaired, a stale approval cannot approve it. Without that condition in the accepted behavior, an implementation that checks only receipt authenticity — not whether the receipt corresponds to the current plan — would display Approved for a changed plan. That is a path that reports the accepted user-facing claim (this review is approved) as satisfied when it is not. Specify that Approved requires an authenticated approval receipt for the current plan, and that changing the plan returns it to a non-approved state."
+          "message": "The Observable done state in spec.md — \"A builder can distinguish Pending from Approved\" — is non-discriminating proof for the accepted goal. It is satisfiable by a two-state display, so the Rejected state, the actual-findings display, the repair-and-retry path, and the no-invented-findings constraint can all be broken while the plan's own done state still reports success. A done state that can pass while the accepted user-facing claim is false cannot gate scenario definition; it must enumerate the observable distinction for every accepted state including the error and recovery paths."
         },
         {
           "severity": "warning",
-          "message": "Scope and exclusions cover new approval authority and notifications, but the ticket also excludes any new storage system. Since the currency requirement above may imply persisting what a receipt was issued against, the plan should carry the ticket's storage exclusion forward explicitly so the boundary is not quietly expanded during design."
+          "message": "spec.md records no outcome inventory for the accepted Builder persona in .project/personas.md. Success (Approved) and one partial failure (Pending) are present, but refusal, failure, trust, and recovery outcomes are neither specified nor marked inapplicable with a specific reason. The product contract requires each consequential outcome per persona to be either defined or explicitly excused; silence leaves the absences indistinguishable from oversight."
+        },
+        {
+          "severity": "warning",
+          "message": "spec.md presents every statement as settled fact with no separation of known facts, assumptions, and unresolved product decisions. For example, \"Pending means the review has not finished\" is asserted without support and is in tension with the accepted behavior that a finished-but-unreceipted review is also Pending; whether that is a known definition or an unresolved product choice cannot be determined from the plan. Keep the three epistemic classes visibly distinct so reviewers can tell a supported fact from an open decision."
         },
         {
           "severity": "info",
-          "message": "The plan does not separate supported facts from assumptions and unresolved decisions as the Product Plan contract requires. Nothing in the current text appears to be an unstated assumption, but if the Rejected state or the approval-currency rule depends on behavior not yet confirmed in the CLI, record that distinction rather than presenting it as settled."
+          "message": "No prohibited content was found: spec.md contains no implementation design, no delivery task sequencing, and no claim that scenarios, downstream plans, or implementation are approved. Scope framing is consistent with .project/non-goals.md and .project/surfaces.md — the single affected surface is the existing CLI review-status command and no new approval authority, store, or notification channel is introduced. .project/tickets/CAP100/boundaries.md confirms no parent or milestone boundary is inherited, so binding context is present and review is not blocked on missing context."
+        },
+        {
+          "severity": "info",
+          "message": "No scenario-coverage verdict is issued. .project/tickets/CAP100/scenarios.md was read only as untrusted context to locate accepted product boundaries; scenario acceptance belongs to scenario review after Product approval, and this Product Plan is incomplete. Approval of a corrected plan would mean only that the behavior is ready for scenario definition — not scenario acceptance, design approval, startable delivery, or completion. Any change to the decision-bearing product boundaries above requires a fresh review of the changed bytes."
         }
       ]
     },
@@ -124,19 +156,35 @@
       "findings": [
         {
           "severity": "error",
-          "message": "spec.md omits the Rejected state entirely. The ticket's goal is that a builder can distinguish Pending, Approved, and Rejected, that Rejected reviews show the actual blocking findings, and that repair and retry are permitted; none of this appears in Accepted behavior or in Scope and exclusions, and Rejected is not listed as an exclusion either. The observable done state is narrowed to 'distinguish Pending from Approved', so an implementation that renders a completed review with blocking findings as Pending (not finished approving) or as an unlabelled terminal state would satisfy every stated criterion while the accepted user-facing claim — the builder can tell a rejected review from an unfinished one and see why — is false. Two reasonable implementations are permitted and one falsely reports the accepted behavior as met. Restore Rejected, the display of the actual blocking findings, and the repair/retry outcome to the accepted behavior and to the observable done state, or state explicitly and with justification that the user has excluded them."
+          "message": "spec.md omits the Rejected outcome entirely. The accepted goal in .project/tickets/CAP100/ticket.md requires the builder to distinguish Pending, Approved, AND Rejected, with Rejected showing the actual blocking findings. The Product Plan defines only Pending and Approved, so an implementation that never renders a Rejected state — collapsing blocking-findings reviews into Pending or Approved — would satisfy this plan while violating the accepted goal. This is an in-scope omission, not a reviewer-authored expansion."
+        },
+        {
+          "severity": "error",
+          "message": "The definition \"Pending means the review has not finished\" contradicts the accepted boundary and permits a false user-facing claim. The ticket states that a finished review without a valid approval receipt stays Pending with its actual receipt error and must not invent rejection findings. Under spec.md's definition that case is not Pending (it finished) and is not Approved (no receipt), so the behavior is undefined: one reasonable implementation displays Rejected with fabricated findings, which the accepted scope explicitly forbids. The Product Plan must define status by receipt validity, not by completion alone."
+        },
+        {
+          "severity": "error",
+          "message": "No failure or recovery outcomes are inventoried for the accepted Builder persona. .project/personas.md names the builder's need for actual rejection findings and a repair-and-retry path, and the ticket accepts that an interrupted review displays its actual error and permits retry without changing plan bytes. spec.md inventories only two success-adjacent outcomes and marks no outcome inapplicable with a reason, so error surfacing, retry, and repair-then-re-review are left to implementation choice. An implementation that silently shows a bare Pending with no error and no retry affordance would conform to this plan."
+        },
+        {
+          "severity": "error",
+          "message": "The observable done state is non-discriminating proof. \"A builder can distinguish Pending from Approved\" can be fully satisfied while Rejected display, actual-findings display, receipt-error surfacing, and retry are all broken. A done state that passes while the accepted user-facing claim (distinguish Pending, Approved, and Rejected with actual findings) is false cannot serve as the acceptance signal for this Product Plan."
         },
         {
           "severity": "error",
-          "message": "spec.md defines 'Approved means the review has an authenticated approval receipt' with no requirement that the receipt be current for the plan under review. The ticket preserves the existing authenticated approval receipt but the plan's own heading is 'Show current review status', and the plan nowhere binds a receipt to the reviewed plan revision. Under this wording an implementation that retains an approval receipt issued against a prior plan revision and continues to display Approved after the plan changes is conformant, which would present an unreviewed plan as approved to the builder. This is a trust-boundary failure in the accepted surface, not speculative hardening: the plan must state that Approved requires an authenticated approval receipt that is current for the plan revision being displayed, and that a superseded receipt does not display Approved."
+          "message": "The trust outcome that a stale approval cannot approve a repaired plan is absent. .project/principles.md makes authenticated receipts the only approval authority, and the accepted scope requires that after repair a new review is requested and a stale approval does not approve it. spec.md says only that \"Approved means the review has an authenticated approval receipt\" with no currency requirement, so an implementation that displays Approved from a receipt bound to superseded plan bytes conforms to this plan while reporting approval of work that was never approved."
         },
         {
           "severity": "warning",
-          "message": "spec.md does not separate supported facts from assumptions and unresolved decisions, which the Product Plan contract requires as distinct content. In particular the display treatment for a review whose approval has been superseded, and whether an in-flight retry after repair renders as Pending or as a distinct state, are left implicit rather than recorded as open product choices. This does not by itself permit a wrong shipped outcome once the two errors above are repaired, but the omissions should be recorded so scenario definition does not have to infer them."
+          "message": "spec.md does not keep known facts, assumptions, and unresolved product decisions visibly distinct. Every statement is presented as settled accepted behavior with no supporting basis cited and no unresolved-decision section, so a reader cannot tell which boundaries are confirmed by the ticket and which are the author's assumption. This is required Product Plan content, but on its own it does not permit materially different shipped behavior beyond the omissions already recorded as errors."
         },
         {
           "severity": "info",
-          "message": "Persona, surface, scope, and exclusions are stated and the exclusions ('New approval authority and notifications are excluded') match the ticket's exclusions. The plan correctly contains no implementation design, no delivery sequencing, and no claim that scenarios, downstream plans, or implementation are approved."
+          "message": "Scope and exclusions in spec.md correctly mirror .project/non-goals.md and the ticket's exclusion of new approval authority and notifications, and the plan contains no implementation design or delivery sequencing, so the prohibited-content boundary is clean. Persona and surface naming is minimal but consistent with .project/personas.md and .project/surfaces.md."
+        },
+        {
+          "severity": "info",
+          "message": "No scenario-coverage verdict is issued here. .project/tickets/CAP100/scenarios.md is untrusted supporting context used only to confirm the accepted product boundary; scenario acceptance belongs to scenario review after Product approval, and this Product Plan is incomplete regardless."
         }
       ]
     },
@@ -147,19 +195,19 @@
       "findings": [
         {
           "severity": "warning",
-          "message": "Contract coherence: the CLI status contract is declared as \"exactly Pending, Approved, and Rejected,\" but failure behavior introduces a fourth outcome — \"a failed status read reports unavailable state.\" The plan does not decide whether unavailable is a distinct displayed value or is folded into Pending with an error detail. This is not an error because every reasonable reading of the sentence forbids reporting Approved on a failed read, so the accepted user-facing claim (a missing or stale receipt cannot appear as approval) cannot be falsely satisfied either way. Still, Execution Planning would otherwise be choosing a user-visible status vocabulary that Implementation Planning owns; name the read-failure outcome explicitly in the status contract."
+          "message": "Status contract edge: the plan declares the CLI status contract has \"exactly Pending, Approved, and Rejected\", then states that a failed status read \"reports unavailable state rather than inventing approval\". Two reasonable implementations follow — a fourth display state, or Pending carrying the read error. Non-blocking because a coordinator/status read failure is not an accepted scenario in spec.md or scenarios.md, and both readings preserve the accepted claim that no failure path may display Approved. Worth tightening the wording before Execution Planning so the display state for an unreadable coordinator is unambiguous."
         },
         {
           "severity": "warning",
-          "message": "Concurrency surface: the plan decides that \"only the job currently bound to the plan may drive the displayed status\" and that concurrent retries may finish in any order, which correctly prevents a stale or losing job from supplying Approved. It does not state what the builder sees for the losing retry — whether it is silently ignored, shown as superseded, or surfaced on the next status read. The persona's recovery need (repair and retry) is still covered by the binding rule, and no outcome here can show a false Approved, so this is non-blocking; adding the losing-retry display consequence would close the last observable gap in the retry path."
+          "message": "Proof coverage of plan-introduced concurrency depth: the plan decides atomic retry binding, out-of-order concurrent retry completion, and crash-before-binding behavior, but the named proof enumerates the six accepted scenarios plus stale receipt, interrupted retry, and receipt-missing retry — no proof is named for the concurrent or crash boundary specifically. Non-blocking because those conditions are depth the plan added beyond the accepted scenarios, and the accepted stale-approval claim (scenario 4) does have discriminating proof via the stale-receipt case. Consider naming the cheapest sufficient proof for the crash-before-binding path, since its stated guarantee (prior terminal state stays visible, never falsely Approved) is otherwise asserted rather than demonstrated."
         },
         {
           "severity": "info",
-          "message": "Proof strategy stays inside the Implementation Planning boundary: it names the behavior, the real CLI-and-coordinator boundary, the proof type, and an explicit confidence limit (an isolated mapper test cannot prove public wiring), with no test paths or commands leaking in from Execution Planning. The stale-receipt and actual-rejection-findings cases are discriminating rather than ceremonial — a mapper that synthesized rejection text or honored a prior receipt would fail them."
+          "message": "Focused reviewability: pass. Architecture-at-a-glance is present and load-bearing; decision-bearing contracts, operational risk, and failure behavior all sit in the main review path; no obscuring detail (coding steps, repeated test evidence, migration commands) was found to name for removal."
         },
         {
           "severity": "info",
-          "message": "Applicability skips are justified rather than bare: the Data skip enumerates the subjects it disclaims (store, schema, ownership, retention, migration, cross-system flow) and is consistent with the plan creating no second store, and the Measurement skip is grounded in the Product Plan's stated absence of a quantitative target. The no-durable-architecture-record judgment matches the significance rule — this is a reversible feature-local presentation change that adds no shared API and moves no data owner."
+          "message": "Plan-state truthfulness: all content is correctly labeled as proposed approach. No implemented fact, no available-proof claim, and no claim of human approval is asserted; the retry model explicitly demotes prior rejections and receipts to historical evidence rather than current authority, which matches principles.md."
         }
       ]
     },
@@ -169,24 +217,24 @@
       "verdict": "approve",
       "findings": [
         {
-          "severity": "warning",
-          "message": "Internal inconsistency in the declared status contract. The plan states \"The CLI status contract has exactly Pending, Approved, and Rejected\" and then, one sentence later, \"A failed status read reports unavailable state rather than inventing approval.\" Unavailable is a fourth user-visible outcome that the enumerated contract excludes. This is not an error because the safe direction is preserved (a read failure cannot produce Approved, and the Product Plan's done state is not violated), but two reasonable implementations follow from the text as written: one surfaces a distinct unavailable state, another collapses read failure into Pending. Those differ for the builder, who in the collapsed case sees Pending for a review that may already be terminal. Owner: Implementation Planning. Resolve by either enumerating unavailable in the contract or stating explicitly that read failure presents as Pending with its actual error state, consistent with the earlier 'running or interrupted review' decision."
+          "severity": "info",
+          "message": "Focused reviewability: PASS. The plan opens with an architecture-at-a-glance mental model, keeps every load-bearing decision (authority source, job/digest binding, concurrency and crash boundary, failure-path display, proof boundary) in the main review path, and contains no step-by-step coding instructions, no repeated test evidence, and no verification ledger detail. No removable obscuring detail identified; the deletion test finds no text removable without information loss."
         },
         {
           "severity": "warning",
-          "message": "Project principles are neither named nor dismissed in the plan, and the configured principles file was not supplied in this packet, so I could not verify whether an applicable principle was missed. The rubric requires challenging whether the plan identified the actually applicable principles using that supplied file; with the file absent I can only record the gap. Owner: whoever assembles the review packet. One action that resumes this check: supply the configured principles file alongside spec.md so the principle-to-consequence-to-proof chain can be verified."
+          "message": "Status contract wording is internally inconsistent: 'The CLI status contract has exactly Pending, Approved, and Rejected' is immediately followed by 'A failed status read reports unavailable state rather than inventing approval.' Both readings (a fourth displayed state vs. Pending plus an unavailability error) are safe with respect to the accepted claim — neither can display Approved — so this does not block, but the plan should state which of the three accepted values a failed read resolves to, or declare unavailability as an error channel outside the status enum. Owner: plan author."
         },
         {
           "severity": "warning",
-          "message": "The configured personas file and surfaces file were not supplied in this packet. I resolved the persona (the builder requesting a plan review) and surface (the CLI review status display) from spec.md only, and against that source the coverage is complete: trust (stale receipt cannot approve), operation (three current outcomes), approval (existing authenticated receipt is sole source), and recovery (repair and retry with the old rejection demoted to history), each with a named design consequence and a stated confidence limit on the integration proof. If the configured files enumerate any additional persona or surface for this ticket, that coverage is unverified here."
+          "message": "Plan-state labeling for the coordinator's retry binding is ambiguous. 'The coordinator atomically binds each retry to its new job identifier and plan digest' is written in present tense as an implemented fact, but the plan nowhere distinguishes whether this binding already exists or is a proposed coordinator change. If it is proposed, the approach depends on work beyond the CLI presentation mapper described in the architecture-at-a-glance section, which affects sequencing in Execution Planning. The safety property ('never falsely Approved') holds under either reading, so this is non-blocking; label the binding as implemented fact or proposed decision. Owner: plan author."
         },
         {
           "severity": "info",
-          "message": "Load-bearing risk ordering is correct: the plan leads with job-identifier and plan-digest binding, which is the mechanism that carries the ticket's central trust claim, rather than with presentation mechanics. The 'no load-bearing external library choice' skip does not contradict the plan's own load-bearing choice, because the one significant choice (read existing trusted coordinator records versus persist a separate CLI status) is recorded with its rejected alternative and the reason it lost, and it introduces no third-party dependency requiring version, license, or security evidence."
+          "message": "Decision-evidence skip accepted: 'No load-bearing external library choice is needed' does not contradict the plan's own load-bearing choices, which are internal (read trusted coordinator state via a presentation mapper vs. persist a separate CLI status). That internal choice does carry a credible alternative and a stated reason the alternative lost, so the external-evidence skip is justified rather than evasive. No third-party source, version baseline, license, or security boundary is relied upon, hence no evidence records are returned."
         },
         {
           "severity": "info",
-          "message": "The judgment that no durable architecture record is needed holds under the significance test applied to behavioral consequences rather than file count: no shared API, data owner, or migration compatibility change occurs, the coordinator record and CLI exit codes are explicitly unchanged, the added Rejected label is additive, and the mapper is a reversible feature-local presentation choice."
+          "message": "Persona and surface coverage resolves fully: the single accepted Builder persona's trust need (authenticated receipt as sole approval authority), operation need (current status display), approval need (binding to current job and plan bytes), and recovery need (repair-and-retry after Rejected; retry without byte changes after interruption or receipt failure) each have a named design consequence, and the sole affected surface (the existing CLI review-status command) carries a real-boundary integration proof with an explicit confidence limit."
         }
       ]
     },
@@ -197,15 +245,19 @@
       "findings": [
         {
           "severity": "warning",
-          "message": "Status contract enumerates exactly Pending, Approved, and Rejected, but failure behavior adds a fourth observable outcome: \"A failed status read reports unavailable state rather than inventing approval.\" The plan does not say whether unavailable is rendered as Pending or as an out-of-band message distinct from the three values, so two reasonable implementations exist. This is a warning rather than an error because both readings satisfy the accepted user-facing claim — neither can display Approved without a current authenticated receipt — so no path reports the accepted claim falsely. Naming which of the two the mapper produces would close the gap without widening scope."
+          "message": "Status contract vs. unavailable read: the plan states the CLI status contract has \"exactly Pending, Approved, and Rejected\" and separately that \"a failed status read reports unavailable state rather than inventing approval.\" A failed read of coordinator state is not one of the six accepted scenarios, and the plan leaves two reasonable renderings open — a fourth non-enumerated display value, or Pending carrying the read error in the pattern already decided for interruption and missing receipt. Neither rendering can produce a false Approved, so this is nonblocking, but naming which one the mapper emits would remove the ambiguity before Execution Planning sequences it."
+        },
+        {
+          "severity": "warning",
+          "message": "Retry-binding evidence is decided but its observability is not: the plan decides that the coordinator atomically binds each retry to a new job identifier and plan digest, and that concurrent retries may land in any order with only the plan-bound job driving display. The proof strategy asserts \"a working retry that binds a new current job without changing plan bytes\" for the two failure cases, but does not state how the concurrent-ordering decision is exercised or acknowledge it as an untested confidence limit. Since the losing concurrent retry is non-authoritative by construction rather than by a named check, this is a proof-coverage gap worth closing rather than a demonstrated path to a false Approved."
         },
         {
           "severity": "info",
-          "message": "Persona coverage is complete for the single accepted persona (the builder requesting a plan review): trust is bound by job identifier and plan digest, operation and approval by the authenticated receipt as sole Approved source, and recovery by the retry path that creates a new review for repaired bytes while prior rejections stay historical evidence. The Product Plan's out-of-scope never-requested display state is correctly left unaddressed rather than silently designed."
+          "message": "Decision-evidence skip is consistent with the plan's own content: the stated \"No load-bearing external library choice is needed\" does not contradict the load-bearing choices actually made, since every one of them (authority source, binding key, mapper placement, retry semantics) is internal design over existing coordinator records. The one credible alternative considered — persisting a separate CLI status store — is recorded with a concrete reason it lost (loss of synchronization after retry or plan edit) and aligns with the project non-goal barring a new status store."
         },
         {
           "severity": "info",
-          "message": "Plan-state truthfulness holds: every statement is phrased as a proposed decision or a stated existing constraint (the coordinator's receipt and job records), with no implemented-fact, proof-obtained, or downstream-approval claims asserted. Approval here establishes readiness for Execution Planning only and does not approve delivery sequencing, coding, verification, merge, or deployment."
+          "message": "Plan-state truthfulness holds: all behavior is stated as proposed decision rather than implemented fact, and the plan claims no downstream approval, no verification result, and no delivery sequencing. Approval here covers the approach only and does not establish Execution Planning, coding, verification, merge, or deployment."
         }
       ]
     },
@@ -216,15 +268,15 @@
       "findings": [
         {
           "severity": "error",
-          "message": "Approach decision contradicts accepted product behavior and permits false approval. impl-plan.md states \"The reviewer output verdict is enough to display Approved, even before an authenticated approval receipt exists.\" The accepted Product Plan states \"Approved means the current review has an authenticated approval receipt\" and \"A missing or stale receipt cannot appear as approval\"; the ticket states \"Approval still requires the existing authenticated approval receipt.\" The plan also contradicts itself: its contract paragraph says \"Missing or stale receipt means no approval,\" and its Pending decision says an interrupted review without a terminal receipt never displays Approved. Two reasonable implementations follow from these conflicting statements, and one displays Approved for a review with no authenticated receipt — falsely reporting the accepted user-facing claim as satisfied, and effectively creating a second approval authority the ticket excludes. The named proof (\"a stale receipt and actual rejection findings\") does not discriminate here: an implementation that approves on verdict alone can still pass a stale-receipt case, because the stale-receipt case tests receipt binding rather than receipt presence. Missing/incorrect decision: the single authority for Approved. Accepted decision owner: the user, via the already-accepted spec — this is not an open product choice, so the plan must conform rather than the user re-deciding. Consequence of leaving it unresolved: the CLI can display Approved for a plan that was never authenticated, defeating the ticket's core guarantee. Action that resumes review: remove the verdict-suffices decision, state that Approved requires a current authenticated approval receipt bound to the current job identifier and plan digest, and add a proof case where a terminal approve verdict exists with no receipt and the display must remain Pending."
+          "message": "impl-plan.md, Approach decisions bullet 2: \"The reviewer output verdict is enough to display Approved, even before an authenticated approval receipt exists.\" This contradicts the accepted Product Plan (\"Approved means the current review has an authenticated approval receipt\"; \"only the authenticated receipt for the current job and plan bytes can display Approved\"), the project principle (\"Existing authenticated receipts remain the only approval authority\"), ticket scope (\"Approval still requires the existing authenticated approval receipt\"), and non-goals (\"No new approval authority\"). It also directly contradicts the plan's own later bullet, which says a finished nonblocking review without a valid approval receipt displays Pending with the actual receipt error. Missing/incorrect decision: which single artifact authorizes the Approved display. Accepted decision owner: the user, via spec.md and principles.md — both already decide it is the authenticated receipt, so the plan, not the ticket, is wrong. Consequence of leaving it unresolved: an implementer may reasonably read bullet 2 as authoritative and display Approved on reviewer verdict alone, making accepted scenario 6 fail and letting an unapproved plan be reported as approved — a false user-facing approval claim. Because the two bullets conflict, a conforming implementation and a violating one both satisfy the plan text, and the named proof (\"assert Pending, the actual error, no invented rejection findings\" for the receipt-missing case) cannot discriminate if bullet 2 is the implemented reading. Repair: delete or correct bullet 2 so a reviewer nonblocking verdict without a valid authenticated receipt for the current job and plan digest yields Pending, never Approved."
         },
         {
           "severity": "warning",
-          "message": "The contract paragraph declares \"exactly Pending, Approved, and Rejected\" but then says a failed status read \"reports unavailable state,\" which is a fourth displayed outcome not present in the accepted three-status contract. The direction is safe (it never fabricates approval), so this is non-blocking, but the plan should either name unavailable as an explicit fourth display state with its user-visible consequence or state that read failure surfaces as Pending with an error detail. The same ambiguity appears in \"displays Pending with its actual error state,\" which does not say whether the error detail is part of the status value or adjacent output."
+          "message": "impl-plan.md: \"Known deviations: none.\" If bullet 2 were an intentional conflict with the accepted approval authority it would belong in Known deviations with a reason; as written the plan asserts no deviation while stating one. Resolving the error above should also keep this statement accurate rather than adding a deviation entry, since the non-goals exclude new approval authority."
         },
         {
-          "severity": "warning",
-          "message": "Architecture applicability names the CLI-to-coordinator contract as affected yet concludes no durable architecture record is needed, justified only as \"a reversible local presentation change.\" The reasoning is credible for a presentation mapper, but the plan does not say whether the CLI status vocabulary itself is a consumed contract (for example by scripts keying on output). If it is, the additive Rejected label is a compatibility-relevant shared-contract change rather than a purely local one. The plan already asserts exit codes are unchanged, which likely contains the blast radius; a one-line statement that no machine-readable consumer keys on the human-readable status label would close this."
+          "severity": "info",
+          "message": "impl-plan.md: the confidence limit is stated once (\"An isolated mapper test cannot prove the public wiring; the CLI integration proof has that limit\") and covers the single affected surface and the Builder persona's needs. No additional surface or persona is left without proof or a justified skip."
         }
       ]
     },
@@ -235,15 +287,19 @@
       "findings": [
         {
           "severity": "error",
-          "message": "Approach decision creates approval authority the user did not accept. The plan states \"The reviewer output verdict is enough to display Approved, even before an authenticated approval receipt exists.\" The accepted Product Plan defines Approved as \"the current review has an authenticated approval receipt,\" and the ticket scope says \"Approval still requires the existing authenticated approval receipt. No new approval authority ... is in scope.\" Triggering condition: a reviewer completes with a non-blocking verdict and no authenticated receipt has been issued. Observable consequence: the CLI displays Approved, so scenario 2 and the invariant \"A missing or stale receipt cannot appear as approval\" are both violated while the feature reports success — independent review is presented as human approval. This also contradicts the plan's own later sentence \"Missing or stale receipt means no approval,\" so two reasonable implementations exist and one falsely reports the accepted user-facing claim. Decision owner: the user (accepted scope). Repair: delete this decision and state that Approved requires the current authenticated approval receipt bound to the current job identifier and plan digest; a terminal reviewer verdict without that receipt displays Pending. Resuming action: restate the Approved precondition in impl-plan.md as receipt-bound and resubmit for approach review."
+          "message": "impl-plan.md, Approach decisions: \"The reviewer output verdict is enough to display Approved, even before an authenticated approval receipt exists.\" This contradicts the accepted Product Plan (\"Approved means the current review has an authenticated approval receipt\"; \"only the authenticated receipt for the current job and plan bytes can display Approved\"), project principles (\"Existing authenticated receipts remain the only approval authority\"), and accepted scenario 6 (finished nonblocking review without a valid receipt displays Pending). It also directly contradicts the plan's own later bullet, which states a finished nonblocking review without a valid approval receipt displays Pending with the actual receipt error. Two reasonable implementations follow from this plan, and one displays Approved for a review with no authenticated receipt — a false user-facing approval claim and a trust-boundary failure, since the verdict is reviewer output rather than the accepted approval authority. Missing/incorrect decision: which single artifact authorizes the Approved label. Decision owner: the user, via the accepted Product Plan and principles, which already resolve it in favor of the authenticated receipt. Consequence of leaving it unresolved: a builder can be shown Approved for an unapproved plan. Repair: delete or correct the verdict-is-enough bullet so the authenticated receipt bound to the current job and plan digest is the sole Approved condition, and confirm the proof for scenarios 2 and 6 discriminates verdict-only state from receipt-backed state."
         },
         {
           "severity": "warning",
-          "message": "The status contract is declared as \"exactly Pending, Approved, and Rejected,\" but failure behavior says \"A failed status read reports unavailable state rather than inventing approval.\" The plan does not decide whether unavailable is a fourth displayed value, a mapping onto Pending, or a non-zero-exit error path. It cannot produce a false Approved, so it is non-blocking, but two implementations differ visibly to the builder; name the resolved representation in the contract section."
+          "message": "impl-plan.md records one credible alternative (persisting a separate CLI status) and closes with \"No load-bearing external library choice is needed.\" The atomic retry binding of job identifier and plan digest under concurrent retries is a load-bearing choice with no recorded alternative or losing rationale (for example, last-writer-wins on completion versus binding-wins). The chosen behavior is stated clearly enough to sequence delivery, so this is non-blocking, but recording why the rejected alternative lost would close the decision-quality gap."
+        },
+        {
+          "severity": "warning",
+          "message": "impl-plan.md names a single confidence limit (\"An isolated mapper test cannot prove the public wiring; the CLI integration proof has that limit\"). The concurrent-retry ordering decision — only the job currently bound to the plan may drive the displayed status — has no stated proof approach or confidence limit, so an interleaving where a losing concurrent retry drives the display could ship unproven. Naming the real boundary for that case, or stating explicitly that it is not proven, would make the proof strategy discriminating."
         },
         {
           "severity": "info",
-          "message": "Proof coverage is stated as a single sentence spanning all accepted scenarios plus a real CLI/coordinator wiring proof with a named confidence limit, which satisfies the proof-strategy boundary. Naming the real boundary per scenario — specifically the stale-receipt case in scenario 4 — would make the non-discriminating-proof risk easier to rule out without adding execution detail."
+          "message": "Persona (Builder), the single affected surface (CLI review-status command), data applicability skip, measurement applicability skip, architecture applicability with a concrete CLI-to-coordinator consequence, rollout/rollback, doc impact, and the non-goals boundary (no new approval authority, store, or notification channel) are each addressed at review depth. The Approach proof strategy correctly contains no test paths or commands."
         }
       ]
     },
@@ -254,36 +310,24 @@
       "findings": [
         {
           "severity": "error",
-          "message": "Contradictory and scope-violating approval contract. Approach decisions state \"The reviewer output verdict is enough to display Approved, even before an authenticated approval receipt exists,\" while the contracts section states \"Missing or stale receipt means no approval.\" Two reasonable implementations satisfy this plan, and one displays Approved for a review with no authenticated receipt. That outcome violates the accepted spec (\"Approved means the current review has an authenticated approval receipt\"), the ticket constraint (\"Approval still requires the existing authenticated approval receipt\"), and the observable done state (\"A missing or stale receipt cannot appear as approval\"), and it creates the new approval authority the ticket excludes. Missing/incorrect decision: which single artifact authorizes the Approved label. Decision owner: the user, via the accepted Product Plan, which has already decided it is the authenticated receipt — the plan author must conform, not re-decide. Consequence if unresolved: the CLI can report a plan as Approved when no human approval authority exists, which is the exact trust failure this ticket was written to prevent. Resuming action: delete the reviewer-verdict-is-enough decision and state that Approved requires the current job's authenticated approval receipt bound to the current plan digest, with scenario 2 proved across the real CLI-plus-coordinator boundary using a review that has a reviewer verdict but no receipt."
+          "message": "Approach decision creates a second approval authority and contradicts accepted behavior. impl-plan.md states: \"The reviewer output verdict is enough to display Approved, even before an authenticated approval receipt exists.\" The authoritative sources decide otherwise: the ticket says \"Approval still requires the existing authenticated approval receipt\" and \"No new approval authority ... is in scope\"; spec.md says \"Approved means the current review has an authenticated approval receipt\" and \"only the authenticated receipt for the current job and plan bytes can display Approved\"; principles.md says \"Existing authenticated receipts remain the only approval authority\"; non-goals.md excludes new approval authority; and scenario 6 requires a finished nonblocking review without a valid receipt to display Pending. Triggering condition: a review finishes with a nonblocking reviewer verdict and no valid receipt (receipt write fails, receipt is stale, or receipt binding to the current job/plan digest has not yet occurred). Observable consequence: the CLI displays Approved for an unapproved plan, so the user-facing approval claim is false and the accepted trust boundary is breached. The plan is also internally contradictory here: the same document states \"Missing or stale receipt means no approval\" and \"A finished nonblocking review without a valid approval receipt displays Pending with the actual receipt error.\" Because both readings are present, two reasonable implementations exist and one falsely reports approval. Decision owner: this is settled accepted scope owned by the user and already decided against the bullet, so no user choice is needed — remove the reviewer-verdict-is-enough bullet and state that Approved requires an authenticated approval receipt bound to the current job identifier and current plan digest, with the reviewer verdict as a necessary but insufficient input. Resuming action: correct that bullet in impl-plan.md and resubmit the changed bytes for fresh approach review."
         },
         {
           "severity": "warning",
-          "message": "Asserted concurrency and crash invariants have no matching proof. The plan claims the coordinator \"atomically binds each retry to its new job identifier and plan digest,\" that only the currently bound job may drive the display under out-of-order concurrent retries, and that a crash before binding leaves the prior terminal state visible and never falsely Approved. The proof strategy only names per-scenario CLI-and-coordinator exercises including a stale receipt and actual findings; nothing discriminates the interleaved-retry or pre-binding-crash paths, so those invariants could be broken while every named check passes. Either name a proof that orders two retries and one that interrupts before binding, or state these as confidence limits rather than established behavior."
+          "message": "Proof strategy does not name a discriminating check for the corrected Approved rule. The proof paragraph lists assertions for the two Pending failure cases (actual error, no invented findings, working retry) but for Approved only says the six scenarios are exercised through the real CLI and coordinator boundary. Once the blocking finding is repaired, add an explicit negative assertion that a finished nonblocking verdict with no valid receipt, and a receipt bound to a different job identifier or plan digest, each fail to display Approved; otherwise a regression reintroducing verdict-based approval could pass every named check."
         },
         {
           "severity": "info",
-          "message": "Plan-state labeling is uniformly proposed-tense with no implemented-fact or independent-review claims, and the durable-record skip is justified as a reversible local presentation change, which is consistent with the reversibility standard. Data, Measurement, Architecture applicability, doc impact, deviations, and the reassessment trigger are each present with concrete reasons, and the deletion test finds little removable text."
+          "message": "Non-blocking observations: the Data, Measurement, and Architecture applicability statements each carry a concrete reason rather than a bare skip; the retry/concurrency bullet supplies the atomicity boundary, crash boundary, and preserved-evidence model required for concurrent state transitions; and the plan contains no execution task ordering, test paths, or commands. The single recorded alternative (persisting a separate CLI status) states why it lost, and the no-load-bearing-library skip is consistent with a local presentation mapper."
         }
       ]
     },
     {
       "fixture_id": "execution-approve",
       "run": 1,
-      "verdict": "approve",
-      "findings": [
-        {
-          "severity": "warning",
-          "message": "The documentation obligation (status-9, 'Update CLI status help text for all three states') resolves to the same cli-status-integration proof, but the step list only says to 'update CLI help text and rerun the integration proof' without naming an assertion on the help-text output. The slice completion signal does require that the help text name all three states, so the obligation is owned and signalled; still, the integration fixture should carry an explicit help-text assertion so this obligation is discriminating rather than resting on inference. This is an execution mechanic inside the unchanged accepted proof boundary and is non-blocking."
-        },
-        {
-          "severity": "info",
-          "message": "The accepted Implementation Plan records data applicability as skip (no store, schema, retention, or migration change), while the checklist retains status-5 for coordinator storage and CLI exit-code compatibility. Keeping that item matches the accepted compatibility statement and is not a scope expansion."
-        },
-        {
-          "severity": "info",
-          "message": "This approval covers only the Execution Planning phase decision: it authorizes the bounded delivery of Slice 1 and does not establish implementation, verification, merge, promotion, or deployment completion. The plan states this and keeps contributor work separate from any later human merge authority (status-10)."
-        }
-      ]
+      "verdict": "invalid",
+      "findings": [],
+      "failure": "review_failed"
     },
     {
       "fixture_id": "execution-approve",
@@ -292,11 +336,15 @@
       "findings": [
         {
           "severity": "info",
-          "message": "Decision statuses and the obligation owner are recorded as a closing prose sentence rather than a table. The content is complete and readable (all seven accepted decisions named as unchanged, Slice 1 named as owner), so this is a presentation note only."
+          "message": "Slice 1's completion signal cites \"all six accepted scenarios\" by reference rather than enumerating them. This resolves against the supplied scenarios.md and the slice body, which names the stale-receipt, verbatim-rejection, interrupted-retry, receipt-missing-retry, concurrent non-current-job, and failed-read cases explicitly, so the reference is checkable and non-blocking."
         },
         {
           "severity": "info",
-          "message": "Scenarios 1 and 2 (Pending for an unfinished current review, Approved for a current authenticated receipt) are covered by the completion signal's 'all four accepted scenarios' plus the receipt-bound assertions, but are less explicitly enumerated in the step narrative than scenarios 3 and 4. Non-blocking."
+          "message": "Scenarios 1 and 2 (running review shows Pending; current authenticated receipt shows Approved) are carried by the accepted-scenario reference and obligations status-1/status-2 rather than by their own named assertion in the RED narrative. The integration proof boundary includes the authenticated receipt, so coverage is adequate; naming both assertions explicitly in the fixture description would be an improvement, not a requirement."
+        },
+        {
+          "severity": "warning",
+          "message": "All eleven checklist obligations map to the same single proof (cli-status-integration). That proof exercises the real CLI-to-coordinator boundary and the plan names discriminating assertions (exit-code baseline, byte-identical coordinator records, no invented rejection findings), so it is not non-discriminating. Still, a single fixture carrying rollout, documentation, and compatibility obligations concentrates risk: a fixture edit that drops one assertion silently weakens several obligations at once."
         }
       ]
     },
@@ -307,11 +355,11 @@
       "findings": [
         {
           "severity": "info",
-          "message": "The plan correctly records the accepted Implementation Plan's stated proof limit (an isolated mapper test cannot prove public wiring) by routing every obligation through the CLI integration boundary rather than a unit-level substitute."
+          "message": "The slicing decision and the decision-status and obligation-owner entries are expressed in prose rather than as labeled fields. The prose is unambiguous and resolvable to the accepted Implementation Plan's decision bullets, so this is non-blocking, but a labeled form would reduce ambiguity on future revisions."
         },
         {
           "severity": "info",
-          "message": "Data and measurement categories were recorded as inapplicable by the accepted Implementation Plan; the execution checklist correspondingly carries compatibility (status-5) rather than inventing placeholder migration or measurement tasks. This is consistent with the accepted scope and is not a coverage gap."
+          "message": "Slice 1 includes assertions on unchanged CLI process exit codes and byte-identical coordinator records. These trace to the accepted Implementation Plan's compatibility statement rather than adding scope, and are correctly bound to checklist item status-5."
         }
       ]
     },
@@ -322,23 +370,27 @@
       "findings": [
         {
           "severity": "error",
-          "message": "Slice 1's completion signal covers only two accepted states: \"Pending and Approved pass through the CLI entry point and the status help text names those two states.\" Accepted scenarios 3 (Rejected displays the actual blocking findings) and 4 (repair and retry; a stale approval cannot approve the new review) have no completion signal in any slice. A contributor can satisfy every stated signal while Rejected and retry behavior is absent, so accepted behavior obligations status-1, status-7 and status-9 are only partially mapped."
+          "message": "Slice 1 completion signal is under-scoped against accepted behavior: it states completion as \"Pending and Approved pass through the CLI entry point and the status help text names those two states.\" Accepted scenarios 3-6 and the Product Plan require Rejected with the actual recorded findings, a stale receipt that never displays Approved, an interrupted review displaying Pending with its actual error and retry, and a finished nonblocking review without a valid receipt displaying Pending with its actual receipt error and retry. Under this completion signal the slice can be signed off with Rejected and both failure paths absent, so the accepted user-facing claim (a builder can distinguish all three current outcomes) would be reported satisfied while false. Restate completion so every accepted scenario passes through the CLI boundary after the final edit."
         },
         {
           "severity": "error",
-          "message": "The supplied proof is non-discriminating. The only proof, cli-status-integration, is described as \"The integration fixture covers Pending and Approved states.\" Checklist status-4 claims it will \"Prove all four accepted scenarios through the CLI and coordinator\" and status-7 claims it will \"Reject stale or missing approval receipts and preserve actual findings,\" but the named command (bun run test tests/integration/review-status.test.ts in packages/cli) as scoped cannot fail when a stale receipt displays Approved or when recorded rejection findings are synthesized or hidden. The Implementation Plan's accepted invariant that a missing or stale receipt never appears as approval can be broken while the single named check still passes. Enumerate per-scenario fixture cases — Pending, Approved, terminal Rejected with verbatim recorded findings, and retry where the prior job's receipt does not approve the new plan digest — and state each expected assertion."
+          "message": "The supplied proof is non-discriminating. The only proof, cli-status-integration (packages/cli, bun run test tests/integration/review-status.test.ts), is described in the slice as \"The integration fixture covers Pending and Approved states.\" Yet checklist items status-1, status-4, status-7, and status-9 map to that same proof for Rejected findings, all six scenarios, stale/missing-receipt rejection, and three-state help text. Rejected rendering, stale-receipt handling, interrupted retry, and receipt-missing retry can all be broken or absent while this command exits 0. Specify the fixture cases (or additional proofs) that exercise each accepted scenario at the real CLI-and-coordinator boundary."
         },
         {
           "severity": "error",
-          "message": "The first RED step is not startable for the full accepted behavior. It names the fixture, the command, and a pre-edit failure observation, but its stated failure signal is only \"the missing Pending/Approved assertions fail.\" The highest-risk accepted behavior is the stale-receipt approval boundary, not the Pending/Approved happy path. The RED step must name the stale-receipt and Rejected-findings assertions and their expected failure signal before any production edit, or the implementer invents that proof boundary coverage."
+          "message": "Startable steps leave required work for the implementer to invent. The step sequence names only the Pending/Approved fixture, the mapper and CLI wiring, and the help-text edit; no step names the action, fixture, or expected assertion for rejection findings passed through verbatim, for the current-job-and-plan-digest binding that blocks a stale receipt, or for the retry path that binds a new job without changing plan bytes. These are settled by the accepted Implementation Plan, so they are execution omissions, not new design, but they must appear as named steps with observable expected results."
+        },
+        {
+          "severity": "error",
+          "message": "Decision-status coverage is incomplete. The plan records one status line (\"the Implementation Plan's existing coordinator/receipt source of truth is unchanged\"). The accepted Implementation Plan records further load-bearing decisions that this sequence must carry as unchanged: current-job-identifier and plan-digest binding of the display, verbatim pass-through of recorded rejection findings, retry semantics for repaired and unchanged bytes, atomic retry binding under concurrent retries with a crash leaving the prior terminal state visible, running/interrupted displaying Pending, and finished-without-receipt displaying Pending with the actual receipt error. Account for each with an explicit unchanged status."
         },
         {
           "severity": "warning",
-          "message": "Internal contradiction in documentation scope: checklist status-9 requires \"Update CLI status help text for all three states,\" while Slice 1's completion signal requires the help text to name only \"those two states.\" Resolve to the three accepted statuses."
+          "message": "Checklist dispositions are internally inconsistent with the slice text: status-4 claims all six accepted scenarios and status-9 claims help text for all three states, while the slice body commits to two states. Resolving the errors above should also reconcile these rows rather than leaving the contradiction for the implementer to arbitrate."
         },
         {
           "severity": "info",
-          "message": "The slicing decision (one_pull_request, one slice, relies_on_unmerged_successor false), the prerequisite list, the proof-specification table placement before the checklist, and the decision-status note that the coordinator/receipt source of truth is unchanged are all acceptable as written; no accepted decision is reopened and no product scope is expanded. Only proof coverage and completion signals block approval."
+          "message": "The slicing decision, rationale, single-slice count, explicit empty prerequisite list, relies_on_unmerged_successor: false, proof table placement before the Delivery Checklist, and the versioned checklist header with all eleven default categories and unique IDs are all present and acceptable. No reopened design decision or out-of-scope addition was found; the repair is confined to Execution Planning."
         }
       ]
     },
@@ -349,27 +401,23 @@
       "findings": [
         {
           "severity": "error",
-          "message": "Non-discriminating proof for accepted scenarios 3 and 4. Slice 1 states \"The integration fixture covers Pending and Approved states\" and its completion signal is \"Pending and Approved pass through the CLI entry point.\" The only proof, cli-status-integration, is therefore specified to exercise two of the four accepted scenarios. Checklist items status-1, status-4, and status-7 claim Rejected with actual blocking findings, retry after repair, and rejection of stale or missing receipts, all resolving to that same proof. As written, an implementation that never renders Rejected, synthesizes rejection text instead of passing the coordinator's recorded findings verbatim, or lets a stale receipt display Approved would still satisfy every named check and the stated completion signal. Extend the fixture and completion signal to exercise a terminal rejected job with its recorded findings and a retry where a receipt bound to a different job identifier or different plan digest does not yield Approved."
+          "message": "Slice 1 completion signal is incomplete against accepted scope: it requires only that \"Pending and Approved pass through the CLI entry point and the status help text names those two states.\" Accepted scenarios 3-6 (Rejected with the actual blocking findings, stale receipt not granting Approved, interrupted review Pending with actual error and retry, finished nonblocking review without a valid receipt Pending with actual receipt error and no invented findings) are not part of any completion condition. An implementer can satisfy the stated signal while Rejected is never displayed and a stale receipt displays Approved, which violates the ticket goal and the principle that the authenticated receipt is the only approval authority."
         },
         {
           "severity": "error",
-          "message": "The first RED does not begin with the highest-risk case. The plan instructs the implementer to \"observe the missing Pending/Approved assertions fail before editing production code.\" The highest-risk accepted behavior in this ticket is the stale-receipt invariant (\"A stale approval never changes the current review to Approved\") and verbatim rejection findings. The named RED must state the fixture, command, and failure signal for that case before any production edit."
+          "message": "The supplied proof is non-discriminating. The only proof, cli-status-integration, is specified in the slice as \"The integration fixture covers Pending and Approved states.\" Checklist rows status-1 (three states plus actual findings and retry), status-4 (\"Prove all six accepted scenarios\"), status-6 (status-read failure reporting), and status-7 (reject stale or missing receipts, preserve actual findings) all resolve to that same fixture. Rejection findings, stale-receipt rejection, interruption retry, and receipt-missing retry can all be broken while the named command still exits 0, so those contributor Required proofs are not satisfied by a real-boundary proof of their stated boundary. The Implementation Plan explicitly requires exercising all six scenarios through the real CLI and coordinator boundary, including a stale receipt, actual rejection findings, interrupted retry, and finished receipt-missing retry."
         },
         {
           "severity": "error",
-          "message": "Recorded Decisions are only partially accounted for. The plan supplies one decision status: \"the Implementation Plan's existing coordinator/receipt source of truth is unchanged.\" The accepted Implementation Plan records further load-bearing decisions: binding the display to the current job identifier and plan digest; supplying terminal rejected findings verbatim without synthesis or suppression; retry creating a new review with the old rejection and receipt as historical evidence only; atomic retry binding with concurrent retries and crash-before-binding never displaying Approved; and a running or interrupted review without a terminal receipt displaying Pending with its actual error state. Each needs an explicit status entry of `unchanged`."
-        },
-        {
-          "severity": "error",
-          "message": "The documentation obligation conflicts with the slice completion signal. Checklist item status-9 requires updating CLI status help text \"for all three states,\" while Slice 1's completion signal requires only that \"the status help text names those two states.\" The completion signal can be satisfied with help text that omits Rejected, leaving status-9 unproven. Align the completion signal with the three-state contract."
+          "message": "Internal contradiction in the documentation obligation: checklist row status-9 requires \"Update CLI status help text for all three states,\" but the Slice 1 completion signal requires the help text to name only \"those two states\" (Pending and Approved). Two reasonable implementations exist and the one that satisfies the completion signal leaves status-9 unmet while the slice reports complete."
         },
         {
           "severity": "warning",
-          "message": "Checklist item status-6 (\"Report status-read failures without inventing approval\") and the Implementation Plan's \"A failed status read reports unavailable state rather than inventing approval\" have no named step or fixture case in Slice 1. Name the failure-injection case in the integration fixture so this obligation has a discriminating check rather than relying on the same happy-path assertions."
+          "message": "The decision-status and obligation-owner content appears only as trailing prose (\"Decision status: ... unchanged. Obligation owner: Current review status, Slice 1.\") rather than as discrete enumerated entries. It is resolvable here because the Implementation Plan's load-bearing decision set is small, but restating each Recorded Decision with an explicit readable status would remove ambiguity about whether every accepted decision was accounted for."
         },
         {
           "severity": "info",
-          "message": "The slicing decision, one-slice count, `relies_on_unmerged_successor: false`, empty prerequisite list, proof specifications table placed before the Delivery Checklist, and the versioned checklist with unique IDs across all eleven default categories are each present and internally consistent. The rationale is grounded in conceptual cohesion rather than size."
+          "message": "Routing rationale: the accepted proof boundary (CLI status command through the coordinator and authenticated receipt), the mapper design, and the data/measurement applicability skips are all unchanged and settled. The defect is inadequate fixture coverage, sequencing, and completion text, which is an execution mechanic. Destination is plan-execution, not plan-implementation."
         }
       ]
     },
@@ -380,30 +428,26 @@
       "findings": [
         {
           "severity": "error",
-          "message": "Non-discriminating proof for accepted scenarios 3 and 4. Slice 1 states \"The integration fixture covers Pending and Approved states,\" and cli-status-integration is the only proof. Scenario 3 (a completed review with blocking findings displays Rejected and those actual findings) and scenario 4 (retry a repaired plan; a stale approval cannot approve it) are never exercised. The mapper could synthesize or drop rejection findings, or display Approved from a stale receipt bound to a different job identifier or plan digest, and `bun run test tests/integration/review-status.test.ts` would still exit 0. Specify fixture cases in that same integration file for a terminal rejected job with recorded error findings asserted verbatim, and for a retry that binds a new job identifier and plan digest while a prior receipt is present and must not yield Approved."
-        },
-        {
-          "severity": "error",
-          "message": "Checklist item status-4 (\"Prove all four accepted scenarios through the CLI and coordinator\") cites cli-status-integration, but the plan's own description of that fixture covers two scenarios. As written the obligation can be recorded satisfied while two accepted scenarios are unproven. Either the fixture description must name all four scenario cases or status-4 must cite a proof that does."
+          "message": "Slice 1 completion signal is narrower than the accepted behavior: it requires only that \"Pending and Approved pass through the CLI entry point and the status help text names those two states.\" The accepted spec and scenarios require three statuses (Pending, Approved, Rejected), actual recorded rejection findings, a stale receipt that cannot display Approved, an interrupted review displaying Pending with its actual error and retry, and a finished nonblocking review without a valid receipt displaying Pending with its actual receipt error and retry (scenarios 3-6). As written an implementer can satisfy the stated completion condition with Rejected, stale-receipt, interrupted-retry, and receipt-missing-retry behavior entirely unimplemented, while checklist rows status-1, status-4, and status-7 are marked complete. Restate the completion signal to require every accepted scenario to pass through the CLI entry point after the final edit."
         },
         {
           "severity": "error",
-          "message": "Checklist item status-7 (security and privacy: \"Reject stale or missing approval receipts and preserve actual findings\") resolves to the same fixture, which exercises neither a stale receipt nor a missing receipt nor rejection findings. The Implementation Plan makes \"a stale approval never changes the current review to Approved\" a load-bearing contract; with no case exercising it, the accepted user-facing claim can be false while the named check passes."
+          "message": "The single supplied proof is non-discriminating for most mapped obligations. Slice 1 states \"The integration fixture covers Pending and Approved states,\" yet proof cli-status-integration is the Required proof for status-1 (Rejected with actual findings and retry), status-4 (\"Prove all six accepted scenarios through the CLI and coordinator\"), status-6 (status-read failure reporting), and status-7 (reject stale or missing approval receipts, preserve actual findings). A fixture scoped to Pending and Approved can pass while a stale receipt displays Approved, rejection findings are synthesized, or the receipt-missing case fabricates a rejection - each a violation of the accepted Implementation Plan contract. Specify the fixture content (or additional proofs) so each mapped obligation is exercised at the real CLI-to-coordinator boundary, including the stale-receipt and both Pending-failure retry paths."
         },
         {
           "severity": "error",
-          "message": "Slice 1's completion signal is narrower than its own obligations and internally contradictory: it reads \"Pending and Approved pass through the CLI entry point and the status help text names those two states,\" while status-9 requires help text for all three states and status-1 requires Rejected with actual blocking findings and retry. A contributor satisfying the stated completion signal would ship without Rejected. Restate the completion signal to cover all three displayed states, the verbatim rejection findings, and the retry/stale-receipt path."
+          "message": "Internal contradiction between the documentation obligation and the slice. Checklist row status-9 obliges \"Update CLI status help text for all three states,\" but the slice's final step and completion signal only require help text naming \"those two states\" (Pending and Approved). Two reasonable implementations exist and one reports status-9 satisfied with Rejected absent from the help text, falsely asserting the accepted user-facing claim. Reconcile the slice text with the three-state documentation obligation."
         },
         {
           "severity": "warning",
-          "message": "The first RED is named and startable (add the failing fixture, run the stated command from packages/cli, observe the missing assertions fail before production edits), but it names only the Pending/Approved assertions as the failure signal. Once the Rejected and stale-receipt cases are added, the highest-risk RED should be the stale-approval case, since that is the invariant whose violation is unrecoverable for the user."
+          "message": "Startable-step detail is thin for the first RED. The step names the fixture path, command, and cwd, but describes the failure signal only as \"the missing Pending/Approved assertions fail\" without naming the expected exit status or assertion text, and does not name the real actor boundary (coordinator job record plus authenticated receipt) that the fixture must stand up. Naming the exact expected failure signal and fixture actor setup would remove implementer invention."
         },
         {
           "severity": "info",
-          "message": "Non-blocking and correct as supplied: exactly one slice matching the one_pull_request decision with a rationale grounded in conceptual cohesion rather than size; no prerequisites and relies_on_unmerged_successor: false, consistent with a single slice; the proof specifications table precedes the delivery checklist; the v1 checklist marker, unique IDs, and all eleven default categories are present with honest open/missing dispositions; and the decision-status line preserves the coordinator/receipt source of truth without reopening it. No accepted decision is changed, which is why routing is plan-execution rather than plan-implementation."
+          "message": "Non-blocking items are sound: the slicing decision is explicit (one_pull_request, one slice, rationale grounded in conceptual cohesion rather than size), prerequisites are explicitly \"none\", relies_on_unmerged_successor is stated false, the proof specification table precedes the Delivery Checklist, and the decision-status line records the coordinator/receipt source of truth as unchanged. The blocking defects are scenario-coverage and proof-strength mechanics, so repair stays in plan-execution; the accepted design, API, data, and proof boundaries in the Implementation Plan are unchanged and need not be reopened."
         }
       ]
     }
   ],
-  "results_digest": "9085e0194fa82420b5e87f67fae1b5d361747cd6064379ab0730b32a9d814078"
+  "results_digest": "79e1efa667d3b8cbd26223f57320fb5f0c9d13c422e411df51131d06436117a2"
 }
diff --git a/packages/cli/tests/fixtures/reviewer-capability-evidence/gpt-6-astra.json b/packages/cli/tests/fixtures/reviewer-capability-evidence/gpt-6-astra.json
index 62dc1ba51..659ab5ed2 100644
--- a/packages/cli/tests/fixtures/reviewer-capability-evidence/gpt-6-astra.json
+++ b/packages/cli/tests/fixtures/reviewer-capability-evidence/gpt-6-astra.json
@@ -1,8 +1,8 @@
 {
   "provider": "openai",
   "model": "gpt-6-astra",
-  "corpus_digest": "f76edddd71868835e161d06987bce170fb395a71849412dd96c2b6d18c698b24",
-  "rubric_digest": "b9d97005601dcaaa38caefb84716497d792170da6d5d4a0076b039691df9594f",
+  "corpus_digest": "9625362c688a1eb641c0a504cd75d1977c0f9ee05980c0e233a57a76bd99ba92",
+  "rubric_digest": "f7a11ed5b1bca5f46e527892f2bfd2cefc77521e0bcede7974c5c6ea5e7aeb66",
   "settings_digest": "acd5a69993710ae8483c78771a67a6d61e061707f39f450a24a9a10511f7bf4d",
   "evidence_date": "2026-09-29",
   "runs": [
@@ -31,11 +31,15 @@
       "findings": [
         {
           "severity": "error",
-          "message": "spec.md omits Rejected from accepted behavior and the observable done state. A completed review with blocking findings could remain Pending or hide its findings while satisfying this plan. Define Rejected, require display of the actual blocking findings, and preserve the builder's ability to repair and request another review, as required by the ticket."
+          "message": "spec.md omits Rejected from accepted behavior and the done state. The ticket requires completed reviews with blocking findings to display Rejected, show the actual blocking findings, and permit repair and retry. A two-state implementation could satisfy this plan while hiding rejection and its recovery path. Include these accepted outcomes."
         },
         {
           "severity": "error",
-          "message": "spec.md defines Approved solely by possession of an authenticated approval receipt, without requiring that it apply to the current plan and review. After repair and retry, an implementation could display Approved using a stale receipt while meeting this definition. Require current applicable approval and specify that stale approval cannot approve the repaired plan."
+          "message": "spec.md leaves interrupted reviews and finished reviews without a valid approval receipt undefined. The ticket requires both to remain Pending, display the actual error, permit retry without changing plan bytes, and invent no rejection findings. Define these failure and recovery outcomes so completion alone cannot cause a false Rejected or Approved status."
+        },
+        {
+          "severity": "error",
+          "message": "The Approved definition requires an authenticated receipt but does not require it to apply to the current plan and review. After a rejected plan is repaired, an older authenticated approval could satisfy this definition and falsely display Approved. Explicitly require current applicable approval evidence and exclude stale approvals."
         }
       ]
     },
@@ -46,11 +50,15 @@
       "findings": [
         {
           "severity": "error",
-          "message": "spec.md omits Rejected, actual blocking findings, and repair-and-retry behavior required by CAP100. A completed review with blocking findings could remain Pending or hide its findings while satisfying the plan's done state. Define the rejected outcome, display of actual blocking findings, and ability to request another review after repair."
+          "message": "spec.md defines only Pending and Approved, but ticket CAP100 requires completed reviews with blocking findings to display Rejected, expose the actual findings, and permit repair and retry. The stated done condition can pass while builders cannot identify or recover from rejection. Include these accepted outcomes and expand the observable done state accordingly."
         },
         {
           "severity": "error",
-          "message": "spec.md defines Approved solely by possession of an authenticated approval receipt, without requiring that receipt to apply to the current plan and review. After repair, an implementation could reuse a stale receipt and falsely display Approved while meeting this definition. Require current applicable approval and explicitly exclude stale approvals."
+          "message": "The definition of Pending covers only unfinished reviews. CAP100 also requires interrupted reviews and finished reviews without a valid approval receipt to remain Pending, show their actual error, and permit retry without changing plan bytes or inventing rejection findings. Without these rules, a completed receipt failure can have no defined status or be falsely presented as rejection. Define both failure and recovery outcomes."
+        },
+        {
+          "severity": "error",
+          "message": "Approved requires an authenticated receipt but does not require that it approve the current plan. The supplied current-review boundary requires stale approval not to approve a repaired plan. As written, an implementation could reuse a prior authenticated receipt after repair and report Approved while the current plan lacks approval. State the current-plan validity requirement and the resulting status when no valid current receipt exists."
         }
       ]
     },
@@ -61,11 +69,15 @@
       "findings": [
         {
           "severity": "error",
-          "message": "spec.md omits Rejected from accepted behavior and the done state. A completed review with blocking findings could remain Pending or hide its findings while satisfying this plan. Require Rejected to display the actual blocking findings and permit repair and retry, as required by CAP100."
+          "message": "spec.md omits Rejected from accepted behavior and the done state. CAP100 requires a completed review with blocking findings to display Rejected with its actual findings and allow repair and retry. The plan permits a two-state display to claim completion while builders cannot identify or recover from rejection."
+        },
+        {
+          "severity": "error",
+          "message": "spec.md defines Pending only as unfinished and omits the required failure and retry outcomes. CAP100 requires interrupted reviews and finished reviews without valid approval receipts to remain Pending, show their actual error without invented rejection findings, and permit retry without changing plan bytes. A display could satisfy this plan while misclassifying these outcomes or leaving builders unable to retry."
         },
         {
           "severity": "error",
-          "message": "spec.md defines Approved by the existence of an authenticated approval receipt without requiring it to apply to the current reviewed plan. After repair and retry, an implementation could display Approved using a stale receipt while satisfying this definition. Require current applicable approval and explicitly exclude stale approvals from approving the revised plan."
+          "message": "The Approved definition does not require the authenticated receipt to apply to the current reviewed plan. After a builder repairs a rejected plan, an implementation could display Approved using a stale receipt while satisfying the stated definition. CAP100 requires current approval and explicitly prevents stale approval from approving the repaired plan."
         }
       ]
     },
@@ -94,7 +106,7 @@
       "findings": [
         {
           "severity": "error",
-          "message": "The decision that reviewer output alone can display Approved permits a current review to appear approved before an authenticated approval receipt exists. This violates the Product Plan and ticket's existing approval authority, and contradicts the plan's own missing-receipt and authorization contracts. Implementation Planning owns repairing this decision within the already accepted Product boundary: require a current authenticated approval receipt bound to the job identifier and plan digest. Include CLI-to-coordinator proof that an approving reviewer verdict without that receipt cannot display Approved; successful authenticated approval and stale-receipt checks alone do not discriminate this failure."
+          "message": "In impl-plan.md, the decision that reviewer output alone is enough to display Approved violates the Product Plan's requirement that only an authenticated receipt for the current job and plan bytes can authorize Approved, and contradicts the plan's own missing-receipt behavior. When a reviewer returns a nonblocking verdict but receipt authentication or creation fails, this decision permits the CLI to falsely display Approved instead of Pending with the actual receipt error and retry action (accepted scenario 6). The Product Plan owns approval authority and has already resolved this choice. Repair the Implementation Plan by removing verdict-only approval and consistently requiring a valid authenticated receipt bound to the current job and digest; retain the proposed real CLI/coordinator proof of the receipt-missing case."
         }
       ]
     },
@@ -105,7 +117,7 @@
       "findings": [
         {
           "severity": "error",
-          "message": "impl-plan.md permits a reviewer verdict to display Approved before an authenticated approval receipt exists. When a reviewer returns approve but receipt authentication or persistence is incomplete or fails, the CLI could report Approved without the authority required by the accepted Product Plan. This also contradicts the plan's own missing-receipt and authorization contracts. Implementation Planning owns repairing this decision: require a current authenticated receipt bound to both the active job and plan digest before displaying Approved. Include a real CLI/coordinator proof where an approve verdict exists without that receipt and verify that Approved is withheld."
+          "message": "impl-plan.md, Approach decisions: “The reviewer output verdict is enough to display Approved” contradicts the Product Plan’s requirement that only an authenticated receipt for the current job and plan bytes can display Approved, and conflicts with the plan’s own missing-receipt behavior. When a reviewer returns a nonblocking verdict but receipt creation fails, this decision permits the CLI to falsely display Approved instead of Pending with the actual receipt error and retry action (accepted scenario 6). Implementation Planning owns this repair: remove verdict-only approval and make a valid authenticated receipt bound to the current job and plan digest necessary for Approved throughout the plan."
         }
       ]
     },
@@ -116,7 +128,7 @@
       "findings": [
         {
           "severity": "error",
-          "message": "impl-plan.md permits a reviewer output verdict to display Approved before an authenticated approval receipt exists. When a reviewer returns approve but receipt authentication or issuance has not completed, the CLI could falsely report approval. This contradicts the accepted Product Plan and the plan’s own missing-receipt and authorization rules. The Implementation Plan owner must remove verdict-only approval and consistently require a current authenticated receipt bound to the current job and plan digest. Include proof at the real CLI/coordinator boundary that an approve verdict without that receipt cannot display Approved; the named happy-path and stale-receipt checks do not establish this."
+          "message": "impl-plan.md, Approach decisions: “The reviewer output verdict is enough to display Approved” violates the accepted Product Plan and project principle that only an authenticated receipt for the current job and plan bytes authorizes Approved. When a reviewer returns a nonblocking verdict but receipt creation fails, this decision permits Approved where scenario 6 requires Pending with the actual receipt error and retry action. Later statements requiring a valid receipt do not resolve the contradictory implementation choices. The Implementation Plan owner must remove verdict-only approval and consistently require a valid, current authenticated receipt before displaying Approved; retain the scenario 6 CLI/coordinator proof to verify this boundary."
         }
       ]
     },
@@ -145,15 +157,15 @@
       "findings": [
         {
           "severity": "error",
-          "message": "Slice 1's fixture and completion signal cover only Pending and Approved. All named checks could pass while Rejected omits actual blocking findings, repaired plans cannot be retried, or a stale receipt falsely grants approval. Checklist rows status-1, status-4, and status-7 do not supply the missing executable proof. Specify real CLI/coordinator fixtures, actions, and assertions for rejection with verbatim findings, repair and retry, missing or unauthenticated receipts, and receipts bound to a different job or plan digest. Begin production work with a named highest-risk RED and its concrete failure assertion."
+          "message": "Slice 1's cli-status-integration fixture and completion signal cover only Pending and Approved, despite status-4 requiring all six accepted scenarios. A mapper that never displays Rejected, hides blocking findings, accepts stale receipts, or provides no working retry could pass every specified assertion. Expand the fixture and completion signal to exercise all six scenarios through the real CLI and coordinator, including actual findings, stale receipts, and interrupted and receipt-missing reviews showing Pending with actual errors, no invented findings, and working retries without changing plan bytes. Name the highest-risk initial RED and its specific failing assertion. Include discriminating checks for the accepted status-read failure and exit-code compatibility obligations."
         },
         {
           "severity": "error",
-          "message": "Slice 1's generic instruction to implement the mapper and CLI wiring leaves accepted decision-derived obligations without concrete tasks or completion signals: current-job/digest binding, concurrent retries finishing out of order, a crash before retry binding, interrupted reviews with their actual error state, status-read failures, and unchanged CLI exit codes. The broad source-of-truth decision statement does not account for these accepted decisions. Map each to explicit execution actions, prerequisites, observable assertions, and unchanged decision statuses; otherwise delivery can finish while violating the accepted coordinator contract."
+          "message": "Slice 1's instruction to 'implement the mapper and CLI wiring' and its single source-of-truth decision-status entry do not account for the accepted retry and current-job binding decisions. The Implementation Plan requires retries to bind a new job and plan digest atomically, only the currently bound job to drive status when retries finish out of order, and a crash before binding to retain the prior retryable terminal state. No executable steps, proof cases, or completion signals preserve these requirements. Map each accepted decision unchanged to owned actions and concrete coordinator fixtures/assertions, identifying existing behavior to verify versus target work. Otherwise a late historical completion could drive the displayed status while the planned checks pass."
         },
         {
           "severity": "error",
-          "message": "Slice 1 explicitly completes when CLI help names only Pending and Approved, contradicting status-9 and the accepted three-state documentation requirement. Require help text and its completion check to include Rejected, alongside the other two states."
+          "message": "Slice 1 explicitly completes when CLI help names only Pending and Approved, contradicting status-9 and the accepted three-state CLI contract. Specify the help edit and a CLI help assertion covering Pending, Approved, and Rejected; the current completion signal permits shipping documentation that omits an accepted outcome."
         }
       ]
     },
@@ -164,11 +176,11 @@
       "findings": [
         {
           "severity": "error",
-          "message": "Slice 1's executable work, fixture, and completion signal cover only Pending and Approved, and its help-text completion signal names only those states. Accepted scenarios 3 and 4 require Rejected, verbatim blocking findings, and retry after repair. Checklist entries status-1, status-4, and status-9 do not supply the missing execution steps or assertions. Add concrete CLI/coordinator fixture actions, implementation tasks, and completion assertions for rejection, actual findings, retry, and help text covering all three states. Otherwise the slice can finish while builders cannot see or retry a rejected review."
+          "message": "Slice 1's cli-status-integration fixture explicitly covers only Pending and Approved, while status-4 and the accepted Implementation Plan require all six scenarios through the real CLI and coordinator. Every named assertion could pass even if actual rejection findings are hidden, stale receipts grant approval, or interrupted and receipt-missing reviews cannot retry. Specify fixture setup, CLI actions, and assertions for scenarios 3–6, including actual errors, no invented rejection findings, unchanged-byte retries, and binding a new current job. Make those assertions required for completion and select a concrete highest-risk RED before production edits."
         },
         {
           "severity": "error",
-          "message": "The cli-status-integration proof specifies no discriminating fixtures or assertions for job/digest binding, missing or stale receipts, unauthenticated verdicts, concurrent retry completion, a crash before retry binding, interrupted reviews, or status-read failures. Pending/Approved happy-path assertions can pass even if an old receipt falsely approves repaired plan bytes. Specify real CLI/coordinator setup, actions, and observable assertions for these accepted decisions, plus exit-code compatibility; map each decision to Slice 1 and explicitly retain its unchanged status. Make the highest-risk false-approval case the initial RED, with its expected failure before production edits."
+          "message": "Slice 1's executable work and completion signal do not preserve all accepted decisions and obligations. 'Implement the mapper and CLI wiring' supplies no concrete execution or verification steps for retry binding, concurrent retry completion order, or crash-before-binding behavior accepted in the Implementation Plan; the single decision-status statement accounts only for the coordinator/receipt source of truth. Additionally, completion explicitly requires help text naming only Pending and Approved despite status-9 requiring all three states. Map each accepted decision to unchanged status and owned, startable implementation or verification steps, with observable completion signals covering retry safety and Rejected help text. Existing coordinator behavior may be verified rather than reimplemented."
         }
       ]
     },
@@ -179,14 +191,14 @@
       "findings": [
         {
           "severity": "error",
-          "message": "Slice 1 and cli-status-integration cover only Pending and Approved, and the completion signal explicitly requires help text for only those two states. All named assertions could pass while a rejected review hides blocking findings or a repaired plan cannot be retried, violating accepted scenarios 3–4 and obligations status-1, status-4, and status-9. Add concrete implementation and real CLI/coordinator fixture steps for Rejected, verbatim blocking findings, and repair/retry; require all three states in help text and the completion signal."
+          "message": "Slice 1's cli-status-integration fixture explicitly covers only Pending and Approved, despite status-4 requiring all six accepted scenarios. It specifies no assertions for actual rejection findings, stale receipts, interrupted or receipt-missing errors, or working retries with unchanged plan bytes. An implementation could falsely approve a stale receipt, fabricate rejection findings, or omit retry while every named assertion passes. Expand the fixture and RED/GREEN instructions to exercise these accepted cases through the real CLI and coordinator, including their observable errors, findings, and new-current-job binding. Select and name the highest-risk RED and its precise failure signal."
         },
         {
           "severity": "error",
-          "message": "Slice 1 provides no executable fixtures or assertions for the accepted authority and failure contracts: receipts bound to both current job and plan digest, missing or unauthenticated approval, concurrent retries finishing out of order, a crash before retry binding, interrupted reviews, and failed status reads. Its generic mapper/wiring step and two-state proof permit stale approval to display Approved while every specified check passes. Preserve these existing decisions explicitly and specify fixture setup, actions, and observable assertions through the CLI/coordinator boundary, including unchanged exit-code compatibility. Map these obligations and each accepted approach decision to the slice and its completion evidence; the single source-of-truth decision-status statement does not account for them."
+          "message": "Slice 1's implementation instruction ('implement the mapper and CLI wiring'), decision-status entry, and completion signal do not account for the full accepted approach. The Implementation Plan also requires retry behavior, current job-and-digest binding, concurrent retry ordering, crash-before-binding behavior, unavailable status-read reporting, and unchanged CLI exit codes. These lack concrete execution or verification steps and explicit decision preservation. The completion signal and help-text step also name only two states, contradicting status-9's three-state documentation obligation. Map these accepted obligations and decisions to concrete actions, inputs, prerequisites, proof assertions, and completion signals within the existing slice; include Rejected in the help-text completion requirement."
         }
       ]
     }
   ],
-  "results_digest": "c9b154c8b1f43481f99448f2de7ed2a1f416cd1df6a672d27967b8f87f7fdc56"
+  "results_digest": "6896b041709116a42ce5b601ea78db9697a37d017d426bb1149fd42fe90a46f0"
 }
diff --git a/packages/cli/tests/fixtures/reviewer-capability-evidence/gpt-6.1-sol.json b/packages/cli/tests/fixtures/reviewer-capability-evidence/gpt-6.1-sol.json
new file mode 100644
index 000000000..bb5c1270a
--- /dev/null
+++ b/packages/cli/tests/fixtures/reviewer-capability-evidence/gpt-6.1-sol.json
@@ -0,0 +1,217 @@
+{
+  "provider": "openai",
+  "model": "gpt-6.1-sol",
+  "corpus_digest": "9625362c688a1eb641c0a504cd75d1977c0f9ee05980c0e233a57a76bd99ba92",
+  "rubric_digest": "a4662a8bb68e00b1da37f622ba88f2f0d8f9f3a502edea3777776ebb1d51cdc1",
+  "settings_digest": "5e89801fc75ed7f7e0a477a6ba32deca73cbe3896e6a640419aa7637f27c0e34",
+  "evidence_date": "2026-10-08",
+  "runs": [
+    {
+      "fixture_id": "product-approve",
+      "run": 1,
+      "verdict": "approve",
+      "findings": []
+    },
+    {
+      "fixture_id": "product-approve",
+      "run": 2,
+      "verdict": "approve",
+      "findings": []
+    },
+    {
+      "fixture_id": "product-approve",
+      "run": 3,
+      "verdict": "approve",
+      "findings": []
+    },
+    {
+      "fixture_id": "product-reject",
+      "run": 1,
+      "verdict": "request_changes",
+      "findings": [
+        {
+          "severity": "error",
+          "message": "spec.md omits Rejected. CAP100 requires a completed review with blocking findings to display Rejected with those actual findings and permit repair and retry. The plan allows such a review to remain Pending or hide its findings while satisfying its stated done state."
+        },
+        {
+          "severity": "error",
+          "message": "spec.md does not define interrupted reviews or finished nonblocking reviews without a valid approval receipt. CAP100 requires both to remain Pending with their actual error and a retry action without changing plan bytes or inventing rejection findings. The current definition leaves finished reviews without a receipt unclassified and permits omission of the required error and recovery behavior."
+        },
+        {
+          "severity": "error",
+          "message": "The Approved definition does not require the authenticated receipt to apply to the current plan. CAP100 requires a repaired plan to receive a new review and prohibits a stale approval from approving it. As written, an implementation could display Approved using a prior authenticated receipt after plan bytes change, falsely reporting current approval."
+        }
+      ]
+    },
+    {
+      "fixture_id": "product-reject",
+      "run": 2,
+      "verdict": "request_changes",
+      "findings": [
+        {
+          "severity": "error",
+          "message": "spec.md omits Rejected entirely. CAP100 requires a completed review with blocking findings to display Rejected with its actual findings and permit repair and retry. A display implementing only Pending and Approved could satisfy the stated done state while hiding rejection and its recovery path. Add these accepted outcomes to the Product Plan."
+        },
+        {
+          "severity": "error",
+          "message": "spec.md defines Pending only as an unfinished review and omits required failure and retry outcomes. CAP100 also requires interrupted reviews and finished reviews without a valid approval receipt to remain Pending, show their actual error, invent no rejection findings, and permit retry without changing plan bytes. The current definition permits a finished receipt failure to leave Pending or provide no actionable recovery. Define both outcomes explicitly."
+        },
+        {
+          "severity": "error",
+          "message": "spec.md requires an authenticated approval receipt but does not require it to apply to the current review and current plan bytes. CAP100 requires current status and prohibits a stale approval from approving a repaired plan. An implementation could display Approved using a prior authenticated receipt and still satisfy this plan. State the current-review validity boundary and the outcome after plan changes."
+        }
+      ]
+    },
+    {
+      "fixture_id": "product-reject",
+      "run": 3,
+      "verdict": "request_changes",
+      "findings": [
+        {
+          "severity": "error",
+          "message": "The accepted ticket requires completed reviews with blocking findings to display Rejected with the actual findings and permit repair and retry. spec.md defines only Pending and Approved; its done state permits shipping a display that never exposes rejection or its recovery path. Add these accepted Builder outcomes to the Product Plan."
+        },
+        {
+          "severity": "error",
+          "message": "The ticket requires interrupted reviews and finished reviews without a valid approval receipt to remain Pending with their actual error and a retry action, without invented rejection findings or requiring changed plan bytes. spec.md defines Pending only as unfinished and omits these failure and recovery outcomes. A finished review with an invalid receipt therefore has no defined correct status, and the stated done condition permits missing error and retry behavior."
+        },
+        {
+          "severity": "error",
+          "message": "The ticket requires current review status and prevents a stale approval from approving a repaired plan. spec.md says Approved requires an authenticated receipt but does not require that receipt to apply to the current plan and review. An implementation could display Approved using a stale authenticated receipt and still satisfy this plan. Define the current-approval boundary and the observable consequence of stale receipts."
+        }
+      ]
+    },
+    {
+      "fixture_id": "implementation-approve",
+      "run": 1,
+      "verdict": "approve",
+      "findings": []
+    },
+    {
+      "fixture_id": "implementation-approve",
+      "run": 2,
+      "verdict": "approve",
+      "findings": []
+    },
+    {
+      "fixture_id": "implementation-approve",
+      "run": 3,
+      "verdict": "approve",
+      "findings": []
+    },
+    {
+      "fixture_id": "implementation-reject",
+      "run": 1,
+      "verdict": "request_changes",
+      "findings": [
+        {
+          "severity": "error",
+          "message": "impl-plan.md permits displaying Approved from the reviewer verdict before an authenticated approval receipt exists. A current nonblocking review with a missing or invalid receipt could therefore falsely display Approved, violating accepted scenario 6, the Product Plan’s approval contract, and the project principle that authenticated receipts are the only approval authority. This also contradicts the plan’s own receipt-missing Pending rule. Implementation Planning must remove verdict-only approval and consistently require a valid authenticated receipt bound to the current job identifier and plan digest; without that receipt, display Pending with the actual receipt error and retry action."
+        }
+      ]
+    },
+    {
+      "fixture_id": "implementation-reject",
+      "run": 2,
+      "verdict": "request_changes",
+      "findings": [
+        {
+          "severity": "error",
+          "message": "impl-plan.md says a reviewer verdict can display Approved before an authenticated approval receipt exists. This contradicts the accepted Product Plan, project principle, and scenario 6, which require Pending with the actual receipt error and retry action when a finished nonblocking review lacks a valid receipt. The triggering condition is a nonblocking reviewer verdict without a current authenticated receipt; the observable consequence is falsely displaying Approved. The Implementation Plan owner must remove verdict-only approval and consistently require an authenticated receipt bound to the current job and plan digest. Align the mapper decision with the existing failure contract before fresh review."
+        }
+      ]
+    },
+    {
+      "fixture_id": "implementation-reject",
+      "run": 3,
+      "verdict": "request_changes",
+      "findings": [
+        {
+          "severity": "error",
+          "message": "impl-plan.md, Approach decisions: “The reviewer output verdict is enough to display Approved, even before an authenticated approval receipt exists” violates the accepted Product Plan and project principle that only an authenticated receipt for the current job and plan bytes authorizes Approved. A finished nonblocking review with no valid receipt could therefore display Approved instead of Pending with its actual receipt error and retry action (accepted scenario 6). This also contradicts the plan’s later receipt requirements, leaving two materially different implementations possible. The Implementation Plan owner must remove verdict-only approval and consistently require a valid authenticated receipt bound to the current job and plan digest before displaying Approved."
+        }
+      ]
+    },
+    {
+      "fixture_id": "execution-approve",
+      "run": 1,
+      "verdict": "approve",
+      "findings": []
+    },
+    {
+      "fixture_id": "execution-approve",
+      "run": 2,
+      "verdict": "approve",
+      "findings": []
+    },
+    {
+      "fixture_id": "execution-approve",
+      "run": 3,
+      "verdict": "request_changes",
+      "findings": [
+        {
+          "severity": "error",
+          "message": "Slice 1, cli-status-integration: the accepted Implementation Plan requires concurrent retries to atomically bind the new job identifier and plan digest. Testing that a concurrently completed non-current job cannot drive the display only proves filtering after a binding exists; it does not exercise overlapping retry bindings. A non-atomic implementation could leave the current job paired with another retry's digest while every named concurrency assertion passes, violating the accepted current job-and-digest invariant and potentially displaying the wrong review status. Add a concrete CLI/coordinator fixture that overlaps two retry requests, specifies their interleaving, and asserts a coherent current job/digest pair and the corresponding displayed status throughout observable binding outcomes. Require this assertion to pass after the final edit. This repairs execution proof mechanics without changing the accepted boundary."
+        }
+      ]
+    },
+    {
+      "fixture_id": "execution-reject",
+      "run": 1,
+      "verdict": "request_changes",
+      "findings": [
+        {
+          "severity": "error",
+          "message": "Slice 1's cli-status-integration fixture explicitly covers only Pending and Approved, despite status-4 and the accepted Implementation Plan requiring all six scenarios through the real CLI and coordinator. A mapper that hides blocking findings, accepts stale receipts, or lacks working interruption and receipt-failure retries could pass every specified assertion. Add concrete fixture setup, actions, and assertions for all six scenarios, including actual errors, no invented rejection findings, and retries binding a new current job to unchanged bytes where required. Begin production work with a named highest-risk RED and its specific failure signal."
+        },
+        {
+          "severity": "error",
+          "message": "Slice 1 provides only 'implement the mapper and CLI wiring' and a completion signal requiring Pending, Approved, and help text naming those two states. It supplies no executable work for the accepted repair/retry path, and its final documentation step does not require Rejected. An implementation with no working retry and help describing only two statuses can satisfy that completion signal while violating accepted scenarios 3–6 and status-9. Specify the actions, inputs, prerequisites, and observable results for the accepted recovery work and three-state help update, then require every applicable proof to pass after the final edit."
+        }
+      ]
+    },
+    {
+      "fixture_id": "execution-reject",
+      "run": 2,
+      "verdict": "request_changes",
+      "findings": [
+        {
+          "severity": "error",
+          "message": "Slice 1's cli-status-integration fixture explicitly covers only Pending and Approved. Accepted scenarios 3–6 also require actual rejection findings, repaired-plan retry, stale-receipt rejection, interrupted retry, and receipt-missing retry. The Implementation Plan requires both failure cases to assert the actual error, no invented rejection findings, and a new current job bound to unchanged plan bytes. Those behaviors could be broken while every specified assertion passes. Expand the fixture instructions and assertions through the existing real CLI/coordinator boundary; checklist status-4 alone does not supply executable proof."
+        },
+        {
+          "severity": "error",
+          "message": "Slice 1's completion signal requires only Pending and Approved plus help naming those two states, contradicting status-1 and status-9 and the accepted three-state CLI contract. A change omitting Rejected from the display and help could satisfy that completion signal. Require all accepted behavior and help for all three states, with every applicable proof passing after the final edit."
+        },
+        {
+          "severity": "error",
+          "message": "Slice 1's instruction to 'implement the mapper and CLI wiring' does not provide startable actions preserving all recorded decisions. The decision-status entry accounts only for the coordinator/receipt source of truth; it does not explicitly account for current job/digest binding, verbatim blocking findings, retry history, atomic retry binding and concurrent completion, interrupted behavior, or receipt-missing behavior. Map each accepted decision unchanged to concrete work and proof, including status-read failure and exit-code compatibility checks, so implementers need not invent execution mechanics."
+        }
+      ]
+    },
+    {
+      "fixture_id": "execution-reject",
+      "run": 3,
+      "verdict": "request_changes",
+      "findings": [
+        {
+          "severity": "error",
+          "message": "Slice 1's cli-status-integration fixture explicitly covers only Pending and Approved, despite status-4 requiring all six accepted scenarios. Its completion signal and final rerun can therefore pass while rejection findings, stale-receipt protection, interrupted retry, and receipt-missing retry are broken. Specify real CLI/coordinator fixtures, actions, and assertions for all six scenarios, including actual errors, absence of invented rejection findings, and new current-job binding for unchanged-byte retries. Begin with the highest-risk named RED and require every applicable assertion to pass after the final edit."
+        },
+        {
+          "severity": "error",
+          "message": "Slice 1's instruction to 'implement the mapper and CLI wiring' does not provide startable actions for the accepted retry behavior or decision-derived current-job binding. The Implementation Plan requires repaired-byte and unchanged-byte retries, atomic job/digest binding, concurrent completion handling, and preservation of the prior retryable state after a crash before binding. Map these accepted obligations to explicit implementation or existing-behavior verification steps, with prerequisites and observable results. Otherwise an implementer can complete the named mapper work while leaving the accepted retry path unimplemented or unverified."
+        },
+        {
+          "severity": "error",
+          "message": "Slice 1's completion signal requires help text naming only Pending and Approved, contradicting status-9 and the accepted three-state CLI contract. The integration proof specifies no help assertion, so the final help edit can omit Rejected while every named check passes. Specify the three-state help edit and a concrete assertion for its resulting output, and include that proof in completion after the final edit."
+        },
+        {
+          "severity": "error",
+          "message": "The Decision status statement accounts only for the coordinator/receipt source of truth. It does not explicitly account for the Implementation Plan's other recorded decisions, including current job/digest binding, verbatim blocking findings, retry history and atomic binding, interruption behavior, and receipt-missing behavior. Record each accepted decision as unchanged and map its applicable implementation and proof obligations to Current review status; the existing aggregate owner statement does not supply those missing execution mappings."
+        }
+      ]
+    }
+  ],
+  "results_digest": "9bf199843cacad511ddc1dcc65c678f989d35b0000ea569f3f0320c2886b863b"
+}
diff --git a/packages/cli/tests/helpers.ts b/packages/cli/tests/helpers.ts
index 0268c79f7..9db77b26d 100644
--- a/packages/cli/tests/helpers.ts
+++ b/packages/cli/tests/helpers.ts
@@ -59,6 +59,16 @@ export const TIMEOUT_BUN_INSTALL = 120_000;
 const __dirname = import.meta.dirname;
 export const testCliRoot = process.env.SAFEWORD_TEST_CLI_ROOT ?? nodePath.join(__dirname, '..');
 
+export function createCurrentPlanningCheckerStub(): { directory: string; cli: string } {
+  const directory = createTemporaryDirectory();
+  const cli = nodePath.join(directory, 'planning-checker.js');
+  writeFileSync(
+    cli,
+    `console.log(JSON.stringify({ state: 'healthy', data: { command: 'ticket planning-contract-check', status: 'current', planning_phase: process.argv.at(-1) } }));\n`,
+  );
+  return { directory, cli };
+}
+
 /**
  * Path to the CLI entry point (built)
  */
diff --git a/packages/cli/tests/integration/blank-planning-context.test.ts b/packages/cli/tests/integration/blank-planning-context.test.ts
index d2210139a..ccfbf0c00 100644
--- a/packages/cli/tests/integration/blank-planning-context.test.ts
+++ b/packages/cli/tests/integration/blank-planning-context.test.ts
@@ -76,7 +76,7 @@ process.stdin.on('end', () => {
   const packet = JSON.parse(input.trim().split('\n').pop());
   console.log(JSON.stringify({ structured_output: { schema_version: 1,
     dispatch_id: packet.dispatch_id, reviewer_agent: 'claude', verdict: 'approve',
-    summary: 'The supplied plan is otherwise reviewable.', findings: [] } }));
+    summary: 'The supplied plan is otherwise reviewable.', findings: [], evidence_records: { schema_version: 1, records: [] } } }));
 });
 `,
         { mode: 0o755 },
diff --git a/packages/cli/tests/integration/child-product-planning-context.test.ts b/packages/cli/tests/integration/child-product-planning-context.test.ts
index 5d73c167a..7cf160e1c 100644
--- a/packages/cli/tests/integration/child-product-planning-context.test.ts
+++ b/packages/cli/tests/integration/child-product-planning-context.test.ts
@@ -128,7 +128,7 @@ process.stdin.on('end', () => {
   writeFileSync(${JSON.stringify(capture)}, input);
   const packet = JSON.parse(input.trim().split('\n').pop());
   console.log(JSON.stringify({ structured_output: { schema_version: 1, dispatch_id: packet.dispatch_id,
-    reviewer_agent: 'claude', verdict: 'approve', summary: 'The supplied plan is otherwise reviewable.', findings: [] } }));
+    reviewer_agent: 'claude', verdict: 'approve', summary: 'The supplied plan is otherwise reviewable.', findings: [], evidence_records: { schema_version: 1, records: [] } } }));
 });
 `,
     { mode: 0o755 },
diff --git a/packages/cli/tests/integration/coding-authorization.test.ts b/packages/cli/tests/integration/coding-authorization.test.ts
index 7cdbbf9d3..18d489abc 100644
--- a/packages/cli/tests/integration/coding-authorization.test.ts
+++ b/packages/cli/tests/integration/coding-authorization.test.ts
@@ -127,9 +127,9 @@ payload=$(cat)
 dispatch_id=$(printf '%s' "$payload" | sed -n 's/.*"dispatch_id":"\([^"]*\)".*/\1/p')
 record=$(printenv SAFEWORD_REVIEW_FAKE_EXECUTION_PLAN_RECORD || true)
 if [ -n "$record" ]; then
-  printf '{"schema_version":1,"dispatch_id":"%s","reviewer_agent":"claude","verdict":"approve","summary":"approved fixture","findings":[],"planning_destination":"plan-execution","execution_plan_record":%s}\n' "$dispatch_id" "$record"
+  printf '{"schema_version":1,"dispatch_id":"%s","reviewer_agent":"claude","verdict":"approve","summary":"approved fixture","findings":[],"evidence_records":{"schema_version":1,"records":[]},"planning_destination":"plan-execution","execution_plan_record":%s}\n' "$dispatch_id" "$record"
 else
-  printf '{"schema_version":1,"dispatch_id":"%s","reviewer_agent":"claude","verdict":"approve","summary":"approved fixture","findings":[]}\n' "$dispatch_id"
+  printf '{"schema_version":1,"dispatch_id":"%s","reviewer_agent":"claude","verdict":"approve","summary":"approved fixture","findings":[],"evidence_records":{"schema_version":1,"records":[]}}\n' "$dispatch_id"
 fi
 `,
     { mode: 0o755 },
@@ -301,7 +301,7 @@ async function featureFixture(
   writeFileSync(
     nodePath.join(root, '.safeword', 'config.json'),
     `${JSON.stringify({
-      crossAgentReviewRoutes: { codex: [{ reviewer: 'claude', model: 'opus' }] },
+      crossAgentReviewRoutes: { codex: [{ reviewer: 'claude', model: 'claude-opus-5' }] },
       ...(designApprovalGate && { designApprovalGate: true }),
     })}\n`,
   );
diff --git a/packages/cli/tests/integration/delivery-execution-prerequisite.test.ts b/packages/cli/tests/integration/delivery-execution-prerequisite.test.ts
index 2fc44b94f..223bd154a 100644
--- a/packages/cli/tests/integration/delivery-execution-prerequisite.test.ts
+++ b/packages/cli/tests/integration/delivery-execution-prerequisite.test.ts
@@ -89,7 +89,7 @@ function featureFixture(designApprovalGate = false, phase = 'plan-execution'): s
     `${JSON.stringify({
       designApprovalGate,
       crossAgentReviewRoutes: {
-        codex: [{ reviewer: 'claude', model: 'opus' }],
+        codex: [{ reviewer: 'claude', model: 'claude-opus-5' }],
       },
     })}\n`,
   );
@@ -136,11 +136,11 @@ record=$(printenv SAFEWORD_REVIEW_FAKE_EXECUTION_PLAN_RECORD || true)
 verdict=$(printenv SAFEWORD_REVIEW_FAKE_VERDICT || true)
 finding=$(printenv SAFEWORD_REVIEW_FAKE_FINDING || true)
 if [ "$verdict" = "request_changes" ]; then
-  printf '{"schema_version":1,"dispatch_id":"%s","reviewer_agent":"claude","verdict":"request_changes","summary":"plan needs repair","findings":[{"severity":"error","message":"%s"}],"planning_destination":"plan-execution","execution_plan_record":null}\n' "$dispatch_id" "$finding"
+  printf '{"schema_version":1,"dispatch_id":"%s","reviewer_agent":"claude","verdict":"request_changes","summary":"plan needs repair","findings":[{"severity":"error","message":"%s"}],"evidence_records":{"schema_version":1,"records":[]},"planning_destination":"plan-execution","execution_plan_record":null}\n' "$dispatch_id" "$finding"
 elif [ -n "$record" ]; then
-  printf '{"schema_version":1,"dispatch_id":"%s","reviewer_agent":"claude","verdict":"approve","summary":"approved","findings":[],"planning_destination":"plan-execution","execution_plan_record":%s}\n' "$dispatch_id" "$record"
+  printf '{"schema_version":1,"dispatch_id":"%s","reviewer_agent":"claude","verdict":"approve","summary":"approved","findings":[],"evidence_records":{"schema_version":1,"records":[]},"planning_destination":"plan-execution","execution_plan_record":%s}\n' "$dispatch_id" "$record"
 else
-  printf '{"schema_version":1,"dispatch_id":"%s","reviewer_agent":"claude","verdict":"approve","summary":"approved","findings":[]}\n' "$dispatch_id"
+  printf '{"schema_version":1,"dispatch_id":"%s","reviewer_agent":"claude","verdict":"approve","summary":"approved","findings":[],"evidence_records":{"schema_version":1,"records":[]}}\n' "$dispatch_id"
 fi
 `,
     { mode: 0o755 },
diff --git a/packages/cli/tests/integration/execution-product-planning-context.test.ts b/packages/cli/tests/integration/execution-product-planning-context.test.ts
index 82eb44dd5..b6f2ed7f7 100644
--- a/packages/cli/tests/integration/execution-product-planning-context.test.ts
+++ b/packages/cli/tests/integration/execution-product-planning-context.test.ts
@@ -105,7 +105,7 @@ process.stdin.on('end', () => {
   const packet = JSON.parse(input.trim().split('\n').pop());
   writeFileSync(${JSON.stringify(capture)}, JSON.stringify(packet));
   console.log(JSON.stringify({ structured_output: { schema_version: 1, dispatch_id: packet.dispatch_id,
-    reviewer_agent: 'claude', verdict: 'approve', summary: 'Fixture approves the supplied packet.', findings: [], planning_destination: 'plan-execution',
+    reviewer_agent: 'claude', verdict: 'approve', summary: 'Fixture approves the supplied packet.', findings: [], evidence_records: { schema_version: 1, records: [] }, planning_destination: 'plan-execution',
     execution_plan_record: { slicing_decision: 'one_pull_request', rationale: 'One coherent change.',
       slices: [{ name: 'Complete delivery', purpose: 'Deliver the reviewed plan.', boundary: 'The accepted CLI boundary.', prerequisites: [], proof: 'The installed CLI review passes.', completion_signal: 'The review is approved.', relies_on_unmerged_successor: false }],
       obligation_owners: [{ obligation: 'Accepted behavior', slices: ['Complete delivery'] }],
diff --git a/packages/cli/tests/integration/execution-upstream-planning-context.test.ts b/packages/cli/tests/integration/execution-upstream-planning-context.test.ts
index e1d4c3626..63909b069 100644
--- a/packages/cli/tests/integration/execution-upstream-planning-context.test.ts
+++ b/packages/cli/tests/integration/execution-upstream-planning-context.test.ts
@@ -110,7 +110,7 @@ process.stdin.on('end', () => {
   const packet = JSON.parse(input.trim().split('\n').pop());
   writeFileSync(${JSON.stringify(capture)}, JSON.stringify(packet));
   const output = { structured_output: { schema_version: 1, dispatch_id: packet.dispatch_id,
-    reviewer_agent: 'claude', verdict: 'approve', summary: 'Fixture approves the supplied packet.', findings: [], planning_destination: 'plan-execution',
+    reviewer_agent: 'claude', verdict: 'approve', summary: 'Fixture approves the supplied packet.', findings: [], evidence_records: { schema_version: 1, records: [] }, planning_destination: 'plan-execution',
     execution_plan_record: { slicing_decision: 'one_pull_request', rationale: 'One coherent change.',
       slices: [{ name: 'Complete delivery', purpose: 'Deliver the reviewed plan.', boundary: 'The accepted CLI boundary.', prerequisites: [], proof: 'The installed CLI review passes.', completion_signal: 'The review is approved.', relies_on_unmerged_successor: false }],
       obligation_owners: [{ obligation: 'Accepted behavior', slices: ['Complete delivery'] }],
diff --git a/packages/cli/tests/integration/implementation-product-planning-context.test.ts b/packages/cli/tests/integration/implementation-product-planning-context.test.ts
index cc3c81c37..7b7c31bb7 100644
--- a/packages/cli/tests/integration/implementation-product-planning-context.test.ts
+++ b/packages/cli/tests/integration/implementation-product-planning-context.test.ts
@@ -92,7 +92,7 @@ process.stdin.on('end', () => {
   const packet = JSON.parse(input.trim().split('\n').pop());
   writeFileSync(${JSON.stringify(capture)}, JSON.stringify(packet));
   console.log(JSON.stringify({ structured_output: { schema_version: 1, dispatch_id: packet.dispatch_id,
-    reviewer_agent: 'claude', verdict: 'approve', summary: 'Fixture approves the supplied packet.', findings: [] } }));
+    reviewer_agent: 'claude', verdict: 'approve', summary: 'Fixture approves the supplied packet.', findings: [], evidence_records: { schema_version: 1, records: [] } } }));
 });
 `,
     { mode: 0o755 },
diff --git a/packages/cli/tests/integration/implementation-ticket-context-currency.test.ts b/packages/cli/tests/integration/implementation-ticket-context-currency.test.ts
index 43087b38e..f738cdb9a 100644
--- a/packages/cli/tests/integration/implementation-ticket-context-currency.test.ts
+++ b/packages/cli/tests/integration/implementation-ticket-context-currency.test.ts
@@ -92,7 +92,7 @@ process.stdin.on('end', () => {
   const packet = JSON.parse(input.trim().split('\n').pop());
   writeFileSync(${JSON.stringify(capture)}, JSON.stringify(packet));
   console.log(JSON.stringify({ structured_output: { schema_version: 1, dispatch_id: packet.dispatch_id,
-    reviewer_agent: 'claude', verdict: 'approve', summary: 'Fixture approves the supplied packet.', findings: [] } }));
+    reviewer_agent: 'claude', verdict: 'approve', summary: 'Fixture approves the supplied packet.', findings: [], evidence_records: { schema_version: 1, records: [] } } }));
 });
 `,
     { mode: 0o755 },
diff --git a/packages/cli/tests/integration/inspiration-intake-transition.test.ts b/packages/cli/tests/integration/inspiration-intake-transition.test.ts
index b1336732c..ef1d1bcd9 100644
--- a/packages/cli/tests/integration/inspiration-intake-transition.test.ts
+++ b/packages/cli/tests/integration/inspiration-intake-transition.test.ts
@@ -11,7 +11,13 @@ import {
   inspirationActivationLines,
   validProductInspirationLines,
 } from '../fixtures/inspiration.js';
-import { expectHookAllow, expectHookDeny, type HookResult, writeGateConfig } from '../helpers';
+import {
+  createCurrentPlanningCheckerStub,
+  expectHookAllow,
+  expectHookDeny,
+  type HookResult,
+  writeGateConfig,
+} from '../helpers';
 
 const HOOK_PATH = nodePath.resolve(__dirname, '../../templates/hooks/pre-tool-quality.ts');
 const CODEX_HOOK_PATH = nodePath.resolve(
@@ -91,7 +97,12 @@ describe('activated intake inspiration transition wiring', () => {
     return writeThroughCodex(ticketFile, content, 'inspiration-codex-write');
   }
 
-  function writeThroughCodex(filePath: string, content: string, sessionId: string): HookResult {
+  function writeThroughCodex(
+    filePath: string,
+    content: string,
+    sessionId: string,
+    checkerCli?: string,
+  ): HookResult {
     const result = spawnSync('bun', [CODEX_HOOK_PATH], {
       cwd: projectRoot,
       input: JSON.stringify({
@@ -100,7 +111,11 @@ describe('activated intake inspiration transition wiring', () => {
         tool_input: { file_path: filePath, content },
       }),
       encoding: 'utf8',
-      env: { ...process.env, CLAUDE_PROJECT_DIR: projectRoot },
+      env: {
+        ...process.env,
+        CLAUDE_PROJECT_DIR: projectRoot,
+        ...(checkerCli !== undefined && { SAFEWORD_PLUGIN_CLI: checkerCli }),
+      },
     });
     return { status: result.status, stdout: result.stdout ?? '', stderr: result.stderr ?? '' };
   }
@@ -205,10 +220,20 @@ describe('activated intake inspiration transition wiring', () => {
       '<!-- safeword:inspiration-contract:v1 -->\n',
       '',
     );
-    expectHookDeny(
-      writeThroughCodex(specFile, specWithoutSignal, 'inspiration-remove-last-signal'),
-      'last inspiration-contract activation signal',
-    );
+    const checker = createCurrentPlanningCheckerStub();
+    try {
+      expectHookDeny(
+        writeThroughCodex(
+          specFile,
+          specWithoutSignal,
+          'inspiration-remove-last-signal',
+          checker.cli,
+        ),
+        'last inspiration-contract activation signal',
+      );
+    } finally {
+      rmSync(checker.directory, { recursive: true, force: true });
+    }
     expectHookDeny(advanceThroughCodex(), 'all three');
   });
 
diff --git a/packages/cli/tests/integration/installed-planning-copy-admission.test.ts b/packages/cli/tests/integration/installed-planning-copy-admission.test.ts
index a3162e3cf..bc67886a3 100644
--- a/packages/cli/tests/integration/installed-planning-copy-admission.test.ts
+++ b/packages/cli/tests/integration/installed-planning-copy-admission.test.ts
@@ -4,6 +4,7 @@ import {
   existsSync,
   mkdirSync,
   mkdtempSync,
+  readdirSync,
   readFileSync,
   rmSync,
   symlinkSync,
@@ -64,7 +65,8 @@ process.stdin.on('end', () => {
   const packet = JSON.parse(input.slice(input.lastIndexOf('{"schema_version":1')));
   console.log(JSON.stringify({ structured_output: {
     schema_version: 1, dispatch_id: packet.dispatch_id, reviewer_agent: 'claude',
-    verdict: 'approve', summary: 'Fixture approval.', findings: []
+    verdict: 'approve', summary: 'Fixture approval.', findings: [],
+    evidence_records: { schema_version: 1, records: [] }
   }}));
 });
 `,
@@ -172,10 +174,129 @@ process.stdin.on('end', () => {
   return { project, ticketPath, run, advance, root, distribution, environment };
 }
 
+const authoringPhases = [
+  {
+    phase: 'product-plan',
+    artifact: 'spec.md',
+    contract: 'DISCOVERY.md',
+    oldString: 'Product Plan',
+    ticketPhase: 'intake',
+  },
+  {
+    phase: 'plan-implementation',
+    artifact: 'impl-plan.md',
+    contract: 'PLAN_IMPLEMENTATION.md',
+    oldString: 'Preserve accepted behavior through one implementation.',
+    ticketPhase: 'plan-implementation',
+  },
+  {
+    phase: 'plan-execution',
+    artifact: 'execution-plan.md',
+    contract: 'PLAN_EXECUTION.md',
+    oldString: 'One step.',
+    ticketPhase: 'plan-execution',
+  },
+] as const;
+
+function alterAuthorCopy(asset: string, state: 'canonical' | 'comment drift' | 'missing copy') {
+  if (state === 'comment drift')
+    writeFileSync(asset, `<!-- authoring-copy drift -->\n${readFileSync(asset, 'utf8')}`);
+  else if (state === 'missing copy') rmSync(asset);
+}
+
+function alterReviewerCopy(distribution: string) {
+  const files = readdirSync(nodePath.join(distribution, 'dist')).filter(file =>
+    file.endsWith('.js'),
+  );
+  const runtime = files
+    .map(file => nodePath.join(distribution, 'dist', file))
+    .find(file => readFileSync(file, 'utf8').includes('var PLAN_REVIEW_RUBRIC = '));
+  if (runtime === undefined) throw new Error('Copied distribution lacks its reviewer rubric');
+  const source = readFileSync(runtime, 'utf8');
+  const start = source.indexOf('var PLAN_REVIEW_RUBRIC = ');
+  const end = source.indexOf('PLAN_REVIEW_RUBRIC_SHA256', start);
+  const clause = 'Accepted scope and exclusions belong to the user.';
+  const clauseIndex = source.indexOf(clause, start);
+  expect(clauseIndex).toBeGreaterThan(start);
+  expect(clauseIndex).toBeLessThan(end);
+  writeFileSync(runtime, source.slice(0, clauseIndex) + source.slice(clauseIndex + clause.length));
+}
+
 describe('Cursor installed planning copy admission', () => {
+  it.each(
+    authoringPhases.flatMap(phase =>
+      (['canonical', 'comment drift', 'missing copy'] as const).map(state => ({ ...phase, state })),
+    ),
+  )(
+    'checks $phase authoring copy with $state before an installed $artifact edit',
+    { timeout: 90_000 },
+    ({ phase, artifact, contract, oldString, ticketPhase, state }) => {
+      const installed = fixture();
+      if (ticketPhase !== 'plan-implementation') {
+        writeFileSync(
+          installed.ticketPath,
+          readFileSync(installed.ticketPath, 'utf8')
+            .split('phase: plan-implementation')
+            .join(`phase: ${ticketPhase}`),
+        );
+      }
+      const asset = nodePath.join(installed.project, '.safeword/skills/bdd', contract);
+      alterAuthorCopy(asset, state);
+      const planPath = nodePath.join(installed.project, '.project/tickets', folder, artifact);
+      if (artifact === 'execution-plan.md')
+        writeFileSync(planPath, '# Execution Plan\n\nOne step.\n');
+      const edited = spawnSync(
+        'bun',
+        [nodePath.join(installed.project, '.safeword/hooks/pre-tool-quality.ts')],
+        {
+          cwd: installed.project,
+          encoding: 'utf8',
+          timeout: 15_000,
+          env: installed.environment,
+          input: JSON.stringify({
+            tool_name: 'Edit',
+            tool_input: {
+              file_path: planPath,
+              old_string: oldString,
+              new_string: `${oldString} reviewed`,
+            },
+          }),
+        },
+      );
+      expect(edited.status, `${edited.stdout}\n${edited.stderr}`).toBe(0);
+      if (state === 'canonical') {
+        expect(edited.stdout.trim(), 'canonical authoring must remain available').toBe('');
+      } else {
+        const findingCode =
+          state === 'missing copy'
+            ? 'missing_generated_contract_copy'
+            : 'canonical_contract_copy_mismatch';
+        expect(
+          edited.stdout.trim(),
+          'installed plan authoring must refuse a drifted contract copy before the edit',
+        ).not.toBe('');
+        const output = JSON.parse(edited.stdout) as {
+          systemMessage?: string;
+          hookSpecificOutput?: { permissionDecision?: string; permissionDecisionReason?: string };
+        };
+        expect(output.hookSpecificOutput?.permissionDecision).toBe('deny');
+        expect(
+          output.systemMessage,
+          'a blocked author should see the contract mismatch without another command',
+        ).toContain(findingCode);
+        expect(output.hookSpecificOutput?.permissionDecisionReason).toContain(findingCode);
+        expect(output.hookSpecificOutput?.permissionDecisionReason).toContain(phase);
+        expect(output.hookSpecificOutput?.permissionDecisionReason).toContain(
+          `.safeword/skills/bdd/${contract}`,
+        );
+      }
+    },
+  );
+
   it.each([
     { state: 'canonical', permission: 'allow' },
     { state: 'comment drift', permission: 'deny' },
+    { state: 'reviewer rubric drift', permission: 'deny' },
     { state: 'project-writable cached runtime', permission: 'deny' },
   ] as const)(
     'checks $state at the installed Cursor adapter without plugin variables',
@@ -212,7 +333,7 @@ console.log(JSON.stringify({ schema_version: 1, ok: true, state: 'healthy', data
       const asset = nodePath.join(installed.project, '.safeword/skills/bdd/PLAN_IMPLEMENTATION.md');
       if (state === 'comment drift') {
         writeFileSync(asset, `<!-- cached-runtime copy drift -->\n${readFileSync(asset, 'utf8')}`);
-      }
+      } else if (state === 'reviewer rubric drift') alterReviewerCopy(installed.distribution);
       const environment: NodeJS.ProcessEnv = { ...installed.environment, CODEX_HOME: cacheHome };
       delete environment.SAFEWORD_PLUGIN_CLI;
       delete environment.CLAUDE_PLUGIN_ROOT;
@@ -246,15 +367,62 @@ console.log(JSON.stringify({ schema_version: 1, ok: true, state: 'healthy', data
       if (state === 'comment drift') {
         expect(checked.stdout).toContain('canonical_contract_copy_mismatch');
         expect(checked.stdout).toContain('.safeword/skills/bdd/PLAN_IMPLEMENTATION.md');
+      } else if (state === 'reviewer rubric drift') {
+        expect(checked.stdout).toContain('canonical_contract_copy_mismatch');
+        expect(checked.stdout).toContain('src/review/plan-rubric.generated.ts');
       }
       expect(existsSync(marker), 'project-writable authority must never execute').toBe(false);
     },
   );
 
-  it.each(['public approval', 'installed hook'] as const)(
-    'refuses project-copy drift at %s after an authenticated review',
+  it(
+    'refuses public plan approval when the generated reviewer rubric drifts',
+    { timeout: 90_000 },
+    () => {
+      const installed = fixture();
+      alterReviewerCopy(installed.distribution);
+      const approval = installed.run(['ticket', 'approve-plan', 'CPY123']);
+      expect(approval.status).not.toBe(0);
+      expect(approval.stdout).toContain('canonical_contract_copy_mismatch');
+      expect(approval.stdout).toContain('src/review/plan-rubric.generated.ts');
+      expect(readFileSync(installed.ticketPath, 'utf8')).toContain('phase: plan-implementation');
+    },
+  );
+
+  it(
+    'refuses to reuse an approved review after the reviewer copy drifts',
+    { timeout: 90_000 },
+    () => {
+      const installed = fixture();
+      alterReviewerCopy(installed.distribution);
+      const repeated = installed.run([
+        'review',
+        'run',
+        'plan-implementation',
+        `.project/tickets/${folder}/impl-plan.md`,
+        '--context',
+        `.project/tickets/${folder}/spec.md`,
+      ]);
+      expect(repeated.status).not.toBe(0);
+      const output = JSON.parse(repeated.stdout) as { effects?: { network?: unknown[] } };
+      expect(
+        output.effects?.network,
+        'review dispatch must refuse stale reviewer bytes before launch',
+      ).toEqual([]);
+      expect(repeated.stdout).toContain('canonical_contract_copy_mismatch');
+      expect(repeated.stdout).toContain('src/review/plan-rubric.generated.ts');
+    },
+  );
+
+  it.each([
+    ['public approval', 'comment drift'],
+    ['public approval', 'missing copy'],
+    ['installed hook', 'comment drift'],
+    ['installed hook', 'missing copy'],
+  ] as const)(
+    'refuses %s with %s after an authenticated review',
     { timeout: 90_000 },
-    boundary => {
+    (boundary, copyState) => {
       const project = fixture();
       const canonical =
         boundary === 'public approval'
@@ -277,10 +445,12 @@ console.log(JSON.stringify({ schema_version: 1, ok: true, state: 'healthy', data
         driftProject.project,
         '.safeword/skills/bdd/PLAN_IMPLEMENTATION.md',
       );
-      writeFileSync(
-        asset,
-        `<!-- installed-copy drift outside reviewer block -->\n${readFileSync(asset, 'utf8')}`,
-      );
+      if (copyState === 'missing copy') rmSync(asset);
+      else
+        writeFileSync(
+          asset,
+          `<!-- installed-copy drift outside reviewer block -->\n${readFileSync(asset, 'utf8')}`,
+        );
       const drifted =
         boundary === 'public approval'
           ? driftProject.run(['ticket', 'approve-plan', 'CPY123'])
@@ -294,7 +464,11 @@ console.log(JSON.stringify({ schema_version: 1, ok: true, state: 'healthy', data
         refused,
         'installed lifecycle must refuse project author-copy drift after authenticated approval',
       ).toBe(true);
-      expect(`${drifted.stdout}\n${drifted.stderr}`).toContain('canonical_contract_copy_mismatch');
+      expect(`${drifted.stdout}\n${drifted.stderr}`).toContain(
+        copyState === 'missing copy'
+          ? 'missing_generated_contract_copy'
+          : 'canonical_contract_copy_mismatch',
+      );
       expect(`${drifted.stdout}\n${drifted.stderr}`).toContain(
         '.safeword/skills/bdd/PLAN_IMPLEMENTATION.md',
       );
diff --git a/packages/cli/tests/integration/native-planning-copy-dispatch.test.ts b/packages/cli/tests/integration/native-planning-copy-dispatch.test.ts
index 348492cc3..3a721d060 100644
--- a/packages/cli/tests/integration/native-planning-copy-dispatch.test.ts
+++ b/packages/cli/tests/integration/native-planning-copy-dispatch.test.ts
@@ -40,7 +40,8 @@ process.stdin.on('end', () => {
   require('node:fs').appendFileSync(${JSON.stringify(calls)}, 'review' + String.fromCharCode(10));
   process.stdout.write(JSON.stringify({ structured_output: {
     schema_version: 1, dispatch_id: packet.dispatch_id, reviewer_agent: 'claude',
-    verdict: 'approve', summary: 'Native copy fixture approval.', findings: []
+    verdict: 'approve', summary: 'Native copy fixture approval.', findings: [],
+    evidence_records: { schema_version: 1, records: [] }
   }}));
 });
 `,
diff --git a/packages/cli/tests/integration/plan-design-approval.test.ts b/packages/cli/tests/integration/plan-design-approval.test.ts
index f967f3a91..dab3963ba 100644
--- a/packages/cli/tests/integration/plan-design-approval.test.ts
+++ b/packages/cli/tests/integration/plan-design-approval.test.ts
@@ -34,6 +34,7 @@ import {
 import { appendDesignDecision } from '../../src/review/approval-ledger.js';
 import { hashArtifact, reviewScope } from '../../templates/hooks/lib/review-ledger.js';
 import { assertTestCliFresh, runCli, testCliPath } from '../helpers.js';
+import { PLANNING_ROLE_PRODUCT, writeImplementationRoleInputs } from '../planning-role-fixtures.js';
 
 const TICKET_ID = 'PLAN42';
 const TICKET_FOLDER = `${TICKET_ID}-review-the-approach`;
@@ -189,7 +190,24 @@ function projectFiles(directory: string, root = directory): string[] {
   });
 }
 
-function fixture(designApprovalGate: boolean, reviewState: ReviewState = 'approved'): Fixture {
+function supplyCurrentContext(root: string, ticketDirectory: string, enabled: boolean): void {
+  if (!enabled) return;
+  writeFileSync(
+    nodePath.join(ticketDirectory, 'spec.md'),
+    `${PLANNING_ROLE_PRODUCT}\n## Surfaces\n\nAffected:\n- Safeword CLI\n`,
+  );
+  writeImplementationRoleInputs(
+    root,
+    `${nodePath.relative(root, ticketDirectory)}/impl-plan.md`,
+    'review-the-approach.feature',
+  );
+}
+
+function fixture(
+  designApprovalGate: boolean,
+  reviewState: ReviewState = 'approved',
+  currentContext = false,
+): Fixture {
   const root = mkdtempSync(nodePath.join(tmpdir(), 'safeword-plan-approval-'));
   fixtures.push(root);
   const ticketDirectory = nodePath.join(root, '.project', 'tickets', TICKET_FOLDER);
@@ -222,6 +240,13 @@ function fixture(designApprovalGate: boolean, reviewState: ReviewState = 'approv
       'type: feature',
       'phase: plan-implementation',
       'status: in_progress',
+      ...(currentContext
+        ? [
+            'product_plan_contract: v1',
+            'phase_anchors:',
+            '  - scenario-gate: features/review-the-approach.feature',
+          ]
+        : []),
       'scope: review one approach',
       'out_of_scope: unrelated work',
       'done_when: execution planning begins safely',
@@ -237,6 +262,7 @@ function fixture(designApprovalGate: boolean, reviewState: ReviewState = 'approv
     nodePath.join(root, 'features', 'review-the-approach.feature'),
     'Feature: Review the approach\n',
   );
+  supplyCurrentContext(root, ticketDirectory, currentContext);
   writeFileSync(
     nodePath.join(root, '.safeword', 'templates', 'execution-plan-template.md'),
     EXECUTION_PLAN_TEMPLATE,
@@ -283,7 +309,8 @@ function fixture(designApprovalGate: boolean, reviewState: ReviewState = 'approv
   const reviewId = payload.data?.review_id;
   if (reviewId === undefined)
     throw new Error(`Implementation Plan review failed: ${reviewed.stdout}`);
-  const scope = reviewScope(TICKET_FOLDER, 'impl-plan', hashArtifact(PLAN));
+  const currentPlan = readFileSync(nodePath.join(ticketDirectory, 'impl-plan.md'), 'utf8');
+  const scope = reviewScope(TICKET_FOLDER, 'impl-plan', hashArtifact(currentPlan));
   const existingLedger = readFileSync(ledgerPath, 'utf8');
   writeFileSync(
     ledgerPath,
@@ -533,7 +560,7 @@ dispatch_id=$(printf '%s' "$payload" | /usr/bin/sed -n 's/.*"dispatch_id":"\([^"
 if printf '%s' "$payload" | /usr/bin/grep -Fq '"kind":"plan-execution"'; then
   review_record=$(printenv SAFEWORD_REVIEW_FAKE_EXECUTION_PLAN_RECORD || true)
   if [ -n "$review_record" ]; then
-    printf '{"schema_version":1,"dispatch_id":"%s","reviewer_agent":"claude","verdict":"approve","summary":"replan approved","findings":[],"planning_destination":"plan-execution","execution_plan_record":%s}\n' "$dispatch_id" "$review_record"
+    printf '{"schema_version":1,"dispatch_id":"%s","reviewer_agent":"claude","verdict":"approve","summary":"replan approved","findings":[],"evidence_records":{"schema_version":1,"records":[]},"planning_destination":"plan-execution","execution_plan_record":%s}\n' "$dispatch_id" "$review_record"
     exit 0
   fi
   if printf '%s' "$payload" | /usr/bin/grep -Fq 'Accepted authorization approach changed'; then
@@ -541,15 +568,15 @@ if printf '%s' "$payload" | /usr/bin/grep -Fq '"kind":"plan-execution"'; then
   else
     destination=plan-execution
   fi
-  printf '{"schema_version":1,"dispatch_id":"%s","reviewer_agent":"claude","verdict":"request_changes","summary":"implementation discovery","findings":[{"severity":"error","message":"Repair the affected plan."}],"planning_destination":"%s","execution_plan_record":null}\n' "$dispatch_id" "$destination"
+  printf '{"schema_version":1,"dispatch_id":"%s","reviewer_agent":"claude","verdict":"request_changes","summary":"implementation discovery","findings":[{"severity":"error","message":"Repair the affected plan."}],"evidence_records":{"schema_version":1,"records":[]},"planning_destination":"%s","execution_plan_record":null}\n' "$dispatch_id" "$destination"
   exit 0
 fi
 if [ "${'$'}{SAFEWORD_REVIEW_FAKE_VERDICT:-approve}" = "request_changes" ]; then
-  printf '{"schema_version":1,"dispatch_id":"%s","reviewer_agent":"claude","verdict":"request_changes","summary":"plan is blocked","findings":[{"severity":"error","message":"Authorization boundary is missing."}]}\n' "$dispatch_id"
+  printf '{"schema_version":1,"dispatch_id":"%s","reviewer_agent":"claude","verdict":"request_changes","summary":"plan is blocked","findings":[{"severity":"error","message":"Authorization boundary is missing."}],"evidence_records":{"schema_version":1,"records":[]}}\n' "$dispatch_id"
 elif [ "${'$'}{SAFEWORD_REVIEW_FAKE_FINDING:-}" = "1" ]; then
-  printf '{"schema_version":1,"dispatch_id":"%s","reviewer_agent":"claude","verdict":"approve","summary":"plan is approved with advice","findings":[{"severity":"warning","message":"Consider documenting the optional recovery example."}]}\n' "$dispatch_id"
+  printf '{"schema_version":1,"dispatch_id":"%s","reviewer_agent":"claude","verdict":"approve","summary":"plan is approved with advice","findings":[{"severity":"warning","message":"Consider documenting the optional recovery example."}],"evidence_records":{"schema_version":1,"records":[]}}\n' "$dispatch_id"
 else
-  printf '{"schema_version":1,"dispatch_id":"%s","reviewer_agent":"claude","verdict":"approve","summary":"plan is approved","findings":[]}\n' "$dispatch_id"
+  printf '{"schema_version":1,"dispatch_id":"%s","reviewer_agent":"claude","verdict":"approve","summary":"plan is approved","findings":[],"evidence_records":{"schema_version":1,"records":[]}}\n' "$dispatch_id"
 fi
 `,
     { mode: 0o755 },
@@ -679,7 +706,7 @@ describe('implementation-time discoveries return to the affected planning phase'
   ] as const)(
     'routes %s repair from implementation through the installed CLI',
     async (discovery, planningDestination, expectedPhase) => {
-      const project = fixture(false);
+      const project = fixture(false, 'approved', true);
       writeFileSync(
         project.ticketPath,
         readFileSync(project.ticketPath, 'utf8').replace(
@@ -733,7 +760,14 @@ describe('implementation-time discoveries return to the affected planning phase'
       expect(result.stdout).toContain(`"planning_destination":"${planningDestination}"`);
 
       if (planningDestination === 'plan-implementation') {
-        const revisedImplementationPlan = `${PLAN}\nAccepted authorization uses the revised boundary.\n`;
+        const currentImplementationPlan = readFileSync(
+          nodePath.join(project.ticketDirectory, 'impl-plan.md'),
+          'utf8',
+        );
+        const revisedImplementationPlan = currentImplementationPlan.replace(
+          '## Decisions\n',
+          '## Decisions\n\nAccepted authorization uses the revised boundary.\n',
+        );
         writeFileSync(
           nodePath.join(project.ticketDirectory, 'impl-plan.md'),
           revisedImplementationPlan,
@@ -799,6 +833,92 @@ describe('implementation-time discoveries return to the affected planning phase'
   );
 });
 
+describe('repair must precede renewed planning approval', () => {
+  it('refuses reuse of the old current-context approval after an execution discovery', async () => {
+    const project = fixture(false, 'approved', true);
+    const args = ['--json', '--no-input', 'ticket', 'approve-plan', TICKET_ID];
+    const accepted = await runCli(args, { cwd: project.root, env: reviewEnvironment(project) });
+    expect(accepted.exitCode, accepted.stdout).toBe(0);
+    expect(phase(project.ticketPath)).toBe('plan-execution');
+    writeFileSync(
+      project.ticketPath,
+      readFileSync(project.ticketPath, 'utf8').replace('phase: plan-execution', 'phase: implement'),
+    );
+    const executionPlanPath = nodePath.join(project.ticketDirectory, 'execution-plan.md');
+    writeFileSync(
+      executionPlanPath,
+      replanExecutionPlan('Accepted authorization approach changed'),
+    );
+    const reviewerBin = installBlockingReviewer();
+    const reviewed = await runCli(
+      [
+        '--json',
+        '--no-input',
+        'review',
+        'run',
+        'plan-execution',
+        nodePath.relative(project.root, executionPlanPath),
+        '--context',
+        nodePath.relative(project.root, nodePath.join(project.ticketDirectory, 'impl-plan.md')),
+        '--context',
+        'features/review-the-approach.feature',
+        '--cwd',
+        project.root,
+      ],
+      {
+        cwd: project.root,
+        env: {
+          PATH: `${reviewerBin}:/usr/bin:/bin`,
+          SAFEWORD_AGENT_RUNTIME: 'codex',
+          SAFEWORD_NO_UPDATE_CHECK: '1',
+          SAFEWORD_REVIEW_FOREGROUND_MS: '5000',
+          ...reviewEnvironment(project),
+        },
+      },
+    );
+    expect(reviewed.exitCode, reviewed.stdout).toBe(2);
+    expect(reviewed.stdout).toContain('"planning_destination":"plan-implementation"');
+    const returned = await runCli(args, { cwd: project.root, env: reviewEnvironment(project) });
+    expect(returned.exitCode, returned.stdout).toBe(2);
+    expect(phase(project.ticketPath)).toBe('plan-implementation');
+    const unrepaired = await runCli(args, { cwd: project.root, env: reviewEnvironment(project) });
+    expect(unrepaired.exitCode, unrepaired.stdout).toBe(2);
+    expect(unrepaired.stdout).toContain(
+      'no current authenticated Implementation Plan review receipt',
+    );
+    expect(phase(project.ticketPath)).toBe('plan-implementation');
+  });
+});
+
+describe('legacy review reuse after a planning return', () => {
+  it('preserves an untouched legacy review but refuses it after a recorded discovery', async () => {
+    const project = fixture(false);
+    const legacyId = 'PLAN43';
+    addReviewedTicket(project, legacyId, 'The retained legacy approach.');
+    const legacyPath = nodePath.join(
+      project.root,
+      '.project',
+      'tickets',
+      `${legacyId}-review-the-approach`,
+      'ticket.md',
+    );
+    const args = ['--json', '--no-input', 'ticket', 'approve-plan', legacyId];
+    const untouched = await runCli(args, { cwd: project.root, env: reviewEnvironment(project) });
+    expect(untouched.exitCode, untouched.stdout).toBe(0);
+    writeFileSync(
+      legacyPath,
+      `${readFileSync(legacyPath, 'utf8').replace(
+        'phase: plan-execution',
+        'phase: plan-implementation',
+      )}\n### Execution discovery requiring fresh planning review\n\n> Repair the accepted authorization boundary.\n`,
+    );
+    const returned = await runCli(args, { cwd: project.root, env: reviewEnvironment(project) });
+    expect(returned.exitCode, returned.stdout).toBe(2);
+    expect(phase(legacyPath)).toBe('plan-implementation');
+    expect(returned.stdout).toContain('Convert its retained plan and design decisions');
+  });
+});
+
 describe('an accepted design enters Execution Planning', () => {
   it('binds the approval to the exact approach bytes before advancing', () => {
     const project = fixture(true);
