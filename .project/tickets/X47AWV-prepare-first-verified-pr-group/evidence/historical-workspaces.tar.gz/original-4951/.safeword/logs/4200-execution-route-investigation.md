# Execution reviewer route investigation

Decision: restore usable Execution review without treating one model's passing
matrix as another model's approval authority.

Investigation questions:

1. Accepted review contract: must the installed default dispatch independently,
   and can an explicit override replace a default? Read the accepted 5F5ZZA plan,
   current policy, configuration parser, and failing public-CLI results.
2. Model identity and authorization: can a moving alias share an exact model's
   evidence? Check current official model configuration, native runtime-confirmed
   identity, and exact admission matching. Preserve require/prefer semantics.
3. Qualification and cost: does the existing exact Claude capability selector
   pass the unchanged 63-case task corpus? First check one actual exact-selector
   dispatch; only a complete passing matrix can admit it. Do not hunt models,
   broaden aliases, change the corpus, or rerun Astra without changed binding.
4. Test boundary and scope: which failing fixtures assume a default reviewer,
   and can their intended behavior be tested with the actually admitted exact
   route while mocking only the reviewer process? Any existing test changes
   require an exact prepared patch and human approval. Legacy migration remains
   separately owned and cannot be hidden by a route correction.

Options to compare:

- Retain explicit Astra-only configuration and document default Execution review
  as unavailable. Smallest code change, but leaves ordinary installed workflows
  and four public-CLI cases blocked.
- Qualify the existing exact Claude selector and use exact qualified defaults
  only for Execution review. Reuses current admission/routing; adds one bounded
  matrix and a small routing change, preserving explicit project overrides.
- Admit aliases or Claude from Astra results. Reject: no evidence supports that
  authorization, and moving aliases can change the actual reviewer.

Current evidence: admission contains only Codex `gpt-6-astra`; both canonical
digests still match after main. Four current targeted failures report zero
eligible routes before dispatch. Current policy uses Claude `opus` and unnamed
Codex defaults. Existing capability evidence names `claude-opus-5` and
`gpt-6-astra`, but capability evidence alone is not task conformance.

Primary references:

- https://code.claude.com/docs/en/model-config — aliases move; full identifiers
  can pin a version; startup options need not change personal settings.
- https://code.claude.com/docs/en/cli-reference — explicit model arguments.
- https://cheatsheetseries.owasp.org/cheatsheets/Authorization_Cheat_Sheet.html —
  default denial and validated authorization on each operation.

Premortem for exact defaults: a later corpus or prompt change makes the selected
model's evidence stale. The existing digest checks must refuse it rather than
silently approve through an alias. No new admission mechanism is needed.

Full CI widens the route census: at source `82c6c830c`, both Node jobs report
43 failed, 11312 passed, and 10 skipped. Eight files fail, with many cases
blocked before reviewer dispatch. The two stale documentation mirrors are
separately repaired and parity now passes. Neither repair qualifies a model.

Exact Claude `claude-opus-5` probe passed its identity guard and one semantic
case (2 tests, 62 filtered). Full qualification now runs at source
`b4ebcd03656bf8383aa164983c415b91e076fc9c`, without a case selector, using the
unchanged corpus and native authenticated default Claude profile. Artifact
destinations are `/tmp/4200-claude-exact-full-live.log` and
`/tmp/4200-claude-exact-full-results.json`. An unfinished matrix cannot admit
the model, and a failed case cannot be hidden by changing its oracle.

Routing implementation constraint, if the complete matrix passes: retain the
existing agent order and project/user/environment overrides, but supply exact
qualified model defaults only for Execution review. Keep ordinary quality and
Implementation defaults unchanged. Use the existing final admission filter
to enforce current contract/corpus binding. Do not introduce a second route
registry, automatically qualify moving aliases, or enable an unproven model.
Characterize configured-route precedence, primary-model overrides, independent
fallback and same-agent fallback in the same route builder before changing it.

No model has been admitted, default changed, fixture weakened, migration policy
changed, PR promoted, or PR merged by this investigation.

Continuation: the original full Claude matrix has produced four observed
failures (omitted prerequisites, missing final proof success, reopened
authorization destination, and invented storage ownership destination). Blind
triage confirms the original requirements; no oracle correction is justified.
The disposable worktree `/private/tmp/4200-prerequisites-probe` contains a small
clarification of those existing requirements. Native v1/v2/v3 probes preserve
the cases and produce the expected outcomes, but they do not qualify a model.
The candidate patch is retained at `/tmp/4200-review-contract-candidate-v3.patch`.
A full unchanged 63-case candidate Claude run was queued behind the original
matrix, then cancelled before dispatch after the fifth failure exposed a
misleading golden-fixture rationale. Independent diagnosis
`7c53be83-1d79-410a-9bd0-59e25ef3cae3` confirms the current rationale falsely
calls the whole complete-delivery slice a fixture-only repair; a truthful
capability-and-incidental-repair rationale preserves its intended boundary.
The one-line patch `/tmp/4200-fixture-discovery-rationale.patch` was explicitly
approved on 2026-10-07 and applied to the root and disposable candidate worktrees.
The original matrix continues without changing any input. After any approved
fixture correction, both models need complete fresh qualification against the
changed corpus and candidate contract before admission; no old result carries
forward merely because the expected verdict is unchanged.
The original failed matrix and every unfinished acceptance obligation remain
visible. No production prompt or routing change has been applied.

2026-10-07 continuation: the original Claude matrix completed with 57 passing,
6 failing, and 0 unfinished cases; its results and raw failures remain retained.
The candidate clarification plus approved rationale correction is frozen in
`/tmp/4200-review-contract-candidate-approved.patch`. Complete fresh native Claude
qualification runs without a case filter and writes to
`/tmp/4200-claude-candidate-approved-live.log` and
`/tmp/4200-claude-candidate-approved-results.json`. It has not qualified a model.
Root routing now has an uncommitted Execution-only exact-default draft; the
existing admission filter remains authoritative and no new admission was written.
Its named baseline test failed before implementation; the draft passes TypeScript,
but behavioral verification waits for the sole live Vitest runner to finish.
Current PR2, PR3, and PR4 CI checks pass at their documentation-restacked heads.
Current PR5 CI retains 43 failures, 11313 passes, and 10 skips per Node job.
The unchanged source corpus fixture correction does not repair these failures.
Legacy approval reuse remains open and separately owned by YCFFNC; no deferral
has been inferred from R7's unrelated accepted host-proof deferral.

The candidate full matrix has now finished: 53 passing, 10 failing, and zero
unfinished cases. Seven failures timed out, one was a reviewer process failure,
and two produced semantic rejections. It does not qualify Claude. The two
semantic outputs are retained verbatim; fresh diagnostic review
dd916abc-c4c0-432d-8483-279ff5328b06 approves both existing packets while naming
the Activation proof-list mismatch as a warning. A review of proposed factual
clarifications, 7d1bc819-bc94-422c-9afa-f55ebe5a351f, approves their direction
and flags input wording that states the desired judgment. The prepared patch
removes that evaluative wording, anchors the pre-refactor snapshots, and remains
unapplied pending explicit fixture-change approval. No expectation is relaxed.
Fresh review of the final prepared patch is pending.
Final prepared-patch review 14095c84-a6fc-4da2-982b-3e5f453e325e now approves
the type-correct patch. A full package typecheck with the patch applied only in
memory also passes. The real corpus is unchanged pending human approval.
Disposition: keep current admission refused until complete fresh qualification;
the absolute path is intentional for this local approval artifact; the optional
task-list fallback matches existing fixture construction. The reviewer also
records the separate denied migration case's seven-versus-six proof mismatch as
an out-of-scope warning. It remains visible, not silently repaired or claimed
as a discriminating proof of migration completion.

The uncommitted exact-default route implementation now passes 41 focused tests,
TypeScript, and all five generated-surface checks. Its admission filter remains
fail-closed; the approved rationale change makes historical corpus-bound
qualification insufficient for the current local source. The combined approval
and routing run retains three Execution-admission failures (76 passes), and
published PR5 CI still retains 43 failures per Node job.

The user chose to fix legacy reuse. A bounded guard implements the existing
current-contract requirement after a recorded Execution discovery; it does not
claim to complete legacy migration. Its current-root public-CLI regression was
RED (incorrect exit 0) and is now GREEN (untouched legacy success plus returned
legacy refusal). The external source review exhausted its route on timeout;
the one constrained fresh-context fallback lacked file-read capability. One
main-thread supplemental review approved the bounded guard with a proof-limit
warning, under prefer, with no independent coverage or machine review stamp.
The complete discovery-return journey and this child's 28 migration scenarios
remain unfinished.
