---
id: V2ZPV1
slug: recover-accurate-completion-evidence
type: task
phase: intake
status: in_progress
created: 2026-10-11T15:02:08.137Z
last_modified: 2026-10-11T15:02:08.137Z
---

# Recover accurate completion evidence for contributors

**Goal:** Define a bounded, authenticated recovery path for mistaken ledger annotations and already-implemented behavior without inventing historical TDD proof.

**Why:** Epic #4200 remains formally blocked because checked evidence cannot be corrected and existing retrospective certification is restricted to CKWE2D.

## Work Log

- 2026-10-11T15:02:08.137Z Started: Created ticket V2ZPV1

- 2026-10-11T15:02:08.137Z Decision: User authorized a separate recovery follow-on. This ticket records the problem and investigation scope; no recovery mechanism or policy override has been implemented.
- 2026-10-11T15:02:08.137Z Verified: Current-head CI run 38119088729 completed successfully for b722f9a27. CI does not resolve the ledger blocker or establish full-stack review readiness.

## Scope

Investigate the smallest authenticated recovery path for two concrete problems in 5F5ZZA, part of epic #4200:

- Correct the mistaken checked REFACTOR annotation for “A declared change invalidates exactly its dependent reviews.” GREEN and REFACTOR both name 15a7c84aa. No separate refactor was warranted; the intended annotation was a documented skip. Preserve the original entry and correction history.
- Certify already-implemented behavior using current evidence without claiming historical RED that was never recorded. The existing retrospective route is restricted to CKWE2D and cannot authorize 5F5ZZA.

Do not disable immutable-evidence guards, introduce a blanket waiver, borrow another ticket's receipts, mark deferred cases passed, or expand OpenCode/cloud verification. Do not merge or promote any PR. Keep this recovery work separate from the implementation PR stack.

## Acceptance Criteria

- Define a reviewed, bounded recovery contract that distinguishes historical TDD evidence, current verification, evidence corrections, and unverified deferrals.
- Identify the exact original annotation, proposed correction, authenticated authority, and durable audit record; reject unauthorized or unrelated evidence changes.
- Demonstrate that certification cannot fabricate historical RED or reuse CKWE2D-only authority for another ticket.
- Preserve visibility of 5F5ZZA's 137 unchecked entries and all 33 deferred cases. Explain which entries remain unresolved after recovery rather than mass-checking them.
- Record the smallest implementation proposal and its tests before changing the trust policy. Completion of this ticket's intake is not completion of epic #4200.

## Related Evidence

- [Blocked ticket](../5F5ZZA-keep-plan-reviews-current-and-trustworthy/ticket.md) and its adjacent test-definitions.md ledger.
- PR #5139: https://github.com/ArcadeAI/safeword/pull/5139
- Green current-head CI: https://github.com/ArcadeAI/safeword/actions/runs/38119088729
- Recovery options: `.safeword/logs/4200-ledger-recovery-options.md`.
- Evidence census and correction history: `.safeword/logs/4200-oct10-final-evidence.md`.
- Existing guards: `packages/cli/templates/hooks/pre-tool-quality.ts` (`historicalEvidenceRemoved`), `packages/cli/templates/hooks/lib/ledger-validation.ts` (SHA collision), and `packages/cli/src/review/retrospective-close.ts` (CKWE2D-only closing proof).
