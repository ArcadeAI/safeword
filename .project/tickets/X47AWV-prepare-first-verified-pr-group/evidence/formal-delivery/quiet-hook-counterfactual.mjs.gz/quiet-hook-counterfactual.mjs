import { readFileSync } from 'node:fs';
import { runInNewContext } from 'node:vm';
import { strict as assert } from 'node:assert';
import ts from '/Users/alex/.codex/worktrees/4200-first-merge-group/safeword/packages/cli/node_modules/typescript/lib/typescript.js';
const source = readFileSync('packages/cli/tests/integration/post-tool-review.test.ts', 'utf8');
const helper = source.slice(source.indexOf('function run('), source.indexOf('function ticketPath('));
const javascript = ts.transpile(helper);
const failure = { status: null, signal: 'SIGTERM', error: new Error('controlled timeout'), stdout: '', stderr: '' };
const expect = (actual, message) => ({ toBe: expected => assert.equal(actual, expected, message) });
try {
  const result = runInNewContext(`${javascript}\nrun('/fixture', 'Edit', {});`, { spawnSync: () => failure, POST_TOOL_QUALITY: '/hook', process: {env:{}}, expect });
  assert.equal(result.context, undefined);
  console.log('FALSE QUIET PASS: actual helper accepts failed child with empty stdout');
  process.exitCode = 1;
} catch (error) {
  if (!String(error).includes('controlled timeout')) throw error;
  console.log('FAILED CHILD REJECTED: actual helper preserves controlled timeout diagnostics');
}
