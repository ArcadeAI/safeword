import { createRequire } from 'node:module';
import { readFileSync } from 'node:fs';
import { strict as assert } from 'node:assert';
const require = createRequire(`${process.cwd()}/packages/cli/package.json`);
const ts = require('typescript');
const {Parser,AstBuilder,GherkinClassicTokenMatcher} = require('@cucumber/gherkin');
const {IdGenerator} = require('@cucumber/messages');
const adapter = ts.createSourceFile('steps.ts',readFileSync('steps/turn-decisions-into-startable-work.steps.ts','utf8'),ts.ScriptTarget.Latest,true);
const names = new Set();
function walk(node) {
  if (ts.isPropertyAssignment(node) && ts.isStringLiteral(node.name) && ts.isObjectLiteralExpression(node.initializer)) {
    if (node.initializer.properties.some(p=>ts.isPropertyAssignment(p) && p.name.getText(adapter)==='testFile' && ts.isStringLiteral(p.initializer) && p.initializer.text==='tests/review/execution-plan-conformance.test.ts')) names.add(node.name.text);
  }
  ts.forEachChild(node,walk);
}
walk(adapter);
assert.ok(names.size>0);
const doc = new Parser(new AstBuilder(IdGenerator.incrementing()),new GherkinClassicTokenMatcher()).parse(readFileSync('features/turn-decisions-into-startable-work.feature','utf8'));
let checked=0;
function scenarios(children,tags=[]) {
  for(const child of children) {
    if(child.rule) scenarios(child.rule.children,[...tags,...child.rule.tags]);
    if(child.scenario && names.has(child.scenario.name)) {
      assert.ok([...tags,...child.scenario.tags].some(t=>t.name==='@live'),child.scenario.name);
      checked++;
    }
  }
}
scenarios(doc.feature.children,doc.feature.tags);
assert.equal(checked,names.size);
console.log(`${checked} corpus-backed scenario definitions all carry @live; the default not-@live filter excludes them.`);
