(
  safeword_plan_status=0
  ( cd '/Users/alex/.codex/worktrees/19aa/safeword' && bun run test ) || { safeword_lane_status=$?; [ "$safeword_plan_status" -ne 0 ] || safeword_plan_status=$safeword_lane_status; }
  ( cd '/Users/alex/.codex/worktrees/19aa/safeword/packages/retro-collector' && bun run test ) || { safeword_lane_status=$?; [ "$safeword_plan_status" -ne 0 ] || safeword_plan_status=$safeword_lane_status; }
  ( cd '/Users/alex/.codex/worktrees/19aa/safeword/packages/cli' && bun run test ) || { safeword_lane_status=$?; [ "$safeword_plan_status" -ne 0 ] || safeword_plan_status=$safeword_lane_status; }
  ( cd '/Users/alex/.codex/worktrees/19aa/safeword/experiments/go-skill-directive/checker' && go test ./... ) || { safeword_lane_status=$?; [ "$safeword_plan_status" -ne 0 ] || safeword_plan_status=$safeword_lane_status; }
  exit "$safeword_plan_status"
)
