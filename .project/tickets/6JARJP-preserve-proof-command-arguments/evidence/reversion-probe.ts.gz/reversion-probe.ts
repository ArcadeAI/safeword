import assert from 'node:assert/strict';
import { mkdtempSync, readFileSync, writeFileSync, rmSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { execFileSync } from 'node:child_process';
const root = '/Users/alex/.codex/worktrees/a7c8/safeword';
const scratch = mkdtempSync('/tmp/6jarjp-test-assessment-');
const source = (path: string, baseline = false) => baseline ? execFileSync('git', ['show', `ca452a9cc:${path}`], {cwd: root, encoding: 'utf8'}) : readFileSync(join(root, path), 'utf8');
const paths = { checklist: 'packages/cli/src/execution-plan/delivery-checklist.ts', output: 'packages/cli/src/review/execution-plan-output.ts' };
function stage(name: string, content: string) {
 const path = join(scratch, name + '.ts');
 content = content.replaceAll("'../execution-plan/delivery-checklist.js'", JSON.stringify(join(root, paths.checklist)))
   .replaceAll("'./review-identity.js'", JSON.stringify(join(root, 'packages/cli/src/execution-plan/review-identity.ts')));
 writeFileSync(path, content); return path;
}
function proofPlan(argv: unknown) {
 const json = JSON.stringify({type: 'command', cwd: '.', argv}).replaceAll('|', String.raw`\|`);
 return ['## Proof specifications', '', '| Proof ID | Method | Scope | Boundary exercised | Qualifies as | Currency | Invocation |', '| --- | --- | --- | --- | --- | --- | --- |', `| proof | command | unit | parser | real_boundary | current_required | ${json} |`, ''].join('\n');
}
try {
 const modules = { currentChecklist: stage('current-checklist', source(paths.checklist)), oldChecklist: stage('baseline-checklist', source(paths.checklist, true)), currentOutput: stage('current-output', source(paths.output)), oldOutput: stage('baseline-output', source(paths.output, true)), mutant: stage('extra-keys-mutant', source(paths.output).replace("if (!hasExactKeys(value, ['type', 'cwd', 'argv']))", 'if (false)')) };
 const mutationReturn = "return { kind: 'approved', output: { ...output, execution_plan_record: validatedCandidate } };";
 const inPlacePath = stage('in-place-mutant', source(paths.output).replace(mutationReturn,
   "validatedCandidate.delivery_definition.proof_specifications[0].invocation.argv.push('unexpected');\n  " + mutationReturn));
 const tests = readFileSync(join(root, 'packages/cli/tests/review/execution-plan-output.test.ts'), 'utf8');
 const fixture = tests.slice(tests.indexOf('function validRecord()'), tests.indexOf('\nfunction approval('));
 const fixturePath = stage('fixture', `import { DELIVERY_CHECKLIST_CATEGORIES } from ${JSON.stringify(join(root, paths.checklist))};\nconst nullRecord = null;\nexport ${fixture}`);
 const currentChecklist = await import(modules.currentChecklist);
 const oldChecklist = await import(modules.oldChecklist);
 const currentOutput = await import(modules.currentOutput);
 const oldOutput = await import(modules.oldOutput);
 const fixtureModule = await import(fixturePath);
 const approval = (argv: unknown) => { const record = fixtureModule.validRecord(); record.delivery_definition.proof_specifications[0].invocation.argv = argv; return {schema_version:1, dispatch_id:'probe', reviewer_agent:'claude', verdict:'approve', summary:'probe', findings:[], planning_destination:'plan-execution', execution_plan_record:record}; };
 const cases = [
  {name:'repeated flags / reviewer validator', argv:['cargo','test','--test','one','--test','two'], mode:'output', check:(m:any, argv:unknown)=>m.validateExecutionPlanOutput(approval(argv)).kind === 'approved'},
  {name:'empty operands / reviewer validator', argv:['node','-e','',' '], mode:'output', check:(m:any, argv:unknown)=>m.validateExecutionPlanOutput(approval(argv)).kind === 'approved'},
  {name:'empty operands / table parser', argv:['node','-e','',' '], mode:'checklist', check:(m:any, argv:unknown)=>m.parseProofSpecifications(proofPlan(argv)).ok === true},
  {name:'JSON backslashes and pipe round trip', argv:['node','-e',String.raw`console.log(/\d|b/, "C:\\tmp")`], mode:'checklist', check:(m:any, argv:unknown)=>{ const r=m.parseProofSpecifications(proofPlan(argv)); return r.ok && JSON.stringify(r.specifications[0].invocation.argv)===JSON.stringify(argv); }},
  {name:'blank executable rejection / table parser', argv:[' ','test'], mode:'checklist', check:(m:any, argv:unknown)=>m.parseProofSpecifications(proofPlan(argv)).ok === false},
  {name:'field-specific malformed argv diagnostic', argv:['node',1], mode:'output', check:(m:any, argv:unknown)=>{const r=m.validateExecutionPlanOutput(approval(argv));return r.kind==='invalid_output' && r.reason?.includes('invocation.argv');}},
 ];
 for (const test of cases) {
  const now = test.check(test.mode === 'output' ? currentOutput : currentChecklist, test.argv);
  const before = Boolean(test.check(test.mode === 'output' ? oldOutput : oldChecklist, test.argv));
  assert.equal(now,true, test.name + ' current must pass'); assert.equal(before,false,test.name + ' baseline must fail');
  console.log('DETECTED baseline reversion:',test.name);
 }
 const missingExactKeys = await import(modules.mutant);
 const extraOutput = approval(['node']); extraOutput.execution_plan_record.delivery_definition.proof_specifications[0].invocation.extra = true;
 assert.equal(currentOutput.validateExecutionPlanOutput(extraOutput).kind,'invalid_output');
 assert.equal(missingExactKeys.validateExecutionPlanOutput(extraOutput).kind,'approved');
 console.log('DETECTED exact-key guard deletion: existing extra-key assertion discriminates.');
 console.log('PASS: 7 standalone reversion probes matching regression assertions; not a full Vitest mutation score.');
 const inPlace = await import(inPlacePath);
 const sharedOutput = approval(['node', '-e', '', ' ']);
 const before = structuredClone(sharedOutput);
 const result = inPlace.validateExecutionPlanOutput(sharedOutput, structuredClone(sharedOutput.execution_plan_record.delivery_definition), sharedOutput.execution_plan_record.normalized_plan_digest);
 assert.deepEqual(result, {kind:'approved',output:sharedOutput});
 assert.notDeepEqual(result, {kind:'approved',output:before});
 console.log('SURVIVED: in-place argv corruption passes the current shared-reference equality; a pre-call snapshot detects it.');
} finally { console.error('Scratch retained:', scratch); }
