@surface.safeword-cli
Feature: Preserve proof command operands
  Rule: Native command operands are preserved exactly
    Scenario: Record the literal operand array
      Given the reviewed command has these literal operands
        """
        ["--test", "one", "--test", "two", "", " ", "C:\\tmp\\report.json", "\\d+\\|pipe"]
        """
      And expected-operands.json contains the same JSON array
      When a contributor records the proof through the packaged CLI
      Then the native child compares process.argv.slice(1) to that file and exits 0
    Scenario: A mismatching operand cannot produce passed evidence
      Given the reviewed command has the same literal operand array
      And expected-operands.json instead replaces the first operand with "different"
      When a contributor records the proof through the packaged CLI
      Then the native child exits 1 because the received operands do not match the expected JSON array
  Rule: Successful native proof is retained for the contributor
    Scenario: Inspect the retained result
      Given the native child passed after comparing the literal operands
      When the contributor reads the Delivery Checklist through the packaged CLI and inspects the retained signed receipt
      Then the receipt outcome is passed, its stdout SHA-256 equals the digest of JSON.stringify of the literal array, and the checklist item is proven
    Scenario: A failed child cannot complete the item
      Given the native child exited 1 for the mismatching expected JSON array
      When the contributor inspects the recorded result through the packaged CLI
      Then the retained receipt outcome is failed and the checklist item remains unproven
  Rule: Contributor proof never grants merge authority
    Scenario: Passed evidence leaves merge permission pending
      Given every applicable contributor item has passed native proof
      When the contributor reads the Delivery Checklist through the packaged CLI
      Then merge_authorization remains pending and the CLI grants no merge authority
