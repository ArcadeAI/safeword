# Execution Plan

## Pull-request slicing

Decision: one pull request
Rationale: The native argv boundary and its retained receipt form one local verification outcome; splitting the probe would leave neither part independently proving operand preservation.

## Slices

### Native argument transport

- Purpose: Verify ordered operand preservation through the existing packaged CLI and native child.
- Boundary: Existing local command-proof execution, retained receipt and read-only checklist projection.
- Prerequisites: none
- Proof: transport
- Completion signal: The native child exits 0 after checking every expected operand, the receipt retains its stdout digest, applicable checklist items are proven and merge authorization remains pending.
- Relies on unmerged successor: false

#### Tasks and tests

1. Create `expected-operands.json` at the project root with this exact JSON:

```json
["--test", "one", "--test", "two", "", " ", "C:\\tmp\\report.json", "\\d+\\|pipe"]
```

2. Failure control: replace only element 0 with `"different"`, then invoke `safeword ticket record-delivery-proof MAN001 item-4 transport --json`. Expect exit 2, retained receipt outcome failed and child exit 1. Invoke `safeword ticket delivery-checklist MAN001 --json` and assert item-4 is unproven. The signed receipt is retained in `.project/skill-invocations.log`; inspect its proof-result fields directly (there is no public receipt-read CLI).
3. Restore expected-operands.json to the exact literal above, commit the fixture revision, then invoke each exact command: `safeword ticket record-delivery-proof MAN001 item-4 transport --json`, `safeword ticket record-delivery-proof MAN001 item-1 transport --json`, and `safeword ticket record-delivery-proof MAN001 item-11 transport --json`. Expect each exit 0 and outcome passed.
4. Invoke `safeword ticket delivery-checklist MAN001 --json`. Assert all applicable contributor items are proven at the current revision, item-4 supersedes its failed proof, and merge_authorization remains pending. Read the retained signed receipt directly and compare stdout bytes and SHA-256 with independently computed UTF-8 JSON.stringify of the literal array above, using node:crypto createHash('sha256'). No production edits or refactor are needed for this disposable verification contribution.

## Obligation ownership

- Preserve native argv, honest passed/failed proof and pending merge permission: Native argument transport

## Decision accounting

- Use the existing packaged CLI and native command-proof runner without production edits.: unchanged
- Compare process.argv.slice(1) against expected-operands.json in the native Node child.: unchanged
- Retain normal signed proof receipts and never infer merge authority from them.: unchanged

## Proof specifications

| Proof ID | Method | Scope | Boundary exercised | Qualifies as | Currency | Invocation |
| --- | --- | --- | --- | --- | --- | --- |
| transport | command | integration | packaged CLI to native child argv and retained receipt | real_boundary | current_required | {"type": "command", "cwd": ".", "argv": ["/Users/alex/.local/share/mise/installs/node/24.18.1/bin/node", "-e", "const actual=process.argv.slice(1);const expected=JSON.parse(require('node:fs').readFileSync('expected-operands.json','utf8'));if(JSON.stringify(actual)!==JSON.stringify(expected))process.exit(1);process.stdout.write(JSON.stringify(actual));", "--", "--test", "one", "--test", "two", "", " ", "C:\\tmp\\report.json", "\\d+\\\|pipe"]} |

## Delivery checklist

<!-- safeword:delivery-checklist:v1 -->

| ID | Category | Obligation | Owner | Required proof | Disposition | Evidence class | Revision | Evidence, reason, or dependency |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| item-1 | outcome and scope | Verify native argument preservation and retain the result. | contributor | transport | complete | current_revision_real_boundary | dd065423483ee47020a01e94eecafc9c82aa1e9b | receipt:0fb7c8e6-a1ab-442f-9f9b-073cdd3a1e9a |
| item-2 | resolved decisions | No change to resolved decisions in this local probe. | contributor | | not_applicable | missing | | This probe only executes an existing local CLI command; it changes no resolved decisions behavior or contract. |
| item-3 | dependency and pull-request decomposition | No change to dependency and pull-request decomposition in this local probe. | contributor | | not_applicable | missing | | This probe only executes an existing local CLI command; it changes no dependency and pull-request decomposition behavior or contract. |
| item-4 | testing | Verify native argument preservation and retain the result. | contributor | transport | complete | current_revision_real_boundary | dd065423483ee47020a01e94eecafc9c82aa1e9b | receipt:d88a42cf-b160-45a3-8f6f-cbd15e7924b4 |
| item-5 | data and compatibility | No change to data and compatibility in this local probe. | contributor | | not_applicable | missing | | This probe only executes an existing local CLI command; it changes no data and compatibility behavior or contract. |
| item-6 | monitoring and failure signals | No change to monitoring and failure signals in this local probe. | contributor | | not_applicable | missing | | This probe only executes an existing local CLI command; it changes no monitoring and failure signals behavior or contract. |
| item-7 | security and privacy | No change to security and privacy in this local probe. | contributor | | not_applicable | missing | | This probe only executes an existing local CLI command; it changes no security and privacy behavior or contract. |
| item-8 | rollout and rollback | No change to rollout and rollback in this local probe. | contributor | | not_applicable | missing | | This probe only executes an existing local CLI command; it changes no rollout and rollback behavior or contract. |
| item-9 | documentation | No change to documentation in this local probe. | contributor | | not_applicable | missing | | This probe only executes an existing local CLI command; it changes no documentation behavior or contract. |
| item-10 | ownership and human dependencies | No change to ownership and human dependencies in this local probe. | contributor | | not_applicable | missing | | This probe only executes an existing local CLI command; it changes no ownership and human dependencies behavior or contract. |
| item-11 | completion evidence | Verify native argument preservation and retain the result. | contributor | transport | complete | current_revision_real_boundary | dd065423483ee47020a01e94eecafc9c82aa1e9b | receipt:c890ade1-bfe6-4711-97fe-169eae60d546 |
