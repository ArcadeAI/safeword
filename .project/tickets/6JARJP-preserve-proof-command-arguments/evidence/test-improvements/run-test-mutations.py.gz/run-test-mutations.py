import json, os, pathlib, shutil, subprocess, tempfile
root=pathlib.Path('/Users/alex/.codex/worktrees/a7c8/safeword')
clone=pathlib.Path(tempfile.mkdtemp(prefix='6jarjp-vitest-mutations-',dir='/tmp'))
archive=subprocess.run(['git','archive','HEAD'],cwd=root,check=True,stdout=subprocess.PIPE).stdout
subprocess.run(['tar','-xf','-','-C',str(clone)],input=archive,check=True)
for suffix in ['node_modules','packages/cli/node_modules']:
 os.symlink(root/suffix,clone/suffix,target_is_directory=True)
output='packages/cli/src/review/execution-plan-output.ts'
checklist='packages/cli/src/execution-plan/delivery-checklist.ts'
test='packages/cli/tests/review/execution-plan-output.test.ts'
parser_test='packages/cli/tests/execution-plan/delivery-checklist.test.ts'
for name in [output,checklist,test,parser_test]: shutil.copy2(root/name,clone/name)
original={name:(clone/name).read_text() for name in [output,checklist,test,parser_test]}
results=[]
def run(name,files,selector,expected):
 log=pathlib.Path('/tmp')/('6jarjp-mutation-'+name+'.log')
 env=os.environ.copy();env['SAFEWORD_TEST_LOCK_MAX_WAIT_MS']='1800000'
 with log.open('w') as stream:
  result=subprocess.run([str(root/'scripts/dev'),'bun','run','--cwd','packages/cli','test',*files,'-t',selector],cwd=clone,env=env,stdout=stream,stderr=subprocess.STDOUT)
 text=log.read_text()
 observed=result.returncode
 if observed!=expected or ('Test Files' not in text):
  raise RuntimeError(f'{name}: expected {expected}, got {observed}; inspect {log}')
 results.append({'name':name,'expected_exit':expected,'exit_code':observed,'log':str(log)})
 pathlib.Path('/tmp/6jarjp-vitest-mutations.json').write_text(json.dumps({'scratch':str(clone),'results':results},indent=2)+'\n')
 print(name,observed,flush=True)
return_line="return { kind: 'approved', output: { ...output, execution_plan_record: validatedCandidate } };"
mutant=original[output].replace(return_line,"(validatedCandidate.delivery_definition.proof_specifications[0].invocation as {argv:string[]}).argv.push('unexpected operand');\n  "+return_line)
assert mutant!=original[output]
(clone/output).write_text(mutant)
weak=subprocess.check_output(['git','show','HEAD:'+test],cwd=root,text=True)
(clone/test).write_text(weak)
run('weak-snapshot-control',[test],'without changing the trusted definition',0)
(clone/test).write_text(original[test])
run('strong-snapshot-kills-corruption',[test],'without changing the trusted definition|from Markdown',1)
(clone/output).write_text(original[output])
bridge=original[checklist].replace('invocation: specification.invocation,',"invocation: specification.invocation.type === 'command' ? {...specification.invocation, argv: specification.invocation.argv.slice(1)} : specification.invocation,")
assert bridge!=original[checklist]
(clone/checklist).write_text(bridge)
run('round-trip-kills-bridge-corruption',[test],'from Markdown',1)
(clone/checklist).write_text(original[checklist])
(clone/output).write_text(original[output].replace("if (!hasExactKeys(value, ['type', 'cwd', 'argv']))",'if (false)'))
run('exact-key-deletion',[test],'rejects extra invocation key',1)
(clone/output).write_text(original[output].replace('!commandArguments(value.argv)','!uniqueNonblankStrings(value.argv, false)'))
run('ordered-argv-reversion',[test],'without changing the trusted definition',1)
(clone/output).write_text(original[output])
old_split=original[checklist].replace("cell += character === '|' ? character : `\\\\${character}`;",'cell += character;')
assert old_split!=original[checklist]
(clone/checklist).write_text(old_split)
run('json-backslash-reversion',[parser_test],'JSON backslashes|escaped pipe and backslash',1)
(clone/checklist).write_text(original[checklist])
run('restored-green',[test,parser_test],'from Markdown|without changing the trusted definition|JSON backslashes|escaped pipe and backslash',0)
print('All deliberate-fault checks completed; production worktree was never mutated.',flush=True)
