import assert from 'node:assert/strict';
import { spawnSync } from 'node:child_process';
import { createHmac } from 'node:crypto';
import { readFileSync, realpathSync, rmSync, writeFileSync } from 'node:fs';
import nodePath from 'node:path';

import { featureFixture, installReviewer } from './6A8ZHX-probe-fixtures.ts';
import { cleanupTrustedReviewerDirectories } from '/Users/alex/.codex/worktrees/e24e/safeword/packages/cli/tests/review-fixtures.ts';

const runtime = '/Users/alex/.codex/worktrees/e24e/safeword/packages/cli/dist/cli.js';
const root = featureFixture();
const folder = '.project/tickets/ABC123-feature';
const target = `${folder}/impl-plan.md`;
const bin = installReviewer();
const environment = {
  ...process.env,
  PATH: `${bin}:/usr/bin:/bin`,
  NODE_ENV: 'test',
  SAFEWORD_AGENT_RUNTIME: 'codex',
  SAFEWORD_REVIEW_KEY_ROOT: nodePath.join(root, '.review-keys'),
};
function invoke(args: string[]) {
  const result = spawnSync(process.execPath, [runtime, ...args, '--json', '--cwd', root], {
    cwd: root, env: environment, encoding: 'utf8', timeout: 30_000,
  });
  assert.equal(result.error, undefined);
  return { exit: result.status, output: JSON.parse(result.stdout) };
}
try {
  writeFileSync(nodePath.join(root, target), readFileSync(nodePath.join(root, folder, 'execution-plan.md')));
  const reviewed = invoke(['review', 'run', 'plan-implementation', target,
    '--context', 'features/feature.feature', '--context', `${folder}/spec.md`, '--no-input']);
  assert.equal(reviewed.exit, 0);
  const id = reviewed.output.data.review_id;
  const path = nodePath.join(root, '.safeword/state/reviews', `${id}.json`);
  const record = JSON.parse(readFileSync(path, 'utf8'));
  delete record.result.data.reviewer_output.verdict;
  const { integrity: _integrity, ...unsigned } = record;
  const key = Buffer.from(readFileSync(nodePath.join(root, '.review-keys/safeword/review-integrity.key'), 'utf8').trim(), 'hex');
  const integrity = createHmac('sha256', key).update(realpathSync.native(root)).update('\0')
    .update(JSON.stringify(unsigned)).digest('hex');
  writeFileSync(path, JSON.stringify({ ...unsigned, integrity }));
  writeFileSync(nodePath.join(root, target), `${readFileSync(nodePath.join(root, target), 'utf8')}\nChanged after review.\n`);
  const strict = invoke(['review', 'status', id]);
  assert.equal(strict.exit, 1);
  assert.equal(strict.output.errors[0].code, 'REVIEW_JOB_INVALID');
  writeFileSync(nodePath.join(root, '.project/skill-invocations.log'),
    `2026-10-21T00:00:00.000Z fixture review:ABC123-feature:phase@plan-execution author:codex reviewer:claude independence:reduced review-id:${id}\n`);
  const prerequisite = invoke(['ticket', 'execution-prerequisite', 'ABC123']);
  const findings = prerequisite.output.findings.map((finding: { code: string }) => finding.code);
  console.log(JSON.stringify({ boundary: 'built CLI in isolated test-key mode', strict_status: strict.exit,
    strict_error: strict.output.errors[0].code, prerequisite_exit: prerequisite.exit,
    grants_authority: prerequisite.output.data.grants_authority, findings }));
  assert.equal(prerequisite.exit, 2);
  assert.equal(prerequisite.output.data.grants_authority, false);
  assert.equal(findings.some((code: string) => code.startsWith('mismatched_execution_plan_review_')), false,
    'An unvalidated malformed stale receipt must not supply mismatch diagnosis');
} finally {
  cleanupTrustedReviewerDirectories();
  rmSync(root, { recursive: true, force: true });
}
